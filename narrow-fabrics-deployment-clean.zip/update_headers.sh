#!/bin/bash

# Find all lines with CardHeader that still have color gradients other than the slate one
grep -n "CardHeader.*from-.*-50.*dark:from-slate-800" client/src/pages/settings/narrow-fabrics-settings.tsx | grep -v "from-slate-50 to-slate-100" | cut -d ":" -f 1 > header_lines.txt

# Process each line and create a sed command to replace it
while read line; do
  # Create the sed command to replace the line
  sed -i "${line}s/CardHeader className=\"flex flex-col sm:flex-row items-start sm:items-center sm:justify-between gap-2 sm:gap-4 rounded-t-none sm:rounded-t-lg bg-gradient-to-r from-[^\"]*-50[^\"]*dark:from-slate-800 dark:to-slate-700 p-3 sm:p-5\"/CardHeader className=\"flex flex-col sm:flex-row items-start sm:items-center sm:justify-between gap-2 sm:gap-4 rounded-t-none sm:rounded-t-lg bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 p-3 sm:p-5 border-b border-slate-200 dark:border-slate-700\"/" client/src/pages/settings/narrow-fabrics-settings.tsx
done < header_lines.txt

# Clean up
rm header_lines.txt

echo "All CardHeader components updated successfully"
