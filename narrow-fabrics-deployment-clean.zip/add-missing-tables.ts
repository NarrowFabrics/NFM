import pg from 'pg';
const { Pool } = pg;

async function main() {
  console.log('Adding missing tables to the database...');
  
  try {
    // Use the pg Pool for direct queries
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    
    // Create missing tables
    await pool.query(`
      CREATE TABLE IF NOT EXISTS "fabric_parts" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "production_unit_settings" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "description" TEXT,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "fabric_yarn_types" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "yarn_counts" (
        "id" SERIAL PRIMARY KEY,
        "count" VARCHAR(50) NOT NULL UNIQUE,
        "description" TEXT,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "yarn_prices" (
        "id" SERIAL PRIMARY KEY,
        "yarn_type_id" INTEGER REFERENCES "fabric_yarn_types"("id"),
        "price_per_kg" DECIMAL(10,2) NOT NULL,
        "effective_date" TIMESTAMP DEFAULT NOW(),
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "profit_margins" (
        "id" SERIAL PRIMARY KEY,
        "category" VARCHAR(100) NOT NULL,
        "margin_percentage" DECIMAL(5,2) NOT NULL,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
    `);
    
    console.log('Missing tables added successfully');
    
    // Close the pool
    await pool.end();
  } catch (e) {
    console.error('Error adding missing tables:', e);
  }
}

main().catch(console.error);