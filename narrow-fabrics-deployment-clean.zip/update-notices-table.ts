// Use direct database connection for this script
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

// Function to get the database URL from environment variables
async function getDatabaseUrl() {
  // Prioritize Neon cloud database if specified
  if (process.env.USE_NEON_DB === 'true' && process.env.NEON_DATABASE_URL) {
    console.log('Using Neon cloud database for connection');
    return process.env.NEON_DATABASE_URL;
  }
  
  // Fallback to regular DATABASE_URL
  if (process.env.DATABASE_URL) {
    console.log('Using standard DATABASE_URL for connection');
    return process.env.DATABASE_URL;
  }
  
  console.error('No database URL found in environment variables');
  throw new Error('Database URL not found');
}

async function updateNoticesTable() {
  let client;
  
  try {
    const dbUrl = await getDatabaseUrl();
    client = new pg.Client({
      connectionString: dbUrl,
    });
    
    await client.connect();
    console.log('Connected to database successfully');
    
    console.log('Updating notices table...');
    
    // Add missing columns to the notices table
    await client.query(`
      ALTER TABLE notices 
      ADD COLUMN IF NOT EXISTS is_published BOOLEAN DEFAULT true,
      ADD COLUMN IF NOT EXISTS start_date TIMESTAMP DEFAULT NOW(),
      ADD COLUMN IF NOT EXISTS end_date TIMESTAMP;
    `);
    
    console.log('Notices table updated successfully');
    return true;
  } catch (error) {
    console.error('Error updating notices table:', error);
    throw error;
  } finally {
    if (client) {
      await client.end();
      console.log('Database connection closed');
    }
  }
}

async function main() {
  try {
    await updateNoticesTable();
    console.log('All table updates completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error in migration:', error);
    process.exit(1);
  }
}

main();