// Use direct database connection for this script
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

// Function to get the database URL from environment variables
async function getDatabaseUrl() {
  // Prioritize Neon cloud database if specified
  if (process.env.USE_NEON_DB === 'true' && process.env.NEON_DATABASE_URL) {
    console.log('Using Neon cloud database for connection');
    return process.env.NEON_DATABASE_URL;
  }
  
  // Fallback to regular DATABASE_URL
  if (process.env.DATABASE_URL) {
    console.log('Using standard DATABASE_URL for connection');
    return process.env.DATABASE_URL;
  }
  
  console.error('No database URL found in environment variables');
  throw new Error('Database URL not found');
}

async function createNoticesTable() {
  let client;
  
  try {
    const dbUrl = await getDatabaseUrl();
    client = new pg.Client({
      connectionString: dbUrl,
    });
    
    await client.connect();
    console.log('Connected to database successfully');
    
    console.log('Creating notices table if it does not exist...');
    
    const result = await client.query(`
      CREATE TABLE IF NOT EXISTS notices (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        expires_at TIMESTAMP,
        priority VARCHAR(20) DEFAULT 'normal',
        is_active BOOLEAN DEFAULT true
      );
    `);
    
    console.log('Notices table created successfully');
    return true;
  } catch (error) {
    console.error('Error creating notices table:', error);
    throw error;
  } finally {
    if (client) {
      await client.end();
      console.log('Database connection closed');
    }
  }
}

async function main() {
  try {
    await createNoticesTable();
    console.log('All tables created successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error in migration:', error);
    process.exit(1);
  }
}

main();