# Firebase ডিপ্লয়মেন্ট গাইড

এই গাইডটি আপনাকে আপনার Narrow Fabrics Management System অ্যাপ্লিকেশনকে Firebase হোস্টিংয়ে ডিপ্লয় করার বিস্তারিত প্রক্রিয়া ব্যাখ্যা করবে। এটি একটি ফ্রি অপশন যা আপনার অ্যাপ্লিকেশন ডিপ্লয় করার জন্য উপযুক্ত।

## প্রাথমিক প্রয়োজনীয়তা

1. Firebase ব্যবহার করার জন্য একটি Google অ্যাকাউন্ট প্রয়োজন
2. [Firebase Console](https://console.firebase.google.com/) এ একটি Firebase প্রজেক্ট তৈরি করতে হবে
3. আপনার সিস্টেমে Node.js এবং npm ইনস্টল করা থাকতে হবে

## ম্যানুয়াল ডিপ্লয়মেন্ট স্টেপস

### 1. Firebase প্রজেক্ট তৈরি করুন

1. [Firebase Console](https://console.firebase.google.com/) এ যান
2. "Add project" (প্রজেক্ট যোগ করুন) এ ক্লিক করুন
3. আপনার প্রজেক্টের নাম দিন (যেমন "narrow-fabrics-management")
4. Google Analytics সেটআপ করুন (ঐচ্ছিক)
5. "Create project" (প্রজেক্ট তৈরি করুন) এ ক্লিক করুন
6. প্রজেক্ট তৈরি হলে, "Web" (</>)-এ ক্লিক করুন আপনার ওয়েব অ্যাপ্লিকেশন রেজিস্টার করতে
7. অ্যাপ নিকনেম দিন এবং "Register app" ক্লিক করুন
8. Firebase SDK কনফিগারেশন নোট করে রাখুন:

```javascript
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-project-id.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "your-messaging-sender-id",
  appId: "your-app-id"
};
```

### 2. আপনার কোড ডাউনলোড করুন

1. Replit থেকে আপনার প্রজেক্ট কোড ডাউনলোড করুন (ZIP ফাইল হিসেবে)
2. আপনার লোকাল কম্পিউটারে একটি ফোল্ডারে উন্মোচন করুন
3. টার্মিনাল খুলুন এবং আপনার প্রজেক্ট ডিরেক্টরিতে নেভিগেট করুন

### 3. Firebase CLI ইনস্টল করুন

```bash
npm install -g firebase-tools
```

### 4. Firebase-এ লগইন করুন

```bash
firebase login
```

এটি একটি ব্রাউজার উইন্ডো খুলবে যেখানে আপনি আপনার Google অ্যাকাউন্টে লগইন করতে পারবেন।

### 5. আপনার পরিবেশ চর ঠিক করুন

আপনার প্রজেক্ট রুট ডিরেক্টরিতে `.env.local` ফাইল তৈরি করুন এবং আপনার Firebase কনফিগারেশন যোগ করুন:

```
VITE_FIREBASE_API_KEY=your-api-key
VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your-messaging-sender-id
VITE_FIREBASE_APP_ID=your-app-id
```

### 6. Firebase ইনিশিয়ালাইজ করুন

```bash
firebase init
```

এই প্রক্রিয়া চলাকালীন:
- "Hosting: Configure files for Firebase Hosting..." বেছে নিন
- "Use an existing project" বেছে নিন এবং আপনার প্রজেক্ট নির্বাচন করুন
- পাবলিক ডিরেক্টরি হিসেবে "dist" টাইপ করুন
- "Configure as a single-page app" প্রশ্নের জন্য "Yes" উত্তর দিন
- "Set up automatic builds and deploys with GitHub" প্রশ্নের জন্য "No" উত্তর দিন

### 7. অ্যাপ বিল্ড করুন

```bash
npm install      # ডিপেন্ডেন্সি ইনস্টল করুন
npm run build    # প্রোডাকশন বিল্ড তৈরি করুন
```

### 8. Firebase-এ ডিপ্লয় করুন

```bash
firebase deploy
```

সাফল্যের সাথে ডিপ্লয় হওয়ার পর, আপনার অ্যাপ্লিকেশনটি এখানে অ্যাক্সেসযোগ্য হবে:
```
https://your-project-id.web.app
```

## অতিরিক্ত কনফিগারেশন: ব্যাকএন্ড সার্ভিস

যেহেতু Firebase হোস্টিং শুধুমাত্র ফ্রন্টএন্ড হোস্ট করতে পারে, আপনার ব্যাকএন্ড সার্ভার হোস্ট করার জন্য কয়েকটি অপশন আছে:

### 1. Firebase Functions ব্যবহার করুন
Firebase Functions দিয়ে আপনার API এন্ডপয়েন্ট হোস্ট করতে পারেন।

```bash
firebase init functions
```

### 2. অন্যান্য হোস্টিং সার্ভিস ব্যবহার করুন
আপনার ব্যাকএন্ড সার্ভারের জন্য এই সেবাগুলি ব্যবহার করতে পারেন:

- Render (ফ্রি টায়ার আছে)
- Railway (সীমিত ফ্রি টায়ার)
- Fly.io (সীমিত ফ্রি টায়ার)
- Heroku (পেইড প্ল্যান)

## ডাটাবেস সেটআপ

আপনি ইতিমধ্যে Neon PostgreSQL ক্লাউড ডাটাবেস ব্যবহার করছেন, যা ইন্টারনেট থেকে অ্যাক্সেসযোগ্য। আপনাকে শুধু নিশ্চিত করতে হবে যে আপনার ডিপ্লয়ড অ্যাপে সঠিক ডাটাবেস কানেকশন স্ট্রিং সেট করা আছে।

## সমস্যা সমাধান

যদি ডিপ্লয়মেন্টের সময় সমস্যা হয়, এখানে কিছু সাধারণ সমাধান দেওয়া হল:

### 1. Firebase লগইন সমস্যা
আপনি যদি লগইন করতে না পারেন:
```bash
firebase logout
firebase login
```

### 2. বিল্ড ফেইল হলে
- `npm install` আবার চালান
- এরর মেসেজ চেক করুন
- প্যাকেজ ডিপেন্ডেন্সি আপডেট করুন

### 3. টাইপস্ক্রিপ্ট কম্পাইলেশন এরর
- `npm run check` চালান
- টাইপ এরর ঠিক করুন

### 4. CORS সমস্যা
ডিপ্লয়ড ফ্রন্টএন্ড ব্যাকএন্ডের সাথে কমিউনিকেট করতে না পারলে, ব্যাকএন্ড সার্ভারে CORS হেডার যোগ করুন।

## অতিরিক্ত রিসোর্স

- [Firebase হোস্টিং ডকুমেন্টেশন](https://firebase.google.com/docs/hosting)
- [Firebase কনসোল](https://console.firebase.google.com/)
- [Firebase CLI ডকুমেন্টেশন](https://firebase.google.com/docs/cli)
- [Vite প্রোডাকশন বিল্ড গাইড](https://vitejs.dev/guide/build.html)