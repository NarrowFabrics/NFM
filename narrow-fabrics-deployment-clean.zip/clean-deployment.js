/**
 * Clean Deployment Package Creator
 * 
 * This script creates a clean deployment package by:
 * 1. Identifying essential project files
 * 2. Copying only those files to a temporary directory
 * 3. Creating a zip file from the clean directory
 * 
 * Usage: node clean-deployment.js
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

// Configuration - add or remove files and directories as needed
const ESSENTIAL_DIRECTORIES = [
  'client',
  'server',
  'shared',
  'scripts'
];

const ESSENTIAL_FILES = [
  '.env.example',
  'drizzle.config.ts',
  'package.json',
  'package-lock.json',
  'render.yaml',
  'build.sh',
  'start.sh',
  'tailwind.config.ts',
  'tsconfig.json',
  'vite.config.ts',
  'RENDER_DEPLOYMENT.md',
  'theme.json'
];

const EXCLUDE_PATTERNS = [
  '.git',
  'node_modules',
  '.replit',
  '.upm',
  '.cache',
  '.config',
  'backups',
  'attached_assets',
  'tmp',
  'temp',
  'dist',
  '.DS_Store',
  '*.log',
  '*.zip'
];

// Main execution
function main() {
  console.log('=== Starting Clean Deployment Package Creation ===');
  
  try {
    // 1. Create the essential files list
    console.log('Identifying essential project files...');
    const essentialFiles = getEssentialFiles();
    
    // 2. Create a clean zip file
    console.log('Creating clean deployment package...');
    createCleanZip(essentialFiles);
    
    console.log('=== Clean Deployment Package Created Successfully ===');
    console.log('Package: narrow-fabrics-deployment-clean.zip');
  } catch (err) {
    console.error('Error creating clean deployment package:', err);
    process.exit(1);
  }
}

// Get all essential files recursively
function getEssentialFiles() {
  let files = [];
  
  // Add individual essential files
  ESSENTIAL_FILES.forEach(file => {
    if (fs.existsSync(file)) {
      files.push(file);
    }
  });
  
  // Add essential directories recursively
  ESSENTIAL_DIRECTORIES.forEach(dir => {
    if (fs.existsSync(dir)) {
      const dirFiles = getFilesRecursively(dir);
      files = files.concat(dirFiles);
    }
  });
  
  return files.filter(file => !isExcluded(file));
}

// Get files recursively from a directory
function getFilesRecursively(dir) {
  let files = [];
  
  const items = fs.readdirSync(dir, { withFileTypes: true });
  
  for (const item of items) {
    const fullPath = path.join(dir, item.name);
    
    if (item.isDirectory()) {
      const subDirFiles = getFilesRecursively(fullPath);
      files = files.concat(subDirFiles);
    } else {
      files.push(fullPath);
    }
  }
  
  return files;
}

// Check if a file should be excluded
function isExcluded(filePath) {
  return EXCLUDE_PATTERNS.some(pattern => {
    if (pattern.includes('*')) {
      // Handle wildcard patterns
      const regex = new RegExp(pattern.replace('*', '.*'));
      return regex.test(filePath);
    } else {
      // Handle exact directory/file matches
      return filePath.includes(pattern);
    }
  });
}

// Create a zip file with only essential files
function createCleanZip(files) {
  // Create file list for zip command
  const fileList = files.join(' ');
  
  try {
    // Use zip command to create the package
    execSync(`zip -r narrow-fabrics-deployment-clean.zip ${fileList}`);
  } catch (err) {
    console.error('Failed to create zip file:', err);
    throw err;
  }
}

// Run the script
main();