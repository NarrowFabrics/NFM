import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { usePermissions } from "@/hooks/use-permissions";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  LayoutDashboard,
  Factory,
  ShoppingCart,
  Layers,
  Palette,
  Package,
  Box,
  Settings,
  Users,
  FileText,
  Cog
} from "lucide-react";

export default function Sidebar({ location }) {
  const { hasPermission } = usePermissions();

  const navigation = [
    { name: 'Dashboard', href: '/' },
    { name: 'Production Plans', href: '/production-plans' },
    { name: 'Orders', href: '/orders' },
    { name: 'Yarn Types', href: '/yarn-types' },
    { name: 'Color Types', href: '/color-types' },
    { name: 'Materials', href: '/materials' },
    { name: 'Product Items', href: '/product-items' },
    { name: 'Item Settings', href: '/unit-settings' },
    { name: 'Settings', href: '/settings' },
  ];

  const adminNavigation = [
    { name: 'Users', href: '/users' },
    { name: 'Audit Logs', href: '/audit-logs' },
  ];

  return (
    <div className="h-full w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200 bg-primary/5">
        <h2 className="text-lg font-semibold text-primary">Narrow Fabrics</h2>
        <p className="text-sm text-gray-600">Management System</p>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4">
          <nav className="space-y-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                  location === item.href
                    ? 'bg-primary/10 text-primary'
                    : 'text-gray-700 hover:bg-gray-100 hover:text-primary'
                )}
              >
                {item.icon && <item.icon className="w-5 h-5" />}
                {item.name}
              </Link>
            ))}

            {hasPermission('admin') && (
              <div className="pt-2 mt-2 border-t border-gray-200">
                {adminNavigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      'flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                      location === item.href
                        ? 'bg-primary/10 text-primary'
                        : 'text-gray-700 hover:bg-gray-100 hover:text-primary'
                    )}
                  >
                    {item.icon && <item.icon className="w-5 h-5" />}
                    {item.name}
                  </Link>
                ))}
              </div>
            )}
          </nav>
        </div>
      </ScrollArea>
    </div>
  );
}