// Force restart the server
const { exec } = require('child_process');

// Kill any node processes that might be using port 5000
exec('pkill -f node || true', (error, stdout, stderr) => {
  console.log('Attempted to kill existing Node processes');
  
  // Give it a moment to free up resources
  setTimeout(() => {
    console.log('Starting application...');
    require('./server/index.ts');
  }, 2000);
});