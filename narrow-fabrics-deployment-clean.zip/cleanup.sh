#!/bin/bash

# Narrow Fabrics Management Project Cleanup Script
# This script removes unnecessary files before deployment

echo "===== Starting project cleanup ====="

# Remove all attachments except crucial ones
echo "Cleaning attached_assets directory..."
find attached_assets -type f -not -name "important_file.png" -delete

# Remove backup files
echo "Removing backup files..."
rm -rf backups/
find . -name "*.bak" -delete
find . -name "*.backup" -delete

# Remove test files
echo "Removing test files..."
rm -f test-*.js
rm -f test-*.ts

# Remove temporary files
echo "Removing temporary files..."
find . -name "*.tmp" -delete
find . -name ".DS_Store" -delete

# Remove ZIP files (except the deployment zip)
echo "Removing ZIP files..."
find . -name "*.zip" -not -name "narrow-fabrics-deployment.zip" -delete

# Remove Git related files if needed
echo "Removing Git related files..."
rm -rf .git/

# Remove Node.js cache
echo "Removing Node.js cache..."
rm -rf .cache/
rm -rf .npm/

# Remove Replit specific directories
echo "Removing Replit specific directories..."
rm -rf .replit/
rm -rf .upm/
rm -rf .local/

# Clean node_modules (uncommment if you want to)
# echo "Removing node_modules..."
# rm -rf node_modules/

# Remove existing ZIP file to create a fresh one
rm -f narrow-fabrics-deployment.zip

echo "===== Project cleanup complete ====="

# Create a clean deployment package
echo "===== Creating deployment package ====="
zip -r narrow-fabrics-deployment-clean.zip . -x "node_modules/*" ".git/*" "attached_assets/*"
echo "===== Deployment package created: narrow-fabrics-deployment-clean.zip ====="