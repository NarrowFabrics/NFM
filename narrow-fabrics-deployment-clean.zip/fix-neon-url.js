import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';
import fs from 'fs';

// Configure path for dotenv
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
dotenv.config({ path: resolve(__dirname, '.env') });

// Function to validate and fix the Neon Database URL
async function fixNeonUrl() {
  console.log('Checking NEON_DATABASE_URL format...');
  
  const neonUrl = process.env.NEON_DATABASE_URL;
  
  if (!neonUrl) {
    console.error('NEON_DATABASE_URL is not set in the environment variables');
    return;
  }
  
  // Check if the URL is binary or hex encoded
  const isBinaryOrHex = /\\x[0-9a-fA-F]{2}/.test(neonUrl);
  
  if (isBinaryOrHex) {
    console.error('The NEON_DATABASE_URL appears to be binary or hex encoded');
    console.log('Please provide a proper PostgreSQL connection string in the format:');
    console.log('postgresql://username:password@hostname/database');
    return;
  }
  
  // Check if the URL starts with postgresql://
  if (!neonUrl.startsWith('postgresql://')) {
    console.error('The NEON_DATABASE_URL does not start with postgresql://');
    console.log('Please provide a proper PostgreSQL connection string in the format:');
    console.log('postgresql://username:password@hostname/database');
    return;
  }
  
  // Parse the URL to check its components
  try {
    const url = new URL(neonUrl);
    console.log('URL parsed successfully:');
    console.log(`Protocol: ${url.protocol}`);
    console.log(`Hostname: ${url.hostname}`);
    console.log(`Port: ${url.port || 'default'}`);
    console.log(`Username: ${url.username ? '(set)' : '(not set)'}`);
    console.log(`Password: ${url.password ? '(set)' : '(not set)'}`);
    console.log(`Pathname: ${url.pathname}`);
    console.log(`Search params: ${url.search}`);
    
    // Check for common issues
    if (url.hostname === 'base') {
      console.error('Hostname is "base" which is causing the ENOTFOUND error');
      console.log('This is likely not a valid hostname for Neon database');
    }
  } catch (error) {
    console.error('Error parsing the URL:', error.message);
    console.log('Please provide a proper PostgreSQL connection string in the format:');
    console.log('postgresql://username:password@hostname/database');
  }
}

fixNeonUrl().catch(console.error);