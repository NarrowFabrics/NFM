// Deployment helper script
import 'dotenv/config';
import * as readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Ask questions and get user input
function askQuestion(query) {
  return new Promise((resolve) => {
    rl.question(query, (answer) => {
      resolve(answer);
    });
  });
}

async function main() {
  console.log('===== Narrow Fabrics Management System Deployment Helper =====');
  
  try {
    // Check if we have a Neon database URL
    const hasNeonDb = !!process.env.NEON_DATABASE_URL;
    
    if (!hasNeonDb) {
      console.log('\n⚠️ Warning: NEON_DATABASE_URL environment variable is not set.');
      console.log('You will not be able to deploy to production without a Neon database connection.');
      const proceed = await askQuestion('\nDo you want to continue with local development mode? (yes/no): ');
      if (proceed.toLowerCase() !== 'yes') {
        console.log('Operation canceled.');
        rl.close();
        return;
      }
    }
    
    // Deployment mode selection
    console.log('\nSelect deployment mode:');
    console.log('1. Local Development (uses local PostgreSQL database)');
    if (hasNeonDb) {
      console.log('2. Production Deployment (uses Neon PostgreSQL database)');
    }
    
    const mode = await askQuestion('\nEnter your choice (1 or 2): ');
    
    if (mode === '1') {
      console.log('\n✅ Selected: Local Development Mode');
      console.log('\nTo start the application in development mode:');
      console.log('1. Make sure your local PostgreSQL database is running');
      console.log('2. Run the command: npm run dev');
      console.log('\nYour application will use the local DATABASE_URL for database connections.');
    } else if (mode === '2' && hasNeonDb) {
      console.log('\n✅ Selected: Production Deployment Mode');
      console.log('\nTo start the application in production mode:');
      console.log('1. Make sure your Neon database schema is up to date (run setup-for-neon-db.js)');
      console.log('2. Run the command: USE_NEON_DB=true npm run dev');
      console.log('\nFor Replit deployment:');
      console.log('1. Add USE_NEON_DB=true to your environment variables');
      console.log('2. Deploy using the Replit deployment features');
      console.log('\nYour application will use the NEON_DATABASE_URL for database connections.');
    } else {
      console.log('\n❌ Invalid choice or option not available.');
    }
    
    console.log('\nThank you for using the deployment helper!');
    rl.close();
  } catch (error) {
    console.error('An error occurred:', error);
    rl.close();
  }
}

// Run the script
main();