// Script to prepare the Neon Database for deployment
import 'dotenv/config';
import { exec } from 'child_process';
import * as readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Ask questions and get user input
function askQuestion(query) {
  return new Promise((resolve) => {
    rl.question(query, (answer) => {
      resolve(answer);
    });
  });
}

async function main() {
  console.log('===== Neon Database Setup for Deployment =====');
  
  // Toggle the USE_NEON_DB flag
  process.env.USE_NEON_DB = 'true';
  
  try {
    console.log('\nVerifying Neon database connection...');
    if (!process.env.NEON_DATABASE_URL) {
      console.error('Error: NEON_DATABASE_URL environment variable is not set.');
      console.log('Please make sure you have set the NEON_DATABASE_URL environment variable with your Neon database connection string.');
      return;
    }

    console.log('\nNeon database URL found in environment variables.');
    
    const proceed = await askQuestion('\nDo you want to apply the schema to the Neon database? (yes/no): ');
    if (proceed.toLowerCase() !== 'yes') {
      console.log('Operation canceled.');
      return;
    }

    console.log('\nApplying schema to Neon database...');
    console.log('Running: npm run db:push');
    
    // Execute the drizzle push command
    exec('USE_NEON_DB=true npm run db:push', (error, stdout, stderr) => {
      if (error) {
        console.error(`Error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.error(`Error: ${stderr}`);
        return;
      }
      
      console.log(stdout);
      console.log('\nSchema successfully applied to Neon database!');
      
      console.log('\nIf this is a fresh deployment, you might need to create an initial admin user.');
      const createUser = askQuestion('\nDo you want to create an initial admin user? (yes/no): ');
      
      if (createUser.toLowerCase() === 'yes') {
        // For security, we should implement a proper user creation flow here
        console.log('\nPlease use the test-register.js script to create your admin user.');
        console.log('Run: USE_NEON_DB=true node test-register.js');
      }
      
      console.log('\nSetup complete! Your Neon database is now ready for deployment.');
      console.log('To run the application with the Neon database, set USE_NEON_DB=true in your environment variables.');
      console.log('For deployment: USE_NEON_DB=true npm run dev');
      
      rl.close();
    });
  } catch (error) {
    console.error('An error occurred:', error);
    rl.close();
  }
}

// Run the script
main();