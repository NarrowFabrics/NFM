// Script to fix all database queries to use db.query properly
import fs from 'fs';

// Read storage.ts file
const filePath = 'server/storage.ts';
const backupPath = 'server/storage.ts.bak';

// Backup the file first
fs.copyFileSync(filePath, backupPath);
console.log(`✅ Backed up ${filePath} to ${backupPath}`);

let content = fs.readFileSync(filePath, 'utf8');

// Fix all query.query double prefixes first (these are mistakes from earlier replacements)
content = content.replace(/db\.query\.query\./g, 'db.query.');

// Create a list of matches with their line numbers for report
const dbRegex = /db\s*\.\s*(?!query)(\w+)\s*\(/g;
let match;
let matches = [];

while ((match = dbRegex.exec(content)) !== null) {
  const lineNumber = content.substring(0, match.index).split('\n').length;
  matches.push({
    method: match[1],
    line: lineNumber,
    fullMatch: match[0]
  });
}

// Replace all direct db method calls with db.query.method
console.log(`Found ${matches.length} db method calls to fix`);

if (matches.length > 0) {
  // Sort by line number in descending order to avoid offset issues when replacing
  matches.sort((a, b) => b.line - a.line);
  
  // Replace each match with the correct db.query. version
  for (const match of matches) {
    const re = new RegExp(match.fullMatch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    content = content.replace(re, `db.query.${match.method}(`);
    
    console.log(`  - Line ${match.line}: ${match.fullMatch} => db.query.${match.method}(`);
  }
  
  // Fix any 'db.method().methodChain()' patterns that might have been missed
  content = content.replace(/db\.\s*(?!query)(\w+)\s*\(\)/g, 'db.query.$1()');
  
  // Write the fixed content back to the file
  fs.writeFileSync(filePath, content);
  console.log(`✅ Fixed ${matches.length} db method calls in ${filePath}`);
} else {
  console.log(`✅ No direct db method calls found that need fixing.`);
}

// Fix let query/countQuery statement patterns 
const regexQueryVar = /let\s+(query|countQuery)\s*=\s*db\s*\.\s*(?!query)/g;
let queryVarMatches = [];
while ((match = regexQueryVar.exec(content)) !== null) {
  const lineNumber = content.substring(0, match.index).split('\n').length;
  queryVarMatches.push({
    varName: match[1],
    line: lineNumber,
    fullMatch: match[0]
  });
}

if (queryVarMatches.length > 0) {
  // Replace all query variable assignments
  for (const match of queryVarMatches) {
    const re = new RegExp(match.fullMatch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    content = content.replace(re, `let ${match.varName} = db.query.`);
    
    console.log(`  - Line ${match.line}: Fixed query variable assignment`);
  }
  
  // Write the fixed content back to the file
  fs.writeFileSync(filePath, content);
  console.log(`✅ Fixed ${queryVarMatches.length} query variable assignments in ${filePath}`);
} else {
  console.log(`✅ No query variable assignments found that need fixing.`);
}

// Count any remaining db. references that might need fixing
const remainingDbRefs = content.match(/db\.\s*(?!query)/g);
if (remainingDbRefs && remainingDbRefs.length > 0) {
  console.log(`⚠️ There are still ${remainingDbRefs.length} db references that might need attention.`);
  console.log(`Example references: ${remainingDbRefs.slice(0, 3).join(', ')}`);
} else {
  console.log(`✅ No remaining direct db references found. All fixed!`);
}