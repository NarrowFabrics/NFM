/**
 * Firebase Setup Script
 * 
 * This script prepares your project for Firebase deployment by:
 * 1. Creating dynamic .firebaserc file with your project ID
 * 2. Setting up your environment variables for Firebase deployment
 * 
 * Usage: node firebase-setup.js
 */

import fs from 'fs';
import { execSync } from 'child_process';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  red: '\x1b[31m'
};

console.log(`${colors.yellow}===================================${colors.reset}`);
console.log(`${colors.yellow}  FIREBASE SETUP                   ${colors.reset}`);
console.log(`${colors.yellow}===================================${colors.reset}`);

// Get Firebase project ID from environment variable
const projectId = process.env.FIREBASE_PROJECT_ID;

if (!projectId) {
  console.error(`${colors.red}[ERROR] FIREBASE_PROJECT_ID environment variable not set${colors.reset}`);
  console.error(`${colors.yellow}Please set FIREBASE_PROJECT_ID before continuing${colors.reset}`);
  process.exit(1);
}

try {
  // Update .firebaserc with actual project ID
  const firebaserc = {
    projects: {
      default: projectId
    }
  };
  
  fs.writeFileSync('.firebaserc', JSON.stringify(firebaserc, null, 2));
  console.log(`${colors.green}[SUCCESS] Updated .firebaserc with project ID: ${projectId}${colors.reset}`);
  
  // Create firebase.json file
  const firebaseJson = {
    hosting: {
      public: "dist/public",
      ignore: [
        "firebase.json",
        "**/.*",
        "**/node_modules/**"
      ],
      rewrites: [
        {
          source: "**",
          destination: "/index.html"
        }
      ]
    }
  };
  
  fs.writeFileSync('firebase.json', JSON.stringify(firebaseJson, null, 2));
  console.log(`${colors.green}[SUCCESS] Updated firebase.json configuration${colors.reset}`);
  
  // Create a .env.production file with Firebase configuration
  const dotenvFile = `FIREBASE_API_KEY=${process.env.FIREBASE_API_KEY || ''}
FIREBASE_AUTH_DOMAIN=${process.env.FIREBASE_AUTH_DOMAIN || ''}
FIREBASE_PROJECT_ID=${process.env.FIREBASE_PROJECT_ID || ''}
FIREBASE_STORAGE_BUCKET=${process.env.FIREBASE_STORAGE_BUCKET || ''}
FIREBASE_MESSAGING_SENDER_ID=${process.env.FIREBASE_MESSAGING_SENDER_ID || ''}
FIREBASE_APP_ID=${process.env.FIREBASE_APP_ID || ''}
USE_NEON_DB=${process.env.USE_NEON_DB || 'true'}
NEON_DATABASE_URL=${process.env.NEON_DATABASE_URL || ''}
DATABASE_URL=${process.env.DATABASE_URL || ''}
`;

  fs.writeFileSync('.env.production', dotenvFile);
  console.log(`${colors.green}[SUCCESS] Created .env.production with Firebase configuration${colors.reset}`);
  
  console.log(`${colors.yellow}===================================${colors.reset}`);
  console.log(`${colors.green}  FIREBASE SETUP COMPLETE!          ${colors.reset}`);
  console.log(`${colors.yellow}===================================${colors.reset}`);
  
  console.log(`${colors.blue}[NEXT STEPS]${colors.reset}`);
  console.log(`${colors.blue}1. Login to Firebase: node firebase-login.js${colors.reset}`);
  console.log(`${colors.blue}2. Deploy to Firebase: node firebase-deploy.js${colors.reset}`);
  
} catch (error) {
  console.error(`${colors.red}[ERROR] Setup failed:${colors.reset}`, error.message);
  process.exit(1);
}