/**
 * Setup System Tables Script
 * 
 * This script creates the necessary tables for system monitoring and notice management:
 * 1. system_metrics - for storing performance metrics
 * 2. Ensures notices table has the required columns for scheduling
 * 
 * Usage: node setup-system-tables.js
 */

import pg from 'pg';
const { Pool } = pg;
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables
dotenv.config();

// Get database connection URL
async function getDatabaseUrl() {
  // Use NEON_DATABASE_URL if available, otherwise fall back to DATABASE_URL
  return process.env.USE_NEON_DB === 'true' && process.env.NEON_DATABASE_URL 
    ? process.env.NEON_DATABASE_URL 
    : process.env.DATABASE_URL;
}

// Create the system_metrics table
async function createSystemMetricsTable(pool) {
  console.log('Creating system_metrics table if it does not exist...');
  
  try {
    // Create the table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS system_metrics (
        id SERIAL PRIMARY KEY,
        timestamp TIMESTAMP DEFAULT NOW(),
        cpu_usage NUMERIC(5,2) NOT NULL,
        memory_usage NUMERIC(5,2) NOT NULL,
        memory_total NUMERIC(10,2) NOT NULL,
        disk_usage NUMERIC(5,2) NOT NULL,
        disk_total NUMERIC(10,2) NOT NULL,
        active_users INTEGER NOT NULL,
        response_time NUMERIC(10,2) NOT NULL,
        db_connections INTEGER NOT NULL,
        db_queries_per_second NUMERIC(10,2) NOT NULL,
        api_requests_per_minute INTEGER NOT NULL,
        error_count INTEGER NOT NULL,
        metadata JSONB DEFAULT '{}'
      );
    `);
    
    // Add index on timestamp for efficient querying
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp ON system_metrics (timestamp);
    `);
    
    console.log('system_metrics table created/verified successfully');
    return true;
  } catch (error) {
    console.error('Error creating system_metrics table:', error);
    throw error;
  }
}

// Ensure the notices table has the necessary columns for scheduling
async function updateNoticesTable(pool) {
  console.log('Checking/updating notices table...');
  
  try {
    // First check if the table exists
    const tableCheck = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'notices'
      );
    `);

    // If the notices table doesn't exist yet, we don't need to update it
    if (!tableCheck.rows[0].exists) {
      console.log('Notices table does not exist yet. No update needed.');
      return false;
    }

    // Check which columns exist in the notices table
    const columnsToCheck = [
      'is_scheduled', 
      'start_date', 
      'start_time', 
      'end_date', 
      'end_time'
    ];
    
    for (const column of columnsToCheck) {
      const columnExistsResult = await pool.query(`
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name='notices' AND column_name=$1
      `, [column]);

      if (columnExistsResult.rows.length === 0) {
        console.log(`Adding ${column} column to notices table...`);
        
        let dataType = 'TEXT';
        if (column === 'is_scheduled') {
          dataType = 'BOOLEAN NOT NULL DEFAULT false';
        }
        
        await pool.query(`
          ALTER TABLE notices
          ADD COLUMN ${column} ${dataType}
        `);
        console.log(`Added ${column} column successfully`);
      } else {
        console.log(`${column} column already exists`);
      }
    }
    
    // Verify the notices table structure
    const tableInfo = await pool.query(`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name='notices'
      ORDER BY ordinal_position
    `);
    
    console.log('Current notices table structure:');
    tableInfo.rows.forEach(row => {
      console.log(`${row.column_name} (${row.data_type}) ${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'}`);
    });
    
    return true;
  } catch (error) {
    console.error('Error updating notices table:', error);
    throw error;
  }
}

// Main function
async function main() {
  let pool;
  
  try {
    const dbUrl = await getDatabaseUrl();
    if (!dbUrl) {
      throw new Error('Database URL not found in environment variables');
    }

    // Create a database connection
    pool = new Pool({
      connectionString: dbUrl,
      ssl: dbUrl?.includes("localhost") ? false : { rejectUnauthorized: false }
    });
    
    console.log('Connected to database.');
    
    // Create the system_metrics table
    await createSystemMetricsTable(pool);
    
    // Update the notices table to ensure it has scheduling columns
    await updateNoticesTable(pool);
    
    console.log('All tables created/updated successfully!');
  } catch (error) {
    console.error('Error setting up system tables:', error);
    process.exit(1);
  } finally {
    if (pool) {
      await pool.end();
      console.log('Database connection closed.');
    }
  }
}

// Run the main function
main();