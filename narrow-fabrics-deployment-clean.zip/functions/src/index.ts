import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import express, { Request, Response, NextFunction } from "express";
import session from "express-session";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import bcrypt from "bcrypt";
import * as schema from "./shared/schema";

admin.initializeApp();

// Create Express server
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Setup session middleware
app.use(
  session({
    secret: process.env.SESSION_SECRET || "default-secret-key-change-in-production",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    }
  })
);

// Database connection
let db: any;
const initDb = async () => {
  const databaseUrl = process.env.USE_NEON_DB === "true" 
    ? process.env.NEON_DATABASE_URL 
    : process.env.DATABASE_URL;
  
  if (!databaseUrl) {
    throw new Error("Database URL not provided in environment variables");
  }
  
  const sql = postgres(databaseUrl, { max: 10 });
  
  // Use the imported schema
  db = drizzle(sql, { schema });
  return db;
};

// Health check endpoint
app.get("/api/health-check", (_req, res) => {
  res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
});

// Authentication middleware
const authenticateUser = (req: any, res: Response, next: NextFunction) => {
  if (req.session && req.session.user) {
    return next();
  }
  return res.status(401).json({ error: "Unauthorized" });
};

// Add your routes here
// For example:
app.get("/api/user", authenticateUser, (req: any, res) => {
  res.status(200).json(req.session.user);
});

// Error handling middleware
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err.stack);
  res.status(500).json({ error: "Something went wrong" });
});

// Initialize the database when function starts
let dbInitialized = false;
const ensureDbInitialized = async () => {
  if (!dbInitialized) {
    await initDb();
    dbInitialized = true;
  }
};

// Export the Express API as a Firebase Function
export const api = functions.https.onRequest(async (request, response) => {
  try {
    await ensureDbInitialized();
    return app(request, response);
  } catch (error) {
    console.error("Failed to initialize database:", error);
    response.status(500).json({ error: "Server initialization failed" });
  }
});