import pg from 'pg';
const { Pool } = pg;

async function main() {
  console.log('Creating yarn_counts table with price fields...');
  
  try {
    // Use the pg Pool for direct queries
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    
    // Create yarn_counts table with all necessary fields
    await pool.query(`
      CREATE TABLE IF NOT EXISTS "yarn_counts" (
        "id" SERIAL PRIMARY KEY,
        "count" VARCHAR(50) NOT NULL UNIQUE,
        "description" TEXT,
        "price_bdt" DECIMAL(10,2),
        "price_usd" DECIMAL(10,2),
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
    `);
    
    console.log('Migration completed successfully');
    
    // Close the pool
    await pool.end();
  } catch (e) {
    console.error('Migration error:', e);
  }
}

main().catch(console.error);