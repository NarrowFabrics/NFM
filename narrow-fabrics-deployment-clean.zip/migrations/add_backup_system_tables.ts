import { drizzle } from "drizzle-orm/postgres-js";
import { migrate } from "drizzle-orm/postgres-js/migrator";
import postgres from "postgres";
import * as dotenv from "dotenv";

dotenv.config();

// Get the database connection string from the environment
const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.error("DATABASE_URL environment variable is not set");
  process.exit(1);
}

const runMigration = async () => {
  console.log("Starting migration...");
  
  // Create a postgres client
  const client = postgres(connectionString, { max: 1 });
  const db = drizzle(client);

  try {
    console.log("Creating new backup system tables...");
    
    // Create the backup system tables
    await client.unsafe(`
      -- Create backups table
      CREATE TABLE IF NOT EXISTS backups (
        id SERIAL PRIMARY KEY,
        filename TEXT NOT NULL,
        description TEXT,
        file_size INTEGER NOT NULL,
        backup_type TEXT NOT NULL,
        version TEXT NOT NULL,
        is_encrypted BOOLEAN DEFAULT FALSE,
        is_compressed BOOLEAN DEFAULT FALSE,
        tables_included TEXT[],
        storage_path TEXT NOT NULL,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        retention_period INTEGER,
        is_auto BOOLEAN DEFAULT FALSE
      );

      -- Create backup_schedules table
      CREATE TABLE IF NOT EXISTS backup_schedules (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        frequency TEXT NOT NULL,
        day_of_week INTEGER,
        day_of_month INTEGER,
        time_of_day VARCHAR(8) NOT NULL,
        backup_type TEXT NOT NULL,
        tables_to_include TEXT[],
        is_encrypted BOOLEAN DEFAULT FALSE,
        is_compressed BOOLEAN DEFAULT FALSE,
        retention_period INTEGER NOT NULL,
        is_active BOOLEAN DEFAULT TRUE,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        last_run TIMESTAMP,
        next_run TIMESTAMP
      );

      -- Create backup_notifications table
      CREATE TABLE IF NOT EXISTS backup_notifications (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        email_notification BOOLEAN DEFAULT FALSE,
        push_notification BOOLEAN DEFAULT FALSE,
        notify_on_success BOOLEAN DEFAULT TRUE,
        notify_on_failure BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW()
      );

      -- Create backup_versions table
      CREATE TABLE IF NOT EXISTS backup_versions (
        id SERIAL PRIMARY KEY,
        backup_id INTEGER REFERENCES backups(id),
        version_number INTEGER NOT NULL,
        changes_description TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);

    console.log("Backup system tables created successfully!");
  } catch (error) {
    console.error("Error running migration:", error);
    process.exit(1);
  } finally {
    await client.end();
  }
};

runMigration();