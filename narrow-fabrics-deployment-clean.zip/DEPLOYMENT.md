# Deployment Guide for Narrow Fabrics Management System

This guide will help you deploy the Narrow Fabrics Management System using the Neon PostgreSQL database for production.

## Prerequisites

1. A Neon account and database set up
2. Your Neon database connection string (NEON_DATABASE_URL)
3. Node.js and npm installed
4. Access to Replit for deployment

## Step 1: Set Up Environment Variables

Ensure you have the following environment variables set in your Replit project:

- `NEON_DATABASE_URL`: Your Neon database connection string
- `USE_NEON_DB`: Set to "true" for production deployment 

To set these variables in Replit:
1. Click on the "Secrets" tab (lock icon) in the left sidebar
2. Add a new secret named `NEON_DATABASE_URL` with your Neon connection string
3. Add a new secret named `USE_NEON_DB` with the value `true`

## Step 2: Prepare Your Neon Database

Before deployment, you need to apply your database schema to the Neon database:

1. Run the setup script:
   ```bash
   node setup-for-neon-db.js
   ```

2. When prompted, confirm that you want to apply the schema to the Neon database

3. The script will run the database migration to create all necessary tables

4. (Optional) Create an initial admin user when prompted

## Step 3: Test Local Deployment with Neon Database

Before deploying to production, it's a good idea to test your application locally with the Neon database:

```bash
USE_NEON_DB=true npm run dev
```

This will start your application using the Neon database instead of the local PostgreSQL database.

## Step 4: Deploy to Replit

1. Ensure all your changes are committed and pushed
2. Set the `USE_NEON_DB` environment variable to `true` in Replit Secrets
3. Use the Replit deployment feature to deploy your application

## Step 5: Verify Deployment

1. Access your deployed application via the provided URL
2. Log in and verify that your data is accessible
3. Test key functionality to ensure everything is working correctly

## Switching Between Development and Production

You can use the deployment helper script to switch between local development and production deployment:

```bash
node deploy.js
```

## Troubleshooting

If you encounter any issues with the Neon database connection:

1. Verify that the `NEON_DATABASE_URL` is correctly formatted
2. Check that the `USE_NEON_DB` environment variable is set to `true`
3. Ensure your IP address has access to the Neon database
4. Check the Neon database logs for any connection issues

## Database Backups

It's recommended to set up regular backups of your Neon database to prevent data loss. The Neon platform provides built-in backup features that you can configure from your dashboard.

## Additional Resources

- [Neon Documentation](https://neon.tech/docs)
- [Replit Deployment Guide](https://docs.replit.com/hosting/deployments-overview)
- [Drizzle ORM Documentation](https://orm.drizzle.team/docs/overview)