/**
 * Firebase Deployment Script
 * 
 * This script automates the Firebase deployment process by:
 * 1. Building the application
 * 2. Initializing Firebase configuration
 * 3. Deploying to Firebase Hosting
 * 
 * Usage: node firebase-deploy.js
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  red: '\x1b[31m'
};

/**
 * Execute a command and log the output
 * @param {string} command - The command to execute
 * @param {string} message - The message to display
 */
function executeCommand(command, message) {
  console.log(`${colors.blue}${message}...${colors.reset}`);
  try {
    execSync(command, { stdio: 'inherit' });
    console.log(`${colors.green}✓ ${message} completed.${colors.reset}`);
    return true;
  } catch (error) {
    console.error(`${colors.red}× ${message} failed: ${error.message}${colors.reset}`);
    return false;
  }
}

/**
 * Main deployment function
 */
async function deploy() {
  console.log(`${colors.yellow}===================================${colors.reset}`);
  console.log(`${colors.yellow}  FIREBASE DEPLOYMENT               ${colors.reset}`);
  console.log(`${colors.yellow}===================================${colors.reset}`);
  
  // Check if Firebase is logged in
  try {
    execSync('npx firebase projects:list', { stdio: 'pipe' });
  } catch (error) {
    console.error(`${colors.red}You are not logged in to Firebase.${colors.reset}`);
    console.log(`${colors.blue}Please run 'node firebase-login.js' first.${colors.reset}`);
    process.exit(1);
  }
  
  // First run firebase-setup.js to ensure .firebaserc is set up correctly
  console.log(`${colors.blue}Setting up Firebase configuration...${colors.reset}`);
  
  try {
    execSync('node firebase-setup.js', { stdio: 'inherit' });
  } catch (error) {
    console.error(`${colors.red}Failed to set up Firebase configuration: ${error.message}${colors.reset}`);
    process.exit(1);
  }
  
  // Create a directory for build artifacts if it doesn't exist
  const distDir = path.join(__dirname, 'dist');
  if (!fs.existsSync(distDir)) {
    fs.mkdirSync(distDir, { recursive: true });
  }
  
  // Create public directory inside dist
  const publicDir = path.join(distDir, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }
  
  // Generate environmental variables for Vite
  console.log(`${colors.blue}Creating .env.production file with environment variables...${colors.reset}`);
  
  // Add Vite-specific environment variables for the build
  const envFile = fs.readFileSync('.env.production', 'utf8');
  const viteEnvContent = envFile
    .split('\n')
    .map(line => {
      // Convert normal env vars to VITE_ prefixed vars
      if (line.startsWith('FIREBASE_')) {
        const [key, value] = line.split('=');
        return `VITE_${key}=${value}`;
      }
      return line;
    })
    .join('\n');
  
  fs.writeFileSync('.env.production', viteEnvContent);
  console.log(`${colors.green}✓ Environment variables prepared.${colors.reset}`);
  
  // Build the application for production
  if (!executeCommand('npm run build', 'Building application')) {
    console.error(`${colors.red}Build failed. Deployment aborted.${colors.reset}`);
    process.exit(1);
  }
  
  // Copy the build output to the Firebase hosting directory
  console.log(`${colors.blue}Preparing files for Firebase hosting...${colors.reset}`);
  
  // Deploy to Firebase
  if (!executeCommand('npx firebase deploy --only hosting', 'Deploying to Firebase')) {
    console.error(`${colors.red}Deployment failed.${colors.reset}`);
    process.exit(1);
  }
  
  console.log(`${colors.yellow}===================================${colors.reset}`);
  console.log(`${colors.green}  DEPLOYMENT COMPLETE!              ${colors.reset}`);
  console.log(`${colors.yellow}===================================${colors.reset}`);
  
  console.log(`${colors.green}Your application is now live at:${colors.reset}`);
  console.log(`${colors.yellow}https://${process.env.FIREBASE_PROJECT_ID}.web.app${colors.reset}`);
}

deploy().catch(error => {
  console.error(`${colors.red}Deployment failed with an error: ${error.message}${colors.reset}`);
  process.exit(1);
});