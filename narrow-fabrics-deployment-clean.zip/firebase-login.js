/**
 * Firebase Login Script
 * 
 * This script helps you log in to Firebase from the CLI
 * 
 * Usage: node firebase-login.js
 */

import { execSync } from 'child_process';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  red: '\x1b[31m'
};

console.log(`${colors.yellow}===================================${colors.reset}`);
console.log(`${colors.yellow}  FIREBASE LOGIN                   ${colors.reset}`);
console.log(`${colors.yellow}===================================${colors.reset}`);

try {
  console.log(`${colors.blue}Logging in to Firebase...${colors.reset}`);
  
  // Run the Firebase login command
  execSync('npx firebase login --no-localhost', { stdio: 'inherit' });
  
  console.log(`${colors.green}Successfully logged in to Firebase.${colors.reset}`);
  console.log(`${colors.blue}Next step: Run 'node firebase-setup.js' to configure your project.${colors.reset}`);
} catch (error) {
  console.error(`${colors.red}Error during Firebase login: ${error.message}${colors.reset}`);
  process.exit(1);
}