/**
 * Firebase Environment Setup Script
 * 
 * This script sets up the environment variables for Firebase deployment
 * It creates or updates the .env.production file with Firebase config
 * 
 * Usage: node firebase-setup-env.js
 */

import fs from 'fs';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  red: '\x1b[31m'
};

/**
 * Setup the production environment file with Firebase variables
 */
function setupEnvFile() {
  console.log(`${colors.blue}Setting up production environment variables...${colors.reset}`);
  
  const env = {};
  
  // Firebase Configuration
  env['FIREBASE_API_KEY'] = process.env.FIREBASE_API_KEY || '';
  env['FIREBASE_AUTH_DOMAIN'] = process.env.FIREBASE_AUTH_DOMAIN || '';
  env['FIREBASE_PROJECT_ID'] = process.env.FIREBASE_PROJECT_ID || '';
  env['FIREBASE_STORAGE_BUCKET'] = process.env.FIREBASE_STORAGE_BUCKET || '';
  env['FIREBASE_MESSAGING_SENDER_ID'] = process.env.FIREBASE_MESSAGING_SENDER_ID || '';
  env['FIREBASE_APP_ID'] = process.env.FIREBASE_APP_ID || '';
  
  // Database Configuration
  env['USE_NEON_DB'] = process.env.USE_NEON_DB || 'true';
  env['NEON_DATABASE_URL'] = process.env.NEON_DATABASE_URL || '';
  env['DATABASE_URL'] = process.env.DATABASE_URL || '';
  
  // Create the .env.production file content
  const envFileContent = Object.entries(env)
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');
  
  fs.writeFileSync('.env.production', envFileContent);
  console.log(`${colors.green}Production environment file (.env.production) created successfully.${colors.reset}`);
  
  // Also create a copy as .env.firebase for the build process
  fs.writeFileSync('.env.firebase', envFileContent);
  console.log(`${colors.green}Firebase environment file (.env.firebase) created successfully.${colors.reset}`);
}

/**
 * Check if Firebase environment variables are set
 */
function checkFirebaseEnv() {
  const requiredVars = [
    'FIREBASE_API_KEY',
    'FIREBASE_AUTH_DOMAIN',
    'FIREBASE_PROJECT_ID',
    'FIREBASE_STORAGE_BUCKET',
    'FIREBASE_MESSAGING_SENDER_ID',
    'FIREBASE_APP_ID'
  ];
  
  const missingVars = requiredVars.filter(varName => !process.env[varName]);
  
  if (missingVars.length > 0) {
    console.warn(`${colors.yellow}Warning: The following Firebase environment variables are missing:${colors.reset}`);
    missingVars.forEach(varName => {
      console.warn(`${colors.yellow}- ${varName}${colors.reset}`);
    });
    console.warn(`${colors.yellow}You may need to set these variables for a proper Firebase deployment.${colors.reset}`);
    return false;
  }
  
  return true;
}

/**
 * Main function
 */
async function main() {
  console.log(`${colors.yellow}===================================${colors.reset}`);
  console.log(`${colors.yellow}  FIREBASE ENVIRONMENT SETUP       ${colors.reset}`);
  console.log(`${colors.yellow}===================================${colors.reset}`);
  
  // Check if Firebase environment variables are set
  const envReady = checkFirebaseEnv();
  
  if (!envReady) {
    console.warn(`${colors.yellow}Continuing with available environment variables...${colors.reset}`);
  }
  
  // Setup the environment file
  setupEnvFile();
  
  console.log(`${colors.yellow}===================================${colors.reset}`);
  console.log(`${colors.green}  ENVIRONMENT SETUP COMPLETE!       ${colors.reset}`);
  console.log(`${colors.yellow}===================================${colors.reset}`);
}

main().catch(error => {
  console.error(`${colors.red}Environment setup failed with an error: ${error.message}${colors.reset}`);
  process.exit(1);
});