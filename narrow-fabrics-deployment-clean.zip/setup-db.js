import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { Client } from 'pg';
import * as schema from './shared/schema.js';

async function main() {
  console.log('Initializing database...');
  
  // Connect to the database
  const client = new Client({
    connectionString: process.env.DATABASE_URL
  });
  
  try {
    await client.connect();
    console.log('Connected to database');
    
    // Create the db instance with our schema
    const db = drizzle(client, { schema });
    
    // Push the schema to the database
    console.log('Pushing schema to database...');
    await migrate(db, { migrationsFolder: './drizzle' });
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
  } finally {
    await client.end();
  }
}

main();