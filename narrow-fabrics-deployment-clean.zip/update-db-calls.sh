#!/bin/bash
# Apply multiple operations on storage.ts to update all db method calls

# First backup the file
cp server/storage.ts server/storage.ts.bak

# Update all await db calls to await db.query
sed -i 's/await db\.\([^q]\)/await db.query.\1/g' server/storage.ts

# Update all db methods that don't have await prefix
sed -i 's/return db\./return db.query./g' server/storage.ts

# Replace any db. instances that may be left out
sed -i 's/let query = db\./let query = db.query./g' server/storage.ts
sed -i 's/let countQuery = db\./let countQuery = db.query./g' server/storage.ts

chmod +x update-db-calls.sh
./update-db-calls.sh

# Check how many direct db. calls still exist
grep -c "db\." server/storage.ts | grep -v "db\.query"
