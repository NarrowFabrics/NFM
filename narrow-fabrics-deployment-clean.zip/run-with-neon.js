// Script to run the application with Neon database
require('dotenv').config();

console.log('Setting up environment for Neon database usage...');

// Force USE_NEON_DB to true in the environment
process.env.USE_NEON_DB = 'true';

// Verify environment setup
console.log('Environment configuration:');
console.log('- USE_NEON_DB:', process.env.USE_NEON_DB);
console.log('- NEON_DATABASE_URL exists:', !!process.env.NEON_DATABASE_URL);

// Spawn the server process with the updated environment
const { spawn } = require('child_process');
const serverProcess = spawn('npm', ['run', 'dev'], {
  env: process.env,
  stdio: 'inherit'
});

serverProcess.on('error', (err) => {
  console.error('Failed to start server process:', err);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('Caught interrupt signal, shutting down...');
  serverProcess.kill('SIGINT');
});

process.on('SIGTERM', () => {
  console.log('Caught termination signal, shutting down...');
  serverProcess.kill('SIGTERM');
});