# Narrow Fabrics Management System

A comprehensive system for managing narrow fabrics manufacturing operations, including material tracking, production planning, and order management.

## Features

- Complete inventory and material management
- Production planning and tracking
- Order management system
- User management with role-based permissions
- Reporting and analytics
- Multilingual support
- Responsive design for all devices

## Tech Stack

- **Frontend**: React, TypeScript, TailwindCSS, Shadcn UI
- **Backend**: Node.js, Express
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js

## Deployment Options

### Option 1: Deploy on Render.com (No Credit Card Required)

1. Fork or clone this repository to your GitHub account
2. Sign up at [Render.com](https://render.com) using your GitHub account
3. Create a new Web Service and connect your GitHub repo
4. Use these settings:
   - **Environment**: Node
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
5. Add these environment variables:
   - `NODE_ENV`: production
   - `USE_NEON_DB`: true
   - `NEON_DATABASE_URL`: (your Neon PostgreSQL connection string)
6. Deploy!

### Option 2: Deploy on Google Cloud Run (Free Tier)

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed instructions on deploying to Google Cloud Run.

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start in production mode
npm start

# Push database schema changes
npm run db:push
```

## License

MIT