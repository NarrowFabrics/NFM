import pg from 'pg';
const { Pool } = pg;
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

async function getDatabaseUrl() {
  // Check if we're using Neon database
  if (process.env.USE_NEON_DB === 'true' && process.env.NEON_DATABASE_URL) {
    return process.env.NEON_DATABASE_URL;
  }
  // Otherwise use the standard DATABASE_URL
  return process.env.DATABASE_URL;
}

async function updateNoticesTable() {
  const databaseUrl = await getDatabaseUrl();
  
  if (!databaseUrl) {
    console.error('No database URL found. Please check your environment variables.');
    process.exit(1);
  }

  const pool = new Pool({
    connectionString: databaseUrl,
  });

  try {
    // First check if the table exists
    const tableCheck = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'notices'
      );
    `);

    if (!tableCheck.rows[0].exists) {
      console.log('Notices table does not exist yet. No update needed.');
      return;
    }

    // Check if columns already exist to avoid errors
    const columnsCheck = await pool.query(`
      SELECT 
        EXISTS(SELECT 1 FROM information_schema.columns WHERE table_name='notices' AND column_name='start_time') as has_start_time,
        EXISTS(SELECT 1 FROM information_schema.columns WHERE table_name='notices' AND column_name='end_time') as has_end_time;
    `);

    const {has_start_time, has_end_time} = columnsCheck.rows[0];

    // Begin transaction
    await pool.query('BEGIN');

    // Add start_time column if it doesn't exist
    if (!has_start_time) {
      console.log('Adding start_time column to notices table...');
      await pool.query(`
        ALTER TABLE notices 
        ADD COLUMN start_time TEXT;
      `);
      console.log('start_time column added.');
    } else {
      console.log('start_time column already exists.');
    }

    // Add end_time column if it doesn't exist
    if (!has_end_time) {
      console.log('Adding end_time column to notices table...');
      await pool.query(`
        ALTER TABLE notices 
        ADD COLUMN end_time TEXT;
      `);
      console.log('end_time column added.');
    } else {
      console.log('end_time column already exists.');
    }

    // Extract time portion from existing timestamps
    if (!has_start_time && !has_end_time) {
      console.log('Updating existing rows to populate time fields...');
      await pool.query(`
        UPDATE notices
        SET 
          start_time = to_char(start_date::timestamp, 'HH24:MI'),
          end_time = CASE WHEN end_date IS NOT NULL THEN to_char(end_date::timestamp, 'HH24:MI') ELSE NULL END;
      `);
      console.log('Existing records updated.');
    }

    // Commit transaction
    await pool.query('COMMIT');
    console.log('Notices table updated successfully.');

  } catch (error) {
    await pool.query('ROLLBACK');
    console.error('Error updating notices table:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

async function main() {
  try {
    await updateNoticesTable();
    console.log('Table update completed successfully.');
  } catch (error) {
    console.error('Failed to update notices table:', error);
    process.exit(1);
  }
}

main();