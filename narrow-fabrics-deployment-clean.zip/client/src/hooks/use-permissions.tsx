import { User } from "@shared/schema";

interface Permission {
  canView: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canCreate: boolean;
}

type ResourceType = 
  | "materials" 
  | "products" 
  | "yarn-types" 
  | "part-of-yarn" 
  | "color-types" 
  | "unit-settings" 
  | "items" 
  | "product-items"
  | "users"
  | "audit-logs";

export function usePermissions(user: User | null) {
  const getPermissions = (resource: ResourceType): Permission => {
    // If no user, no permissions
    if (!user) {
      return {
        canView: false,
        canEdit: false,
        canDelete: false,
        canCreate: false
      };
    }

    // Admin has all permissions
    if (user.is_admin) {
      return {
        canView: true,
        canEdit: true,
        canDelete: true,
        canCreate: true
      };
    }

    // Regular users have view-only access to materials and products
    const viewOnlyResources = [
      "materials",
      "products",
      "yarn-types",
      "part-of-yarn",
      "color-types"
    ];

    if (viewOnlyResources.includes(resource)) {
      return {
        canView: true,
        canEdit: false,
        canDelete: false,
        canCreate: false
      };
    }

    // No access to other resources for regular users
    return {
      canView: false,
      canEdit: false,
      canDelete: false,
      canCreate: false
    };
  };

  // Check if user has specific permission
  const hasPermission = (resource: ResourceType, action: keyof Permission): boolean => {
    const permissions = getPermissions(resource);
    return permissions[action];
  };

  return {
    getPermissions,
    hasPermission
  };
}

// Utility component for conditional rendering based on permissions
export function WithPermission({ 
  resource, 
  permission, 
  user,
  children 
}: { 
  resource: ResourceType;
  permission: keyof Permission;
  user: User | null;
  children: React.ReactNode;
}) {
  const { hasPermission } = usePermissions(user);

  if (!hasPermission(resource, permission)) {
    return null;
  }

  return <>{children}</>;
}