import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Bell, Settings, Menu, Search, User, LogOut, UserCog } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  onOpenSidebar: () => void;
  user?: {
    name: string;
    email: string;
    username: string;
    is_admin: boolean;
  };
}

export default function Header({ onOpenSidebar, user }: HeaderProps) {
  const [searchValue, setSearchValue] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement global search functionality here
    console.log("Search for:", searchValue);
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) {
        setIsSearchOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className="bg-white shadow-sm z-10">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Mobile menu button */}
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden"
          onClick={onOpenSidebar}
        >
          <Menu className="h-5 w-5" />
          <span className="sr-only">Open sidebar</span>
        </Button>

        {/* Search */}
        <div className={`flex-1 flex justify-center px-4 lg:px-0 lg:justify-end ${isSearchOpen ? 'block w-full' : 'hidden md:flex'}`}>
          <form onSubmit={handleSearchSubmit} className="w-full max-w-lg lg:max-w-xs relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">
              <Search className="h-4 w-4" />
            </span>
            <Input 
              type="text" 
              className="block w-full h-10 pl-10 pr-3 py-2 rounded-md text-sm bg-gray-50 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary" 
              placeholder="Search..." 
              value={searchValue}
              onChange={handleSearchChange}
            />
          </form>
        </div>

        {/* Right side buttons */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsSearchOpen(!isSearchOpen)}
          >
            <Search className="h-5 w-5" />
          </Button>
          
          {/* Notifications Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full text-gray-500 hover:bg-gray-100 relative"
              >
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full"></span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-80" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-medium">Notifications</h4>
                  <Link href="/settings/notices" className="text-xs text-primary">View all</Link>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-[300px] overflow-y-auto">
                {/* We'll display notifications here when available */}
                <div className="flex flex-col items-center justify-center p-4 text-center">
                  <Bell className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">You're all caught up!</p>
                  <p className="text-xs text-muted-foreground mt-1">No new notifications</p>
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Link href="/settings">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full text-gray-500 hover:bg-gray-100"
              title="Settings"
            >
              <Settings className="h-5 w-5" />
            </Button>
          </Link>
          
          {/* User Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8 border border-gray-200">
                  <AvatarImage src={user?.name ? `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=random` : undefined} alt={user?.name || "User"} />
                  <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{user?.name || "User"}</p>
                  <p className="text-xs leading-none text-muted-foreground">{user?.email || ""}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <Link href="/profile">
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
              </Link>
              <Link href="/settings/app-settings">
                <DropdownMenuItem>
                  <UserCog className="mr-2 h-4 w-4" />
                  <span>App Settings</span>
                </DropdownMenuItem>
              </Link>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => {
                fetch('/api/logout', { method: 'POST' })
                  .then(() => {
                    window.location.href = '/auth';
                  })
                  .catch(err => {
                    console.error('Logout failed:', err);
                  });
              }}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
