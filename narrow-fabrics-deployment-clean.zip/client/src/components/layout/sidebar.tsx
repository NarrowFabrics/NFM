import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Link } from "wouter";
import { User } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions } from "@/hooks/use-permissions";
import { ScrollArea as UIScrollArea } from "@/components/ui/scroll-area";
import {
  LayoutDashboard,
  Factory,
  ShoppingCart,
  ScrollText,
  Palette,
  Package,
  Tag,
  Sliders,
  Ruler,
  Users,
  LogOut,
  X,
  Layers,
  Settings,
  Scissors,
  Activity,
  ChevronDown,
  ChevronRight,
  BarChart4,
  FileText,
  Database,
  Save,
  Cog,
  Factory as FactoryIcon,
  Calculator,
  FileDown,
  Cpu
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
}

interface NavItemProps {
  path: string;
  label: string;
  icon: React.ReactNode;
  resource?: string;
  children?: React.ReactNode;
}

const ScrollArea = ({ children }: { children: React.ReactNode }) => {
  return (
    <UIScrollArea className="h-[calc(100vh-4rem)]">
      {children}
    </UIScrollArea>
  );
};

export default function Sidebar({ isOpen, onClose, user }: SidebarProps) {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const { hasPermission } = usePermissions(user);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [visualizationsOpen, setVisualizationsOpen] = useState(false);

  const userInitials = user?.name
    ? user.name
        .split(' ')
        .map(part => part[0])
        .join('')
        .toUpperCase()
        .slice(0, 2)
    : "U";

  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Check if the current location is a settings page to auto-expand settings
  const isSettingsPage = location.startsWith('/settings');
  const isVisualizationsPage = location.startsWith('/visualizations');
  
  // Use effect to auto-expand/collapse sections based on current location
  useEffect(() => {
    // Auto-expand settings when on settings pages
    setSettingsOpen(isSettingsPage);
    
    // Auto-expand visualizations when on visualization pages
    setVisualizationsOpen(isVisualizationsPage);
  }, [location, isSettingsPage, isVisualizationsPage]);

  const NavItem = ({ path, label, icon, resource, children }: NavItemProps) => {
    const isActive = location === path;

    if (resource && !hasPermission(resource as any, "canView")) {
      return null;
    }

    return (
      <div className={`${isActive ? "border-l-4 border-primary bg-blue-50 text-primary" : ""}`}>
        <Link 
          href={path}
          className={`flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100`}
        >
          <div className="w-5 mr-3 text-center">{icon}</div>
          <span>{label}</span>
        </Link>
        {children}
      </div>
    );
  };
  
  const ToggleItem = ({ label, icon, isOpen, onToggle, children }: { 
    label: string, 
    icon: React.ReactNode, 
    isOpen: boolean, 
    onToggle: () => void,
    children?: React.ReactNode 
  }) => {
    return (
      <div>
        <button
          onClick={onToggle}
          className="w-full flex items-center justify-between px-4 py-3 text-gray-700 hover:bg-gray-100"
        >
          <div className="flex items-center">
            <div className="w-5 mr-3 text-center">{icon}</div>
            <span>{label}</span>
          </div>
          <div>
            {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
          </div>
        </button>
        {isOpen && children && (
          <div className="pl-6 pb-2 bg-gray-50">{children}</div>
        )}
      </div>
    );
  };

  return (
    <aside
      className={`bg-white w-64 shadow-lg fixed inset-y-0 z-20 transform transition-transform duration-300 ease-in-out lg:transform-none lg:relative ${
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      }`}
    >
      <div className={`h-full transition-opacity duration-300 ${isOpen ? "opacity-100" : "opacity-0 lg:opacity-100"}`}>
        {/* Logo */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary flex items-center justify-center rounded-md">
              <Layers className="text-white" />
            </div>
            <span className="text-xl font-semibold text-gray-800">NarrowFabrics</span>
          </div>
          <button className="text-gray-500 lg:hidden" onClick={onClose}>
            <X />
          </button>
        </div>

        {/* Navigation items */}
        <div className="h-full flex-1 flex-col justify-between">
          <ScrollArea>
            <nav className="space-y-4">
              <div className="px-4 mb-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                Main
              </div>

              <NavItem path="/" label="Dashboard" icon={<LayoutDashboard size={18} />} />
              <NavItem path="/price-quotation" label="Price Quotation" icon={<Factory size={18} />} />
              <NavItem path="/orders" label="Orders" icon={<ShoppingCart size={18} />} />
              <NavItem path="/materials" label="Materials" icon={<Package size={18} />} />
              
              {/* Data Visualization dropdown */}
              <div className="space-y-1">
                <ToggleItem 
                  label="Data Visualization" 
                  icon={<BarChart4 size={18} />} 
                  isOpen={visualizationsOpen} 
                  onToggle={() => {
                    setVisualizationsOpen(!visualizationsOpen);
                    // If toggling to open and not already on a visualization page, navigate to main viz page
                    if (!visualizationsOpen && !location.startsWith('/visualizations')) {
                      window.location.href = '/visualizations';
                    }
                  }}
                >
                  <div className="space-y-1 pt-1">
                    <NavItem 
                      path="/visualizations" 
                      label="Dashboard" 
                      icon={<LayoutDashboard size={16} />} 
                    />
                    <NavItem 
                      path="/visualizations/data-tables" 
                      label="Data Tables" 
                      icon={<FileText size={16} />} 
                    />
                    <NavItem 
                      path="/visualizations/reports" 
                      label="Reports" 
                      icon={<Database size={16} />} 
                    />
                    <NavItem 
                      path="/visualizations/summary" 
                      label="Summary" 
                      icon={<Activity size={16} />} 
                    />
                    {hasPermission('admin') && (
                      <NavItem 
                        path="/performance-dashboard" 
                        label="System Performance" 
                        icon={<Cpu size={16} />} 
                      />
                    )}
                  </div>
                </ToggleItem>
              </div>
              
              {/* Settings navigation with dropdown */}
              <div className="space-y-1">
                <ToggleItem 
                  label="Settings" 
                  icon={<Settings size={18} />} 
                  isOpen={settingsOpen} 
                  onToggle={() => setSettingsOpen(!settingsOpen)}
                >
                  <div className="space-y-1 pt-1">
                    <NavItem 
                      path="/settings" 
                      label="Overview" 
                      icon={<BarChart4 size={16} />} 
                    />
                    <NavItem 
                      path="/settings/narrow-fabrics-settings" 
                      label="Narrow Fabrics" 
                      icon={<Settings size={16} />} 
                    />
                    <NavItem 
                      path="/settings/user-control" 
                      label="User Controls" 
                      icon={<Users size={16} />} 
                    />
                    <NavItem 
                      path="/settings/factory-data" 
                      label="Factory & Buyer" 
                      icon={<FactoryIcon size={16} />} 
                    />
                    <NavItem 
                      path="/settings/price-quotation-data" 
                      label="Price Quotation" 
                      icon={<Calculator size={16} />} 
                    />
                    <NavItem 
                      path="/settings/backup-restore-settings" 
                      label="Backup & Restore" 
                      icon={<Save size={16} />} 
                    />
                    <NavItem 
                      path="/settings/app-settings" 
                      label="App Settings" 
                      icon={<Cog size={16} />} 
                    />
                  </div>
                </ToggleItem>
              </div>
            </nav>
          </ScrollArea>

          {/* User info */}
          {user && (
            <div className="border-t border-gray-200 p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                  {userInitials}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-800">{user.name}</p>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
                <div className="ml-auto">
                  <button 
                    className="text-gray-500 hover:text-gray-700"
                    onClick={handleLogout}
                    disabled={logoutMutation.isPending}
                  >
                    <LogOut size={18} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}