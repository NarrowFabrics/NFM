import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";

interface SkeletonCardProps {
  hasHeader?: boolean;
  hasFooter?: boolean;
  headerAction?: boolean;
  contentLines?: number;
}

export function SkeletonCard({
  hasHeader = true,
  hasFooter = false,
  headerAction = false,
  contentLines = 3,
}: SkeletonCardProps) {
  return (
    <Card className="w-full">
      {hasHeader && (
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <Skeleton className="h-5 w-[120px]" />
          {headerAction && <Skeleton className="h-8 w-8 rounded-full" />}
        </CardHeader>
      )}
      <CardContent className="py-6">
        {contentLines > 0 && contentLines <= 5 && (
          <div className="space-y-4">
            {Array(contentLines).fill(null).map((_, i) => (
              <Skeleton 
                key={i} 
                className="h-5" 
                style={{ width: `${90 - (i * 10)}%` }} 
              />
            ))}
          </div>
        )}
      </CardContent>
      {hasFooter && (
        <CardFooter className="flex justify-between">
          <Skeleton className="h-10 w-[100px]" />
          <Skeleton className="h-10 w-[70px]" />
        </CardFooter>
      )}
    </Card>
  );
}

export function SkeletonDashboardCard() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <Skeleton className="h-4 w-[140px]" />
        <Skeleton className="h-4 w-4 rounded-full" />
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <Skeleton className="h-8 w-[140px]" />
          <Skeleton className="h-4 w-[180px]" />
        </div>
      </CardContent>
    </Card>
  );
}