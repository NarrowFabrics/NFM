import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  ChevronLeft, 
  ChevronRight, 
  ChevronsLeft,
  ChevronsRight,
  Search
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Column<T> {
  header: string;
  accessorKey: keyof T;
  cell?: (info: { row: T }) => React.ReactNode;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  pagination?: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    perPage: number;
    onPageChange: (page: number) => void;
    onPerPageChange?: (perPage: number) => void;
  };
  isLoading?: boolean;
  searchable?: boolean;
  onSearch?: (searchTerm: string) => void;
}

export function DataTable<T>({
  data,
  columns,
  pagination,
  isLoading,
  searchable,
  onSearch,
}: DataTableProps<T>) {
  const [searchTerm, setSearchTerm] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchTerm);
    }
  };

  return (
    <div className="space-y-4">
      {searchable && (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm mb-4">
          <form onSubmit={handleSearch} className="flex gap-2 w-full max-w-md">
            <div className="relative flex-grow">
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-10 rounded-md text-sm border-gray-300 dark:border-gray-700"
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400">
                <Search className="h-4 w-4" />
              </div>
            </div>
            <Button type="submit" variant="secondary" className="h-10">Search</Button>
          </form>
        </div>
      )}

      <div className="rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <Table className="w-full">
          <TableHeader>
            <TableRow className="bg-gray-50 dark:bg-gray-800">
              {columns.map((column, index) => (
                <TableHead 
                  key={index} 
                  className={`py-3 px-4 text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 ${
                    index === 0 ? "text-left" : 
                    index === columns.length - 1 ? "text-right" : 
                    "text-center"
                  }`}
                >
                  {column.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              // Skeleton rows for table loading state
              Array(pagination?.perPage || 5).fill(null).map((_, index) => (
                <TableRow key={`skeleton-${index}`} className="border-b border-gray-200 dark:border-gray-700">
                  {columns.map((_, colIndex) => (
                    <TableCell 
                      key={`skeleton-cell-${colIndex}`}
                      className={`py-3 px-4 ${
                        colIndex === 0 ? "text-left" : 
                        colIndex === columns.length - 1 ? "text-right" : 
                        "text-center"
                      }`}
                    >
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-[80%] animate-pulse"></div>
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : data.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center p-4 text-gray-500 dark:text-gray-400"
                >
                  No results found.
                </TableCell>
              </TableRow>
            ) : (
              data.map((row, rowIndex) => (
                <TableRow key={rowIndex} className="hover:bg-gray-50 dark:hover:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                  {columns.map((column, columnIndex) => (
                    <TableCell 
                      key={columnIndex}
                      className={`py-3 px-4 text-sm ${
                        columnIndex === 0 ? "text-left" : 
                        columnIndex === columns.length - 1 ? "text-right" : 
                        "text-center"
                      }`}
                    >
                      {column.cell
                        ? column.cell({ row })
                        : row[column.accessorKey] as React.ReactNode}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {pagination && (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm mt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          {isLoading ? (
            // Skeleton for pagination info and controls when loading
            <>
              <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-[200px] animate-pulse"></div>
              <div className="flex items-center gap-4">
                <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-[120px] animate-pulse"></div>
                <div className="flex items-center gap-2">
                  <div className="h-9 w-9 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                  <div className="h-9 w-9 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                  <div className="h-9 w-[100px] bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                  <div className="h-9 w-9 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                  <div className="h-9 w-9 bg-gray-200 dark:bg-gray-700 rounded animate-pulse hidden sm:block"></div>
                </div>
              </div>
            </>
          ) : (
            // Actual pagination when data is loaded
            <>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Showing <span className="font-medium">{pagination.currentPage === 1 ? 1 : (pagination.currentPage - 1) * pagination.perPage + 1}</span> to{" "}
                <span className="font-medium">{Math.min(pagination.currentPage * pagination.perPage, pagination.totalItems)}</span> of{" "}
                <span className="font-medium">{pagination.totalItems}</span> entries
              </div>
              <div className="flex flex-wrap items-center gap-4 sm:gap-6">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 whitespace-nowrap">Items per page</p>
                  <Select
                    value={pagination.perPage.toString()}
                    onValueChange={(value) => pagination.onPerPageChange?.(parseInt(value))}
                  >
                    <SelectTrigger className="h-9 w-[70px] rounded-md border-gray-300 dark:border-gray-700">
                      <SelectValue placeholder={pagination.perPage.toString()} />
                    </SelectTrigger>
                    <SelectContent side="top">
                      {[10, 20, 30, 40, 50].map((pageSize) => (
                        <SelectItem key={pageSize} value={pageSize.toString()}>
                          {pageSize}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    className="hidden h-9 w-9 p-0 rounded-md border-gray-300 dark:border-gray-700 sm:flex"
                    onClick={() => pagination.onPageChange(1)}
                    disabled={pagination.currentPage === 1}
                  >
                    <span className="sr-only">Go to first page</span>
                    <ChevronsLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    className="h-9 w-9 p-0 rounded-md border-gray-300 dark:border-gray-700"
                    onClick={() => pagination.onPageChange(pagination.currentPage - 1)}
                    disabled={pagination.currentPage === 1}
                  >
                    <span className="sr-only">Go to previous page</span>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <div className="flex w-[100px] items-center justify-center text-sm font-medium bg-gray-50 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md h-9 px-2">
                    Page {pagination.currentPage} of {pagination.totalPages}
                  </div>
                  <Button
                    variant="outline"
                    className="h-9 w-9 p-0 rounded-md border-gray-300 dark:border-gray-700"
                    onClick={() => pagination.onPageChange(pagination.currentPage + 1)}
                    disabled={pagination.currentPage === pagination.totalPages}
                  >
                    <span className="sr-only">Go to next page</span>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    className="hidden h-9 w-9 p-0 rounded-md border-gray-300 dark:border-gray-700 sm:flex"
                    onClick={() => pagination.onPageChange(pagination.totalPages)}
                    disabled={pagination.currentPage === pagination.totalPages}
                  >
                    <span className="sr-only">Go to last page</span>
                    <ChevronsRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
