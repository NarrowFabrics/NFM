import { Skeleton } from "@/components/ui/skeleton";

interface SkeletonTableProps {
  rows?: number;
  columns?: number;
  showHeader?: boolean;
}

export function SkeletonTable({
  rows = 5,
  columns = 4,
  showHeader = true,
}: SkeletonTableProps) {
  return (
    <div className="w-full overflow-hidden border rounded-md">
      {showHeader && (
        <div className="bg-muted/5 p-4 border-b">
          <div className="flex items-center justify-between">
            <Skeleton className="h-8 w-[250px]" />
            <Skeleton className="h-8 w-[180px]" />
          </div>
        </div>
      )}
      
      <div className="p-4">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              {Array(columns)
                .fill(null)
                .map((_, index) => (
                  <th key={index} className="pb-3">
                    <Skeleton className="h-5 w-full" />
                  </th>
                ))}
            </tr>
          </thead>
          <tbody>
            {Array(rows)
              .fill(null)
              .map((_, rowIndex) => (
                <tr key={rowIndex} className="border-b">
                  {Array(columns)
                    .fill(null)
                    .map((_, colIndex) => (
                      <td key={`${rowIndex}-${colIndex}`} className="py-3">
                        <Skeleton className="h-5 w-full" />
                      </td>
                    ))}
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      
      <div className="p-4 border-t">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-[100px]" />
          <Skeleton className="h-8 w-[120px]" />
        </div>
      </div>
    </div>
  );
}