import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { BellRing, X, AlertTriangle, InfoIcon, CheckCircle, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface Notice {
  id: number;
  title: string;
  content: string;
  priority: string;
  start_date: string;
  end_date?: string;
  is_published: boolean;
  is_scheduled: boolean;
  created_by: number;
  created_at: string;
  updated_at: string;
  department?: string;
  target_roles?: string[];
}

export default function NoticePanel() {
  const [dismissedNotices, setDismissedNotices] = useState<number[]>(() => {
    // Load dismissed notices from local storage
    try {
      if (typeof window !== 'undefined') {
        const savedDismissed = localStorage.getItem('dismissedNotices');
        return savedDismissed ? JSON.parse(savedDismissed) : [];
      }
    } catch (error) {
      console.error("Error accessing localStorage:", error);
    }
    return [];
  });

  const { data, isLoading, error } = useQuery<Notice[]>({
    queryKey: ['/api/notices/active'],
  });

  // Filter out dismissed notices
  const activeNotices = data?.filter(notice => !dismissedNotices.includes(notice.id)) || [];

  // Handle notice dismissal
  const dismissNotice = (id: number) => {
    const newDismissed = [...dismissedNotices, id];
    setDismissedNotices(newDismissed);
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem('dismissedNotices', JSON.stringify(newDismissed));
      }
    } catch (error) {
      console.error("Error saving to localStorage:", error);
    }
  };

  // Get priority icon and color
  const getPriorityAttributes = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return { 
          icon: <AlertTriangle className="h-5 w-5" />, 
          color: 'text-red-600 bg-red-50 border-red-200' 
        };
      case 'medium':
        return { 
          icon: <InfoIcon className="h-5 w-5" />, 
          color: 'text-amber-600 bg-amber-50 border-amber-200' 
        };
      case 'low':
      default:
        return { 
          icon: <CheckCircle className="h-5 w-5" />, 
          color: 'text-green-600 bg-green-50 border-green-200' 
        };
    }
  };

  // If there are no active notices after filtering, don't render anything
  if ((!data || data.length === 0 || activeNotices.length === 0) && !isLoading) {
    return null;
  }

  return (
    <div className="mb-6">
      {isLoading ? (
        <Card className="border-l-4 border-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Skeleton className="h-8 w-8 rounded-full" />
                <div>
                  <Skeleton className="h-4 w-48 mb-2" />
                  <Skeleton className="h-3 w-72" />
                </div>
              </div>
              <Skeleton className="h-8 w-8 rounded" />
            </div>
          </CardContent>
        </Card>
      ) : error ? (
        <Card className="border-l-4 border-red-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-6 w-6 text-red-500" />
                <div>
                  <h3 className="font-medium">Error loading notices</h3>
                  <p className="text-sm text-gray-600">Please try again later</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        activeNotices.map((notice) => {
          const priorityAttr = getPriorityAttributes(notice.priority);
          
          return (
            <Card 
              key={notice.id} 
              className="border-l-4 border-primary mb-3 shadow-sm transition-all hover:shadow"
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className={`p-1.5 rounded-full ${priorityAttr.color.split(' ')[1]}`}>
                      <BellRing className={`h-5 w-5 ${priorityAttr.color.split(' ')[0]}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{notice.title}</h3>
                        <Badge variant="outline" className={priorityAttr.color}>
                          {priorityAttr.icon}
                          <span className="ml-1">{notice.priority}</span>
                        </Badge>
                      </div>
                      <p className="mt-1 text-sm text-gray-600">{notice.content}</p>
                      <div className="mt-2 flex items-center text-xs text-gray-500 gap-2">
                        <span>Posted: {new Date(notice.created_at).toLocaleDateString()}</span>
                        {notice.end_date && (
                          <span>· Expires: {new Date(notice.end_date).toLocaleDateString()}</span>
                        )}
                        {notice.department && (
                          <Badge variant="outline" className="text-xs">
                            {notice.department}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-8 w-8 p-0 rounded-full"
                      onClick={() => dismissNotice(notice.id)}
                    >
                      <X className="h-4 w-4" />
                      <span className="sr-only">Dismiss</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })
      )}
    </div>
  );
}