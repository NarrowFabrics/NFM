import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useFormatting } from '@/contexts/FormatContext';

export default function FormatDemo() {
  const { formatDate, formatTime, formatDateTime } = useFormatting();
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  
  // Update the time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">Date & Time Format Preview</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="border rounded-md p-3">
            <div className="text-sm font-medium mb-1">Date Format:</div>
            <div className="text-lg">{formatDate(currentDateTime)}</div>
          </div>
          <div className="border rounded-md p-3">
            <div className="text-sm font-medium mb-1">Time Format:</div>
            <div className="text-lg">{formatTime(currentDateTime)}</div>
          </div>
        </div>
        <div className="border rounded-md p-3">
          <div className="text-sm font-medium mb-1">Date & Time Combined:</div>
          <div className="text-lg">{formatDateTime(currentDateTime)}</div>
        </div>
      </CardContent>
    </Card>
  );
}