import React from 'react';
import { Input } from '@/components/ui/input';
import { useFormatting } from '@/contexts/FormatContext';

interface TimeInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}

/**
 * TimeInput Component
 * 
 * A custom time input component that respects the user's time format preference.
 * HTML time inputs always use 24-hour format (HH:MM) regardless of display preferences.
 * This component provides an aria-label to help users understand the time format.
 */
export function TimeInput({
  value,
  onChange,
  placeholder = '',
  className = '',
  disabled = false
}: TimeInputProps) {
  const { timeFormat } = useFormatting();
  
  // Format the time for display in the aria-label
  const formatTimeForLabel = (time: string): string => {
    if (!time) return '';
    
    try {
      // Parse the time value (which should be in HH:MM format)
      const [hours, minutes] = time.split(':').map(Number);
      
      if (isNaN(hours) || isNaN(minutes)) {
        return time;
      }
      
      if (timeFormat === '12') {
        // Convert to 12-hour format for display
        const period = hours >= 12 ? 'PM' : 'AM';
        const displayHours = hours % 12 || 12; // Convert 0 to 12
        const displayMinutes = minutes.toString().padStart(2, '0');
        return `${displayHours}:${displayMinutes} ${period}`;
      } else {
        // Use 24-hour format
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      }
    } catch (e) {
      console.error('Error formatting time:', e);
      return time;
    }
  };
  
  // Handle input change
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
  };
  
  // Format the time for the aria-label
  const formattedTime = formatTimeForLabel(value);
  
  return (
    <Input
      type="time"
      value={value}
      onChange={handleChange}
      placeholder={placeholder}
      className={className}
      disabled={disabled}
      aria-label={`Time: ${formattedTime} (${timeFormat === '12' ? '12-hour format' : '24-hour format'})`}
    />
  );
}