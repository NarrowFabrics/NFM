import { Skeleton } from "@/components/ui/skeleton";

interface SkeletonChartProps {
  height?: number;
  showLegend?: boolean;
  chartType?: 'bar' | 'line' | 'pie' | 'area';
}

export function SkeletonChart({
  height = 300,
  showLegend = true,
  chartType = 'bar',
}: SkeletonChartProps) {
  return (
    <div className="w-full overflow-hidden border rounded-md p-4">
      {/* Chart Title and Controls */}
      <div className="flex items-center justify-between mb-4">
        <Skeleton className="h-8 w-[200px]" />
        {showLegend && (
          <div className="flex space-x-2">
            <Skeleton className="h-6 w-[60px]" />
            <Skeleton className="h-6 w-[70px]" />
            <Skeleton className="h-6 w-[80px]" />
          </div>
        )}
      </div>
      
      {/* Chart Area */}
      <div style={{ height: `${height}px` }} className="w-full relative">
        {chartType === 'bar' && <BarChartSkeleton />}
        {chartType === 'line' && <LineChartSkeleton />}
        {chartType === 'pie' && <PieChartSkeleton />}
        {chartType === 'area' && <AreaChartSkeleton />}
      </div>
      
      {/* X-Axis Labels */}
      {(chartType === 'bar' || chartType === 'line' || chartType === 'area') && (
        <div className="mt-6 flex justify-between">
          {Array(6).fill(null).map((_, i) => (
            <Skeleton key={i} className="h-4 w-[40px]" />
          ))}
        </div>
      )}
    </div>
  );
}

function BarChartSkeleton() {
  return (
    <div className="w-full h-full flex items-end justify-between">
      {Array(12).fill(null).map((_, i) => (
        <Skeleton 
          key={i} 
          className="w-[7%] mx-1" 
          style={{ 
            height: `${Math.floor(Math.random() * 60) + 20}%`,
          }} 
        />
      ))}
    </div>
  );
}

function LineChartSkeleton() {
  return (
    <div className="w-full h-full relative">
      <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path 
          d={`M0,${80 - Math.random() * 30} 
            ${Array(10).fill(null).map((_, i) => {
              const x = (i + 1) * 10;
              const y = 80 - Math.random() * 60;
              return `L${x},${y}`;
            }).join(' ')}` 
          }
          stroke="currentColor" 
          strokeWidth="2"
          fill="none"
          className="text-muted"
        />
      </svg>
      
      {/* Data points */}
      <div className="absolute inset-0">
        {Array(6).fill(null).map((_, i) => {
          const left = `${(i + 1) * 15}%`;
          const top = `${Math.floor(Math.random() * 70) + 10}%`;
          return (
            <div key={i} className="absolute" style={{ left, top }}>
              <Skeleton className="h-3 w-3 rounded-full" />
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PieChartSkeleton() {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <div className="relative w-3/4 h-3/4">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="10" className="text-muted/20" />
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="10" strokeDasharray="283" strokeDashoffset="100" className="text-muted" />
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="10" strokeDasharray="283" strokeDashoffset="200" className="text-muted/50" transform="rotate(120 50 50)" />
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="10" strokeDasharray="283" strokeDashoffset="240" className="text-muted/30" transform="rotate(220 50 50)" />
        </svg>
      </div>
    </div>
  );
}

function AreaChartSkeleton() {
  return (
    <div className="w-full h-full relative">
      <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path 
          d={`M0,${80 - Math.random() * 30} 
            ${Array(10).fill(null).map((_, i) => {
              const x = (i + 1) * 10;
              const y = 80 - Math.random() * 60;
              return `L${x},${y}`;
            }).join(' ')} 
            L100,100 L0,100 Z`
          }
          fill="currentColor" 
          className="text-muted/20"
        />
      </svg>
    </div>
  );
}