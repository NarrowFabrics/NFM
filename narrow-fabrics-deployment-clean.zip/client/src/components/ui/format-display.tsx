import { useFormatting } from "@/contexts/FormatContext";

export function getTimeFormatText(timeFormat: string): string {
  return timeFormat === '12' 
    ? '12-hour format (hh:mm AM/PM)' 
    : '24-hour format (HH:MM)';
}

export function TimeFormatDisplay() {
  const formatContext = useFormatting();
  const formatText = getTimeFormatText(formatContext.timeFormat);
  
  return (
    <span>Time in {formatText}</span>
  );
}