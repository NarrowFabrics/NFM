import React from 'react';
import { useFormatting } from '@/contexts/FormatContext';

interface TimeDisplayProps {
  time: string; // Time in HH:MM format
  className?: string;
}

/**
 * TimeDisplay Component
 * 
 * A component that displays a time value according to the user's time format preference.
 * - Displays time in 12-hour format (with AM/PM) when timeFormat is '12'
 * - Displays time in 24-hour format when timeFormat is '24'
 */
export function TimeDisplay({ time, className = '' }: TimeDisplayProps) {
  const { formatTime } = useFormatting();
  
  if (!time) return null;
  
  try {
    // Use the formatTime function from the FormatContext
    // First create a Date object for today with the specified time
    const [hours, minutes] = time.split(':').map(Number);
    
    if (isNaN(hours) || isNaN(minutes)) {
      return <span className={className}>{time}</span>;
    }
    
    const today = new Date();
    today.setHours(hours, minutes, 0, 0);
    
    return <span className={className}>{formatTime(today)}</span>;
  } catch (e) {
    console.error('Error formatting time for display:', e);
    return <span className={className}>{time}</span>;
  }
}