import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

export default function ServerConnectionChecker({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const { toast } = useToast();

  // Check server connection status on mount
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['/api/health-check'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/health-check', { 
          on401: 'returnNull', 
          headers: { 'Cache-Control': 'no-cache' } 
        });
        return response;
      } catch (error) {
        console.error('Server connection error:', error);
        return null;
      }
    },
    retry: 2,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (isError && retryCount < 3) {
      // If error, open dialog
      setIsOpen(true);
    } else if (!isError && isOpen) {
      // If connection restored, close dialog
      setIsOpen(false);
      toast({
        title: "কানেকশন স্থাপন হয়েছে",
        description: "সার্ভারের সাথে সফলভাবে সংযোগ স্থাপন করা হয়েছে।",
        variant: "default",
      });
    }
  }, [isError, isOpen, toast, retryCount]);

  const handleRetry = async () => {
    setRetryCount(prev => prev + 1);
    await refetch();
  };

  return (
    <>
      {children}
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>সার্ভার কানেকশন সমস্যা</DialogTitle>
            <DialogDescription>
              অ্যাপ্লিকেশন সার্ভারের সাথে সংযোগ স্থাপন করতে সমস্যা হচ্ছে। 
              ইন্টারনেট সংযোগ চেক করুন এবং আবার চেষ্টা করুন।
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end space-x-2 py-4">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              বন্ধ করুন
            </Button>
            <Button onClick={handleRetry} disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  অপেক্ষা করুন...
                </>
              ) : (
                "আবার চেষ্টা করুন"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}