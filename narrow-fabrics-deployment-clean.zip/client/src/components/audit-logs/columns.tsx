import { ColumnDef } from "@tanstack/react-table";
import { UserActivity } from "@shared/schema";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Avatar } from "@/components/ui/avatar";

type UserActivityWithName = UserActivity & {
  user_name?: string;
};

export const columns: ColumnDef<UserActivityWithName>[] = [
  {
    accessorKey: "timestamp",
    header: "Time",
    cell: ({ row }) => {
      const timestamp = row.getValue("timestamp");
      return timestamp ? format(new Date(timestamp as string), "PPpp") : "N/A";
    },
  },
  {
    accessorKey: "user_id",
    header: "User",
    cell: ({ row }) => {
      const user = row.original;
      return (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <div className="flex h-full w-full items-center justify-center bg-primary text-white">
              {user.user_name?.[0]?.toUpperCase() || "U"}
            </div>
          </Avatar>
          <span>{user.user_name || `User ${user.user_id}`}</span>
        </div>
      );
    },
  },
  {
    accessorKey: "action",
    header: "Action",
    cell: ({ row }) => {
      const action = row.getValue("action") as string;
      return (
        <Badge variant={getBadgeVariant(action)}>
          {formatAction(action)}
        </Badge>
      );
    },
  },
  {
    accessorKey: "details",
    header: "Details",
    cell: ({ row }) => {
      const details = row.getValue("details") as Record<string, unknown>;
      return (
        <div className="max-w-[500px] truncate text-sm text-muted-foreground">
          {formatDetails(details)}
        </div>
      );
    },
  },
];

function getBadgeVariant(action: string): "default" | "destructive" | "outline" | "secondary" {
  if (action.startsWith("create")) return "default";
  if (action.startsWith("update")) return "secondary";
  if (action.startsWith("delete")) return "destructive";
  return "outline";
}

function formatAction(action: string): string {
  return action
    .split("_")
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function formatDetails(details: Record<string, unknown>): string {
  try {
    if (!details || Object.keys(details).length === 0) return "No additional details";

    const formattedParts = Object.entries(details).map(([key, value]) => {
      const formattedKey = key.split("_").map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
      ).join(" ");

      if (typeof value === "object") {
        return `${formattedKey}: ${JSON.stringify(value)}`;
      }
      return `${formattedKey}: ${value}`;
    });

    return formattedParts.join(" | ");
  } catch (error) {
    return "Error displaying details";
  }
}