import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "./components/ui/toaster";
import NotFound from "./pages/not-found";
import AuthPage from "./pages/auth-page";
import DashboardPage from "./pages/dashboard-page";
import PriceQuotationPage from "./pages/Sidebar-Page/Price-quotation-page";
import OrdersPage from "./pages/orders-page";
import YarnTypesPage from "./pages/yarn-types-page";
import ColorTypesPage from "./pages/color-types-page";
import MaterialsPage from "./pages/Materials/Materials-page";
import ProductItemsPage from "./pages/product-items-page";
import ItemSettingsPage from "./pages/item-settings-page";
import UnitSettingsPage from "./pages/unit-settings-page";
import UsersPage from "./pages/users-page";
import AuditLogsPage from "./pages/audit-logs-page";
import ProfilePage from "./pages/profile-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";
import SettingsPage from './pages/settings/index';
import NarrowFabricsSettings from './pages/settings/narrow-fabrics-settings';
import UserControlSettings from './pages/settings/user-control-settings';
import FactoryDataSettings from './pages/settings/factory-data-settings';
import PriceQuotationSettings from './pages/settings/price-quotation-settings';
import BackupRestoreSettings from './pages/settings/backup-restore-settings';
import AppSettings from './pages/settings/app-settings';
import NoticeSettings from './pages/settings/notice-settings';
import ServerConnectionChecker from './components/server-connection-checker';
import { CurrencyProvider } from './contexts/CurrencyContext';
import { FormatProvider } from './contexts/FormatContext';

// Data Visualization Pages
import DataVisualizationPage from './pages/visualizations/index';
import DataTablesPage from './pages/visualizations/data-tables';
import ReportsPage from './pages/visualizations/reports';
import SummaryPage from './pages/visualizations/summary';
import PerformanceDashboard from './pages/performance-dashboard';

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/price-quotation" component={PriceQuotationPage} />
      <ProtectedRoute path="/orders" component={OrdersPage} />
      <ProtectedRoute path="/yarn-types" component={YarnTypesPage} />
      <ProtectedRoute path="/color-types" component={ColorTypesPage} />
      <ProtectedRoute path="/materials" component={MaterialsPage} />
      <ProtectedRoute path="/product-items" component={ProductItemsPage} />
      <ProtectedRoute path="/item-settings" component={ItemSettingsPage} />
      <ProtectedRoute path="/unit-settings" component={UnitSettingsPage} />
      <ProtectedRoute path="/users" component={UsersPage} adminOnly={true} />
      <ProtectedRoute path="/audit-logs" component={AuditLogsPage} adminOnly={true} />
      <ProtectedRoute path="/part-of-yarn" component={YarnTypesPage} />
      
      {/* Data Visualization Pages */}
      <ProtectedRoute path="/visualizations" component={DataVisualizationPage} />
      <ProtectedRoute path="/visualizations/data-tables/:tableType?" component={DataTablesPage} />
      <ProtectedRoute path="/visualizations/reports" component={ReportsPage} />
      <ProtectedRoute path="/visualizations/summary" component={SummaryPage} />
      <ProtectedRoute path="/performance-dashboard" component={PerformanceDashboard} adminOnly={true} />
      
      {/* Main Settings */}
      <ProtectedRoute path="/settings" component={SettingsPage} />
      
      {/* Settings Sub-pages */}
      <ProtectedRoute path="/settings/narrow-fabrics-settings" component={NarrowFabricsSettings} />
      <ProtectedRoute path="/settings/user-control" component={UserControlSettings} />
      <ProtectedRoute path="/settings/factory-data" component={FactoryDataSettings} />
      <ProtectedRoute path="/settings/price-quotation-data" component={PriceQuotationSettings} />
      <ProtectedRoute path="/settings/backup-restore-settings" component={BackupRestoreSettings} />
      <ProtectedRoute path="/settings/backup" component={BackupRestoreSettings} />
      <ProtectedRoute path="/settings/app-settings" component={AppSettings} />
      <ProtectedRoute path="/settings/notices" component={NoticeSettings} />
      
      {/* Backward compatibility routes */}
      <ProtectedRoute path="/narrow-fabrics-settings" component={NarrowFabricsSettings} />
      <ProtectedRoute path="/user-control" component={UserControlSettings} />
      <ProtectedRoute path="/factory-data" component={FactoryDataSettings} />
      <ProtectedRoute path="/price-quotation-data" component={PriceQuotationSettings} />
      <ProtectedRoute path="/backup-restore-settings" component={BackupRestoreSettings} />

      <ProtectedRoute path="/app-settings" component={AppSettings} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CurrencyProvider>
          <FormatProvider>
            <ServerConnectionChecker>
              <Router />
              <Toaster />
            </ServerConnectionChecker>
          </FormatProvider>
        </CurrencyProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;