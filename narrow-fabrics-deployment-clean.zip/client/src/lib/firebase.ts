// Firebase client configuration
// Important: These values are public and can be exposed in client-side code

export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "narrow-fabrics-management.firebaseapp.com",
  projectId: "narrow-fabrics-management",
  storageBucket: "narrow-fabrics-management.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Note: You'll need to replace these placeholders with your actual Firebase config
// values from the Firebase console after you create your project