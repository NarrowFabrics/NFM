import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';

// This is only needed for TypeScript type definitions
declare module 'jspdf' {
  interface jsPDF {
    autotable: typeof autoTable;
  }
}

/**
 * Generic data export utilities for different formats
 */

// Helper to create a filename with date
export const generateFilename = (prefix: string, extension: string): string => {
  const currentDate = format(new Date(), 'dd-MM-yy_mm-HH');
  return `${prefix}_${currentDate}.${extension}`;
};

// Export data to CSV
export const exportToCSV = <T extends object>(data: T[], filename: string) => {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Data");
  
  // Generate CSV file
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  saveAs(blob, filename);
};

// Export data to Excel
export const exportToExcel = <T extends object>(data: T[], filename: string) => {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Data");
  
  // Generate Excel file
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  saveAs(blob, filename);
};

// Export data to PDF
export const exportToPDF = <T extends Record<string, any>>(
  data: T[], 
  title: string, 
  filename: string, 
  columns?: { header: string; dataKey: string }[]
) => {
  try {
    console.log('Starting PDF export process');
    console.log('Data to export:', data ? 'Data exists' : 'No data', 
                'Length:', data?.length, 
                'Is array:', Array.isArray(data));
    
    // Make sure we have data to export
    if (!data || !Array.isArray(data) || data.length === 0) {
      console.warn('No data to export to PDF');
      return;
    }
    
    // Create a safe copy of the data
    const safeData = data.map(item => {
      const safeItem: Record<string, any> = {};
      
      // Only include primitive values or simple objects
      for (const key in item) {
        const value = item[key];
        
        // Skip undefined/null values
        if (value === undefined || value === null) {
          safeItem[key] = '';
          continue;
        }
        
        // Handle different types appropriately
        switch (typeof value) {
          case 'boolean':
            safeItem[key] = value ? 'Yes' : 'No';
            break;
          case 'number':
            safeItem[key] = value.toString();
            break;
          case 'string':
            safeItem[key] = value;
            break;
          case 'object':
            // Handle Date objects
            if (Object.prototype.toString.call(value) === '[object Date]') {
              safeItem[key] = format(value as Date, 'dd-MM-yy');
            } 
            // Handle arrays by converting to comma-separated values
            else if (Array.isArray(value)) {
              try {
                safeItem[key] = value.join(', ');
              } catch (e) {
                safeItem[key] = '[Array]';
              }
            } 
            // Other objects converted to string
            else {
              try {
                safeItem[key] = JSON.stringify(value).substring(0, 50);
              } catch (e) {
                safeItem[key] = '[Object]';
              }
            }
            break;
          default:
            // Functions, symbols, etc. converted to simple text
            safeItem[key] = `[${typeof value}]`;
        }
      }
      return safeItem;
    });
    
    console.log('Data sanitized successfully');
    
    // Create a new PDF document
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Add title and date
    doc.setFontSize(18);
    doc.text(title, 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${format(new Date(), 'dd-MM-yy')}`, 14, 30);
    
    // If columns are not provided, generate them from the safe data
    let safeColumns = columns;
    if (!safeColumns && safeData.length > 0) {
      // Get columns from the first item
      safeColumns = Object.keys(safeData[0])
        .filter(key => key !== 'elasticParts' && key !== '_id') // Filter out problematic fields
        .map(key => ({
          header: key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' '),
          dataKey: key
        }));
    }
    
    console.log('Columns generated:', safeColumns ? safeColumns.length : 0);
    
    if (!safeColumns || safeColumns.length === 0) {
      throw new Error('No columns could be generated for the PDF');
    }
    
    // Create a 2D array for the table body
    const tableBody = safeData.map(item => {
      return safeColumns!.map(col => {
        const value = item[col.dataKey];
        return value !== undefined ? value : '';
      });
    });
    
    console.log('Table body created, rows:', tableBody.length);
    
    // Generate the table
    autoTable(doc, {
      startY: 40,
      head: [safeColumns.map(col => col.header)],
      body: tableBody,
      margin: { top: 40 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255 },
      alternateRowStyles: { fillColor: [245, 245, 245] }
    });
    
    // Save the PDF
    doc.save(filename);
  } catch (error) {
    console.error('PDF generation error details:', {
      error: error,
      errorType: typeof error,
      errorSummary: String(error)
    });
    
    // More specific error handling
    if (error instanceof Error) {
      console.error('Error name:', error.name);
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
    
    throw new Error('Failed to generate PDF: ' + (error instanceof Error ? error.message : String(error)));
  }
};

// Create a report that combines multiple datasets
export const generateReport = (
  datasets: Array<{
    data: Record<string, any>[];
    title: string;
    columns?: { header: string; dataKey: string }[];
  }>,
  reportTitle: string,
  filename: string
) => {
  try {
    console.log('Starting report generation process');
    
    // Create a new PDF document
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Add report title and header
    doc.setFontSize(22);
    doc.text(reportTitle, 14, 20);
    doc.setFontSize(12);
    doc.text(`Generated on: ${format(new Date(), 'dd-MM-yy')}`, 14, 30);
    
    let currentY = 40;
    
    // Process each dataset
    for (let index = 0; index < datasets.length; index++) {
      const dataset = datasets[index];
      
      // Sanitize the data for each dataset
      if (!dataset.data || !Array.isArray(dataset.data) || dataset.data.length === 0) {
        console.log(`Dataset "${dataset.title}" has no data, skipping`);
        continue;
      }
      
      // Add section title
      doc.setFontSize(16);
      doc.text(dataset.title, 14, currentY);
      currentY += 10;
      
      // Create safe data for this dataset
      const safeData = dataset.data.map(item => {
        const safeItem: Record<string, any> = {};
        
        // Process each field
        for (const key in item) {
          const value = item[key];
          
          // Skip undefined/null values
          if (value === undefined || value === null) {
            safeItem[key] = '';
            continue;
          }
          
          // Handle different types appropriately
          switch (typeof value) {
            case 'boolean':
              safeItem[key] = value ? 'Yes' : 'No';
              break;
            case 'number':
              safeItem[key] = value.toString();
              break;
            case 'string':
              safeItem[key] = value;
              break;
            case 'object':
              // Handle Date objects
              if (Object.prototype.toString.call(value) === '[object Date]') {
                safeItem[key] = format(value as Date, 'dd-MM-yy');
              } 
              // Handle arrays by converting to comma-separated values
              else if (Array.isArray(value)) {
                try {
                  safeItem[key] = value.join(', ');
                } catch (e) {
                  safeItem[key] = '[Array]';
                }
              } 
              // Other objects converted to string
              else {
                try {
                  safeItem[key] = JSON.stringify(value).substring(0, 50);
                } catch (e) {
                  safeItem[key] = '[Object]';
                }
              }
              break;
            default:
              // Functions, symbols, etc. converted to simple text
              safeItem[key] = `[${typeof value}]`;
          }
        }
        return safeItem;
      });
      
      // Generate or use provided columns
      let safeColumns = dataset.columns;
      if (!safeColumns && safeData.length > 0) {
        safeColumns = Object.keys(safeData[0])
          .filter(key => key !== 'elasticParts' && key !== '_id') // Filter out problematic fields
          .map(key => ({
            header: key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' '),
            dataKey: key
          }));
      }
      
      // Skip if no columns could be generated
      if (!safeColumns || safeColumns.length === 0) {
        console.log(`No columns for dataset "${dataset.title}", skipping`);
        continue;
      }
      
      // Create a 2D array for the table body
      const tableBody = safeData.map(item => {
        return safeColumns!.map(col => {
          const value = item[col.dataKey];
          return value !== undefined ? value : '';
        });
      });
      
      // Generate the table for this dataset
      autoTable(doc, {
        startY: currentY,
        head: [safeColumns.map(col => col.header)],
        body: tableBody,
        margin: { top: currentY },
        headStyles: { fillColor: [41, 128, 185], textColor: 255 },
        alternateRowStyles: { fillColor: [245, 245, 245] }
      });
      
      // Update Y position for next section
      // @ts-ignore - autoTable adds this property
      currentY = doc.lastAutoTable.finalY + 20;
      
      // Add page break if needed (except for the last dataset)
      if (index < datasets.length - 1 && currentY > 250) {
        doc.addPage();
        currentY = 20;
      }
    }
    
    // Save the PDF
    doc.save(filename);
    console.log('Report generated successfully');
    
  } catch (error) {
    console.error('Report generation error details:', {
      error: error,
      errorType: typeof error,
      errorSummary: String(error)
    });
    
    // More specific error handling
    if (error instanceof Error) {
      console.error('Error name:', error.name);
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
    
    throw new Error('Failed to generate report: ' + (error instanceof Error ? error.message : String(error)));
  }
};

// Export a specific section's data
export const exportSectionData = <T extends Record<string, any>>(
  data: T[],
  sectionName: string,
  format: 'csv' | 'excel' | 'pdf'
) => {
  // Generate a nice filename
  const filename = generateFilename(sectionName.replace(/\s+/g, '_').toLowerCase(), 
    format === 'csv' ? 'csv' : format === 'excel' ? 'xlsx' : 'pdf');
  
  // Export in the requested format
  switch (format) {
    case 'csv':
      exportToCSV(data, filename);
      break;
    case 'excel':
      exportToExcel(data, filename);
      break;
    case 'pdf':
      exportToPDF(data, sectionName, filename);
      break;
  }
};