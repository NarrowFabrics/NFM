import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Edit, 
  Trash, 
  RefreshCw,
  Loader2,
  Tag
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ProductItem, insertProductItemSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form schema
const formSchema = insertProductItemSchema.extend({
  specifications: z.any().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function ProductItemsPage() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [editingProductItem, setEditingProductItem] = useState<ProductItem | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [productItemToDelete, setProductItemToDelete] = useState<number | null>(null);
  const [specifications, setSpecifications] = useState<{ name: string; value: string }[]>([{ name: "", value: "" }]);

  // Fetch product items
  const {
    data: productItemsData,
    isLoading,
    refetch,
  } = useQuery<{ productItems: ProductItem[]; total: number }>({
    queryKey: ["/api/product-items", page, perPage, categoryFilter, search],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, category, search] = queryKey;
      let url = `/api/product-items?page=${page}&limit=${perPage}`;
      if (category) url += `&category=${category}`;
      if (search) url += `&search=${search}`;
      
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch product items');
      }
      return res.json();
    },
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      category: "",
      name: "",
      specifications: [],
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      // Filter out empty specifications
      const filteredSpecs = specifications
        .filter(spec => spec.name.trim() && spec.value.trim())
        .map(spec => ({
          name: spec.name.trim(),
          value: spec.value.trim()
        }));
      
      const dataToSend = { ...values, specifications: filteredSpecs };
      
      const res = await apiRequest("POST", "/api/product-items", dataToSend);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Product item created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/product-items"] });
      setIsFormDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: FormValues }) => {
      // Filter out empty specifications
      const filteredSpecs = specifications
        .filter(spec => spec.name.trim() && spec.value.trim())
        .map(spec => ({
          name: spec.name.trim(),
          value: spec.value.trim()
        }));
      
      const dataToSend = { ...values, specifications: filteredSpecs };
      
      const res = await apiRequest("PUT", `/api/product-items/${id}`, dataToSend);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Product item updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/product-items"] });
      setIsFormDialogOpen(false);
      setEditingProductItem(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/product-items/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Product item deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/product-items"] });
      setIsDeleteDialogOpen(false);
      setProductItemToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle create button click
  const handleCreate = () => {
    form.reset({
      category: "",
      name: "",
      specifications: [],
    });
    setSpecifications([{ name: "", value: "" }]);
    setEditingProductItem(null);
    setIsFormDialogOpen(true);
  };

  // Handle edit button click
  const handleEdit = (productItem: ProductItem) => {
    form.reset({
      category: productItem.category,
      name: productItem.name,
      specifications: productItem.specifications,
    });
    
    // Convert specifications array to our state format
    const specsArray = productItem.specifications as Array<{ name: string; value: string }>;
    if (specsArray && specsArray.length > 0) {
      setSpecifications(specsArray);
    } else {
      setSpecifications([{ name: "", value: "" }]);
    }
    
    setEditingProductItem(productItem);
    setIsFormDialogOpen(true);
  };

  // Handle delete button click
  const handleDeleteClick = (id: number) => {
    setProductItemToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    if (productItemToDelete !== null) {
      deleteMutation.mutate(productItemToDelete);
    }
  };

  // Handle adding a new specification
  const handleAddSpecification = () => {
    setSpecifications([...specifications, { name: "", value: "" }]);
  };

  // Handle removing a specification
  const handleRemoveSpecification = (index: number) => {
    const newSpecs = [...specifications];
    newSpecs.splice(index, 1);
    setSpecifications(newSpecs);
  };

  // Handle specification field changes
  const handleSpecificationChange = (index: number, field: 'name' | 'value', value: string) => {
    const newSpecs = [...specifications];
    newSpecs[index][field] = value;
    setSpecifications(newSpecs);
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    if (editingProductItem) {
      updateMutation.mutate({ id: editingProductItem.id, values });
    } else {
      createMutation.mutate(values);
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Table columns definition
  const columns = [
    {
      header: "ID",
      accessorKey: "id" as keyof ProductItem,
    },
    {
      header: "Category",
      accessorKey: "category" as keyof ProductItem,
    },
    {
      header: "Name",
      accessorKey: "name" as keyof ProductItem,
      cell: ({ row }: { row: ProductItem }) => (
        <div className="flex items-center space-x-2">
          <Tag className="h-4 w-4 text-primary" />
          <span>{row.name}</span>
        </div>
      ),
    },
    {
      header: "Specifications",
      accessorKey: "specifications" as keyof ProductItem,
      cell: ({ row }: { row: ProductItem }) => {
        const specs = row.specifications as Array<{ name: string; value: string }>;
        return (
          <div className="max-w-xs truncate">
            {specs && specs.length > 0 ? (
              <span>{specs.length} specifications</span>
            ) : (
              <span className="text-gray-400">No specifications</span>
            )}
          </div>
        );
      },
    },
    {
      header: "Created Date",
      accessorKey: "created_at" as keyof ProductItem,
      cell: ({ row }: { row: ProductItem }) => formatDate(row.created_at),
    },
    {
      header: "Actions",
      cell: ({ row }: { row: ProductItem }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => handleEdit(row)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteClick(row.id)}>
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  // Product categories
  const categories = [
    "Elastic",
    "Ribbon",
    "Webbing",
    "Tape",
    "Cord",
    "Zipper",
    "Label",
    "Other"
  ];

  return (
    <AppLayout
      title="Product Items"
      description="Manage your product catalog"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> New Product Item
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <Select
            value={categoryFilter || "all"}
            onValueChange={(value) => {
              setCategoryFilter(value === "all" ? null : value);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setPage(1);
              refetch();
            }}
            className="flex gap-2"
          >
            <Input
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full sm:w-auto"
            />
            <Button type="submit">Search</Button>
          </form>
        </div>
      </div>

      <DataTable
        data={productItemsData?.productItems || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          productItemsData
            ? {
                currentPage: page,
                totalPages: Math.ceil(productItemsData.total / perPage),
                totalItems: productItemsData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />

      {/* Create/Edit Form Dialog */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingProductItem ? "Edit Product Item" : "Create Product Item"}
            </DialogTitle>
            <DialogDescription>
              {editingProductItem
                ? "Update the product item details below."
                : "Fill in the details to create a new product item."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <FormControl>
                        <Select 
                          value={field.value} 
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category} value={category}>{category}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Product name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium">Specifications</h3>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleAddSpecification}
                  >
                    <Plus className="h-4 w-4 mr-1" /> Add Specification
                  </Button>
                </div>
                
                {specifications.map((spec, index) => (
                  <div 
                    key={index} 
                    className="grid grid-cols-2 gap-4 items-center mb-4"
                  >
                    <Input
                      placeholder="Specification name"
                      value={spec.name}
                      onChange={(e) => handleSpecificationChange(index, 'name', e.target.value)}
                    />
                    <div className="flex items-center gap-2">
                      <Input
                        placeholder="Value"
                        value={spec.value}
                        onChange={(e) => handleSpecificationChange(index, 'value', e.target.value)}
                      />
                      {specifications.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveSpecification(index)}
                        >
                          <Trash className="h-4 w-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {(createMutation.isPending || updateMutation.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {editingProductItem ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    editingProductItem ? "Update Product" : "Create Product"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the product item. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
