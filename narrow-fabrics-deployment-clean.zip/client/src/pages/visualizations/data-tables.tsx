import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { DataTable } from "@/components/ui/data-table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pagination } from "@/components/ui/pagination";
import { FileDown, Filter, Search, RefreshCw } from "lucide-react";

import AppLayout from "@/components/layout/app-layout";
import { apiRequest } from "@/lib/queryClient";
import { exportToCSV, exportToExcel } from "@/lib/export-utils";

// Define the table configurations for different data types
const TABLE_CONFIGS = {
  "materials": {
    title: "Materials",
    description: "View all materials in the database",
    endpoints: {
      list: "/api/materials",
    },
    columns: [
      { header: "ID", accessorKey: "id" },
      { header: "Name", accessorKey: "name" },
      { header: "Category", accessorKey: "category" },
      { header: "Unit Price", accessorKey: "unit_price", cell: ({ row }) => `$${row.unit_price?.toFixed(2) || '0.00'}` },
      { header: "Quantity", accessorKey: "quantity" },
      { header: "Created At", accessorKey: "created_at", cell: ({ row }) => new Date(row.created_at).toLocaleDateString() },
    ],
    filters: [
      { name: "category", label: "Category", type: "select", options: ["Yarn", "Fabric", "Elastic", "Hardware", "All"] }
    ]
  },
  "orders": {
    title: "Orders",
    description: "All customer orders and their details",
    endpoints: {
      list: "/api/orders",
    },
    columns: [
      { header: "ID", accessorKey: "id" },
      { header: "Customer", accessorKey: "customer_name" },
      { header: "Order Date", accessorKey: "order_date", cell: ({ row }) => new Date(row.order_date).toLocaleDateString() },
      { header: "Status", accessorKey: "status", cell: ({ row }) => (
        <Badge variant={row.status === "Completed" ? "success" : row.status === "In Progress" ? "outline" : "secondary"}>
          {row.status}
        </Badge>
      )},
      { header: "Total Amount", accessorKey: "total_amount", cell: ({ row }) => `$${row.total_amount?.toFixed(2) || '0.00'}` },
    ],
    filters: [
      { name: "status", label: "Status", type: "select", options: ["All", "Pending", "In Progress", "Completed", "Cancelled"] }
    ]
  },
  "production-plans": {
    title: "Production Plans",
    description: "All scheduled production plans",
    endpoints: {
      list: "/api/production-plans",
    },
    columns: [
      { header: "ID", accessorKey: "id" },
      { header: "Name", accessorKey: "name" },
      { header: "Start Date", accessorKey: "start_date", cell: ({ row }) => new Date(row.start_date).toLocaleDateString() },
      { header: "End Date", accessorKey: "end_date", cell: ({ row }) => new Date(row.end_date).toLocaleDateString() },
      { header: "Status", accessorKey: "status", cell: ({ row }) => (
        <Badge variant={row.status === "Completed" ? "success" : row.status === "In Progress" ? "outline" : "secondary"}>
          {row.status}
        </Badge>
      )},
      { header: "Product Item", accessorKey: "product_item_name" },
    ],
    filters: [
      { name: "status", label: "Status", type: "select", options: ["All", "Planned", "In Progress", "Completed", "Cancelled"] }
    ]
  },
  "yarn-types": {
    title: "Yarn Types",
    description: "Different types of yarn used in production",
    endpoints: {
      list: "/api/yarn-types",
    },
    columns: [
      { header: "ID", accessorKey: "id" },
      { header: "Name", accessorKey: "name" },
      { header: "Code", accessorKey: "code" },
      { header: "Description", accessorKey: "description" },
      { header: "Is Active", accessorKey: "is_active", cell: ({ row }) => (
        <Badge variant={row.is_active ? "outline" : "secondary"}>
          {row.is_active ? "Active" : "Inactive"}
        </Badge>
      )},
    ],
    filters: [
      { name: "is_active", label: "Status", type: "select", options: ["All", "Active", "Inactive"] }
    ]
  },
  "color-types": {
    title: "Color Types",
    description: "All color options available for products",
    endpoints: {
      list: "/api/color-types",
    },
    columns: [
      { header: "ID", accessorKey: "id" },
      { header: "Name", accessorKey: "name" },
      { header: "Description", accessorKey: "description" },
      { header: "Is Active", accessorKey: "is_active", cell: ({ row }) => (
        <Badge variant={row.is_active ? "outline" : "secondary"}>
          {row.is_active ? "Active" : "Inactive"}
        </Badge>
      )},
      { header: "Created At", accessorKey: "created_at", cell: ({ row }) => new Date(row.created_at).toLocaleDateString() },
    ],
    filters: [
      { name: "is_active", label: "Status", type: "select", options: ["All", "Active", "Inactive"] }
    ]
  },
};

// Function to format a filename for exports
const formatExportFilename = (tableType) => {
  return `${TABLE_CONFIGS[tableType]?.title || tableType}-data-${new Date().toISOString().split('T')[0]}`;
};

export default function DataTablesPage() {
  // Match route params to get the table type
  const [, params] = useRoute("/visualizations/data-tables/:tableType?");
  const { tableType = "materials" } = params || {};
  
  // Ensure we're using a valid table type
  const currentTableType = TABLE_CONFIGS[tableType] ? tableType : "materials";
  const tableConfig = TABLE_CONFIGS[currentTableType];
  
  // State for pagination, search, and filters
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({});
  
  // Reset pagination when table type changes
  useEffect(() => {
    setCurrentPage(1);
    setSearchTerm("");
    setFilters({});
  }, [currentTableType]);
  
  // Fetch data for the current table
  const { data, isLoading, refetch } = useQuery({
    queryKey: [tableConfig.endpoints.list, currentPage, perPage, searchTerm, filters],
    queryFn: async () => {
      // Build query params
      const queryParams = new URLSearchParams();
      queryParams.append("page", currentPage.toString());
      queryParams.append("limit", perPage.toString());
      
      if (searchTerm) {
        queryParams.append("search", searchTerm);
      }
      
      // Add active filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== "All") {
          queryParams.append(key, value.toString());
        }
      });
      
      const url = `${tableConfig.endpoints.list}?${queryParams.toString()}`;
      return apiRequest(url);
    }
  });

  // Extract table data and pagination info
  const tableData = data?.data || [];
  const totalItems = data?.total || 0;
  const totalPages = Math.ceil(totalItems / perPage);
  
  // Handle search input
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1); // Reset to first page when searching
  };
  
  // Handle filter changes
  const handleFilterChange = (name, value) => {
    setFilters(prev => ({ ...prev, [name]: value }));
    setCurrentPage(1); // Reset to first page when filtering
  };
  
  // Export functions
  const handleExportCSV = () => {
    if (tableData.length > 0) {
      exportToCSV(tableData, formatExportFilename(currentTableType));
    }
  };
  
  const handleExportExcel = () => {
    if (tableData.length > 0) {
      exportToExcel(tableData, formatExportFilename(currentTableType));
    }
  };

  return (
    <AppLayout>
      <div className="container mx-auto py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">{tableConfig.title}</h1>
          <p className="text-gray-500">{tableConfig.description}</p>
        </div>

        {/* Table Type Tabs */}
        <Tabs defaultValue={currentTableType} className="mb-6">
          <TabsList className="grid grid-cols-5 mb-4">
            <TabsTrigger value="materials" asChild>
              <Link href="/visualizations/data-tables/materials">Materials</Link>
            </TabsTrigger>
            <TabsTrigger value="orders" asChild>
              <Link href="/visualizations/data-tables/orders">Orders</Link>
            </TabsTrigger>
            <TabsTrigger value="production-plans" asChild>
              <Link href="/visualizations/data-tables/production-plans">Production</Link>
            </TabsTrigger>
            <TabsTrigger value="yarn-types" asChild>
              <Link href="/visualizations/data-tables/yarn-types">Yarn Types</Link>
            </TabsTrigger>
            <TabsTrigger value="color-types" asChild>
              <Link href="/visualizations/data-tables/color-types">Color Types</Link>
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
              <div>
                <CardTitle>{tableConfig.title} List</CardTitle>
                <CardDescription>
                  Showing {tableData.length} of {totalItems} records
                </CardDescription>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={handleExportCSV}>
                  <FileDown className="mr-2 h-4 w-4" />
                  CSV
                </Button>
                <Button variant="outline" size="sm" onClick={handleExportExcel}>
                  <FileDown className="mr-2 h-4 w-4" />
                  Excel
                </Button>
                <Button variant="ghost" size="sm" onClick={() => refetch()}>
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            {/* Search and Filters */}
            <div className="mb-4 flex flex-col space-y-4 md:flex-row md:items-center md:space-x-4 md:space-y-0">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={handleSearch}
                />
              </div>
              
              {tableConfig.filters && tableConfig.filters.map((filter) => (
                <div key={filter.name} className="flex items-center space-x-2">
                  <Filter className="h-4 w-4 text-gray-400" />
                  <Select
                    value={filters[filter.name] || "All"}
                    onValueChange={(value) => handleFilterChange(filter.name, value)}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder={filter.label} />
                    </SelectTrigger>
                    <SelectContent>
                      {filter.options.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
            
            {/* Data Table */}
            <DataTable
              data={tableData}
              columns={tableConfig.columns}
              pagination={{
                currentPage,
                totalPages,
                totalItems,
                perPage,
                onPageChange: setCurrentPage,
                onPerPageChange: setPerPage,
              }}
              isLoading={isLoading}
            />
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}

function MoreHorizontal(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
      <circle cx="5" cy="12" r="1" />
    </svg>
  );
}