import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BarChart, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, Bar, Line } from "recharts";
import { LayoutDashboard, FileText, Database, Activity, ArrowRight } from "lucide-react";

import AppLayout from "@/components/layout/app-layout";
import { apiRequest } from "@/lib/queryClient";
import { SkeletonCard, SkeletonDashboardCard } from "@/components/ui/skeleton-card";
import { SkeletonChart } from "@/components/ui/skeleton-chart";

export default function DataVisualizationPage() {
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch dashboard stats
  const { data: dashboardStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/stats/dashboard'],
    queryFn: async () => {
      const response = await apiRequest<{
        totalOrders: number;
        totalProductionPlans: number;
        totalMaterials: number;
        totalRevenue: number;
      }>('/api/stats/dashboard');
      return response;
    }
  });

  // Fetch recent orders for chart
  const { data: recentOrders, isLoading: isLoadingOrders } = useQuery({
    queryKey: ['/api/orders/recent'],
    queryFn: async () => {
      const response = await apiRequest<any[]>('/api/orders/recent?limit=10');
      return response;
    }
  });

  // Prepare chart data from orders
  const orderChartData = recentOrders ? recentOrders.map(order => ({
    name: new Date(order.order_date).toLocaleDateString(),
    amount: order.total_amount
  })) : [];

  // Sample visualization links
  const visualizationLinks = [
    {
      title: "Data Tables",
      description: "Browse and filter database records in interactive tables",
      icon: <FileText className="h-8 w-8 text-primary" />,
      path: "/visualizations/data-tables",
      badge: "Tables",
    },
    {
      title: "Reports",
      description: "Generate and download detailed reports in various formats",
      icon: <Database className="h-8 w-8 text-primary" />,
      path: "/visualizations/reports",
      badge: "Reports",
    },
    {
      title: "Summary",
      description: "View key metrics and insights at a glance",
      icon: <Activity className="h-8 w-8 text-primary" />,
      path: "/visualizations/summary",
      badge: "Insights",
    },
  ];

  return (
    <AppLayout>
      <div className="container mx-auto py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Data Visualization</h1>
          <p className="text-gray-500">
            Explore and analyze your data through interactive visualizations and reports
          </p>
        </div>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full md:w-1/3 grid-cols-2">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="visualizations">Visualizations</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {isLoadingStats ? (
                // Loading skeletons for stats cards
                <>
                  <SkeletonDashboardCard />
                  <SkeletonDashboardCard />
                  <SkeletonDashboardCard />
                  <SkeletonDashboardCard />
                </>
              ) : (
                // Actual stats cards
                <>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {dashboardStats?.totalOrders || 0}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Production Plans</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {dashboardStats?.totalProductionPlans || 0}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Materials</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {dashboardStats?.totalMaterials || 0}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        ${(dashboardStats?.totalRevenue || 0).toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            {/* Charts */}
            <div className="grid gap-6 md:grid-cols-2">
              {isLoadingOrders ? (
                // Loading skeleton for chart
                <SkeletonChart height={300} chartType="bar" showLegend={true} />
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Orders</CardTitle>
                    <CardDescription>Order amounts from the last 10 orders</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={orderChartData}>
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="amount" name="Order Amount" fill="#4f46e5" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}

              {isLoadingStats ? (
                // Loading skeleton for metrics
                <SkeletonCard hasHeader={true} contentLines={4} />
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Data Overview</CardTitle>
                    <CardDescription>Key metrics from your database</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Orders</span>
                        <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                          <div className="bg-primary h-2.5 rounded-full" style={{ width: '70%' }}></div>
                        </div>
                        <span className="text-sm">{dashboardStats?.totalOrders || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Production</span>
                        <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                          <div className="bg-green-500 h-2.5 rounded-full" style={{ width: '45%' }}></div>
                        </div>
                        <span className="text-sm">{dashboardStats?.totalProductionPlans || 0}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Materials</span>
                        <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                          <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: '60%' }}></div>
                        </div>
                        <span className="text-sm">{dashboardStats?.totalMaterials || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            <div className="flex justify-end">
              <Button onClick={() => setActiveTab("visualizations")}>
                Explore Visualizations <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </TabsContent>

          {/* Visualizations Tab */}
          <TabsContent value="visualizations" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
              {visualizationLinks.map((link, index) => (
                <Card key={index} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      {link.icon}
                      <Badge variant="outline">{link.badge}</Badge>
                    </div>
                    <CardTitle className="mt-4">{link.title}</CardTitle>
                    <CardDescription>{link.description}</CardDescription>
                  </CardHeader>
                  <CardFooter>
                    <Link href={link.path}>
                      <Button variant="outline" className="w-full">
                        View {link.title} <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}