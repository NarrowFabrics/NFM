import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, BarChart, PieChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, Line, Bar, Pie, Cell } from "recharts";
import { Calendar, Clock, ArrowUpRight, ArrowDownRight, Zap, TrendingUp, Download } from "lucide-react";

import AppLayout from "@/components/layout/app-layout";
import { apiRequest } from "@/lib/queryClient";
import { exportToCSV } from "@/lib/export-utils";

// Static data for demo purposes - will connect to real API endpoints
const currentDate = new Date();
const formatDate = (date: Date) => {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(date);
};

export default function SummaryPage() {
  const [activeView, setActiveView] = useState<string>("business");
  
  // Fetch dashboard stats
  const { data: dashboardStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/stats/dashboard'],
    queryFn: async () => {
      const response = await apiRequest<{
        totalOrders: number;
        totalProductionPlans: number;
        totalMaterials: number;
        totalRevenue: number;
      }>('/api/stats/dashboard');
      return response;
    }
  });
  
  // Fetch KPI metrics
  const { data: kpiData, isLoading: isLoadingKPI } = useQuery({
    queryKey: ['/api/stats/kpi'],
    queryFn: async () => {
      const response = await apiRequest('/api/stats/kpi');
      return response;
    }
  });
  
  // Generate monthly data for charts
  const monthlyOrdersData = [
    { month: 'Jan', orders: 22, revenue: 15200 },
    { month: 'Feb', orders: 28, revenue: 18700 },
    { month: 'Mar', orders: 25, revenue: 16900 },
    { month: 'Apr', orders: 31, revenue: 21500 },
    { month: 'May', orders: 29, revenue: 19800 },
    { month: 'Jun', orders: 36, revenue: 24850 }
  ];
  
  // Material distribution data
  const materialDistribution = [
    { name: 'Yarn', value: 35 },
    { name: 'Fabric', value: 25 },
    { name: 'Elastic', value: 20 },
    { name: 'Hardware', value: 15 },
    { name: 'Other', value: 5 }
  ];
  
  // Color palette for charts
  const COLORS = ['#4f46e5', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6'];
  
  // Handle export of summary data
  const handleExportSummary = () => {
    const exportData = {
      businessMetrics: kpiData?.salesMetrics,
      operationalMetrics: kpiData?.operationalMetrics,
      monthlyData: monthlyOrdersData,
      materialDistribution: materialDistribution
    };
    
    exportToCSV(exportData, `summary-report-${new Date().toISOString().split('T')[0]}`);
  };

  return (
    <AppLayout>
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Business Summary</h1>
            <p className="text-gray-500">
              Overview of key metrics and performance indicators
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="bg-gray-100 px-3 py-1 rounded-md flex items-center">
              <Calendar className="h-4 w-4 mr-2 text-gray-500" />
              <span className="text-sm text-gray-600">{formatDate(currentDate)}</span>
            </div>
            <Button variant="outline" size="sm" onClick={handleExportSummary}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
        
        {/* View Tabs */}
        <Tabs defaultValue="business" value={activeView} onValueChange={setActiveView} className="mb-6">
          <TabsList className="grid w-full md:w-1/3 grid-cols-2">
            <TabsTrigger value="business">Business Metrics</TabsTrigger>
            <TabsTrigger value="operational">Operational Metrics</TabsTrigger>
          </TabsList>
          
          {/* Business Metrics View */}
          <TabsContent value="business" className="space-y-6 mt-6">
            {/* KPI Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Revenue</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">
                      ${kpiData?.salesMetrics?.revenue?.current?.toLocaleString() || 0}
                    </CardTitle>
                    <Badge variant={kpiData?.salesMetrics?.revenue?.trend === 'up' ? 'outline' : 'destructive'} className="flex items-center h-6">
                      {kpiData?.salesMetrics?.revenue?.trend === 'up' ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
                      {kpiData?.salesMetrics?.revenue?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: ${kpiData?.salesMetrics?.revenue?.previous?.toLocaleString() || 0}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Orders</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">{kpiData?.salesMetrics?.orders?.current || 0}</CardTitle>
                    <Badge variant={kpiData?.salesMetrics?.orders?.trend === 'up' ? 'outline' : 'destructive'} className="flex items-center h-6">
                      {kpiData?.salesMetrics?.orders?.trend === 'up' ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
                      {kpiData?.salesMetrics?.orders?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: {kpiData?.salesMetrics?.orders?.previous || 0}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Avg. Order Value</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">${kpiData?.salesMetrics?.averageOrderValue?.current || 0}</CardTitle>
                    <Badge variant={kpiData?.salesMetrics?.averageOrderValue?.trend === 'up' ? 'outline' : 'destructive'} className="flex items-center h-6">
                      {kpiData?.salesMetrics?.averageOrderValue?.trend === 'up' ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
                      {kpiData?.salesMetrics?.averageOrderValue?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: ${kpiData?.salesMetrics?.averageOrderValue?.previous || 0}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Conversion Rate</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">{kpiData?.salesMetrics?.conversionRate?.current || 0}%</CardTitle>
                    <Badge variant={kpiData?.salesMetrics?.conversionRate?.trend === 'up' ? 'outline' : 'destructive'} className="flex items-center h-6">
                      {kpiData?.salesMetrics?.conversionRate?.trend === 'up' ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
                      {kpiData?.salesMetrics?.conversionRate?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: {kpiData?.salesMetrics?.conversionRate?.previous || 0}%</div>
                </CardContent>
              </Card>
            </div>
            
            {/* Business Charts */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Revenue & Orders</CardTitle>
                  <CardDescription>Trends over the last 6 months</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={monthlyOrdersData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <XAxis dataKey="month" />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Line
                        yAxisId="left"
                        type="monotone"
                        dataKey="revenue"
                        stroke="#4f46e5"
                        activeDot={{ r: 8 }}
                      />
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="orders"
                        stroke="#22c55e"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Material Distribution</CardTitle>
                  <CardDescription>Breakdown by material type</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={materialDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {materialDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Operational Metrics View */}
          <TabsContent value="operational" className="space-y-6 mt-6">
            {/* Operational KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Production Efficiency</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">{kpiData?.operationalMetrics?.productionEfficiency?.current || 0}%</CardTitle>
                    <Badge variant={kpiData?.operationalMetrics?.productionEfficiency?.trend === 'up' ? 'outline' : 'destructive'} className="flex items-center h-6">
                      {kpiData?.operationalMetrics?.productionEfficiency?.trend === 'up' ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
                      {kpiData?.operationalMetrics?.productionEfficiency?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: {kpiData?.operationalMetrics?.productionEfficiency?.previous || 0}%</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Material Waste</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">{kpiData?.operationalMetrics?.materialWaste?.current || 0}%</CardTitle>
                    <Badge 
                      variant={kpiData?.operationalMetrics?.materialWaste?.trend === 'down' ? 'outline' : 'destructive'} 
                      className="flex items-center h-6"
                    >
                      {kpiData?.operationalMetrics?.materialWaste?.trend === 'down' ? <ArrowDownRight className="h-3 w-3 mr-1" /> : <ArrowUpRight className="h-3 w-3 mr-1" />}
                      {kpiData?.operationalMetrics?.materialWaste?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: {kpiData?.operationalMetrics?.materialWaste?.previous || 0}%</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>On-Time Delivery</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">{kpiData?.operationalMetrics?.onTimeDelivery?.current || 0}%</CardTitle>
                    <Badge variant={kpiData?.operationalMetrics?.onTimeDelivery?.trend === 'up' ? 'outline' : 'destructive'} className="flex items-center h-6">
                      {kpiData?.operationalMetrics?.onTimeDelivery?.trend === 'up' ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
                      {kpiData?.operationalMetrics?.onTimeDelivery?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: {kpiData?.operationalMetrics?.onTimeDelivery?.previous || 0}%</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Production Cost</CardDescription>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-2xl">${kpiData?.operationalMetrics?.productionCost?.current?.toLocaleString() || 0}</CardTitle>
                    <Badge 
                      variant={kpiData?.operationalMetrics?.productionCost?.trend === 'down' ? 'outline' : 'destructive'} 
                      className="flex items-center h-6"
                    >
                      {kpiData?.operationalMetrics?.productionCost?.trend === 'down' ? <ArrowDownRight className="h-3 w-3 mr-1" /> : <ArrowUpRight className="h-3 w-3 mr-1" />}
                      {kpiData?.operationalMetrics?.productionCost?.percentChange || 0}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-gray-500">vs. previous month: ${kpiData?.operationalMetrics?.productionCost?.previous?.toLocaleString() || 0}</div>
                </CardContent>
              </Card>
            </div>
            
            {/* Operational Performance Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Operational Performance</CardTitle>
                <CardDescription>Key operational metrics comparison</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      {
                        name: "Production Efficiency",
                        current: kpiData?.operationalMetrics?.productionEfficiency?.current || 0,
                        previous: kpiData?.operationalMetrics?.productionEfficiency?.previous || 0,
                      },
                      {
                        name: "Material Waste",
                        current: kpiData?.operationalMetrics?.materialWaste?.current || 0,
                        previous: kpiData?.operationalMetrics?.materialWaste?.previous || 0,
                      },
                      {
                        name: "On-Time Delivery",
                        current: kpiData?.operationalMetrics?.onTimeDelivery?.current || 0,
                        previous: kpiData?.operationalMetrics?.onTimeDelivery?.previous || 0,
                      }
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="current" name="Current Month" fill="#4f46e5" />
                    <Bar dataKey="previous" name="Previous Month" fill="#94a3b8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            {/* Production Cost Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>Cost Breakdown</CardTitle>
                <CardDescription>Current production cost categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Materials</span>
                      <span className="text-sm font-medium">45%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '45%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Labor</span>
                      <span className="text-sm font-medium">32%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-green-500 h-2.5 rounded-full" style={{ width: '32%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Overhead</span>
                      <span className="text-sm font-medium">18%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: '18%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Shipping</span>
                      <span className="text-sm font-medium">5%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: '5%' }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}