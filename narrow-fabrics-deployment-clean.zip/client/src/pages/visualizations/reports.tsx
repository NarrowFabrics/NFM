import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { FileDown, Download, Printer, FileText, BarChart, FileBarChart } from "lucide-react";

import AppLayout from "@/components/layout/app-layout";
import { apiRequest } from "@/lib/queryClient";
import { exportToPDF, exportToExcel, exportToCSV } from "@/lib/export-utils";

// Define report configurations
const REPORT_CONFIGS = {
  "orders": {
    title: "Orders Report",
    description: "Generate detailed reports on customer orders",
    apiEndpoint: "/api/reports/orders",
    columns: [
      { header: "Order ID", dataKey: "id" },
      { header: "Customer", dataKey: "customer_name" },
      { header: "Order Date", dataKey: "order_date" },
      { header: "Items", dataKey: "item_count" },
      { header: "Status", dataKey: "status" },
      { header: "Total", dataKey: "total_amount" },
    ],
    filters: {
      date: true,
      status: ["All", "Pending", "In Progress", "Completed", "Cancelled"],
      customer: true,
    }
  },
  "inventory": {
    title: "Inventory Report",
    description: "Track inventory levels and material usage",
    apiEndpoint: "/api/reports/inventory",
    columns: [
      { header: "Material ID", dataKey: "id" },
      { header: "Name", dataKey: "name" },
      { header: "Category", dataKey: "category" },
      { header: "In Stock", dataKey: "quantity" },
      { header: "Unit", dataKey: "unit" },
      { header: "Unit Price", dataKey: "unit_price" },
      { header: "Total Value", dataKey: "total_value" },
    ],
    filters: {
      category: ["All", "Yarn", "Fabric", "Elastic", "Hardware"],
      stock: ["All", "In Stock", "Low Stock", "Out of Stock"],
    }
  },
  "production": {
    title: "Production Report",
    description: "Analyze production plans and manufacturing metrics",
    apiEndpoint: "/api/reports/production",
    columns: [
      { header: "Plan ID", dataKey: "id" },
      { header: "Name", dataKey: "name" },
      { header: "Start Date", dataKey: "start_date" },
      { header: "End Date", dataKey: "end_date" },
      { header: "Product", dataKey: "product_name" },
      { header: "Quantity", dataKey: "quantity" },
      { header: "Status", dataKey: "status" },
      { header: "Progress", dataKey: "progress" },
    ],
    filters: {
      date: true,
      status: ["All", "Planned", "In Progress", "Completed", "Cancelled"],
      product: true,
    }
  },
  "financial": {
    title: "Financial Report",
    description: "View financial data including revenue and expenses",
    apiEndpoint: "/api/reports/financial",
    columns: [
      { header: "Date", dataKey: "date" },
      { header: "Type", dataKey: "type" },
      { header: "Category", dataKey: "category" },
      { header: "Description", dataKey: "description" },
      { header: "Amount", dataKey: "amount" },
      { header: "Balance", dataKey: "balance" },
    ],
    filters: {
      date: true,
      type: ["All", "Revenue", "Expense", "Investment"],
      category: true,
    }
  },
};

export default function ReportsPage() {
  const [selectedReport, setSelectedReport] = useState("orders");
  const [dateRange, setDateRange] = useState({
    from: new Date(new Date().setDate(new Date().getDate() - 30)),
    to: new Date(),
  });
  const [selectedFormat, setSelectedFormat] = useState("pdf");
  const [selectedFilters, setSelectedFilters] = useState<{[key: string]: string}>({});
  const [includeCharts, setIncludeCharts] = useState(true);
  const [includeDetails, setIncludeDetails] = useState(true);
  const [includeHeaders, setIncludeHeaders] = useState(true);
  
  const reportConfig = REPORT_CONFIGS[selectedReport as keyof typeof REPORT_CONFIGS];
  
  // Fetch report data
  const { data: reportData, isLoading, refetch } = useQuery({
    queryKey: [reportConfig.apiEndpoint, dateRange, selectedFilters],
    queryFn: async () => {
      // Build query params
      const queryParams = new URLSearchParams();
      
      if (dateRange.from) {
        queryParams.append("fromDate", dateRange.from.toISOString());
      }
      if (dateRange.to) {
        queryParams.append("toDate", dateRange.to.toISOString());
      }
      
      // Add selected filters
      Object.entries(selectedFilters).forEach(([key, value]) => {
        if (value && value !== "All") {
          queryParams.append(key, value);
        }
      });
      
      const url = `${reportConfig.apiEndpoint}?${queryParams.toString()}`;
      return apiRequest(url);
    },
    // Don't auto-fetch on mount - we'll let the user configure filters first
    enabled: false,
  });

  const handleGenerateReport = () => {
    refetch();
  };
  
  const handleExport = () => {
    if (!reportData || reportData.length === 0) {
      return;
    }
    
    const filename = `${reportConfig.title.replace(/\s+/g, '-').toLowerCase()}_${new Date().toISOString().split('T')[0]}`;
    
    switch (selectedFormat) {
      case "pdf":
        exportToPDF(
          reportData,
          filename,
          reportConfig.columns,
          `${reportConfig.title} - ${new Date().toLocaleDateString()}`,
          includeHeaders,
          includeCharts
        );
        break;
      case "excel":
        exportToExcel(reportData, filename);
        break;
      case "csv":
        exportToCSV(reportData, filename);
        break;
    }
  };

  return (
    <AppLayout>
      <div className="container mx-auto py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Reports</h1>
          <p className="text-gray-500">
            Generate, customize, and export detailed reports from your data
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-4">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Report Selection</CardTitle>
                <CardDescription>Choose the report type and format</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Report Type Selection */}
                <div className="space-y-2">
                  <Label>Report Type</Label>
                  <Tabs 
                    defaultValue="orders" 
                    value={selectedReport} 
                    onValueChange={setSelectedReport} 
                    className="w-full"
                  >
                    <TabsList className="grid grid-cols-2 mb-4">
                      <TabsTrigger value="orders">Orders</TabsTrigger>
                      <TabsTrigger value="inventory">Inventory</TabsTrigger>
                      <TabsTrigger value="production">Production</TabsTrigger>
                      <TabsTrigger value="financial">Financial</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
                
                {/* Export Format */}
                <div className="space-y-2">
                  <Label>Export Format</Label>
                  <Select defaultValue="pdf" value={selectedFormat} onValueChange={setSelectedFormat}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">
                        <div className="flex items-center">
                          <FileText className="mr-2 h-4 w-4" />
                          <span>PDF</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="excel">
                        <div className="flex items-center">
                          <FileBarChart className="mr-2 h-4 w-4" />
                          <span>Excel</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="csv">
                        <div className="flex items-center">
                          <FileDown className="mr-2 h-4 w-4" />
                          <span>CSV</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {/* Date Range */}
                {reportConfig.filters.date && (
                  <div className="space-y-2">
                    <Label>Date Range</Label>
                    <DateRangePicker
                      date={dateRange}
                      setDate={setDateRange}
                    />
                  </div>
                )}
                
                {/* Status Filter */}
                {reportConfig.filters.status && (
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select 
                      defaultValue="All"
                      onValueChange={(value) => setSelectedFilters(prev => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        {reportConfig.filters.status.map((status) => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                {/* Category Filter */}
                {reportConfig.filters.category && (
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select 
                      defaultValue="All"
                      onValueChange={(value) => setSelectedFilters(prev => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {reportConfig.filters.category.map((category) => (
                          <SelectItem key={category} value={category}>{category}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                {/* Report Options */}
                <div className="space-y-2">
                  <Label>Report Options</Label>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeCharts" 
                      checked={includeCharts} 
                      onCheckedChange={() => setIncludeCharts(!includeCharts)} 
                    />
                    <Label htmlFor="includeCharts">Include Charts</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeDetails" 
                      checked={includeDetails} 
                      onCheckedChange={() => setIncludeDetails(!includeDetails)} 
                    />
                    <Label htmlFor="includeDetails">Include Details</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeHeaders" 
                      checked={includeHeaders} 
                      onCheckedChange={() => setIncludeHeaders(!includeHeaders)} 
                    />
                    <Label htmlFor="includeHeaders">Include Headers</Label>
                  </div>
                </div>
                
                {/* Generate Button */}
                <Button className="w-full" onClick={handleGenerateReport}>
                  Generate Report
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-3">
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{reportConfig.title}</CardTitle>
                    <CardDescription>{reportConfig.description}</CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleExport}
                      disabled={!reportData || reportData.length === 0}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Export
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      disabled={!reportData || reportData.length === 0}
                      onClick={() => window.print()}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {isLoading ? (
                  <div className="flex items-center justify-center h-80">
                    <div className="text-center">
                      <div className="spinner mb-4"></div>
                      <p>Generating report...</p>
                    </div>
                  </div>
                ) : reportData && reportData.length > 0 ? (
                  <div className="space-y-8">
                    {includeCharts && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Report Visualization</CardTitle>
                        </CardHeader>
                        <CardContent className="h-64 flex items-center justify-center">
                          <div className="text-center text-gray-500">
                            <BarChart className="mx-auto h-12 w-12 mb-2" />
                            <p>Chart visualization will appear here in the final report</p>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                    
                    {includeDetails && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Report Details</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="overflow-x-auto">
                            <table className="w-full border-collapse">
                              {includeHeaders && (
                                <thead>
                                  <tr className="bg-gray-100">
                                    {reportConfig.columns.map((column, index) => (
                                      <th key={index} className="p-2 text-left border font-medium text-gray-700">
                                        {column.header}
                                      </th>
                                    ))}
                                  </tr>
                                </thead>
                              )}
                              <tbody>
                                {reportData.slice(0, 7).map((row, rowIndex) => (
                                  <tr key={rowIndex} className={rowIndex % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                                    {reportConfig.columns.map((column, colIndex) => (
                                      <td key={colIndex} className="p-2 border text-gray-700">
                                        {row[column.dataKey]}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                                {reportData.length > 7 && (
                                  <tr>
                                    <td colSpan={reportConfig.columns.length} className="p-2 border text-center text-gray-500">
                                      ... and {reportData.length - 7} more rows
                                    </td>
                                  </tr>
                                )}
                              </tbody>
                            </table>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                    
                    <div className="text-center text-sm text-gray-500">
                      <p>Generated on {new Date().toLocaleString()}</p>
                      <p className="mt-1">This report contains {reportData.length} records</p>
                    </div>
                  </div>
                ) : (
                  <div className="h-80 flex items-center justify-center">
                    <Alert className="max-w-md">
                      <AlertDescription>
                        {!reportData ? (
                          <div className="text-center">
                            <p className="mb-2">Configure your report options and click 'Generate Report' to view data</p>
                            <Button className="mt-2" onClick={handleGenerateReport}>Generate Report</Button>
                          </div>
                        ) : (
                          <div className="text-center">
                            <p className="mb-2">No data found for the selected filters</p>
                            <Button className="mt-2" onClick={handleGenerateReport}>Try Different Filters</Button>
                          </div>
                        )}
                      </AlertDescription>
                    </Alert>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}