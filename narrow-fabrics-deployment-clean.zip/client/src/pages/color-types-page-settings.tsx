
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw, Plus, Edit, Trash } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ColorType } from "@shared/schema";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  is_active: z.boolean().default(true),
});

type FormValues = z.infer<typeof formSchema>;

export default function ColorTypesPageSettings() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [activeFilter, setActiveFilter] = useState<boolean | null>(null);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [editingColorType, setEditingColorType] = useState<ColorType | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [colorTypeToDelete, setColorTypeToDelete] = useState<number | null>(null);

  const {
    data: colorTypesData,
    isLoading,
    refetch,
  } = useQuery<{ colorTypes: ColorType[]; total: number }>({
    queryKey: ["/api/color-types", page, perPage, activeFilter],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, activeFilter] = queryKey;
      let url = `/api/color-types?page=${page}&limit=${perPage}`;
      if (activeFilter !== null) url += `&activeOnly=${activeFilter}`;
      
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch color types');
      }
      return res.json();
    },
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      is_active: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const res = await fetch("/api/color-types", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!res.ok) throw new Error("Failed to create color type");
      return res.json();
    },
    onSuccess: () => {
      toast({ description: "Color type created successfully" });
      setIsFormDialogOpen(false);
      form.reset();
      refetch();
    },
    onError: () => {
      toast({ variant: "destructive", description: "Failed to create color type" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: FormValues & { id: number }) => {
      const res = await fetch(`/api/color-types/${data.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!res.ok) throw new Error("Failed to update color type");
      return res.json();
    },
    onSuccess: () => {
      toast({ description: "Color type updated successfully" });
      setIsFormDialogOpen(false);
      setEditingColorType(null);
      form.reset();
      refetch();
    },
    onError: () => {
      toast({ variant: "destructive", description: "Failed to update color type" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/color-types/${id}`, {
        method: "DELETE",
        credentials: 'include',
      });
      if (!res.ok) throw new Error("Failed to delete color type");
      return res.json();
    },
    onSuccess: () => {
      toast({ description: "Color type deleted successfully" });
      setIsDeleteDialogOpen(false);
      setColorTypeToDelete(null);
      refetch();
    },
    onError: () => {
      toast({ variant: "destructive", description: "Failed to delete color type" });
    },
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  // Helper function to get badge variant based on status
  const getStatusBadgeVariant = (isActive: boolean): "default" | "destructive" | "outline" | "secondary" => {
    return isActive ? "default" : "destructive";
  };

  const handleCreate = () => {
    form.reset({ name: "", is_active: true });
    setEditingColorType(null);
    setIsFormDialogOpen(true);
  };

  const handleEdit = (colorType: ColorType) => {
    form.reset({
      name: colorType.name,
      is_active: colorType.is_active,
    });
    setEditingColorType(colorType);
    setIsFormDialogOpen(true);
  };

  const handleDeleteClick = (id: number) => {
    setColorTypeToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const onSubmit = (data: FormValues) => {
    if (editingColorType) {
      updateMutation.mutate({ ...data, id: editingColorType.id });
    } else {
      createMutation.mutate(data);
    }
  };

  const columns = [
    {
      header: "Name",
      accessorKey: "name" as keyof ColorType,
    },
    {
      header: "Status",
      accessorKey: "is_active" as keyof ColorType,
      cell: ({ row }: { row: ColorType }) => (
        <Badge variant={getStatusBadgeVariant(row.is_active)}>
          {row.is_active ? "Active" : "Inactive"}
        </Badge>
      ),
    },
    {
      header: "Created At",
      accessorKey: "created_at" as keyof ColorType,
      cell: ({ row }: { row: ColorType }) => formatDate(row.created_at),
    },
    {
      header: "Actions",
      cell: ({ row }: { row: ColorType }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => handleEdit(row)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteClick(row.id)}>
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <AppLayout
      title="Color Types Settings"
      description="Manage color types"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> New Color Type
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>        
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant={activeFilter === null ? "default" : "outline"} 
              onClick={() => setActiveFilter(null)}
              className={`h-10 ${activeFilter === null ? 'bg-primary text-primary-foreground' : ''}`}
            >
              All
            </Button>
            <Button 
              variant={activeFilter === true ? "default" : "outline"} 
              onClick={() => setActiveFilter(true)}
              className={`h-10 ${activeFilter === true ? 'bg-primary text-primary-foreground' : ''}`}
            >
              Active Only
            </Button>
            <Button 
              variant={activeFilter === false ? "default" : "outline"} 
              onClick={() => setActiveFilter(false)}
              className={`h-10 ${activeFilter === false ? 'bg-primary text-primary-foreground' : ''}`}
            >
              Inactive Only
            </Button>
          </div>
        </div>
      </div>

      <DataTable
        data={colorTypesData?.colorTypes || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          colorTypesData
            ? {
                currentPage: page,
                totalPages: Math.ceil(colorTypesData.total / perPage),
                totalItems: colorTypesData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />

      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingColorType ? "Edit Color Type" : "Create Color Type"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="is_active"
                render={({ field }) => (
                  <FormItem className="flex items-center space-x-2">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormLabel className="!mt-0">Active</FormLabel>
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsFormDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">
                  {editingColorType ? "Update" : "Create"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the color type.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (colorTypeToDelete) deleteMutation.mutate(colorTypeToDelete);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
