import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Edit, 
  Trash, 
  RefreshCw,
  Loader2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { YarnType, insertYarnTypeSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form schema
const formSchema = insertYarnTypeSchema;
type FormValues = z.infer<typeof formSchema>;

export default function YarnTypesPage() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [activeFilter, setActiveFilter] = useState<boolean | null>(null);
  const [search, setSearch] = useState("");
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [editingYarnType, setEditingYarnType] = useState<YarnType | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [yarnTypeToDelete, setYarnTypeToDelete] = useState<number | null>(null);

  // Fetch yarn types
  const {
    data: yarnTypesData,
    isLoading,
    refetch,
  } = useQuery<{ yarnTypes: YarnType[]; total: number }>({
    queryKey: ["/api/yarn-types", page, perPage, activeFilter],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, activeFilter] = queryKey;
      let url = `/api/yarn-types?page=${page}&limit=${perPage}`;
      if (activeFilter !== null) url += `&activeOnly=${activeFilter}`;
      
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch yarn types');
      }
      return res.json();
    },
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      is_active: true,
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest("POST", "/api/yarn-types", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Yarn type created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/yarn-types"] });
      setIsFormDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: FormValues }) => {
      const res = await apiRequest("PUT", `/api/yarn-types/${id}`, values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Yarn type updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/yarn-types"] });
      setIsFormDialogOpen(false);
      setEditingYarnType(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/yarn-types/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Yarn type deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/yarn-types"] });
      setIsDeleteDialogOpen(false);
      setYarnTypeToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle create button click
  const handleCreate = () => {
    form.reset({
      name: "",
      is_active: true,
    });
    setEditingYarnType(null);
    setIsFormDialogOpen(true);
  };

  // Handle edit button click
  const handleEdit = (yarnType: YarnType) => {
    form.reset({
      name: yarnType.name,
      is_active: yarnType.is_active,
    });
    setEditingYarnType(yarnType);
    setIsFormDialogOpen(true);
  };

  // Handle delete button click
  const handleDeleteClick = (id: number) => {
    setYarnTypeToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    if (yarnTypeToDelete !== null) {
      deleteMutation.mutate(yarnTypeToDelete);
    }
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    if (editingYarnType) {
      updateMutation.mutate({ id: editingYarnType.id, values });
    } else {
      createMutation.mutate(values);
    }
  };

  // Table columns definition
  const columns = [
    {
      header: "ID",
      accessorKey: "id" as keyof YarnType,
    },
    {
      header: "Name",
      accessorKey: "name" as keyof YarnType,
    },
    {
      header: "Status",
      accessorKey: "is_active" as keyof YarnType,
      cell: ({ row }: { row: YarnType }) => (
        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
          row.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {row.is_active ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      header: "Actions",
      cell: ({ row }: { row: YarnType }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => handleEdit(row)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteClick(row.id)}>
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <AppLayout
      title="Yarn Types"
      description="Manage yarn types for your materials"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> New Yarn Type
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant={activeFilter === null ? "default" : "outline"} 
              onClick={() => setActiveFilter(null)}
              className="h-10"
            >
              All
            </Button>
            <Button 
              variant={activeFilter === true ? "default" : "outline"} 
              onClick={() => setActiveFilter(true)}
              className="h-10"
            >
              Active Only
            </Button>
            <Button 
              variant={activeFilter === false ? "default" : "outline"} 
              onClick={() => setActiveFilter(false)}
              className="h-10"
            >
              Inactive Only
            </Button>
          </div>
        </div>
      </div>

      <DataTable
        data={yarnTypesData?.yarnTypes || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          yarnTypesData
            ? {
                currentPage: page,
                totalPages: Math.ceil(yarnTypesData.total / perPage),
                totalItems: yarnTypesData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />

      {/* Create/Edit Form Dialog */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingYarnType ? "Edit Yarn Type" : "Create Yarn Type"}
            </DialogTitle>
            <DialogDescription>
              {editingYarnType
                ? "Update the yarn type details below."
                : "Fill in the details to create a new yarn type."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Yarn type name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="is_active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Inactive yarn types won't be available for selection in materials.
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {(createMutation.isPending || updateMutation.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {editingYarnType ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    editingYarnType ? "Update" : "Create"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the yarn type. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
