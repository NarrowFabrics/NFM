import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { ProductionPlan, insertProductionPlanSchema, ItemUnit } from "@shared/schema";
import AppLayout from "@/components/layout/app-layout";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Scan, Camera, ScanSearch, Download, FileSpreadsheet, FileText, Check, AlertCircle } from "lucide-react";
import { exportToCSV, exportToExcel, exportToPDF, generateFilename } from "@/lib/export-utils";

// UI Components
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";

// Icons
import {
  Banknote,
  Briefcase,
  Building,
  Calendar,
  CalendarClock,
  DollarSign,
  Factory,
  HelpCircle,
  Mail,
  MapPin,
  MessageSquare,
  Phone,
  Plus,
  Printer,
  RefreshCw,
  Save,
  Settings,
  Trash,
  Trash2,
  User,
  UserCircle,
  Users,
} from "lucide-react";

// Form schema for quotation
const quotationFormSchema = z.object({
  date: z.string().min(1, "Date is required"),
  quotationNumber: z.string().min(1, "Quotation number is required"),
  creatorName: z.string().min(1, "Creator name is required"),
  factoryName: z.string().min(1, "Factory name is required"),
  buyerName: z.string().optional(),
  buyerType: z.string().optional(),
  otherBuyerType: z.string().optional(),
  merchantName: z.string().optional(),
  jobRole: z.string().optional(),
  otherJobRole: z.string().optional(),
  department: z.string().optional(),
  buyerEmail: z.string().email("Invalid email address").optional().or(z.literal("")),
  countryCode: z.string().default("+880"),
  buyerPhone: z.string().optional(),
  buyerAddress: z.string().optional(),
  inquiryType: z.string().min(1, "Inquiry type is required"),
  preferredCurrency: z.string().optional(),
  paymentTerms: z.string().optional(),
  remarks: z.string().optional(),
  articleNumber: z.string().optional(),
  productionUnit: z.string().min(1, "Production unit is required"),
  itemName: z.string().min(1, "Item name is required"),
  sizeWidth: z.coerce.number().min(0, "Size/Width must be a positive number"),
  weightGramYds: z.coerce.number().min(0, "Weight must be a positive number"),
  pricePerYds: z.coerce.number().min(0, "Price must be a positive number"),
}).refine((data) => {
  // Only require payment terms and currency for Price Inquiry and Bulk Order
  if (data.inquiryType === 'price' || data.inquiryType === 'bulk') {
    return !!data.paymentTerms && !!data.preferredCurrency;
  }
  // For Sample Request and Technical Query, these fields are optional
  return true;
}, {
  message: "Payment Terms and Preferred Currency are required for Price Inquiry and Bulk Order",
  path: ["paymentTerms", "preferredCurrency"]
});

type QuotationFormValues = z.infer<typeof quotationFormSchema>;

// Settings schema
const settingsFormSchema = z.object({
  usdConversionRate: z.coerce.number().min(1, "Conversion rate must be positive"),
  sizeUnit: z.enum(["MM", "CM"]),
  lengthUnit: z.enum(["YDS", "MTR"]),
  priceCurrency: z.enum(["USD", "TK"]),
  additionalPrice: z.coerce.number().min(0, "Additional price must be non-negative"),
});

type SettingsFormValues = z.infer<typeof settingsFormSchema>;

// Elastic parts schema
type ElasticPart = {
  id: number;
  part: string;
  yarnCategory: string;
  yarnCount: string;
  color: string;
  weight: string;
  priceUsd: string;
  priceBdt: string;
  remarks: string;
};

export default function PriceQuotationPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSettingsDialogOpen, setIsSettingsDialogOpen] = useState(false);
  const [isScannerDialogOpen, setIsScannerDialogOpen] = useState(false);
  const [elasticParts, setElasticParts] = useState<ElasticPart[]>([
    { id: 1, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
    { id: 2, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
    { id: 3, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
    { id: 4, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
  ]);
  const printRef = useRef<HTMLDivElement>(null);
  
  // Auto-save related states
  const [autoSaveEnabled, setAutoSaveEnabled] = useState<boolean>(true);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [savingStatus, setSavingStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const autoSaveIntervalRef = useRef<number | null>(null); // For cleanup
  
  // Generate formatted date (DD MMM YY)
  const generateFormattedDate = () => {
    const now = new Date();
    return now.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: '2-digit'
    }).replace(/ /g, ' ');
  };

  // Generate quotation number with format "Jist-DD MMM YY-Users_Full_name-0001"
  const generateQuotationNumber = () => {
    const dateFormat = generateFormattedDate();
    const userName = user?.name?.replace(/\s/g, '_') || 'User';
    return `Jist-${dateFormat}-${userName}-0001`;
  };

  // Generate Article Number 
  const generateArticleNumber = (unit: string, item: string, width: number): string => {
    // Unit code mapping
    const unitCodeMap: Record<string, string> = {
      "Jacquard Loom": "J",
      "Needle Loom": "N",
      "Crochet Machine": "C", 
      "Drawstring Machine": "D",
      "Screen Print": "N_P",
      "Embossed/Heat Print": "N_EM",
      // Default to first letter of unit if not found
      "unit1": "U1",
      "unit2": "U2",
      "unit3": "U3"
    };
    
    // Get unit code, default to "X" if not found
    const unitCode = unitCodeMap[unit] || "X";
    
    // Item code - use first 3 chars or whole string if shorter
    const itemCode = item.length > 3 ? item.substring(0, 3).toUpperCase() : item.toUpperCase();
    
    // Generate a unique code (timestamp-based for simplicity)
    const uniqueCode = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    
    // Format: Jist-[UnitCode]-[ItemCode]-[UniqueCode]-[Width]
    return `Jist-${unitCode}-${itemCode}-${uniqueCode}-${width || 0}`;
  };
  
  // Handle scan business card
  const handleScanBusinessCard = () => {
    // Check if device has camera
    const hasCamera = navigator.mediaDevices && 'getUserMedia' in navigator.mediaDevices;
    
    if (hasCamera) {
      setIsScannerDialogOpen(true);
      toast({
        title: "Scanner opened",
        description: "Position the business card within the frame to scan.",
      });
      
      // In a real implementation, we would activate the camera and use OCR to extract data
      // For this demo, we'll simulate a successful scan after a delay
      setTimeout(() => {
        // Simulate extracted data from a business card
        const sampleData = {
          factoryName: "Textile Express Ltd.",
          buyerName: "John Doe",
          merchantName: "Jane Smith",
          department: "Procurement",
          buyerPhone: "9876543",
          countryCode: "+1",
          buyerEmail: "john.doe@textileexpress.com",
          buyerAddress: "123 Fabric Street, Textile City, TC 12345"
        };
        
        // Populate the form with the extracted data
        form.setValue("factoryName", sampleData.factoryName);
        form.setValue("buyerName", sampleData.buyerName);
        form.setValue("merchantName", sampleData.merchantName);
        form.setValue("department", sampleData.department);
        form.setValue("buyerPhone", sampleData.buyerPhone);
        form.setValue("countryCode", sampleData.countryCode);
        form.setValue("buyerEmail", sampleData.buyerEmail);
        form.setValue("buyerAddress", sampleData.buyerAddress);
        
        // Close the dialog
        setIsScannerDialogOpen(false);
        
        toast({
          title: "Scan completed",
          description: "Buyer information has been extracted and filled in the form.",
        });
      }, 2000);
    } else {
      toast({
        title: "Camera not available",
        description: "Your device doesn't have a camera or permission was denied.",
        variant: "destructive",
      });
    }
  };

  // Settings state
  const [settings, setSettings] = useState<SettingsFormValues>({
    usdConversionRate: 110,
    sizeUnit: "MM",
    lengthUnit: "YDS",
    priceCurrency: "USD",
    additionalPrice: 30,
  });

  // Settings form
  const settingsForm = useForm<SettingsFormValues>({
    resolver: zodResolver(settingsFormSchema),
    defaultValues: settings,
  });

  // Fetch production units from narrow fabrics settings
  // Maps Unit field to Production Unit
  const { data: productionUnits } = useQuery({
    queryKey: ["/api/settings/production-units"],
    select: (data: any) => {
      const settings = data?.settings || [];
      // Map the settings data to make it compatible with our form
      return settings.map((unit: any) => ({
        ...unit,
        // Use unit's name property for display and value
        name: unit.name
      }));
    },
  });

  // Initialize main quotation form
  const form = useForm<QuotationFormValues>({
    resolver: zodResolver(quotationFormSchema),
    defaultValues: {
      date: new Date().toISOString().split("T")[0],
      quotationNumber: generateQuotationNumber(),
      creatorName: user?.name || "",
      factoryName: "",
      buyerName: "",
      buyerType: "",
      otherBuyerType: "",
      merchantName: "",
      jobRole: "",
      otherJobRole: "",
      department: "",
      buyerEmail: "",
      countryCode: "+880",
      buyerPhone: "",
      buyerAddress: "",
      preferredCurrency: "",
      paymentTerms: "",
      inquiryType: "",
      remarks: "",
      articleNumber: "",
      productionUnit: "",
      itemName: "",
      sizeWidth: 0,
      weightGramYds: 0,
      pricePerYds: 0,
    },
  });
  
  // Get the selected production unit to use for filtering items
  const selectedProductionUnit = form.watch("productionUnit");

  // Fetch items from our dedicated Items endpoint, filtered by production unit
  const { data: itemsList, error: itemsError } = useQuery({
    queryKey: ["/api/items-data", selectedProductionUnit], // Include production unit in query key for proper caching
    queryFn: async () => {
      // Create URL with query parameter if production unit is selected
      const url = selectedProductionUnit 
        ? `/api/items-data?productionUnit=${encodeURIComponent(selectedProductionUnit)}`
        : '/api/items-data';
      return apiRequest(url);
    },
    select: (data: any) => {
      console.log("Items data from API:", data);
      const items = data?.items || [];
      // Map the items data to make it compatible with our form
      return items.map((item: any) => ({
        id: item.id,
        name: item.name,
        unit: item.unit,
        description: item.description,
        is_active: item.is_active
      }));
    },
    onError: (error) => {
      console.error("Error fetching items:", error);
    },
    enabled: true, // Always fetch initially, then re-fetch when production unit changes
  });

  // Fallback to item units if narrow fabrics data is not available
  const { data: itemUnits } = useQuery({
    queryKey: ["/api/item-units"],
    select: (data: any) => data?.itemUnits || [],
  });
  
  // Fetch fabric parts for elastic parts dropdown
  const { data: fabricParts } = useQuery({
    queryKey: ["/api/settings/fabric-parts"],
    select: (data: any) => data?.fabricParts || [],
  });
  
  // Fetch yarn categories for dropdown
  const { data: yarnCategories } = useQuery({
    queryKey: ["/api/settings/yarn-categories"],
    select: (data: any) => data?.categories || [],
  });
  
  // Fetch yarn counts for dropdown
  const { data: yarnCounts } = useQuery({
    queryKey: ["/api/settings/yarn-counts"],
    select: (data: any) => data?.counts || [],
  });
  
  // Fetch color types for dropdown
  const { data: colorTypes } = useQuery({
    queryKey: ["/api/settings/color-types"],
    select: (data: any) => data?.colorTypes || [],
  });

  // Form already defined earlier in the code

  // Watch for changes in production unit and item name to auto-generate article number
  useEffect(() => {
    // Set up a subscription to watch for changes in these fields
    const subscription = form.watch((value, { name }) => {
      if (name === "productionUnit" || name === "itemName" || name === "sizeWidth") {
        const productionUnit = form.getValues("productionUnit");
        const itemName = form.getValues("itemName");
        const sizeWidth = form.getValues("sizeWidth");
        
        if (productionUnit && itemName) {
          const articleNumber = generateArticleNumber(productionUnit, itemName, sizeWidth);
          form.setValue("articleNumber", articleNumber);
        }
      }
    });
    
    // Clean up subscription on unmount
    return () => subscription.unsubscribe();
  }, [form]);
  
  // Auto-save handler function
  const performAutoSave = () => {
    if (!autoSaveEnabled) return;
    
    // Only auto-save if we have some minimum required fields
    // This prevents saving empty/incomplete forms
    const values = form.getValues();
    const hasMinimumData = values.factoryName || values.buyerName || values.productionUnit || values.itemName;
    
    if (!hasMinimumData) return;
    
    // Check form validity before saving
    const isValid = form.formState.isValid;
    
    // For auto-save, we'll still save even if some validation fails
    // This ensures user never loses data while working
    autoSaveMutation.mutate({
      ...values,
      elasticParts,
    });
  };
  
  // Set up auto-save interval
  useEffect(() => {
    if (autoSaveEnabled) {
      // Auto-save every 30 seconds
      const intervalId = window.setInterval(() => {
        performAutoSave();
      }, 30000);
      
      autoSaveIntervalRef.current = intervalId;
      
      return () => {
        if (autoSaveIntervalRef.current) {
          window.clearInterval(autoSaveIntervalRef.current);
        }
      };
    }
    
    return undefined;
  }, [autoSaveEnabled, form, elasticParts]);
  
  // Auto-save on form field changes after debounce
  useEffect(() => {
    if (!autoSaveEnabled) return undefined;
    
    // Create a timeout to auto-save after changes with debounce
    const subscription = form.watch(() => {
      // If user is actively typing, don't save immediately
      setSavingStatus('idle');
      
      // Set a debounce timeout for auto-save (3 seconds after last change)
      const timeoutId = window.setTimeout(() => {
        performAutoSave();
      }, 3000);
      
      return () => {
        window.clearTimeout(timeoutId);
      };
    });
    
    return () => {
      subscription.unsubscribe();
    };
  }, [autoSaveEnabled, form, elasticParts]);
  
  // Helper function to map form values to API data structure
  const mapFormToApiData = (values: QuotationFormValues, parts: ElasticPart[]) => {
    return {
      reference_no: values.quotationNumber,
      customer_type: values.buyerType || undefined,
      customer_name: values.buyerName || values.factoryName,
      customer_contact: values.countryCode + values.buyerPhone,
      customer_email: values.buyerEmail,
      customer_address: values.buyerAddress,
      
      contact_person: values.merchantName,
      contact_designation: values.jobRole,
      
      inquiry_type: values.inquiryType,
      production_unit: values.productionUnit,
      item_name: values.itemName,
      size_width: values.sizeWidth,
      size_unit: settings.sizeUnit,
      weight_gram_yds: values.weightGramYds,
      length_unit: settings.lengthUnit,
      
      price_per_unit: values.pricePerYds,
      price_currency: settings.priceCurrency,
      additional_price_percentage: settings.additionalPrice,
      payment_terms: values.paymentTerms,
      remarks: values.remarks,
      article_number: values.articleNumber,
      
      elastic_parts_data: parts,
      is_active: true
    };
  };

  // Auto-save mutation for quietly saving in the background
  const autoSaveMutation = useMutation({
    mutationFn: async (values: QuotationFormValues & { elasticParts: ElasticPart[] }) => {
      const quotationData = mapFormToApiData(values, values.elasticParts);
      
      return apiRequest('/api/quotations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(quotationData)
      });
    },
    onMutate: () => {
      setSavingStatus('saving');
    },
    onSuccess: (data) => {
      setSavingStatus('saved');
      setLastSaved(new Date());
      // No user-visible toast for auto-save
    },
    onError: (error: Error) => {
      console.error("Auto-save error:", error);
      setSavingStatus('error');
      // Optional: silent error handling, or a less intrusive notification
      // toast({
      //   title: "Auto-save failed",
      //   description: "Your changes couldn't be saved automatically. They will be saved when you submit the form.",
      //   variant: "destructive",
      // });
    },
  });
  
  // Create mutation for manual saving the quotation (with user feedback)
  const saveMutation = useMutation({
    mutationFn: async (values: QuotationFormValues & { elasticParts: ElasticPart[] }) => {
      // Map form data to API structure
      const quotationData = mapFormToApiData(values, values.elasticParts);
      
      return apiRequest('/api/quotations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(quotationData)
      });
    },
    onSuccess: (data) => {
      setSavingStatus('saved');
      setLastSaved(new Date());
      toast({
        title: "Success",
        description: "Quotation saved successfully!",
      });
      // Reset form or redirect to list page
      // form.reset();
    },
    onError: (error: Error) => {
      setSavingStatus('error');
      console.error("Error saving quotation:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to save quotation. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle settings form submission
  const onSettingsSubmit = (values: SettingsFormValues) => {
    setSettings(values);
    setIsSettingsDialogOpen(false);
    toast({
      title: "Settings updated",
      description: "Your quotation settings have been updated.",
    });
  };

  // Handle main form submission
  const onSubmit = (values: QuotationFormValues) => {
    saveMutation.mutate({
      ...values,
      elasticParts,
    });
  };

  // Country data for phone number dropdown
  const countryData = [
    { id: "af", code: "+93", name: "Afghanistan", shortForm: "AFG", flag: "af" },
    { id: "al", code: "+355", name: "Albania", shortForm: "ALB", flag: "al" },
    { id: "dz", code: "+213", name: "Algeria", shortForm: "DZA", flag: "dz" },
    { id: "ad", code: "+376", name: "Andorra", shortForm: "AND", flag: "ad" },
    { id: "ao", code: "+244", name: "Angola", shortForm: "AGO", flag: "ao" },
    { id: "ar", code: "+54", name: "Argentina", shortForm: "ARG", flag: "ar" },
    { id: "am", code: "+374", name: "Armenia", shortForm: "ARM", flag: "am" },
    { id: "au", code: "+61", name: "Australia", shortForm: "AUS", flag: "au" },
    { id: "at", code: "+43", name: "Austria", shortForm: "AUT", flag: "at" },
    { id: "az", code: "+994", name: "Azerbaijan", shortForm: "AZE", flag: "az" },
    { id: "bh", code: "+973", name: "Bahrain", shortForm: "BHR", flag: "bh" },
    { id: "bd", code: "+880", name: "Bangladesh", shortForm: "BGD", flag: "bd" },
    { id: "by", code: "+375", name: "Belarus", shortForm: "BLR", flag: "by" },
    { id: "be", code: "+32", name: "Belgium", shortForm: "BEL", flag: "be" },
    { id: "bz", code: "+501", name: "Belize", shortForm: "BLZ", flag: "bz" },
    { id: "bj", code: "+229", name: "Benin", shortForm: "BEN", flag: "bj" },
    { id: "bt", code: "+975", name: "Bhutan", shortForm: "BTN", flag: "bt" },
    { id: "bo", code: "+591", name: "Bolivia", shortForm: "BOL", flag: "bo" },
    { id: "ba", code: "+387", name: "Bosnia", shortForm: "BIH", flag: "ba" },
    { id: "bw", code: "+267", name: "Botswana", shortForm: "BWA", flag: "bw" },
    { id: "br", code: "+55", name: "Brazil", shortForm: "BRA", flag: "br" },
    { id: "bn", code: "+673", name: "Brunei", shortForm: "BRN", flag: "bn" },
    { id: "bg", code: "+359", name: "Bulgaria", shortForm: "BGR", flag: "bg" },
    { id: "bf", code: "+226", name: "Burkina Faso", shortForm: "BFA", flag: "bf" },
    { id: "bi", code: "+257", name: "Burundi", shortForm: "BDI", flag: "bi" },
    { id: "kh", code: "+855", name: "Cambodia", shortForm: "KHM", flag: "kh" },
    { id: "cm", code: "+237", name: "Cameroon", shortForm: "CMR", flag: "cm" },
    { id: "ca", code: "+1", name: "Canada", shortForm: "CAN", flag: "ca" },
    { id: "cv", code: "+238", name: "Cape Verde", shortForm: "CPV", flag: "cv" },
    { id: "cf", code: "+236", name: "Central African Rep.", shortForm: "CAF", flag: "cf" },
    { id: "td", code: "+235", name: "Chad", shortForm: "TCD", flag: "td" },
    { id: "cl", code: "+56", name: "Chile", shortForm: "CHL", flag: "cl" },
    { id: "cn", code: "+86", name: "China", shortForm: "CHN", flag: "cn" },
    { id: "co", code: "+57", name: "Colombia", shortForm: "COL", flag: "co" },
    { id: "km", code: "+269", name: "Comoros", shortForm: "COM", flag: "km" },
    { id: "cg", code: "+242", name: "Congo", shortForm: "COG", flag: "cg" },
    { id: "cr", code: "+506", name: "Costa Rica", shortForm: "CRI", flag: "cr" },
    { id: "hr", code: "+385", name: "Croatia", shortForm: "HRV", flag: "hr" },
    { id: "cu", code: "+53", name: "Cuba", shortForm: "CUB", flag: "cu" },
    { id: "cy", code: "+357", name: "Cyprus", shortForm: "CYP", flag: "cy" },
    { id: "cz", code: "+420", name: "Czech Republic", shortForm: "CZE", flag: "cz" },
    { id: "dk", code: "+45", name: "Denmark", shortForm: "DNK", flag: "dk" },
    { id: "dj", code: "+253", name: "Djibouti", shortForm: "DJI", flag: "dj" },
    { id: "do", code: "+1809", name: "Dominican Republic", shortForm: "DOM", flag: "do" },
    { id: "ec", code: "+593", name: "Ecuador", shortForm: "ECU", flag: "ec" },
    { id: "eg", code: "+20", name: "Egypt", shortForm: "EGY", flag: "eg" },
    { id: "sv", code: "+503", name: "El Salvador", shortForm: "SLV", flag: "sv" },
    { id: "gq", code: "+240", name: "Equatorial Guinea", shortForm: "GNQ", flag: "gq" },
    { id: "er", code: "+291", name: "Eritrea", shortForm: "ERI", flag: "er" },
    { id: "ee", code: "+372", name: "Estonia", shortForm: "EST", flag: "ee" },
    { id: "et", code: "+251", name: "Ethiopia", shortForm: "ETH", flag: "et" },
    { id: "fj", code: "+679", name: "Fiji", shortForm: "FJI", flag: "fj" },
    { id: "fi", code: "+358", name: "Finland", shortForm: "FIN", flag: "fi" },
    { id: "fr", code: "+33", name: "France", shortForm: "FRA", flag: "fr" },
    { id: "ga", code: "+241", name: "Gabon", shortForm: "GAB", flag: "ga" },
    { id: "gm", code: "+220", name: "Gambia", shortForm: "GMB", flag: "gm" },
    { id: "ge", code: "+995", name: "Georgia", shortForm: "GEO", flag: "ge" },
    { id: "de", code: "+49", name: "Germany", shortForm: "DEU", flag: "de" },
    { id: "gh", code: "+233", name: "Ghana", shortForm: "GHA", flag: "gh" },
    { id: "gr", code: "+30", name: "Greece", shortForm: "GRC", flag: "gr" },
    { id: "gt", code: "+502", name: "Guatemala", shortForm: "GTM", flag: "gt" },
    { id: "gn", code: "+224", name: "Guinea", shortForm: "GIN", flag: "gn" },
    { id: "gy", code: "+592", name: "Guyana", shortForm: "GUY", flag: "gy" },
    { id: "ht", code: "+509", name: "Haiti", shortForm: "HTI", flag: "ht" },
    { id: "hn", code: "+504", name: "Honduras", shortForm: "HND", flag: "hn" },
    { id: "hk", code: "+852", name: "Hong Kong", shortForm: "HKG", flag: "hk" },
    { id: "hu", code: "+36", name: "Hungary", shortForm: "HUN", flag: "hu" },
    { id: "is", code: "+354", name: "Iceland", shortForm: "ISL", flag: "is" },
    { id: "in", code: "+91", name: "India", shortForm: "IND", flag: "in" },
    { id: "id", code: "+62", name: "Indonesia", shortForm: "IDN", flag: "id" },
    { id: "ir", code: "+98", name: "Iran", shortForm: "IRN", flag: "ir" },
    { id: "iq", code: "+964", name: "Iraq", shortForm: "IRQ", flag: "iq" },
    { id: "ie", code: "+353", name: "Ireland", shortForm: "IRL", flag: "ie" },
    { id: "il", code: "+972", name: "Israel", shortForm: "ISR", flag: "il" },
    { id: "it", code: "+39", name: "Italy", shortForm: "ITA", flag: "it" },
    { id: "ci", code: "+225", name: "Ivory Coast", shortForm: "CIV", flag: "ci" },
    { id: "jm", code: "+1876", name: "Jamaica", shortForm: "JAM", flag: "jm" },
    { id: "jp", code: "+81", name: "Japan", shortForm: "JPN", flag: "jp" },
    { id: "jo", code: "+962", name: "Jordan", shortForm: "JOR", flag: "jo" },
    { id: "kz", code: "+7", name: "Kazakhstan", shortForm: "KAZ", flag: "kz" },
    { id: "ke", code: "+254", name: "Kenya", shortForm: "KEN", flag: "ke" },
    { id: "kw", code: "+965", name: "Kuwait", shortForm: "KWT", flag: "kw" },
    { id: "kg", code: "+996", name: "Kyrgyzstan", shortForm: "KGZ", flag: "kg" },
    { id: "la", code: "+856", name: "Laos", shortForm: "LAO", flag: "la" },
    { id: "lv", code: "+371", name: "Latvia", shortForm: "LVA", flag: "lv" },
    { id: "lb", code: "+961", name: "Lebanon", shortForm: "LBN", flag: "lb" },
    { id: "ls", code: "+266", name: "Lesotho", shortForm: "LSO", flag: "ls" },
    { id: "lr", code: "+231", name: "Liberia", shortForm: "LBR", flag: "lr" },
    { id: "ly", code: "+218", name: "Libya", shortForm: "LBY", flag: "ly" },
    { id: "lt", code: "+370", name: "Lithuania", shortForm: "LTU", flag: "lt" },
    { id: "lu", code: "+352", name: "Luxembourg", shortForm: "LUX", flag: "lu" },
    { id: "mo", code: "+853", name: "Macau", shortForm: "MAC", flag: "mo" },
    { id: "mk", code: "+389", name: "Macedonia", shortForm: "MKD", flag: "mk" },
    { id: "mg", code: "+261", name: "Madagascar", shortForm: "MDG", flag: "mg" },
    { id: "mw", code: "+265", name: "Malawi", shortForm: "MWI", flag: "mw" },
    { id: "my", code: "+60", name: "Malaysia", shortForm: "MYS", flag: "my" },
    { id: "mv", code: "+960", name: "Maldives", shortForm: "MDV", flag: "mv" },
    { id: "ml", code: "+223", name: "Mali", shortForm: "MLI", flag: "ml" },
    { id: "mt", code: "+356", name: "Malta", shortForm: "MLT", flag: "mt" },
    { id: "mr", code: "+222", name: "Mauritania", shortForm: "MRT", flag: "mr" },
    { id: "mu", code: "+230", name: "Mauritius", shortForm: "MUS", flag: "mu" },
    { id: "mx", code: "+52", name: "Mexico", shortForm: "MEX", flag: "mx" },
    { id: "md", code: "+373", name: "Moldova", shortForm: "MDA", flag: "md" },
    { id: "mc", code: "+377", name: "Monaco", shortForm: "MCO", flag: "mc" },
    { id: "mn", code: "+976", name: "Mongolia", shortForm: "MNG", flag: "mn" },
    { id: "me", code: "+382", name: "Montenegro", shortForm: "MNE", flag: "me" },
    { id: "ma", code: "+212", name: "Morocco", shortForm: "MAR", flag: "ma" },
    { id: "mz", code: "+258", name: "Mozambique", shortForm: "MOZ", flag: "mz" },
    { id: "mm", code: "+95", name: "Myanmar", shortForm: "MMR", flag: "mm" },
    { id: "na", code: "+264", name: "Namibia", shortForm: "NAM", flag: "na" },
    { id: "np", code: "+977", name: "Nepal", shortForm: "NPL", flag: "np" },
    { id: "nl", code: "+31", name: "Netherlands", shortForm: "NLD", flag: "nl" },
    { id: "nz", code: "+64", name: "New Zealand", shortForm: "NZL", flag: "nz" },
    { id: "ni", code: "+505", name: "Nicaragua", shortForm: "NIC", flag: "ni" },
    { id: "ne", code: "+227", name: "Niger", shortForm: "NER", flag: "ne" },
    { id: "ng", code: "+234", name: "Nigeria", shortForm: "NGA", flag: "ng" },
    { id: "kp", code: "+850", name: "North Korea", shortForm: "PRK", flag: "kp" },
    { id: "no", code: "+47", name: "Norway", shortForm: "NOR", flag: "no" },
    { id: "om", code: "+968", name: "Oman", shortForm: "OMN", flag: "om" },
    { id: "pk", code: "+92", name: "Pakistan", shortForm: "PAK", flag: "pk" },
    { id: "ps", code: "+970", name: "Palestine", shortForm: "PSE", flag: "ps" },
    { id: "pa", code: "+507", name: "Panama", shortForm: "PAN", flag: "pa" },
    { id: "pg", code: "+675", name: "Papua New Guinea", shortForm: "PNG", flag: "pg" },
    { id: "py", code: "+595", name: "Paraguay", shortForm: "PRY", flag: "py" },
    { id: "pe", code: "+51", name: "Peru", shortForm: "PER", flag: "pe" },
    { id: "ph", code: "+63", name: "Philippines", shortForm: "PHL", flag: "ph" },
    { id: "pl", code: "+48", name: "Poland", shortForm: "POL", flag: "pl" },
    { id: "pt", code: "+351", name: "Portugal", shortForm: "PRT", flag: "pt" },
    { id: "qa", code: "+974", name: "Qatar", shortForm: "QAT", flag: "qa" },
    { id: "ro", code: "+40", name: "Romania", shortForm: "ROU", flag: "ro" },
    { id: "ru", code: "+7", name: "Russia", shortForm: "RUS", flag: "ru" },
    { id: "rw", code: "+250", name: "Rwanda", shortForm: "RWA", flag: "rw" },
    { id: "sa", code: "+966", name: "Saudi Arabia", shortForm: "SAU", flag: "sa" },
    { id: "sn", code: "+221", name: "Senegal", shortForm: "SEN", flag: "sn" },
    { id: "rs", code: "+381", name: "Serbia", shortForm: "SRB", flag: "rs" },
    { id: "sl", code: "+232", name: "Sierra Leone", shortForm: "SLE", flag: "sl" },
    { id: "sg", code: "+65", name: "Singapore", shortForm: "SGP", flag: "sg" },
    { id: "sk", code: "+421", name: "Slovakia", shortForm: "SVK", flag: "sk" },
    { id: "si", code: "+386", name: "Slovenia", shortForm: "SVN", flag: "si" },
    { id: "so", code: "+252", name: "Somalia", shortForm: "SOM", flag: "so" },
    { id: "za", code: "+27", name: "South Africa", shortForm: "ZAF", flag: "za" },
    { id: "kr", code: "+82", name: "South Korea", shortForm: "KOR", flag: "kr" },
    { id: "ss", code: "+211", name: "South Sudan", shortForm: "SSD", flag: "ss" },
    { id: "es", code: "+34", name: "Spain", shortForm: "ESP", flag: "es" },
    { id: "lk", code: "+94", name: "Sri Lanka", shortForm: "LKA", flag: "lk" },
    { id: "sd", code: "+249", name: "Sudan", shortForm: "SDN", flag: "sd" },
    { id: "sr", code: "+597", name: "Suriname", shortForm: "SUR", flag: "sr" },
    { id: "sz", code: "+268", name: "Swaziland", shortForm: "SWZ", flag: "sz" },
    { id: "se", code: "+46", name: "Sweden", shortForm: "SWE", flag: "se" },
    { id: "ch", code: "+41", name: "Switzerland", shortForm: "CHE", flag: "ch" },
    { id: "sy", code: "+963", name: "Syria", shortForm: "SYR", flag: "sy" },
    { id: "tw", code: "+886", name: "Taiwan", shortForm: "TWN", flag: "tw" },
    { id: "tj", code: "+992", name: "Tajikistan", shortForm: "TJK", flag: "tj" },
    { id: "tz", code: "+255", name: "Tanzania", shortForm: "TZA", flag: "tz" },
    { id: "th", code: "+66", name: "Thailand", shortForm: "THA", flag: "th" },
    { id: "tg", code: "+228", name: "Togo", shortForm: "TGO", flag: "tg" },
    { id: "tn", code: "+216", name: "Tunisia", shortForm: "TUN", flag: "tn" },
    { id: "tr", code: "+90", name: "Turkey", shortForm: "TUR", flag: "tr" },
    { id: "tm", code: "+993", name: "Turkmenistan", shortForm: "TKM", flag: "tm" },
    { id: "ug", code: "+256", name: "Uganda", shortForm: "UGA", flag: "ug" },
    { id: "ua", code: "+380", name: "Ukraine", shortForm: "UKR", flag: "ua" },
    { id: "ae", code: "+971", name: "United Arab Emirates", shortForm: "ARE", flag: "ae" },
    { id: "gb", code: "+44", name: "United Kingdom", shortForm: "GBR", flag: "gb" },
    { id: "us", code: "+1", name: "United States", shortForm: "USA", flag: "us" },
    { id: "uy", code: "+598", name: "Uruguay", shortForm: "URY", flag: "uy" },
    { id: "uz", code: "+998", name: "Uzbekistan", shortForm: "UZB", flag: "uz" },
    { id: "ve", code: "+58", name: "Venezuela", shortForm: "VEN", flag: "ve" },
    { id: "vn", code: "+84", name: "Vietnam", shortForm: "VNM", flag: "vn" },
    { id: "ye", code: "+967", name: "Yemen", shortForm: "YEM", flag: "ye" },
    { id: "zm", code: "+260", name: "Zambia", shortForm: "ZMB", flag: "zm" },
    { id: "zw", code: "+263", name: "Zimbabwe", shortForm: "ZWE", flag: "zw" },
  ];

  // Update elastic part
  const updateElasticPart = (id: number, field: keyof ElasticPart, value: string) => {
    setElasticParts(
      elasticParts.map((part) =>
        part.id === id ? { ...part, [field]: value } : part
      )
    );
  };

  // Add new elastic part row
  const addElasticPart = () => {
    if (elasticParts.length < 5) {
      const newId = Math.max(...elasticParts.map((p) => p.id)) + 1;
      setElasticParts([
        ...elasticParts,
        { id: newId, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
      ]);
    }
  };

  // Remove elastic part row
  const removeElasticPart = (id: number) => {
    if (elasticParts.length > 1) {
      setElasticParts(elasticParts.filter((part) => part.id !== id));
    }
  };

  // Reset form
  const resetForm = () => {
    form.reset({
      date: new Date().toISOString().split("T")[0],
      quotationNumber: generateQuotationNumber(),
      creatorName: user?.name || "",
      factoryName: "",
      buyerName: "",
      buyerType: "",
      otherBuyerType: "",
      merchantName: "",
      jobRole: "",
      otherJobRole: "",
      department: "",
      buyerEmail: "",
      countryCode: "+880",
      buyerPhone: "",
      buyerAddress: "",
      preferredCurrency: "usd",
      paymentTerms: "",
      inquiryType: "",
      remarks: "",
      productionUnit: "",
      itemName: "",
      sizeWidth: 0,
      weightGramYds: 0,
      pricePerYds: 0,
    });
    setElasticParts([
      { id: 1, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
      { id: 2, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
      { id: 3, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
      { id: 4, part: "", yarnCategory: "", yarnCount: "", color: "", weight: "", priceUsd: "", priceBdt: "", remarks: "" },
    ]);
    toast({
      title: "Form cleared",
      description: "All fields have been reset to their default values.",
    });
  };

  // Prepare data for export
  const prepareExportData = () => {
    const formData = form.getValues();
    
    // Format date strings
    const formattedDate = new Date(formData.date).toLocaleDateString();
    
    // Basic quotation information
    const exportData = {
      'Quotation Number': formData.quotationNumber,
      'Date': formattedDate,
      'Created By': formData.creatorName,
      'Factory Name': formData.factoryName,
      'Buyer Name': formData.buyerName || 'N/A',
      'Buyer Type': formData.buyerType || 'N/A',
      'Merchant Name': formData.merchantName || 'N/A',
      'Contact Info': `${formData.countryCode} ${formData.buyerPhone}`,
      'Email': formData.buyerEmail || 'N/A',
      'Address': formData.buyerAddress || 'N/A',
      'Inquiry Type': formData.inquiryType,
      'Production Unit': formData.productionUnit,
      'Item Name': formData.itemName,
      'Article Number': formData.articleNumber,
      'Size/Width': `${formData.sizeWidth} ${settings.sizeUnit}`,
      'Weight': `${formData.weightGramYds} gram/${settings.lengthUnit}`,
      'Price': `${formData.pricePerYds} ${settings.priceCurrency}/${settings.lengthUnit}`,
      'Additional Price': `${settings.additionalPrice}%`,
      'Payment Terms': formData.paymentTerms || 'N/A',
      'Remarks': formData.remarks || 'N/A'
    };
    
    return exportData;
  };
  
  // Handle CSV export
  const handleExportCSV = () => {
    const exportData = prepareExportData();
    exportToCSV([exportData], generateFilename('price-quotation', 'csv'));
    toast({
      title: "Export Successful",
      description: "Quotation data has been exported to CSV format.",
    });
  };
  
  // Handle Excel export
  const handleExportExcel = () => {
    const exportData = prepareExportData();
    exportToExcel([exportData], generateFilename('price-quotation', 'xlsx'));
    toast({
      title: "Export Successful",
      description: "Quotation data has been exported to Excel format.",
    });
  };
  
  // Handle PDF export
  const handleExportPDF = () => {
    const exportData = prepareExportData();
    
    // Convert the object to an array for PDF export
    const exportArray = Object.entries(exportData).map(([key, value]) => {
      return { Field: key, Value: value };
    });
    
    exportToPDF(
      exportArray, 
      ['Field', 'Value'], 
      generateFilename('price-quotation', 'pdf'), 
      'Price Quotation Data'
    );
    
    toast({
      title: "Export Successful",
      description: "Quotation data has been exported to PDF format.",
    });
  };

  // Handle print
  const handlePrint = () => {
    if (printRef.current) {
      const content = printRef.current;
      const printWindow = window.open('', '_blank');

      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Price Quotation</title>
              <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
                .header { display: flex; justify-content: space-between; margin-bottom: 20px; }
                .company { font-size: 24px; font-weight: bold; }
                .quotation-info { margin-bottom: 20px; }
                .section { margin-bottom: 20px; }
                .section-title { font-size: 18px; font-weight: bold; margin-bottom: 10px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .footer { margin-top: 30px; }
                .signatures { display: flex; justify-content: space-between; margin-top: 50px; }
                .signature { width: 200px; text-align: center; }
                .signature-line { border-top: 1px solid #000; margin-top: 50px; }
              </style>
            </head>
            <body>
              ${content.innerHTML}
              <div class="signatures">
                <div class="signature">
                  <div class="signature-line"></div>
                  <p>Authorized Signature</p>
                </div>
                <div class="signature">
                  <div class="signature-line"></div>
                  <p>Customer Signature</p>
                </div>
              </div>
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  // Format currency
  // Use the formatCurrency function from the CurrencyContext
  const { formatCurrency } = useCurrency();

  // Calculate total price
  const calculateTotalPrice = () => {
    const basePrice = form.getValues("pricePerYds") || 0;
    const quantity = form.getValues("weightGramYds") || 0;
    const additionalPercentage = settings.additionalPrice / 100;
    const total = basePrice * quantity * (1 + additionalPercentage);
    return total;
  };

  return (
    <AppLayout
      title="Price Quotation"
      description="Create detailed price quotations for narrow fabrics products"
    >
      {/* Scanner Dialog */}
      <Dialog open={isScannerDialogOpen} onOpenChange={setIsScannerDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Camera className="h-5 w-5 text-primary" />
              Scan Business Card
            </DialogTitle>
            <DialogDescription>
              Position the business card within the frame and keep it steady
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center justify-center p-4">
            <div className="w-full aspect-video bg-gray-100 rounded-md overflow-hidden relative flex items-center justify-center mb-4 border-2 border-dashed border-primary/50">
              <div className="absolute inset-4 border-2 border-primary/20 rounded-md flex items-center justify-center">
                <Scan className="h-20 w-20 text-primary/20 animate-pulse" />
              </div>
              <div className="absolute bottom-3 left-0 right-0 text-center text-sm text-muted-foreground">
                Scanning...
              </div>
            </div>
            <div className="space-y-1 w-full">
              <div className="flex items-center gap-2">
                <div className="h-2 bg-primary rounded-full w-full animate-pulse"></div>
              </div>
              <p className="text-xs text-center text-muted-foreground">Extracting information from card...</p>
            </div>
          </div>
          <DialogFooter className="flex items-center justify-between sm:justify-between">
            <Button 
              variant="secondary" 
              onClick={() => setIsScannerDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              type="button"
              disabled
              className="opacity-50"
            >
              <ScanSearch className="mr-2 h-4 w-4" />
              Scanning...
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Main content */}
      <div className="container mx-auto p-6 max-w-7xl">
        {/* Header with title and settings button */}
        <div className="flex justify-between items-center mb-6 pb-4 border-b">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-2">
              <FileText className="h-8 w-8 text-blue-600" />
              Price Quotation
            </h1>
            <p className="text-gray-500 mt-1">Create and manage detailed price quotations for your clients</p>
          </div>
          <Button
            variant="ghost"
            className="p-2"
            onClick={() => setIsSettingsDialogOpen(true)}
          >
            <Settings className="w-5 h-5 text-gray-600" />
          </Button>
        </div>

        {/* Settings Dialog */}
        <Dialog open={isSettingsDialogOpen} onOpenChange={setIsSettingsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Quotation Settings</DialogTitle>
              <DialogDescription>
                Configure your quotation settings and preferences
              </DialogDescription>
            </DialogHeader>
            <Form {...settingsForm}>
              <form onSubmit={settingsForm.handleSubmit(onSettingsSubmit)} className="space-y-4">
                <FormField
                  control={settingsForm.control}
                  name="usdConversionRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>USD Conversion Rate (TK)</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={settingsForm.control}
                  name="sizeUnit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Size/Weight Unit</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select unit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="MM">MM</SelectItem>
                          <SelectItem value="CM">CM</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={settingsForm.control}
                  name="lengthUnit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Length Unit</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select unit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="YDS">YDS</SelectItem>
                          <SelectItem value="MTR">MTR</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={settingsForm.control}
                  name="priceCurrency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price Currency</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="USD">USD</SelectItem>
                          <SelectItem value="TK">TK</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={settingsForm.control}
                  name="additionalPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Price (%)</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="submit">Save Settings</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Quotation Form */}
        <Form {...form}>
          <div className="relative">
            {/* Auto-save status indicator */}
            <div className="absolute top-0 right-0 flex items-center gap-2 text-sm">
              <div className="flex items-center">
                <label className="mr-2 text-sm text-gray-600 cursor-pointer hover:text-gray-900" htmlFor="autosave-toggle">
                  Auto-save
                </label>
                <Switch
                  id="autosave-toggle"
                  checked={autoSaveEnabled}
                  onCheckedChange={setAutoSaveEnabled}
                />
              </div>
              
              {savingStatus === 'idle' && lastSaved && (
                <div className="text-gray-500 flex items-center gap-1">
                  <span>Last saved: {new Date(lastSaved).toLocaleTimeString()}</span>
                </div>
              )}
              
              {savingStatus === 'saving' && (
                <div className="text-amber-500 flex items-center gap-1">
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>Saving...</span>
                </div>
              )}
              
              {savingStatus === 'saved' && (
                <div className="text-green-500 flex items-center gap-1">
                  <Check className="h-4 w-4" />
                  <span>Saved</span>
                </div>
              )}
              
              {savingStatus === 'error' && (
                <div className="text-red-500 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  <span>Save failed</span>
                </div>
              )}
            </div>
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div ref={printRef}>
              {/* Section 1: Quotation Info and Buyer Details */}
              <Card className="mb-6 border-slate-200">
                <CardHeader>
                  <div className="flex justify-between items-start w-full">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <FileText className="h-5 w-5 text-blue-600" />
                        Buyer Information
                      </CardTitle>
                      <CardDescription>
                        Enter buyer details and quotation information
                      </CardDescription>
                    </div>
                    <Button 
                      type="button"
                      variant="outline" 
                      size="sm"
                      className="flex items-center gap-2 text-primary border-primary hover:bg-primary/10 transition-colors"
                      onClick={() => handleScanBusinessCard()}
                    >
                      <ScanSearch className="h-4 w-4" />
                      <span>Scan Card</span>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Top Row - Auto Generated Fields */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <FormField
                      control={form.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" /> Date
                          </FormLabel>
                          <FormControl>
                            <Input 
                              type="date" 
                              {...field} 
                              disabled 
                              className="bg-gray-50"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="quotationNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <FileText className="h-4 w-4" /> Quotation Number
                          </FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              disabled 
                              className="bg-gray-50"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="creatorName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <User className="h-4 w-4" /> Quotation Creator
                          </FormLabel>
                          <FormControl>
                            <Input {...field} disabled className="bg-gray-50" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Factory Information */}
                  <div className="mb-6">
                    <FormField
                      control={form.control}
                      name="factoryName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Factory className="h-4 w-4" /> Factory Name
                          </FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Buyer Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <FormField
                      control={form.control}
                      name="buyerName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <User className="h-4 w-4" /> Buyer Name
                          </FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div>
                      <FormField
                        control={form.control}
                        name="buyerType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="flex items-center gap-1">
                              <Users className="h-4 w-4" /> Buyer Type
                            </FormLabel>
                            <Select
                              onValueChange={(value) => {
                                field.onChange(value);
                                // Clear other buyer type if not "other"
                                if (value !== "other") {
                                  form.setValue("otherBuyerType", "");
                                }
                              }}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select buyer type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="master">Master Buyer</SelectItem>
                                <SelectItem value="buyer">Buyer Merchant</SelectItem>
                                <SelectItem value="garment">Garment Merchant</SelectItem>
                                <SelectItem value="other">Other (specify)</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      {form.watch("buyerType") === "other" && (
                        <FormField
                          control={form.control}
                          name="otherBuyerType"
                          render={({ field }) => (
                            <FormItem className="mt-2">
                              <FormControl>
                                <Input {...field} placeholder="Specify buyer type" className="mt-0" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  </div>

                  {/* Merchant & Job Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <FormField
                      control={form.control}
                      name="merchantName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <UserCircle className="h-4 w-4" /> Merchant Name
                          </FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="jobRole"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Briefcase className="h-4 w-4" /> Job Role
                          </FormLabel>
                          <Select
                            onValueChange={(value) => {
                              field.onChange(value);
                              // Clear other job role if not "other"
                              if (value !== "other") {
                                form.setValue("otherJobRole", "");
                              }
                            }}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select job role" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="owner">Owner</SelectItem>
                              <SelectItem value="merchandiser_head">Merchandiser (Head)</SelectItem>
                              <SelectItem value="merchandiser_gm">Merchandiser (GM)</SelectItem>
                              <SelectItem value="merchandiser_dgm">Merchandiser (DGM)</SelectItem>
                              <SelectItem value="merchandiser_agm">Merchandiser (AGM)</SelectItem>
                              <SelectItem value="merchandiser_sr_manager">Merchandiser (Sr. Manager)</SelectItem>
                              <SelectItem value="merchandiser_manager">Merchandiser (Manager)</SelectItem>
                              <SelectItem value="merchandiser_asst_manager">Merchandiser (Asst. Manager)</SelectItem>
                              <SelectItem value="merchandiser_sr_executive">Merchandiser (Sr. Executive)</SelectItem>
                              <SelectItem value="merchandiser_executive">Merchandiser (Executive)</SelectItem>
                              <SelectItem value="merchandiser_jr_executive">Merchandiser (Jr. Executive)</SelectItem>
                              <SelectItem value="merchandiser_officer">Merchandiser (Officer)</SelectItem>
                              <SelectItem value="merchandiser_trainee">Merchandiser (Trainee)</SelectItem>
                              <SelectItem value="other">Other (specify)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    {form.watch("jobRole") === "other" && (
                      <FormField
                        control={form.control}
                        name="otherJobRole"
                        render={({ field }) => (
                          <FormItem className="mt-2">
                            <FormControl>
                              <Input {...field} placeholder="Specify job role" className="mt-0" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>

                  {/* Department & Contact */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <FormField
                      control={form.control}
                      name="department"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Building className="h-4 w-4" /> Department
                          </FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="buyerPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Phone className="h-4 w-4" /> Phone Number
                          </FormLabel>
                          <div className="flex">
                            <div className="relative flex-shrink-0">
                              <FormField
                                control={form.control}
                                name="countryCode"
                                render={({ field: countryField }) => (
                                  <Select
                                    onValueChange={countryField.onChange}
                                    defaultValue={countryField.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger className="w-[130px] rounded-r-none border-r-0 focus:ring-0 focus:ring-offset-0">
                                        <div className="flex items-center gap-2">
                                          <img 
                                            src={`https://flagcdn.com/w20/${countryData.find(c => c.code === countryField.value)?.flag || 'bd'}.png`} 
                                            alt="Flag" 
                                            className="w-5 h-3 object-cover" 
                                          />
                                          <span>{countryField.value}</span>
                                        </div>
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <ScrollArea className="h-[300px]">
                                        {countryData.map((country) => (
                                          <SelectItem key={country.id} value={country.code}>
                                            <div className="flex items-center gap-2">
                                              <img 
                                                src={`https://flagcdn.com/w20/${country.flag}.png`} 
                                                alt={country.name} 
                                                className="w-5 h-3 object-cover" 
                                              />
                                              <div className="flex flex-col">
                                                <div className="flex items-center gap-1">
                                                  <span>{country.code}</span>
                                                  <span className="text-xs text-muted-foreground">({country.shortForm})</span>
                                                </div>
                                                <span className="text-xs text-muted-foreground">{country.name}</span>
                                              </div>
                                            </div>
                                          </SelectItem>
                                        ))}
                                      </ScrollArea>
                                    </SelectContent>
                                  </Select>
                                )}
                              />
                            </div>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="rounded-l-none" 
                                placeholder="Enter phone number" 
                                onChange={(e) => {
                                  // Call the original onChange
                                  field.onChange(e);
                                  
                                  // Auto-detect country code from phone number
                                  const phoneNumber = e.target.value;
                                  // Prepare country codes without the plus sign for comparison
                                  const countriesWithoutPlus = countryData.map(country => ({
                                    ...country,
                                    codeWithoutPlus: country.code.replace('+', '')
                                  }));
                                  
                                  // Try to match the start of the phone number against country codes
                                  // Sort by code length (descending) to match longer codes first
                                  const sortedCountries = [...countriesWithoutPlus].sort(
                                    (a, b) => b.codeWithoutPlus.length - a.codeWithoutPlus.length
                                  );
                                  
                                  for (const country of sortedCountries) {
                                    if (phoneNumber.startsWith(country.codeWithoutPlus)) {
                                      // Set the country code in the dropdown
                                      form.setValue('countryCode', country.code);
                                      
                                      // Remove the country code from the phone number
                                      const numberWithoutCode = phoneNumber.substring(country.codeWithoutPlus.length);
                                      form.setValue('buyerPhone', numberWithoutCode);
                                      break;
                                    }
                                  }
                                }}
                              />
                            </FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Email & Address */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <FormField
                      control={form.control}
                      name="buyerEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Mail className="h-4 w-4" /> Email Address
                          </FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="buyerAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" /> Address
                          </FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Payment Terms & Options */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <FormField
                      control={form.control}
                      name="inquiryType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <HelpCircle className="h-4 w-4" /> Inquiry Type
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="sample">Sample Request</SelectItem>
                              <SelectItem value="price">Price Inquiry</SelectItem>
                              <SelectItem value="bulk">Bulk Order</SelectItem>
                              <SelectItem value="technical">Technical Query</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="paymentTerms"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <CalendarClock className="h-4 w-4" /> Payment Terms
                            {(form.watch("inquiryType") === "price" || form.watch("inquiryType") === "bulk") && (
                              <span className="text-red-500">*</span>
                            )}
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select terms" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="advance">100% Advance</SelectItem>
                              <SelectItem value="net30">Net 30 Days</SelectItem>
                              <SelectItem value="net60">Net 60 Days</SelectItem>
                              <SelectItem value="cod">Cash on Delivery</SelectItem>
                              <SelectItem value="custom">Custom</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="preferredCurrency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Banknote className="h-4 w-4" /> Preferred Currency
                            {(form.watch("inquiryType") === "price" || form.watch("inquiryType") === "bulk") && (
                              <span className="text-red-500">*</span>
                            )}
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select currency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="usd">USD ($)</SelectItem>
                              <SelectItem value="eur">EUR (€)</SelectItem>
                              <SelectItem value="gbp">GBP (£)</SelectItem>
                              <SelectItem value="bdt">BDT (৳)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Remarks */}
                  <div>
                    <FormField
                      control={form.control}
                      name="remarks"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <MessageSquare className="h-4 w-4" /> Remarks
                          </FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Enter any additional notes or remarks"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Section 2: Product Details */}
              <Card className="mb-6 border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Factory className="h-5 w-5 text-blue-600" />
                    Product Information
                  </CardTitle>
                  <CardDescription>
                    Enter product and production details
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  {/* Article Number Field */}
                  <FormField
                    control={form.control}
                    name="articleNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-1">
                          <FileText className="h-4 w-4" /> Article Number
                        </FormLabel>
                        <div className="flex gap-2">
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Jist-J-ELA-001-20"
                              className="flex-1"
                            />
                          </FormControl>
                          <Button 
                            type="button" 
                            variant="outline" 
                            size="icon"
                            onClick={() => {
                              const unit = form.getValues("productionUnit");
                              const item = form.getValues("itemName");
                              const width = form.getValues("sizeWidth");
                              if (unit && item) {
                                form.setValue("articleNumber", generateArticleNumber(unit, item, width));
                              } else {
                                toast({
                                  title: "Cannot Generate Article Number",
                                  description: "Please select Production Unit and Item first",
                                  variant: "destructive",
                                });
                              }
                            }}
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="productionUnit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Production Unit</FormLabel>
                        <Select
                          onValueChange={(value) => {
                            field.onChange(value);
                            // Auto-generate article number when both production unit and item are selected
                            const item = form.getValues("itemName");
                            const width = form.getValues("sizeWidth");
                            if (item) {
                              form.setValue("articleNumber", generateArticleNumber(value, item, width));
                            }
                          }}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Select production unit" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {productionUnits && productionUnits.length > 0 ? (
                              productionUnits.map((unit: any) => (
                                <SelectItem key={`unit-${unit.id}`} value={unit.name}>
                                  {unit.name}
                                </SelectItem>
                              ))
                            ) : (
                              <>
                                <SelectItem key="jacquard-loom" value="Jacquard Loom">Jacquard Loom</SelectItem>
                                <SelectItem key="needle-loom" value="Needle Loom">Needle Loom</SelectItem>
                                <SelectItem key="crochet-machine" value="Crochet Machine">Crochet Machine</SelectItem>
                                <SelectItem key="drawstring-machine" value="Drawstring Machine">Drawstring Machine</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="itemName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Item</FormLabel>
                        <Select
                          onValueChange={(value) => {
                            field.onChange(value);
                            // Auto-generate article number when both production unit and item are selected
                            const unit = form.getValues("productionUnit");
                            const width = form.getValues("sizeWidth");
                            if (unit) {
                              form.setValue("articleNumber", generateArticleNumber(unit, value, width));
                            }
                          }}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Select item" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {itemsList && itemsList.length > 0 ? (
                              // Filter items by the selected production unit
                              itemsList
                                .filter(item => {
                                  const selectedUnit = form.getValues("productionUnit");
                                  // Debug the filtering
                                  console.log("Filtering items:", {
                                    selectedUnit,
                                    itemProductionUnit: item.productionUnit,
                                    item
                                  });
                                  
                                  // If no unit is selected, show all items
                                  if (!selectedUnit) return true;
                                  
                                  // Check if the item's production unit matches the selected unit
                                  return item.productionUnit === selectedUnit;
                                })
                                .map((item: any) => (
                                  <SelectItem key={`item-${item.id}`} value={item.name}>
                                    {item.name}
                                  </SelectItem>
                                ))
                            ) : itemUnits && itemUnits.length > 0 ? (
                              itemUnits.map((item: any) => (
                                <SelectItem key={`unit-${item.id}`} value={item.name}>
                                  {item.name}
                                </SelectItem>
                              ))
                            ) : (
                              <>
                                <SelectItem key="elastic-band" value="Elastic Band">Elastic Band</SelectItem>
                                <SelectItem key="narrow-fabric" value="Narrow Fabric">Narrow Fabric</SelectItem>
                                <SelectItem key="ribbon" value="Ribbon">Ribbon</SelectItem>
                                <SelectItem key="cord" value="Cord">Cord</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="sizeWidth"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Size/Width ({settings.sizeUnit})</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="weightGramYds"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Weight (Gram/{settings.lengthUnit})</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Section 3: Elastic Parts Table */}
              <Card className="mb-6 border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trash2 className="h-5 w-5 text-blue-600" />
                    Elastic Parts Information
                  </CardTitle>
                  <CardDescription>
                    Enter details for each elastic part used in the product
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50px] font-bold">SL</TableHead>
                          <TableHead className="font-bold">Elastic Parts</TableHead>
                          <TableHead className="font-bold">Yarn Type</TableHead>
                          <TableHead className="font-bold">Yarn Count</TableHead>
                          <TableHead className="font-bold">Color</TableHead>
                          <TableHead className="font-bold">Weight</TableHead>
                          <TableHead className="font-bold">Price (USD)</TableHead>
                          <TableHead className="font-bold">Price (BDT)</TableHead>
                          <TableHead className="font-bold">Remark's</TableHead>
                          <TableHead className="w-[80px] text-right font-bold">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {elasticParts.map((part, index) => (
                          <TableRow key={part.id}>
                            <TableCell className="font-medium">{index + 1}</TableCell>
                            <TableCell>
                              <Select
                                value={part.part}
                                onValueChange={(value) =>
                                  updateElasticPart(part.id, "part", value)
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select elastic part" />
                                </SelectTrigger>
                                <SelectContent>
                                  {fabricParts?.map((fabricPart: any) => (
                                    <SelectItem key={fabricPart.id} value={fabricPart.name}>
                                      {fabricPart.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={part.yarnCategory}
                                onValueChange={(value) =>
                                  updateElasticPart(part.id, "yarnCategory", value)
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select yarn type" />
                                </SelectTrigger>
                                <SelectContent>
                                  {yarnCategories?.map((category: any) => (
                                    <SelectItem key={category.id} value={category.name}>
                                      {category.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={part.yarnCount}
                                onValueChange={(value) =>
                                  updateElasticPart(part.id, "yarnCount", value)
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select yarn count" />
                                </SelectTrigger>
                                <SelectContent>
                                  {yarnCounts
                                    ?.filter((count: any) => 
                                      !part.yarnCategory || count.YarnCategoriesName === part.yarnCategory
                                    )
                                    .map((count: any) => (
                                      <SelectItem key={count.id} value={count.count}>
                                        {count.count}
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={part.color}
                                onValueChange={(value) =>
                                  updateElasticPart(part.id, "color", value)
                                }
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select color" />
                                </SelectTrigger>
                                <SelectContent>
                                  {colorTypes?.map((color: any) => (
                                    <SelectItem key={color.id} value={color.name}>
                                      {color.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                step="0.01"
                                value={part.weight || ""}
                                onChange={(e) =>
                                  updateElasticPart(part.id, "weight", e.target.value)
                                }
                                placeholder="Weight"
                              />
                            </TableCell>
                            <TableCell>
                              <div className="relative">
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={part.priceUsd || ""}
                                  onChange={(e) =>
                                    updateElasticPart(part.id, "priceUsd", e.target.value)
                                  }
                                  placeholder="USD"
                                  className="pl-6"
                                />
                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="relative">
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={part.priceBdt || ""}
                                  onChange={(e) =>
                                    updateElasticPart(part.id, "priceBdt", e.target.value)
                                  }
                                  placeholder="BDT"
                                  className="pl-6"
                                />
                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500">৳</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Input
                                value={part.remarks}
                                onChange={(e) =>
                                  updateElasticPart(
                                    part.id,
                                    "remarks",
                                    e.target.value
                                  )
                                }
                                placeholder="Remarks"
                              />
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeElasticPart(part.id)}
                                disabled={elasticParts.length <= 1}
                              >
                                <Trash className="h-4 w-4 text-red-500" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  {elasticParts.length < 5 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="mt-4"
                      onClick={addElasticPart}
                    >
                      <Plus className="h-4 w-4 mr-2" /> Add Row
                    </Button>
                  )}
                </CardContent>
              </Card>

              {/* Section 4: Pricing Information */}
              <Card className="mb-6 border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-blue-600" />
                    Pricing Information
                  </CardTitle>
                  <CardDescription>
                    Enter pricing details for the quotation
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold text-gray-700">Product Summary</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Production Unit:</span>
                          <span className="font-medium">
                            {form.watch("productionUnit") || "Not specified"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Item:</span>
                          <span className="font-medium">
                            {form.watch("itemName") || "Not specified"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Size/Width:</span>
                          <span className="font-medium">
                            {form.watch("sizeWidth") || 0} {settings.sizeUnit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Weight:</span>
                          <span className="font-medium">
                            {form.watch("weightGramYds") || 0} Gram/{settings.lengthUnit}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="md:col-span-2">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="pricePerYds"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                Price/{settings.lengthUnit} ({settings.priceCurrency})
                              </FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input 
                                    type="number" 
                                    step="0.01" 
                                    {...field} 
                                    className="pl-6" 
                                  />
                                  <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500">
                                    {settings.priceCurrency === 'USD' ? '$' : 
                                     settings.priceCurrency === 'BDT' ? '৳' : 
                                     settings.priceCurrency === 'EUR' ? '€' : 
                                     settings.priceCurrency === 'GBP' ? '£' : 
                                     settings.priceCurrency === 'JPY' || settings.priceCurrency === 'CNY' ? '¥' :
                                     settings.priceCurrency === 'INR' ? '₹' :
                                     settings.priceCurrency === 'KRW' ? '₩' : '$'
                                    }
                                  </span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="space-y-2">
                          <Label>Total Value</Label>
                          <div className="bg-gray-50 border rounded p-3 flex items-center justify-between">
                            <span className="text-gray-600">Base Price:</span>
                            <span>
                              {formatCurrency(
                                (form.watch("pricePerYds") || 0) *
                                  (form.watch("weightGramYds") || 0),
                                settings.priceCurrency.toLowerCase()
                              )}
                            </span>
                          </div>
                          <div className="bg-gray-50 border rounded p-3 flex items-center justify-between">
                            <span className="text-gray-600">
                              Additional ({settings.additionalPrice}%):
                            </span>
                            <span>
                              {formatCurrency(
                                (form.watch("pricePerYds") || 0) *
                                  (form.watch("weightGramYds") || 0) *
                                  (settings.additionalPrice / 100),
                                settings.priceCurrency.toLowerCase()
                              )}
                            </span>
                          </div>
                          <div className="bg-blue-50 border border-blue-200 rounded p-3 flex items-center justify-between">
                            <span className="font-semibold text-blue-700">Total:</span>
                            <span className="font-bold text-blue-700">
                              {formatCurrency(calculateTotalPrice(), settings.priceCurrency.toLowerCase())}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Section 5: Action Buttons */}
            <div className="flex justify-end space-x-4 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={resetForm}
                className="bg-gray-50"
              >
                <Trash2 className="h-4 w-4 mr-2" /> Clear
              </Button>
              
              {/* Export Dropdown */}
              <div className="relative group">
                <Button
                  type="button"
                  variant="outline"
                  className="bg-green-50 text-green-700 border-green-200 group-hover:bg-green-100"
                >
                  <Download className="h-4 w-4 mr-2" /> Export
                </Button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg overflow-hidden z-20 hidden group-hover:block">
                  <div className="py-1">
                    <button
                      onClick={handleExportCSV}
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                    >
                      <FileText className="h-4 w-4 mr-2" /> Export as CSV
                    </button>
                    <button
                      onClick={handleExportExcel}
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                    >
                      <FileSpreadsheet className="h-4 w-4 mr-2" /> Export as Excel
                    </button>
                    <button
                      onClick={handleExportPDF}
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                    >
                      <FileText className="h-4 w-4 mr-2" /> Export as PDF
                    </button>
                  </div>
                </div>
              </div>
              
              <Button
                type="button"
                variant="outline"
                onClick={handlePrint}
                className="bg-blue-50 text-blue-700 border-blue-200"
              >
                <Printer className="h-4 w-4 mr-2" /> Print
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                <Save className="h-4 w-4 mr-2" /> Save Quotation
              </Button>
            </div>
          </form>
        </div>
        </Form>
      </div>
    </AppLayout>
  );
}