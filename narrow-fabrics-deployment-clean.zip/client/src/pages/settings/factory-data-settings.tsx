import { useState } from 'react';
import AppLayout from '@/components/layout/app-layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Factory, Building, UserCheck, ShoppingBag, MapPin, Phone, Mail, CreditCard } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';

export default function FactoryDataSettings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('factories');
  const [showAddFactoryDialog, setShowAddFactoryDialog] = useState(false);
  const [showAddBuyerDialog, setShowAddBuyerDialog] = useState(false);

  // Dummy data for demonstration
  const [factories, setFactories] = useState([
    { 
      id: 1, 
      name: 'Main Factory', 
      location: 'Dhaka, Bangladesh', 
      contact: '+880 1712-345678',
      email: 'factory@example.com',
      capacity: '250 units/day',
      status: 'Active' 
    },
    { 
      id: 2, 
      name: 'Secondary Production Unit', 
      location: 'Chittagong, Bangladesh', 
      contact: '+880 1812-345678',
      email: 'factory2@example.com',
      capacity: '150 units/day',
      status: 'Active' 
    },
    { 
      id: 3, 
      name: 'Overseas Production', 
      location: 'Delhi, India', 
      contact: '+91 9812-345678',
      email: 'india@example.com',
      capacity: '100 units/day',
      status: 'Inactive' 
    },
  ]);

  const [buyers, setBuyers] = useState([
    { 
      id: 1, 
      name: 'Textile International', 
      country: 'USA', 
      contact: '+1 555-123-4567',
      email: 'orders@textileintl.com',
      paymentTerms: 'Net 30',
      status: 'Active' 
    },
    { 
      id: 2, 
      name: 'European Fabrics', 
      country: 'Germany', 
      contact: '+49 555-123-4567',
      email: 'procurement@eurofabrics.de',
      paymentTerms: 'Net 45',
      status: 'Active' 
    },
    { 
      id: 3, 
      name: 'Asia Textiles Co.', 
      country: 'Japan', 
      contact: '+81 555-123-4567',
      email: 'purchase@asiatex.jp',
      paymentTerms: 'Net 60',
      status: 'On Hold' 
    },
  ]);

  const handleAddFactory = () => {
    toast({
      title: 'Factory Added',
      description: 'New factory has been successfully added',
    });
    setShowAddFactoryDialog(false);
  };

  const handleAddBuyer = () => {
    toast({
      title: 'Buyer Added',
      description: 'New buyer has been successfully added',
    });
    setShowAddBuyerDialog(false);
  };

  return (
    <AppLayout title="Factory & Buyer Data" description="Manage factory and buyer information">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Factory className="h-7 w-7 text-primary" />
              Factory & Buyer Data
            </h1>
            <p className="text-gray-500 mt-1">Manage factory locations and buyer information</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="factories" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              Factory Locations
            </TabsTrigger>
            <TabsTrigger value="buyers" className="flex items-center gap-2">
              <ShoppingBag className="h-4 w-4" />
              Buyers
            </TabsTrigger>
          </TabsList>

          <TabsContent value="factories" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Factory Management</CardTitle>
                  <CardDescription>View and manage factory locations</CardDescription>
                </div>
                <Button onClick={() => setShowAddFactoryDialog(true)}>
                  <Building className="h-4 w-4 mr-2" />
                  Add Factory
                </Button>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-4">
                  <div className="relative w-64">
                    <Input placeholder="Search factories..." className="pl-8" />
                    <search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      Export
                    </Button>
                    <Button variant="outline" size="sm">
                      Filter
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Factory Name</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Capacity</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {factories.map((factory) => (
                        <TableRow key={factory.id}>
                          <TableCell className="font-medium">{factory.name}</TableCell>
                          <TableCell>{factory.location}</TableCell>
                          <TableCell>{factory.contact}</TableCell>
                          <TableCell>{factory.capacity}</TableCell>
                          <TableCell>
                            <Badge
                              variant={factory.status === 'Active' ? 'default' : 'secondary'}
                            >
                              {factory.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-500">
                              Delete
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="buyers" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Buyer Management</CardTitle>
                  <CardDescription>View and manage buyer information</CardDescription>
                </div>
                <Button onClick={() => setShowAddBuyerDialog(true)}>
                  <UserCheck className="h-4 w-4 mr-2" />
                  Add Buyer
                </Button>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-4">
                  <div className="relative w-64">
                    <Input placeholder="Search buyers..." className="pl-8" />
                    <search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      Export
                    </Button>
                    <Button variant="outline" size="sm">
                      Filter
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Buyer Name</TableHead>
                        <TableHead>Country</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Payment Terms</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {buyers.map((buyer) => (
                        <TableRow key={buyer.id}>
                          <TableCell className="font-medium">{buyer.name}</TableCell>
                          <TableCell>{buyer.country}</TableCell>
                          <TableCell>{buyer.contact}</TableCell>
                          <TableCell>{buyer.paymentTerms}</TableCell>
                          <TableCell>
                            <Badge
                              variant={buyer.status === 'Active' ? 'default' : 'secondary'}
                              className={buyer.status === 'On Hold' ? 'bg-yellow-500 text-white' : ''}
                            >
                              {buyer.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-500">
                              Delete
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add Factory Dialog */}
        <Dialog open={showAddFactoryDialog} onOpenChange={setShowAddFactoryDialog}>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Add New Factory</DialogTitle>
              <DialogDescription>Add a new factory or production facility</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="factoryName" className="text-right">
                  Factory Name
                </Label>
                <Input id="factoryName" placeholder="Factory Name" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="factoryLocation" className="text-right">
                  Location
                </Label>
                <div className="col-span-3 flex gap-2">
                  <Input id="factoryLocation" placeholder="Address" className="flex-1" />
                  <div className="w-32">
                    <Input placeholder="Country" />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="factoryContact" className="text-right">
                  Contact
                </Label>
                <div className="col-span-3 flex gap-2 items-center">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <Input id="factoryContact" placeholder="Phone Number" className="flex-1" />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="factoryEmail" className="text-right">
                  Email
                </Label>
                <div className="col-span-3 flex gap-2 items-center">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <Input id="factoryEmail" type="email" placeholder="Email Address" className="flex-1" />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="factoryCapacity" className="text-right">
                  Capacity
                </Label>
                <Input id="factoryCapacity" placeholder="Production Capacity (e.g., 200 units/day)" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="factoryStatus" className="text-right">
                  Status
                </Label>
                <select
                  id="factoryStatus"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="maintenance">Under Maintenance</option>
                </select>
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="factoryNotes" className="text-right pt-2">
                  Notes
                </Label>
                <Textarea id="factoryNotes" placeholder="Additional information" className="col-span-3" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddFactoryDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddFactory}>Add Factory</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Add Buyer Dialog */}
        <Dialog open={showAddBuyerDialog} onOpenChange={setShowAddBuyerDialog}>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Add New Buyer</DialogTitle>
              <DialogDescription>Add a new buyer or client</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="buyerName" className="text-right">
                  Buyer Name
                </Label>
                <Input id="buyerName" placeholder="Company Name" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="buyerCountry" className="text-right">
                  Country
                </Label>
                <div className="col-span-3 flex gap-2 items-center">
                  <MapPin className="h-4 w-4 text-gray-400" />
                  <Input id="buyerCountry" placeholder="Country" className="flex-1" />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="buyerContact" className="text-right">
                  Contact
                </Label>
                <div className="col-span-3 flex gap-2 items-center">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <Input id="buyerContact" placeholder="Phone Number" className="flex-1" />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="buyerEmail" className="text-right">
                  Email
                </Label>
                <div className="col-span-3 flex gap-2 items-center">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <Input id="buyerEmail" type="email" placeholder="Email Address" className="flex-1" />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="buyerPaymentTerms" className="text-right">
                  Payment Terms
                </Label>
                <div className="col-span-3 flex gap-2 items-center">
                  <CreditCard className="h-4 w-4 text-gray-400" />
                  <Input id="buyerPaymentTerms" placeholder="e.g., Net 30, Net 60" className="flex-1" />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="buyerStatus" className="text-right">
                  Status
                </Label>
                <select
                  id="buyerStatus"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="onhold">On Hold</option>
                </select>
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="buyerNotes" className="text-right pt-2">
                  Notes
                </Label>
                <Textarea id="buyerNotes" placeholder="Additional information" className="col-span-3" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddBuyerDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddBuyer}>Add Buyer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}