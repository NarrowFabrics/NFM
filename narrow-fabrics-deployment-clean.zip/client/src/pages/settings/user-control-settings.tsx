import { useState, useEffect } from 'react';
import AppLayout from '@/components/layout/app-layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
// Remove Tooltip import as we'll use a custom one
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { format } from 'date-fns';
import { 
  User, 
  Users, 
  Shield, 
  ShieldAlert, 
  ShieldCheck, 
  ShieldQuestion,
  UserPlus, 
  Key, 
  Lock, 
  UserCheck, 
  Settings, 
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Eye,
  EyeOff,
  PenTool,
  Trash2,
  AlertTriangle,
  CheckCircle,
  LogOut,
  UserX,
  RefreshCw,
  Clock,
  Calendar as CalendarIcon,
  Filter,
  Search,
  Download,
  BarChart3,
  FileText,
  AlertCircle,
  Activity,
  Network,
  Fingerprint,
  Globe,
  History,
  Smartphone,
  Laptop,
  Building,
  HelpCircle,
  Plus,
  Minus,
  Copy,
  XCircle,
  CheckCircle2,
  ArrowUpDown,
  Layers,
  Save,
  Lock as LockIcon,
  Unlock,
  Timer,
  LayoutDashboard
} from 'lucide-react';

// Create a custom tooltip wrapper since we're already importing Tooltip from UI components
function CustomTooltip({ content, children }: { content: string; children: React.ReactNode }) {
  return (
    <div className="group relative inline-block">
      {children}
      <span className="invisible absolute bottom-full left-1/2 z-50 mb-2 -translate-x-1/2 whitespace-nowrap rounded bg-black px-2 py-1 text-xs text-white group-hover:visible">
        {content}
        <span className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-black"></span>
      </span>
    </div>
  );
}

// User session type for active sessions
interface UserSession {
  id: number;
  deviceType: 'mobile' | 'desktop' | 'tablet';
  location: string;
  ipAddress: string;
  browser: string;
  lastActive: string;
  isCurrentSession: boolean;
}

// User activity log entry type
interface ActivityLogEntry {
  id: number;
  userId: number;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
  ipAddress: string;
  severity: 'info' | 'warning' | 'critical';
}

// Interface for the advanced filter options
interface AdvancedFilterOptions {
  roleFilter: string;
  statusFilter: string;
  dateRange: {
    from: Date | undefined;
    to: Date | undefined;
  };
  permissionFilter: string;
  searchQuery: string;
  activityLevel: number[];
}

// Types for the role editor
interface CustomPermission {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
}

interface RoleInheritance {
  inheritsFrom: string[];
  timeLimit?: {
    enabled: boolean;
    expiresAfter: number; // in days
  };
}

export default function UserControlSettings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('users');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showAddRoleDialog, setShowAddRoleDialog] = useState(false);
  const [showPermissionDialog, setShowPermissionDialog] = useState(false);
  const [selectedRole, setSelectedRole] = useState<any>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  interface DeleteItem {
    id: number | null;
    type: string;
  }
  const [itemToDelete, setItemToDelete] = useState<DeleteItem>({ id: null, type: '' });
  
  // New state for enhancements
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [showSessionsDialog, setShowSessionsDialog] = useState(false);
  const [showActivityLog, setShowActivityLog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [showCompareRolesDialog, setShowCompareRolesDialog] = useState(false);
  const [rolesToCompare, setRolesToCompare] = useState<number[]>([]);
  const [showRoleEditorDialog, setShowRoleEditorDialog] = useState(false);
  const [show2FADialog, setShow2FADialog] = useState(false);
  const [showIPRestrictionsDialog, setShowIPRestrictionsDialog] = useState(false);
  const [showRoleWizard, setShowRoleWizard] = useState(false);
  const [showBatchOperationsDialog, setShowBatchOperationsDialog] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);
  const [securityScoreVisible, setSecurityScoreVisible] = useState(true);
  const [securityScore, setSecurityScore] = useState(78);
  
  // Advanced filter options
  const [filterOptions, setFilterOptions] = useState<AdvancedFilterOptions>({
    roleFilter: '',
    statusFilter: '',
    dateRange: {
      from: undefined,
      to: undefined
    },
    permissionFilter: '',
    searchQuery: '',
    activityLevel: [0, 100]
  });

  // Fetch real user data from the API with TanStack Query
  const { data: userData, isLoading: isLoadingUsers } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/users', { 
          credentials: 'include' 
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch users');
        }
        
        return response.json();
      } catch (error) {
        console.error('Error fetching users:', error);
        toast({
          title: 'Error',
          description: 'Failed to load users. Please try again.',
          variant: 'destructive'
        });
        return { users: [], total: 0 };
      }
    }
  });
  
  // Use the fetched data or an empty array if still loading
  const users = userData?.users || [];

  // Comprehensive role hierarchy based on the screenshot
  const [roles, setRoles] = useState([
    { 
      id: 1, 
      name: 'Admin', 
      description: 'Highest privilege with full system access',
      permissions: 'Full Access to all settings and features', 
      users: 1,
      badge: 'highest',
      details: {
        fullAccess: [
          'Manage and modify all settings',
          'Create, modify, and remove any roles',
          'Grant or revoke permissions to view the main settings panel for any role'
        ],
        responsibilities: [
          'Oversee overall security and monitor activity logs',
          'Configure system-wide settings'
        ]
      }
    },
    { 
      id: 2, 
      name: 'Sub-Admin', 
      description: 'Elevated privilege with conditional access',
      permissions: 'Conditional access requiring Admin approval', 
      users: 2,
      badge: 'elevated',
      details: {
        corePermissions: [
          'Access and view the main settings panel when permission is granted by an Admin',
          'Modify a subset of settings such as user content management, scheduling, or limited configuration options',
          'Manage user accounts within assigned modules (cannot change critical system settings)'
        ],
        limitations: [
          'Cannot reassign roles beyond their permitted scope',
          'Restricted from modifying core security or system-wide configurations'
        ]
      }
    },
    { 
      id: 3, 
      name: 'Moderator', 
      description: 'Limited privilege for specific functions',
      permissions: 'Limited, read-only for most settings', 
      users: 4,
      badge: 'limited',
      details: {
        corePermissions: [
          'View the main settings panel in a read-only or limited-interaction mode if granted access by an Admin',
          'Moderate user-generated content and review user activity',
          'Report or flag issues for Admin or Sub-Admin review'
        ],
        limitations: [
          'No permissions to change system settings, pricing, or user roles',
          'Can only view settings (or interact with a very limited subset) as allowed by the Admin'
        ]
      }
    },
    { 
      id: 4, 
      name: 'Member', 
      description: 'Default role with minimal access',
      permissions: 'Minimal access to personal settings only', 
      users: 8,
      badge: 'default',
      details: {
        standardPermissions: [
          'No access to the main settings panel by default',
          'Interact with user-specific features (profile settings, personal data)'
        ],
        conditionalAccess: [
          'View-Only Mode: If an Admin explicitly grants permission, a member can access a restricted, read-only view of the main settings panel to monitor specific settings or reports'
        ],
        limitations: [
          'No ability to modify any core settings or access sensitive configurations'
        ]
      }
    },
  ]);

  // Define action permission modules
  const [permissionModules, setPermissionModules] = useState([
    {
      name: 'Dashboard',
      permissions: [
        { id: 'dashboard-view', label: 'View Dashboard', roles: ['Admin', 'Sub-Admin', 'Moderator', 'Member'] },
        { id: 'dashboard-analytics', label: 'Access Analytics', roles: ['Admin', 'Sub-Admin'] }
      ]
    },
    {
      name: 'User Management',
      permissions: [
        { id: 'users-view', label: 'View Users', roles: ['Admin', 'Sub-Admin', 'Moderator'] },
        { id: 'users-create', label: 'Create Users', roles: ['Admin', 'Sub-Admin'] },
        { id: 'users-edit', label: 'Edit Users', roles: ['Admin', 'Sub-Admin'] },
        { id: 'users-delete', label: 'Delete Users', roles: ['Admin'] },
        { id: 'roles-manage', label: 'Manage Roles', roles: ['Admin'] }
      ]
    },
    {
      name: 'Production Plans',
      permissions: [
        { id: 'prod-view', label: 'View Production Plans', roles: ['Admin', 'Sub-Admin', 'Moderator'] },
        { id: 'prod-create', label: 'Create Production Plans', roles: ['Admin', 'Sub-Admin'] },
        { id: 'prod-edit', label: 'Edit Production Plans', roles: ['Admin', 'Sub-Admin'] },
        { id: 'prod-delete', label: 'Delete Production Plans', roles: ['Admin'] },
        { id: 'prod-approve', label: 'Approve Production Plans', roles: ['Admin'] }
      ]
    },
    {
      name: 'Orders',
      permissions: [
        { id: 'order-view', label: 'View Orders', roles: ['Admin', 'Sub-Admin', 'Moderator', 'Member'] },
        { id: 'order-create', label: 'Create Orders', roles: ['Admin', 'Sub-Admin', 'Moderator'] },
        { id: 'order-edit', label: 'Edit Orders', roles: ['Admin', 'Sub-Admin'] },
        { id: 'order-delete', label: 'Delete Orders', roles: ['Admin'] },
        { id: 'order-approve', label: 'Approve Orders', roles: ['Admin', 'Sub-Admin'] }
      ]
    },
    {
      name: 'Settings',
      permissions: [
        { id: 'settings-view', label: 'View Settings', roles: ['Admin', 'Sub-Admin'] },
        { id: 'settings-edit', label: 'Edit Settings', roles: ['Admin'] },
        { id: 'settings-security', label: 'Manage Security Settings', roles: ['Admin'] },
        { id: 'settings-backup', label: 'Backup and Restore', roles: ['Admin'] }
      ]
    },
    {
      name: 'System Security',
      permissions: [
        { id: 'security-logs', label: 'View Security Logs', roles: ['Admin'] },
        { id: 'security-users', label: 'Lock/Unlock User Accounts', roles: ['Admin'] },
        { id: 'security-reset', label: 'Reset User Passwords', roles: ['Admin'] },
        { id: 'security-monitor', label: 'Monitor User Activity', roles: ['Admin', 'Sub-Admin'] }
      ]
    }
  ]);

  // State for new user form
  const [newUser, setNewUser] = useState({
    username: '',
    email: '',
    name: '',
    password: '',
    confirmPassword: '',
    is_admin: false
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<{[key: string]: string}>({});
  
  // Function to handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setNewUser({
      ...newUser,
      [name]: type === 'checkbox' ? checked : value
    });
    
    // Clear error for this field when user types
    if (formErrors[name]) {
      setFormErrors({
        ...formErrors,
        [name]: ''
      });
    }
  };
  
  // Validate form before submission
  const validateForm = () => {
    const errors: {[key: string]: string} = {};
    
    if (!newUser.username.trim()) {
      errors.username = 'Username is required';
    }
    
    if (!newUser.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(newUser.email)) {
      errors.email = 'Email is invalid';
    }
    
    if (!newUser.name.trim()) {
      errors.name = 'Name is required';
    }
    
    if (!newUser.password) {
      errors.password = 'Password is required';
    } else if (newUser.password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }
    
    if (newUser.password !== newUser.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Functions to handle various actions
  const handleAddUser = async () => {
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Prepare user data - exclude confirmPassword
      const { confirmPassword, ...userData } = newUser;
      
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(userData)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to create user');
      }
      
      // Invalidate the users query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      
      toast({
        title: 'User Added',
        description: 'New user has been successfully added',
      });
      
      // Reset form and close dialog
      setNewUser({
        username: '',
        email: '',
        name: '',
        password: '',
        confirmPassword: '',
        is_admin: false
      });
      setShowAddDialog(false);
    } catch (error) {
      console.error('Error creating user:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create user',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddRole = () => {
    toast({
      title: 'Role Added',
      description: 'New role has been successfully created',
    });
    setShowAddRoleDialog(false);
  };

  const handleSavePermissions = () => {
    toast({
      title: 'Permissions Updated',
      description: 'Role permissions have been successfully updated',
    });
    setShowPermissionDialog(false);
  };

  // Import the queryClient from @lib/queryClient for cache invalidation
  const handleDeleteItem = async () => {
    try {
      if (itemToDelete.type === 'user') {
        // Send request to the API to delete the user
        const response = await fetch(`/api/users/${itemToDelete.id}`, {
          method: 'DELETE',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json'
          }
        });
        
        if (!response.ok) {
          throw new Error('Failed to delete user');
        }
        
        // Invalidate the user's query cache to refresh the data
        queryClient.invalidateQueries({ queryKey: ['/api/users'] });
        
        toast({
          title: 'User Deleted',
          description: 'User has been successfully removed',
        });
      } else if (itemToDelete.type === 'role') {
        // For now, keep the client-side role handling since we haven't implemented the API for it yet
        setRoles(roles.filter(role => role.id !== itemToDelete.id));
        toast({
          title: 'Role Deleted',
          description: 'Role has been successfully removed',
        });
      }
    } catch (error) {
      console.error('Error deleting item:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete the item. Please try again.',
        variant: 'destructive'
      });
    }
    
    setDeleteConfirmOpen(false);
  };

  // Enhanced action handlers with proper typing
  const confirmDelete = (id: number, type: string) => {
    setItemToDelete({ id, type });
    setDeleteConfirmOpen(true);
  };

  const viewRolePermissions = (role: any) => {
    setSelectedRole(role);
    setShowPermissionDialog(true);
  };

  const getRoleBadgeVariant = (badge: string) => {
    switch (badge) {
      case 'highest': return 'destructive';
      case 'elevated': return 'default';
      case 'limited': return 'secondary';
      case 'default': return 'outline';
      default: return 'outline';
    }
  };
  
  // New handlers for advanced features
  const viewUserSessions = (user: any) => {
    setSelectedUser(user);
    setShowSessionsDialog(true);
  };
  
  const viewUserActivity = (user: any) => {
    setSelectedUser(user);
    setShowActivityLog(true);
  };
  
  const setupTwoFactor = (user: any) => {
    setSelectedUser(user);
    setShow2FADialog(true);
  };
  
  const configureIPRestrictions = (user: any) => {
    setSelectedUser(user);
    setShowIPRestrictionsDialog(true);
  };
  
  const toggleUserSelection = (userId: number) => {
    if (selectedUsers.includes(userId)) {
      setSelectedUsers(selectedUsers.filter(id => id !== userId));
    } else {
      setSelectedUsers([...selectedUsers, userId]);
    }
  };
  
  const handleBatchOperation = (operation: string) => {
    if (selectedUsers.length === 0) {
      toast({
        title: "No users selected",
        description: "Please select at least one user for batch operations",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Batch Operation Completed",
      description: `Applied ${operation} to ${selectedUsers.length} users`
    });
    
    setSelectedUsers([]);
    setShowBatchOperationsDialog(false);
  };
  
  // Format date strings
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM d, yyyy h:mm a');
    } catch (e) {
      return dateString;
    }
  };

  return (
    <AppLayout title="User Control Settings" description="Manage users, roles and permissions">
      <div className="container mx-auto py-6 px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Users className="h-7 w-7 text-primary" />
              User Control Settings
            </h1>
            <p className="text-gray-500 mt-1">Comprehensive user, role, and permission management</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setActiveTab('roles')}>
              <Shield className="h-4 w-4 mr-2" />
              Manage Roles
            </Button>
            <Button onClick={() => setShowAddDialog(true)}>
              <UserPlus className="h-4 w-4 mr-2" />
              Add User
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="users" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="roles" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Roles
            </TabsTrigger>
            <TabsTrigger value="permissions" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              Permissions
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>View and manage user accounts and their associated roles</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
                  <div className="relative w-full md:w-64">
                    <Input placeholder="Search users..." className="pl-8" />
                    <User className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  </div>
                  <div className="flex gap-2 w-full md:w-auto">
                    <select 
                      className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <option value="">Filter by Role</option>
                      {roles.map(role => (
                        <option key={role.id} value={role.name}>{role.name}</option>
                      ))}
                    </select>
                    <Button variant="outline" size="sm">
                      Export
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Last Login</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoadingUsers ? (
                        // Loading state - show skeleton rows
                        Array.from({ length: 4 }).map((_, index) => (
                          <TableRow key={`loading-${index}`}>
                            <TableCell>
                              <div className="h-4 w-[120px] bg-gray-200 rounded animate-pulse"></div>
                            </TableCell>
                            <TableCell>
                              <div className="h-4 w-[180px] bg-gray-200 rounded animate-pulse"></div>
                            </TableCell>
                            <TableCell>
                              <div className="h-6 w-[100px] bg-gray-200 rounded animate-pulse"></div>
                            </TableCell>
                            <TableCell>
                              <div className="h-6 w-[80px] bg-gray-200 rounded animate-pulse"></div>
                            </TableCell>
                            <TableCell>
                              <div className="h-4 w-[140px] bg-gray-200 rounded animate-pulse"></div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <div className="h-8 w-8 bg-gray-200 rounded animate-pulse"></div>
                                <div className="h-8 w-8 bg-gray-200 rounded animate-pulse"></div>
                                <div className="h-8 w-8 bg-gray-200 rounded animate-pulse"></div>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : users.length === 0 ? (
                        // No users found state
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                            No users found
                          </TableCell>
                        </TableRow>
                      ) : (
                        // Render actual user data
                        users.map((user) => (
                          <TableRow key={user.id}>
                            <TableCell className="font-medium">{user.name}</TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>
                              <Badge
                                variant={user.is_admin ? 'destructive' : 'outline'}
                                className="capitalize"
                              >
                                {user.is_admin ? 'Admin' : 'User'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="default"
                                className="bg-green-100 text-green-800 hover:bg-green-100 hover:text-green-800"
                              >
                                <div className="flex items-center gap-1">
                                  <CheckCircle className="h-3 w-3" />
                                  Active
                                </div>
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {user.last_login_at 
                                ? new Date(user.last_login_at).toLocaleString() 
                                : 'Never'}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => {
                                  // Open edit dialog with user data 
                                  toast({
                                    title: "Edit User",
                                    description: "This feature is coming soon",
                                  });
                                }}
                              >
                                <PenTool className="h-4 w-4" />
                                <span className="sr-only">Edit</span>
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-amber-500"
                                title="Reset Password"
                                onClick={() => {
                                  // Reset password functionality
                                  toast({
                                    title: "Reset Password",
                                    description: "Password reset feature is coming soon",
                                  });
                                }}
                              >
                                <RefreshCw className="h-4 w-4" />
                                <span className="sr-only">Reset</span>
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-red-500"
                                onClick={() => confirmDelete(user.id, 'user')}
                              >
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
              <CardFooter className="flex items-center justify-between border-t p-4">
                <div className="text-sm text-gray-500">
                  {isLoadingUsers ? (
                    <div className="h-4 w-[100px] bg-gray-200 rounded animate-pulse"></div>
                  ) : (
                    <span>Showing {users.length} users</span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline" disabled>
                    Previous
                  </Button>
                  <Button size="sm" variant="outline" disabled={isLoadingUsers || users.length === 0}>
                    Next
                  </Button>
                </div>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Activity Log</CardTitle>
                <CardDescription>Monitor recent user actions and logins</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {isLoadingUsers ? (
                    // Loading state - show skeleton activity items
                    Array.from({ length: 3 }).map((_, index) => (
                      <div key={`loading-activity-${index}`} className="flex items-start gap-4 p-3 rounded-lg bg-gray-50">
                        <div className="h-8 w-8 rounded-full bg-gray-200 animate-pulse"></div>
                        <div className="flex-1">
                          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                            <div className="h-4 w-[120px] bg-gray-200 rounded animate-pulse"></div>
                            <div className="h-4 w-[100px] bg-gray-200 rounded animate-pulse mt-1 sm:mt-0"></div>
                          </div>
                          <div className="h-4 w-full bg-gray-200 rounded animate-pulse mt-2"></div>
                        </div>
                      </div>
                    ))
                  ) : users.length === 0 ? (
                    // No users found state
                    <div className="text-center py-8 text-gray-500">
                      No user activity found
                    </div>
                  ) : (
                    // Render actual user activity data
                    users.slice(0, 3).map((user, index) => (
                      <div key={index} className="flex items-start gap-4 p-3 rounded-lg bg-gray-50">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <User className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                            <p className="font-medium">{user.name}</p>
                            <p className="text-sm text-gray-500">
                              {user.last_login_at 
                                ? new Date(user.last_login_at).toLocaleString() 
                                : 'Never logged in'}
                            </p>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">
                            {index === 0 ? "Registered user" : 
                             index === 1 ? "User added to system" : 
                             "New account created"}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
              <CardFooter className="justify-end">
                <Button variant="ghost" size="sm">
                  View All Activity <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="roles" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Role Management</CardTitle>
                <CardDescription>Define role hierarchy and permission levels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-4">
                  <p className="text-sm text-gray-500">Manage the system's role hierarchy and access levels</p>
                  <Button onClick={() => setShowAddRoleDialog(true)}>
                    <Shield className="h-4 w-4 mr-2" />
                    Add New Role
                  </Button>
                </div>

                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Role Name</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Access Level</TableHead>
                        <TableHead>Users</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {roles.map((role) => (
                        <TableRow key={role.id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {role.name === 'Admin' ? <ShieldAlert className="h-4 w-4 text-red-500" /> :
                                role.name === 'Sub-Admin' ? <ShieldCheck className="h-4 w-4 text-primary" /> :
                                role.name === 'Moderator' ? <Shield className="h-4 w-4 text-amber-500" /> :
                                <ShieldQuestion className="h-4 w-4 text-gray-500" />
                              }
                              {role.name}
                            </div>
                          </TableCell>
                          <TableCell>{role.description}</TableCell>
                          <TableCell>
                            <Badge variant={getRoleBadgeVariant(role.badge)}>
                              {role.badge === 'highest' ? 'Highest Privilege' :
                                role.badge === 'elevated' ? 'Elevated Privilege' :
                                role.badge === 'limited' ? 'Limited Privilege' :
                                'Default Privilege'
                              }
                            </Badge>
                          </TableCell>
                          <TableCell>{role.users}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm" onClick={() => viewRolePermissions(role)}>
                              <Key className="h-4 w-4" />
                              <span className="sr-only md:not-sr-only md:ml-2">Permissions</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <PenTool className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-red-500"
                              onClick={() => confirmDelete(role.id, 'role')}
                              disabled={role.name === 'Admin'} // Prevent deleting the Admin role
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {roles.map(role => (
                <Card key={role.id} className="overflow-hidden">
                  <CardHeader className={`${
                    role.badge === 'highest' ? 'bg-red-50 border-b border-red-100' :
                    role.badge === 'elevated' ? 'bg-blue-50 border-b border-blue-100' :
                    role.badge === 'limited' ? 'bg-amber-50 border-b border-amber-100' :
                    'bg-gray-50 border-b border-gray-100'
                  }`}>
                    <div className="flex justify-between items-center">
                      <CardTitle className="flex items-center gap-2">
                        {role.name === 'Admin' ? <ShieldAlert className="h-5 w-5 text-red-500" /> :
                          role.name === 'Sub-Admin' ? <ShieldCheck className="h-5 w-5 text-primary" /> :
                          role.name === 'Moderator' ? <Shield className="h-5 w-5 text-amber-500" /> :
                          <ShieldQuestion className="h-5 w-5 text-gray-500" />
                        }
                        {role.name} Role
                      </CardTitle>
                      <Badge variant={getRoleBadgeVariant(role.badge)}>
                        {role.badge === 'highest' ? 'Highest Privilege' :
                          role.badge === 'elevated' ? 'Elevated Privilege' :
                          role.badge === 'limited' ? 'Limited Privilege' :
                          'Default Privilege'
                        }
                      </Badge>
                    </div>
                    <CardDescription>{role.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="p-5">
                    <ScrollArea className="h-[200px] pr-4">
                      <div className="space-y-4">
                        {role.details.fullAccess && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2">Full Access:</h4>
                            <ul className="space-y-1 pl-5 list-disc text-sm text-gray-700">
                              {role.details.fullAccess.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {role.details.responsibilities && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2">Additional Responsibilities:</h4>
                            <ul className="space-y-1 pl-5 list-disc text-sm text-gray-700">
                              {role.details.responsibilities.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {role.details.corePermissions && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2">Core Permissions:</h4>
                            <ul className="space-y-1 pl-5 list-disc text-sm text-gray-700">
                              {role.details.corePermissions.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {role.details.standardPermissions && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2">Standard Permissions:</h4>
                            <ul className="space-y-1 pl-5 list-disc text-sm text-gray-700">
                              {role.details.standardPermissions.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {role.details.conditionalAccess && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2">Conditional Access:</h4>
                            <ul className="space-y-1 pl-5 list-disc text-sm text-gray-700">
                              {role.details.conditionalAccess.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {role.details.limitations && (
                          <div>
                            <h4 className="font-semibold text-sm mb-2">Limitations:</h4>
                            <ul className="space-y-1 pl-5 list-disc text-sm text-gray-700">
                              {role.details.limitations.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                  <CardFooter className="bg-gray-50 border-t px-5 py-3">
                    <div className="flex justify-between w-full items-center">
                      <span className="text-sm text-gray-500">{role.users} user{role.users !== 1 ? 's' : ''} with this role</span>
                      <Button size="sm" variant="outline" onClick={() => viewRolePermissions(role)}>
                        Manage Permissions
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="permissions" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Permission Management</CardTitle>
                <CardDescription>Configure granular access permissions across the system</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-6">
                  {permissionModules.map((module, index) => (
                    <Card key={index}>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">{module.name}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-[300px]">Permission</TableHead>
                                  {roles.map(role => (
                                    <TableHead key={role.id} className="text-center">
                                      {role.name}
                                    </TableHead>
                                  ))}
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {module.permissions.map((permission, i) => (
                                  <TableRow key={i}>
                                    <TableCell className="font-medium">{permission.label}</TableCell>
                                    {roles.map(role => (
                                      <TableCell key={role.id} className="text-center">
                                        <Checkbox 
                                          id={`${permission.id}-${role.id}`} 
                                          checked={permission.roles.includes(role.name)}
                                          disabled={role.name === 'Admin'} // Admin always has all permissions
                                        />
                                      </TableCell>
                                    ))}
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="mt-6 flex justify-end">
                  <Button onClick={handleSavePermissions} className="w-full md:w-auto">
                    Save All Permission Changes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add User Dialog */}
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
              <DialogDescription>Create a new user account with appropriate role assignment</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="username" className="text-right">
                  Username
                </Label>
                <div className="col-span-3">
                  <Input 
                    id="username"
                    name="username"
                    placeholder="Username" 
                    value={newUser.username}
                    onChange={handleInputChange}
                    className={formErrors.username ? "border-red-500" : ""}
                  />
                  {formErrors.username && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.username}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Full Name
                </Label>
                <div className="col-span-3">
                  <Input 
                    id="name"
                    name="name"
                    placeholder="Full Name" 
                    value={newUser.name}
                    onChange={handleInputChange}
                    className={formErrors.name ? "border-red-500" : ""}
                  />
                  {formErrors.name && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <div className="col-span-3">
                  <Input 
                    id="email"
                    name="email"
                    type="email" 
                    placeholder="Email Address" 
                    value={newUser.email}
                    onChange={handleInputChange}
                    className={formErrors.email ? "border-red-500" : ""}
                  />
                  {formErrors.email && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.email}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="password" className="text-right">
                  Password
                </Label>
                <div className="col-span-3">
                  <Input 
                    id="password"
                    name="password"
                    type="password" 
                    placeholder="Set a password" 
                    value={newUser.password}
                    onChange={handleInputChange}
                    className={formErrors.password ? "border-red-500" : ""}
                  />
                  {formErrors.password && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.password}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="confirmPassword" className="text-right">
                  Confirm Password
                </Label>
                <div className="col-span-3">
                  <Input 
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password" 
                    placeholder="Confirm password" 
                    value={newUser.confirmPassword}
                    onChange={handleInputChange}
                    className={formErrors.confirmPassword ? "border-red-500" : ""}
                  />
                  {formErrors.confirmPassword && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.confirmPassword}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">Admin Access</Label>
                <div className="flex items-center space-x-2 col-span-3">
                  <Checkbox 
                    id="is_admin" 
                    name="is_admin"
                    checked={newUser.is_admin}
                    onCheckedChange={(checked) => {
                      setNewUser({
                        ...newUser,
                        is_admin: checked === true
                      });
                    }}
                  />
                  <label
                    htmlFor="is_admin"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Grant admin privileges
                  </label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setNewUser({
                  username: '',
                  email: '',
                  name: '',
                  password: '',
                  confirmPassword: '',
                  is_admin: false
                });
                setFormErrors({});
                setShowAddDialog(false);
              }}>
                Cancel
              </Button>
              <Button onClick={handleAddUser} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <span className="animate-spin mr-2">⟳</span>
                    Adding...
                  </>
                ) : 'Add User'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Add Role Dialog */}
        <Dialog open={showAddRoleDialog} onOpenChange={setShowAddRoleDialog}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Create New Role</DialogTitle>
              <DialogDescription>Define a new role and its permissions</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="role-name" className="text-right">
                  Role Name
                </Label>
                <Input id="role-name" placeholder="Role Name" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="role-description" className="text-right">
                  Description
                </Label>
                <Input id="role-description" placeholder="Brief description" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="base-role" className="text-right">
                  Base On
                </Label>
                <select
                  id="base-role"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                >
                  <option value="">Start from scratch</option>
                  {roles.map(role => (
                    <option key={role.id} value={role.name}>Copy from {role.name}</option>
                  ))}
                </select>
              </div>
              <div className="col-span-full">
                <Label className="block mb-2">Access Level</Label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <Checkbox id="access-settings" />
                    <Label htmlFor="access-settings" className="flex-1">
                      <span className="font-medium">Settings Access</span>
                      <p className="text-sm font-normal text-gray-500">Can view and modify settings</p>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <Checkbox id="access-users" />
                    <Label htmlFor="access-users" className="flex-1">
                      <span className="font-medium">User Management</span>
                      <p className="text-sm font-normal text-gray-500">Can create and manage users</p>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <Checkbox id="access-data" />
                    <Label htmlFor="access-data" className="flex-1">
                      <span className="font-medium">Data Access</span>
                      <p className="text-sm font-normal text-gray-500">Can view and modify system data</p>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <Checkbox id="access-security" />
                    <Label htmlFor="access-security" className="flex-1">
                      <span className="font-medium">Security Controls</span>
                      <p className="text-sm font-normal text-gray-500">Can access security settings</p>
                    </Label>
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddRoleDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddRole}>Create Role</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* View Role Permissions Dialog */}
        {selectedRole && (
          <Dialog open={showPermissionDialog} onOpenChange={setShowPermissionDialog}>
            <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {selectedRole.name === 'Admin' ? <ShieldAlert className="h-5 w-5 text-red-500" /> :
                    selectedRole.name === 'Sub-Admin' ? <ShieldCheck className="h-5 w-5 text-primary" /> :
                    selectedRole.name === 'Moderator' ? <Shield className="h-5 w-5 text-amber-500" /> :
                    <ShieldQuestion className="h-5 w-5 text-gray-500" />
                  }
                  {selectedRole.name} Role Permissions
                </DialogTitle>
                <DialogDescription>
                  Configure specific permissions for the {selectedRole.name} role
                </DialogDescription>
              </DialogHeader>
              
              <div className="py-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Role Information</h3>
                  <Badge variant={getRoleBadgeVariant(selectedRole.badge)}>
                    {selectedRole.badge === 'highest' ? 'Highest Privilege' :
                      selectedRole.badge === 'elevated' ? 'Elevated Privilege' :
                      selectedRole.badge === 'limited' ? 'Limited Privilege' :
                      'Default Privilege'
                    }
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-4">{selectedRole.description}</p>
                
                <Separator className="my-4" />
                
                <h3 className="text-lg font-semibold mb-4">Permission Modules</h3>
                
                <div className="space-y-6">
                  {permissionModules.map((module, idx) => (
                    <div key={idx} className="rounded-md border">
                      <div className="p-3 bg-gray-50 border-b flex justify-between items-center">
                        <h4 className="font-medium">{module.name}</h4>
                        {selectedRole.name === 'Admin' ? (
                          <Badge variant="outline" className="bg-gray-100">Always Full Access</Badge>
                        ) : (
                          <div className="flex items-center space-x-2">
                            <Label htmlFor={`module-toggle-${idx}`} className="text-sm">
                              Enable All
                            </Label>
                            <Switch 
                              id={`module-toggle-${idx}`} 
                              disabled={selectedRole.name === 'Admin'}
                              checked={module.permissions.every(p => p.roles.includes(selectedRole.name))}
                            />
                          </div>
                        )}
                      </div>
                      <div className="p-3 divide-y">
                        {module.permissions.map((permission, i) => (
                          <div key={i} className="py-2 flex items-center justify-between">
                            <Label 
                              htmlFor={`perm-${idx}-${i}`} 
                              className="flex-1 cursor-pointer"
                            >
                              {permission.label}
                            </Label>
                            <Checkbox 
                              id={`perm-${idx}-${i}`} 
                              checked={permission.roles.includes(selectedRole.name)}
                              disabled={selectedRole.name === 'Admin'} // Admin always has all permissions
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setShowPermissionDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSavePermissions}>Save Permissions</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the 
                {itemToDelete.type === 'user' ? ' user account' : ' role'} and remove
                {itemToDelete.type === 'user' ? ' their data from our servers.' : ' all associated permissions.'}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteItem} className="bg-red-600 hover:bg-red-700">
                {itemToDelete.type === 'user' ? (
                  <UserX className="h-4 w-4 mr-2" />
                ) : (
                  <Trash2 className="h-4 w-4 mr-2" />
                )}
                Delete {itemToDelete.type === 'user' ? 'User' : 'Role'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AppLayout>
  );
}