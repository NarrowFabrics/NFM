import { Settings, Users, Database, FileText, Save, Cog, Factory, Calculator, BellRing } from "lucide-react";
import { Card, CardDescription } from "@/components/ui/card";
import { Link } from "wouter";
import AppLayout from "@/components/layout/app-layout";

export default function SettingsPage() {
  const settingsOptions = [
    {
      icon: <Settings className="w-12 h-12" />,
      title: "Narrow Fabrics Settings",
      description: "Configure fabric parts, yarn types, and production units",
      href: "/settings/narrow-fabrics-settings"
    },
    {
      icon: <Users className="w-12 h-12" />,
      title: "User Control Settings",
      description: "Manage users, roles, and permissions",
      href: "/settings/user-control"
    },
    {
      icon: <Factory className="w-12 h-12" />,
      title: "Factory & Buyer Data",
      description: "Configure factory locations and buyer information",
      href: "/settings/factory-data"
    },
    {
      icon: <Calculator className="w-12 h-12" />,
      title: "Price Quotation Data",
      description: "Configure exchange rates, markups, and templates",
      href: "/settings/price-quotation-data"
    },
    {
      icon: <BellRing className="w-12 h-12" />,
      title: "Notice Management",
      description: "Create and manage system-wide announcements and notices",
      href: "/settings/notices"
    },
    {
      icon: <Save className="w-12 h-12" />,
      title: "Backup & Restore",
      description: "Manage database backups and restoration",
      href: "/settings/backup"
    },
    {
      icon: <Cog className="w-12 h-12" />,
      title: "App Settings",
      description: "Configure appearance and system behavior",
      href: "/settings/app-settings"
    }
  ];

  return (
    <AppLayout title="Settings" description="Manage application settings">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Settings className="h-7 w-7 text-primary" />
              Settings
            </h1>
            <p className="text-gray-500 mt-1">Configure application settings and preferences</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {settingsOptions.map((option) => (
            <Link href={option.href} key={option.href}>
              <Card className="p-6 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition-colors">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="text-primary">{option.icon}</div>
                  <div>
                    <h2 className="text-xl font-semibold">{option.title}</h2>
                    <CardDescription className="mt-2">{option.description}</CardDescription>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}