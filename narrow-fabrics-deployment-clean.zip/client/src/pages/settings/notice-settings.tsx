import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { BellRing, Calendar, CalendarClock, Plus, Edit2, Trash2, AlertTriangle, Info, CheckCircle2, Clock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useFormatting } from "@/contexts/FormatContext";
import { TimeFormatDisplay, getTimeFormatText } from "@/components/ui/format-display";
import { TimeInput } from "@/components/ui/time-input";
import { TimeDisplay } from "@/components/ui/time-display";
import AppLayout from "@/components/layout/app-layout";

// Form validation schema
const formSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters long" }),
  content: z.string().min(10, { message: "Content must be at least 10 characters long" }),
  priority: z.enum(["low", "medium", "high"]),
  start_date: z.string().min(1, { message: "Start date is required" }),
  end_date: z.string().optional(),
  start_time: z.string().optional(),
  end_time: z.string().optional(),
  is_published: z.boolean().default(false),
  is_scheduled: z.boolean().default(false),
  department: z.string().optional(),
  target_roles: z.array(z.string()).optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface Notice {
  id: number;
  title: string;
  content: string;
  priority: string;
  start_date: string;
  end_date?: string;
  is_published: boolean;
  is_scheduled: boolean;
  created_by: number;
  created_at: string;
  updated_at: string;
  department?: string;
  target_roles?: string; // This comes as a comma-separated string from the database
}

export default function NoticeSettingsPage() {
  const { toast } = useToast();
  const { formatDate, timeFormat } = useFormatting();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedNotice, setSelectedNotice] = useState<Notice | null>(null);
  const [deleteNoticeId, setDeleteNoticeId] = useState<number | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  // Define default form values
  const defaultValues: FormValues = {
    title: "",
    content: "",
    priority: "medium",
    start_date: new Date().toISOString().split('T')[0],
    end_date: undefined,
    start_time: "09:00",
    end_time: undefined,
    is_published: true,
    is_scheduled: false,
    department: undefined,
    target_roles: [],
  };

  // Define the response type from API
  interface NoticesResponse {
    notices: Notice[];
    total: number;
  }

  // Get notices
  const { data, isLoading } = useQuery<NoticesResponse>({
    queryKey: ['/api/notices'],
  });
  
  // Extract notices from response
  const notices = data?.notices;

  // Create form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  // Edit form
  const editForm = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  // Create notice mutation
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      // Convert data types to match server expectations
      let startDate = values.start_date ? new Date(values.start_date) : new Date();
      let endDate = values.end_date ? new Date(values.end_date) : undefined;
      
      // Apply time if scheduled and time fields are provided
      if (values.is_scheduled) {
        if (values.start_time) {
          const [hours, minutes] = values.start_time.split(':').map(Number);
          startDate.setHours(hours, minutes);
        }
        
        if (endDate && values.end_time) {
          const [hours, minutes] = values.end_time.split(':').map(Number);
          endDate.setHours(hours, minutes);
        }
      }
      
      const formattedValues = {
        ...values,
        // Use the date objects with time applied
        start_date: startDate,
        end_date: endDate,
        // Send target_roles as is - schema will handle conversion
        target_roles: values.target_roles,
      };
      
      return apiRequest('/api/notices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formattedValues),
      });
    },
    onSuccess: () => {
      toast({
        title: "Notice created",
        description: "Notice has been created successfully",
      });
      setIsCreateDialogOpen(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/notices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notices/active'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating notice",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update notice mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: FormValues }) => {
      // Convert data types to match server expectations
      let startDate = values.start_date ? new Date(values.start_date) : new Date();
      let endDate = values.end_date ? new Date(values.end_date) : undefined;
      
      // Apply time if scheduled and time fields are provided
      if (values.is_scheduled) {
        if (values.start_time) {
          const [hours, minutes] = values.start_time.split(':').map(Number);
          startDate.setHours(hours, minutes);
        }
        
        if (endDate && values.end_time) {
          const [hours, minutes] = values.end_time.split(':').map(Number);
          endDate.setHours(hours, minutes);
        }
      }
      
      const formattedValues = {
        ...values,
        // Use the date objects with time applied
        start_date: startDate,
        end_date: endDate,
        // Send target_roles as is - schema will handle conversion
        target_roles: values.target_roles,
      };
      
      return apiRequest(`/api/notices/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formattedValues),
      });
    },
    onSuccess: () => {
      toast({
        title: "Notice updated",
        description: "Notice has been updated successfully",
      });
      setIsEditDialogOpen(false);
      editForm.reset();
      setSelectedNotice(null);
      queryClient.invalidateQueries({ queryKey: ['/api/notices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notices/active'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating notice",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete notice mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/notices/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Notice deleted",
        description: "Notice has been deleted successfully",
      });
      setIsDeleteDialogOpen(false);
      setDeleteNoticeId(null);
      queryClient.invalidateQueries({ queryKey: ['/api/notices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notices/active'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting notice",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Check for scheduled notices mutation
  const checkScheduledMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('/api/notices/check-scheduled', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({}),
      });
    },
    onSuccess: (data) => {
      if (data.published > 0) {
        toast({
          title: "Scheduled notices published",
          description: `${data.published} notices were automatically published.`,
        });
      } else {
        toast({
          title: "No scheduled notices to publish",
          description: "No notices are currently scheduled for publishing.",
        });
      }
      queryClient.invalidateQueries({ queryKey: ['/api/notices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notices/active'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error checking scheduled notices",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Publish/Unpublish notice mutation
  const publishMutation = useMutation({
    mutationFn: async ({ id, publish }: { id: number; publish: boolean }) => {
      return apiRequest(`/api/notices/${id}/${publish ? 'publish' : 'unpublish'}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Notice status updated",
        description: "Notice publishing status has been updated",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/notices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notices/active'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating status",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCreateSubmit = (values: FormValues) => {
    // Log to help debug validation issues
    console.log('Form values:', values);
    console.log('Form errors:', form.formState.errors);
    createMutation.mutate(values);
  };

  const handleEditSubmit = (values: FormValues) => {
    // Log to help debug validation issues
    console.log('Edit form values:', values);
    console.log('Edit form errors:', editForm.formState.errors);
    
    if (selectedNotice) {
      updateMutation.mutate({ id: selectedNotice.id, values });
    }
  };

  const handleEditNotice = (notice: Notice) => {
    setSelectedNotice(notice);
    
    // Convert target_roles from comma-separated string to array if needed
    const targetRolesArray = notice.target_roles?.length ? notice.target_roles.split(',') : [];
    
    // Extract time information from the date fields if available
    const startDate = new Date(notice.start_date);
    const endDate = notice.end_date ? new Date(notice.end_date) : undefined;
    
    // Format the time in HH:MM format
    const startTime = startDate ? 
      `${String(startDate.getHours()).padStart(2, '0')}:${String(startDate.getMinutes()).padStart(2, '0')}` : 
      "09:00";
    
    const endTime = endDate ? 
      `${String(endDate.getHours()).padStart(2, '0')}:${String(endDate.getMinutes()).padStart(2, '0')}` : 
      undefined;
    
    // Set form values
    editForm.reset({
      title: notice.title,
      content: notice.content,
      priority: notice.priority as "low" | "medium" | "high",
      start_date: startDate.toISOString().split('T')[0],
      end_date: endDate ? endDate.toISOString().split('T')[0] : undefined,
      start_time: startTime,
      end_time: endTime,
      is_published: notice.is_published,
      is_scheduled: notice.is_scheduled,
      department: notice.department,
      target_roles: targetRolesArray,
    });
    
    setIsEditDialogOpen(true);
  };

  const handleDeleteClick = (notice: Notice) => {
    setDeleteNoticeId(notice.id);
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (deleteNoticeId) {
      deleteMutation.mutate(deleteNoticeId);
    }
  };

  const handlePublishToggle = (notice: Notice) => {
    publishMutation.mutate({ id: notice.id, publish: !notice.is_published });
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  // Filter notices based on active tab
  const filteredNotices = notices?.filter(notice => {
    if (activeTab === "all") return true;
    if (activeTab === "published") return notice.is_published;
    if (activeTab === "draft") return !notice.is_published;
    if (activeTab === "scheduled") return notice.is_scheduled;
    return true;
  });

  // Helper function to get priority color
  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-amber-600 bg-amber-50';
      case 'low': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <AppLayout title="Notice Management" description="Manage system notices and announcements">
      <div className="container py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <BellRing className="h-7 w-7 text-primary" />
              Notice Management
            </h1>
            <p className="text-gray-500 mt-1">Create and manage system-wide announcements and notices</p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={() => checkScheduledMutation.mutate()}
              disabled={checkScheduledMutation.isPending}
            >
              <CalendarClock className="h-4 w-4" />
              {checkScheduledMutation.isPending 
                ? "Checking..." 
                : "Check Scheduled Notices"}
            </Button>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  New Notice
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Create Notice</DialogTitle>
                  <DialogDescription>
                    Create a new notice or announcement to display to users
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleCreateSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Notice title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Content</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Notice content" className="min-h-[100px]" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Priority</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select priority" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="department"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Department (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Production, Finance" {...field} value={field.value || ''} />
                            </FormControl>
                            <FormDescription className="text-xs">
                              You can leave this field empty
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="pt-2">
                      <div className="flex items-center gap-2 mb-3">
                        <Clock className="h-5 w-5 text-muted-foreground" />
                        <h3 className="text-sm font-medium">Notice Schedule Settings</h3>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="start_date"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Schedule Date</FormLabel>
                              <FormControl>
                                <Input 
                                  type="date" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription className="text-xs">
                                When the notice will become visible
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="start_time"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Schedule Time</FormLabel>
                              <FormControl>
                                <TimeInput
                                  value={field.value || '09:00'}
                                  onChange={field.onChange}
                                />
                              </FormControl>
                              <FormDescription className="text-xs">
                                <TimeFormatDisplay />
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <FormField
                          control={form.control}
                          name="end_date"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>End Date (Optional)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="date" 
                                  {...field} 
                                  value={field.value || ''} 
                                />
                              </FormControl>
                              <FormDescription className="text-xs">
                                When the notice will stop displaying
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="end_time"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>End Time (Optional)</FormLabel>
                              <FormControl>
                                <TimeInput
                                  value={field.value || ''}
                                  onChange={field.onChange}
                                />
                              </FormControl>
                              <FormDescription className="text-xs">
                                <TimeFormatDisplay />
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <FormField
                        control={form.control}
                        name="is_published"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                            <div className="space-y-0.5">
                              <FormLabel>Publish Immediately</FormLabel>
                              <FormDescription className="text-xs">
                                Make this notice visible right away
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="is_scheduled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                            <div className="space-y-0.5">
                              <FormLabel>Schedule Notice</FormLabel>
                              <FormDescription className="text-xs">
                                Use the specified time settings
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <DialogFooter className="pt-4">
                      <Button variant="outline" type="button" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
                      <Button type="submit" disabled={createMutation.isPending}>
                        {createMutation.isPending ? "Creating..." : "Create Notice"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        <Tabs defaultValue="all" value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Notices</TabsTrigger>
            <TabsTrigger value="published">Published</TabsTrigger>
            <TabsTrigger value="draft">Drafts</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
          </TabsList>
          
          <TabsContent value={activeTab}>
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="p-4">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-5 w-1/3" />
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                    <CardFooter className="p-4 flex justify-between">
                      <Skeleton className="h-10 w-24" />
                      <Skeleton className="h-10 w-24" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : filteredNotices && filteredNotices.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredNotices.map((notice) => (
                  <Card key={notice.id} className="overflow-hidden">
                    <CardHeader className="p-4 pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg mr-2">{notice.title}</CardTitle>
                        <Badge className={getPriorityColor(notice.priority)}>
                          {notice.priority}
                        </Badge>
                      </div>
                      <div className="flex items-center mt-1 text-xs text-muted-foreground">
                        <Calendar className="mr-1 h-3 w-3" />
                        {new Date(notice.created_at).toLocaleDateString()}
                      </div>
                      {notice.is_scheduled && (
                        <div className="flex items-center mt-1 text-xs text-blue-600">
                          <Clock className="mr-1 h-3 w-3" />
                          Scheduled: {new Date(notice.start_date).toLocaleDateString()}
                          <span className="ml-1">
                            at <TimeDisplay 
                                 time={`${String(new Date(notice.start_date).getHours()).padStart(2, '0')}:${String(new Date(notice.start_date).getMinutes()).padStart(2, '0')}`} 
                               />
                          </span>
                        </div>
                      )}
                    </CardHeader>
                    <CardContent className="p-4 pt-2">
                      <p className="text-sm line-clamp-3">{notice.content}</p>
                      {notice.department && (
                        <Badge variant="outline" className="mt-2 text-xs">
                          {notice.department}
                        </Badge>
                      )}
                    </CardContent>
                    <CardFooter className="p-4 flex justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleEditNotice(notice)}
                        >
                          <Edit2 className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={() => handleDeleteClick(notice)}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                      <div>
                        <Button 
                          variant={notice.is_published ? "default" : "secondary"} 
                          size="sm"
                          onClick={() => handlePublishToggle(notice)}
                        >
                          {notice.is_published 
                            ? <CheckCircle2 className="h-4 w-4 mr-1" /> 
                            : <Info className="h-4 w-4 mr-1" />
                          }
                          {notice.is_published ? "Published" : "Publish"}
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="bg-gray-100 rounded-full p-3 mb-4">
                  <AlertTriangle className="h-6 w-6 text-amber-500" />
                </div>
                <h3 className="text-lg font-medium mb-1">No notices found</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {activeTab === "all" 
                    ? "There are no notices in the system yet." 
                    : `There are no ${activeTab} notices available.`
                  }
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create New Notice
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Notice Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Notice</DialogTitle>
            <DialogDescription>
              Update the notice information
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Notice title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editForm.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Notice content" className="min-h-[100px]" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select priority" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="department"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Department (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Production, Finance" {...field} value={field.value || ''} />
                      </FormControl>
                      <FormDescription className="text-xs">
                        You can leave this field empty
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="pt-2">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <h3 className="text-sm font-medium">Notice Schedule Settings</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="start_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Schedule Date</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription className="text-xs">
                          When the notice will become visible
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="start_time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Schedule Time</FormLabel>
                        <FormControl>
                          <TimeInput
                            value={field.value || '09:00'}
                            onChange={field.onChange}
                          />
                        </FormControl>
                        <FormDescription className="text-xs">
                          <TimeFormatDisplay />
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <FormField
                    control={editForm.control}
                    name="end_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date (Optional)</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                            value={field.value || ''} 
                          />
                        </FormControl>
                        <FormDescription className="text-xs">
                          When the notice will stop displaying
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="end_time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Time (Optional)</FormLabel>
                        <FormControl>
                          <TimeInput
                            value={field.value || ''}
                            onChange={field.onChange}
                          />
                        </FormControl>
                        <FormDescription className="text-xs">
                          <TimeFormatDisplay />
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 pt-2">
                <FormField
                  control={editForm.control}
                  name="is_published"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Publish</FormLabel>
                        <FormDescription className="text-xs">
                          Make this notice visible
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="is_scheduled"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Schedule</FormLabel>
                        <FormDescription className="text-xs">
                          Use the specified time settings
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter className="pt-4">
                <Button variant="outline" type="button" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update Notice"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to delete this notice?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the notice
              and remove it from the system.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleConfirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}