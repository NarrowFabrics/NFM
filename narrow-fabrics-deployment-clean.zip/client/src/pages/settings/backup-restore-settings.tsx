import { useState, useEffect, useCallback } from 'react';
import AppLayout from '@/components/layout/app-layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import {
  Save,
  UploadCloud,
  Calendar,
  Database,
  FileDown,
  FileUp,
  Clock,
  RotateCcw,
  Trash,
  FileIcon,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  ShieldAlert,
  Info,
  ChevronRight
} from 'lucide-react';

// Types for our backup system
interface BackupHistoryItem {
  id: number;
  fileName: string;
  date: string;
  time: string;
  size: string;
  status: 'Completed' | 'Failed' | 'In Progress';
  type: 'Full' | 'Differential' | 'Partial';
  isEncrypted: boolean;
  isCompressed: boolean;
  downloadUrl?: string;
}

interface BackupSchedule {
  id: number;
  name: string;
  frequency: 'Daily' | 'Weekly' | 'Monthly' | 'Custom';
  backupType: 'Full' | 'Differential';
  nextRun: string;
  status: 'Active' | 'Paused';
  tablesToInclude?: string[];
  retentionPeriod: number;
}

interface BackupSettings {
  compression: boolean;
  encryption: boolean;
  retentionPeriod: number;
  versionsToKeep: number;
  emailNotifications: boolean;
  notifyOnSuccess: boolean;
  notifyOnFailure: boolean;
  autoBackupBeforeRestore: boolean;
}

export default function BackupRestoreSettings() {
  const { toast } = useToast();
  const [backingUp, setBackingUp] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Backup database mutation - uses the new /api/database/backup endpoint
  const backupMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('/api/database/backup', {
        method: 'POST',
      });
      return response;
    },
    onSuccess: (data) => {
      // Create a blob from the data
      const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });

      // Create a date string for the filename
      const date = new Date();
      const dateString = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

      // Create a link to download the file
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `database-backup-${dateString}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: 'Backup created',
        description: 'Database has been backed up successfully',
      });

      setBackingUp(false);
      setBackupProgress(100);
    },
    onError: (error: Error) => {
      toast({
        title: 'Error creating backup',
        description: error.message,
        variant: 'destructive',
      });
      setBackingUp(false);
      setBackupProgress(0);
    },
  });

  // Handle creating a backup
  const handleBackup = () => {
    setBackingUp(true);
    setBackupProgress(0);
    backupMutation.mutate();
  };


  const [restoreProgress, setRestoreProgress] = useState(0);
  const [restoring, setRestoring] = useState(false);
  const [autoBackupInfo, setAutoBackupInfo] = useState<any>(null);
  const [fileValidationStatus, setFileValidationStatus] = useState<'valid' | 'invalid' | 'checking' | null>(null);
  const [fileValidationMessage, setFileValidationMessage] = useState<string>('');

  // Handle restoring from a backup file
  const handleRestore = () => {
    //setRestoreConfirmOpen(false);

    if (!selectedFile) {
      toast({
        title: 'No file selected',
        description: 'Please select a backup file to restore',
        variant: 'destructive',
      });
      return;
    }

    if (fileValidationStatus === 'invalid') {
      toast({
        title: 'Invalid backup file',
        description: fileValidationMessage || 'The selected file is not a valid backup file',
        variant: 'destructive',
      });
      return;
    }

    // Create a FormData object to send the file
    const formData = new FormData();
    formData.append('backupFile', selectedFile);

    // Set restore in progress
    setRestoring(true);
    setRestoreProgress(10);

    // Simulate progress while restoration is happening
    const interval = setInterval(() => {
      setRestoreProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 5;
      });
    }, 500);

    // Start the restore process
    //restoreMutation.mutate(formData, {
    //  onSuccess: (data) => {
    //    clearInterval(interval);
    //    setRestoreProgress(100);

    //    // If there's auto backup info, save it
    //    if (data.autoBackup) {
    //      setAutoBackupInfo(data.autoBackup);
    //    }

    //    setTimeout(() => {
    //      setRestoring(false);
    //      setRestoreProgress(0);
    //    }, 2000);
    //  },
    //  onError: () => {
    //    clearInterval(interval);
    //    setRestoring(false);
    //    setRestoreProgress(0);
    //  }
    //});
  };

  // Handle file selection for restore
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setSelectedFile(file);

      // Validate the backup file
      setFileValidationStatus('checking');

      // Read the file content
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          const data = JSON.parse(content);

          // Basic validation - check for required fields
          if (data && data.version && data.timestamp &&
            data.users && Array.isArray(data.users) &&
            data.yarnTypes && Array.isArray(data.yarnTypes)) {

            setFileValidationStatus('valid');
            setFileValidationMessage('');
          } else {
            setFileValidationStatus('invalid');
            setFileValidationMessage('The file does not contain valid backup data');
          }
        } catch (err) {
          setFileValidationStatus('invalid');
          setFileValidationMessage('Could not parse the file as JSON');
        }
      };

      reader.onerror = () => {
        setFileValidationStatus('invalid');
        setFileValidationMessage('Error reading the file');
      };

      reader.readAsText(file);
    } else {
      setSelectedFile(null);
      setFileValidationStatus(null);
      setFileValidationMessage('');
    }
  };

  // Mock backup settings
  const backupSettings: BackupSettings = {
    compression: true,
    encryption: false,
    retentionPeriod: 30,
    versionsToKeep: 5,
    emailNotifications: true,
    notifyOnSuccess: false,
    notifyOnFailure: true,
    autoBackupBeforeRestore: true
  };

  return (
    <AppLayout title="Backup & Restore Settings" description="Manage database backups and restoration">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Save className="h-7 w-7 text-primary" />
              Backup & Restore Settings
            </h1>
            <p className="text-gray-500 mt-1">Manage database backups and restoration</p>
          </div>
        </div>

        <Tabs defaultValue="backup" className="space-y-4">
          <TabsList>
            <TabsTrigger value="backup">Backup</TabsTrigger>
            <TabsTrigger value="restore">Restore</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Backup Tab */}
          <TabsContent value="backup" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileDown className="h-5 w-5 text-primary" />
                  Create Database Backup
                </CardTitle>
                <CardDescription>
                  Create a backup of your database that you can download to your device
                </CardDescription>
              </CardHeader>
              <CardContent>
                {(backingUp || backupMutation.isPending) && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Creating backup...</span>
                      <span>{backupProgress}%</span>
                    </div>
                    <Progress value={backupProgress} className="h-2" />
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => {
                    toast({
                      title: "Backup operation",
                      description: "Configure automatic backups in settings",
                    })
                  }}
                >
                  <Clock className="h-4 w-4 mr-2" />
                  Schedule
                </Button>
                <Button
                  onClick={handleBackup}
                  disabled={backingUp || backupMutation.isPending}
                >
                  {(backingUp || backupMutation.isPending) ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <FileDown className="h-4 w-4 mr-2" />
                  )}
                  {(backingUp || backupMutation.isPending) ? "Creating backup..." : "Create backup"}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Restore Tab */}
          <TabsContent value="restore" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RotateCcw className="h-5 w-5 text-primary" />
                  Restore from Backup
                </CardTitle>
                <CardDescription>
                  Restore your database from a previous backup file
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Input
                  type="file"
                  accept=".json"
                  onChange={handleFileChange}
                />
                {selectedFile && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <FileIcon className="h-4 w-4 text-gray-500" />
                      <span>{selectedFile.name}</span>
                      <Badge variant="outline" className="ml-2">
                        {(selectedFile.size / 1024).toFixed(2)} KB
                      </Badge>
                    </div>

                    {fileValidationStatus === 'checking' && (
                      <div className="flex items-center gap-2 text-sm text-yellow-600">
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        <span>Checking file validity...</span>
                      </div>
                    )}

                    {fileValidationStatus === 'valid' && (
                      <div className="flex items-center gap-2 text-sm text-green-600">
                        <CheckCircle className="h-4 w-4" />
                        <span>Valid backup file</span>
                      </div>
                    )}

                    {fileValidationStatus === 'invalid' && (
                      <div className="flex items-center gap-2 text-sm text-red-600">
                        <AlertTriangle className="h-4 w-4" />
                        <span>{fileValidationMessage || 'Invalid backup file'}</span>
                      </div>
                    )}
                  </div>
                )}
                {restoring && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Restore progress</span>
                      <span>{restoreProgress}%</span>
                    </div>
                    <Progress value={restoreProgress} className="h-2" />
                  </div>
                )}

                {autoBackupInfo && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 text-sm">
                    <div className="flex items-center gap-2 font-medium text-yellow-800 mb-1">
                      <ShieldAlert className="h-4 w-4" />
                      <span>Automatic backup created</span>
                    </div>
                    <p className="text-yellow-700 mb-2">
                      A backup of your previous data was automatically created before the restore operation.
                    </p>
                    <div className="flex items-center gap-2 text-yellow-700">
                      <Info className="h-4 w-4" />
                      <span>Filename: {autoBackupInfo.filename}</span>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button
                  variant="destructive"
                  onClick={handleRestore}
                  disabled={!selectedFile}
                >
                  {restoring ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <RotateCcw className="h-4 w-4 mr-2" />
                  )}
                  {restoring ? "Restoring..." : "Restore from Backup"}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-primary" />
                  Backup Settings
                </CardTitle>
                <CardDescription>
                  Configure backup preferences and notification settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Backup Options</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="compression" className="flex items-center gap-2">
                          <span>Compression</span>
                          <Badge variant="outline" className="ml-2">Reduces file size</Badge>
                        </Label>
                        <Switch
                          id="compression"
                          checked={backupSettings.compression}
                          onCheckedChange={(checked) => {
                            // In a real app, we would update the state and call an API
                            toast({
                              title: "Setting updated",
                              description: `Compression ${checked ? 'enabled' : 'disabled'}`
                            });
                          }}
                        />
                      </div>
                      <p className="text-sm text-gray-500">
                        Compress backup files to save storage space
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="encryption" className="flex items-center gap-2">
                          <span>Encryption</span>
                          <Badge variant="outline" className="ml-2">Improves security</Badge>
                        </Label>
                        <Switch
                          id="encryption"
                          checked={backupSettings.encryption}
                          onCheckedChange={(checked) => {
                            toast({
                              title: "Setting updated",
                              description: `Encryption ${checked ? 'enabled' : 'disabled'}`
                            });
                          }}
                        />
                      </div>
                      <p className="text-sm text-gray-500">
                        Encrypt backup files to protect sensitive data
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="retentionPeriod">Retention Period (days)</Label>
                      <Input
                        id="retentionPeriod"
                        type="number"
                        min="1"
                        value={backupSettings.retentionPeriod.toString()}
                        onChange={(e) => {
                          const value = parseInt(e.target.value);
                          if (!isNaN(value) && value > 0) {
                            toast({
                              title: "Setting updated",
                              description: `Retention period set to ${value} days`
                            });
                          }
                        }}
                      />
                      <p className="text-sm text-gray-500">
                        Number of days to keep backups before automatic deletion
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="backupVersions">Versions to Keep</Label>
                      <Input
                        id="backupVersions"
                        type="number"
                        min="1"
                        value={backupSettings.versionsToKeep.toString()}
                        onChange={(e) => {
                          const value = parseInt(e.target.value);
                          if (!isNaN(value) && value > 0) {
                            toast({
                              title: "Setting updated",
                              description: `Versions to keep set to ${value}`
                            });
                          }
                        }}
                      />
                      <p className="text-sm text-gray-500">
                        Number of versions to retain for each backup
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="text-lg font-medium">Notifications</h3>
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Email Notifications</Label>
                        <p className="text-sm text-gray-500">Receive backup status updates via email</p>
                      </div>
                      <Switch
                        id="emailNotifications"
                        checked={backupSettings.emailNotifications}
                        onCheckedChange={(checked) => {
                          toast({
                            title: "Setting updated",
                            description: `Email notifications ${checked ? 'enabled' : 'disabled'}`
                          });
                        }}
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-3 ml-6">
                        <Checkbox
                          id="notifyOnSuccess"
                          checked={backupSettings.notifyOnSuccess}
                          onCheckedChange={(checked) => {
                            if (typeof checked === 'boolean') {
                              toast({
                                title: "Setting updated",
                                description: `Notifications for successful backups ${checked ? 'enabled' : 'disabled'}`
                              });
                            }
                          }}
                        />
                        <Label htmlFor="notifyOnSuccess">Notify on successful backups</Label>
                      </div>
                      <div className="flex items-center gap-3 ml-6">
                        <Checkbox
                          id="notifyOnFailure"
                          checked={backupSettings.notifyOnFailure}
                          onCheckedChange={(checked) => {
                            if (typeof checked === 'boolean') {
                              toast({
                                title: "Setting updated",
                                description: `Notifications for failed backups ${checked ? 'enabled' : 'disabled'}`
                              });
                            }
                          }}
                        />
                        <Label htmlFor="notifyOnFailure">Notify on backup failures</Label>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button
                  onClick={() => {
                    toast({
                      title: "Settings saved",
                      description: "Your backup settings have been saved successfully"
                    });
                  }}
                >
                  Save Settings
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}