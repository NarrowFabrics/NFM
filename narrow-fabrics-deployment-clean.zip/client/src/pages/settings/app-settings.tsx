import { useState, useEffect } from 'react';
import AppLayout from '@/components/layout/app-layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Settings, Moon, Sun, Globe, BellRing, Eye, Bell, CheckSquare } from 'lucide-react';
import { useFormatting } from '@/contexts/FormatContext';
import FormatDemo from '@/components/ui/format-demo';

export default function AppSettings() {
  const { toast } = useToast();
  const formatContext = useFormatting();
  const [theme, setTheme] = useState('light');
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState('en');
  const [currencyFormat, setCurrencyFormat] = useState('usd');
  const [exchangeRate, setExchangeRate] = useState(110); // 1 USD = 110 BDT (default value)
  const [dateFormat, setDateFormat] = useState(formatContext.dateFormat || 'MM/DD/YYYY');
  const [timeFormat, setTimeFormat] = useState(formatContext.timeFormat || '12'); // 12-hour format by default
  const [fontSize, setFontSize] = useState(16);
  const [autoLogout, setAutoLogout] = useState(30);
  const [analytics, setAnalytics] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);
  
  // Load saved settings from localStorage on initial load
  useEffect(() => {
    const savedDateFormat = localStorage.getItem('dateFormat');
    const savedTimeFormat = localStorage.getItem('timeFormat');
    const savedLanguage = localStorage.getItem('language');
    const savedCurrencyFormat = localStorage.getItem('currencyFormat');
    const savedAutoLogout = localStorage.getItem('autoLogout');
    const savedAnalytics = localStorage.getItem('analytics');
    
    if (savedDateFormat) {
      setDateFormat(savedDateFormat);
    }
    
    if (savedTimeFormat) {
      setTimeFormat(savedTimeFormat);
    }
    
    if (savedLanguage) {
      setLanguage(savedLanguage);
    }
    
    if (savedCurrencyFormat) {
      setCurrencyFormat(savedCurrencyFormat);
    }
    
    if (savedAutoLogout) {
      setAutoLogout(parseInt(savedAutoLogout, 10));
    }
    
    if (savedAnalytics !== null) {
      setAnalytics(savedAnalytics === 'true');
    }
  }, []);
  
  const handleSaveGeneral = () => {
    // Save settings to localStorage for persistence
    const settingsToSave = {
      language,
      currencyFormat,
      dateFormat,
      timeFormat,
      autoLogout,
      analytics,
      ...(currencyFormat === 'bdt' && { exchangeRate }),
    };

    console.log('Saving settings:', settingsToSave);
    
    // Save all settings to localStorage
    localStorage.setItem('dateFormat', dateFormat);
    localStorage.setItem('timeFormat', timeFormat);
    localStorage.setItem('language', language);
    localStorage.setItem('currencyFormat', currencyFormat);
    localStorage.setItem('autoLogout', autoLogout.toString());
    localStorage.setItem('analytics', analytics.toString());
    
    if (currencyFormat === 'bdt' && exchangeRate) {
      localStorage.setItem('exchangeRate', exchangeRate.toString());
    }
    
    // The FormatContext will automatically pick up these changes on next render
    // because it reads from localStorage in its useEffect hook
    
    // Force a page reload to ensure all components using the format context are updated
    window.location.reload();
    
    toast({
      title: 'Settings Saved',
      description: 'General settings have been updated',
    });
  };
  
  const handleSavePreferences = () => {
    toast({
      title: 'Preferences Saved',
      description: 'Your preferences have been updated',
    });
  };
  
  const handleSaveNotifications = () => {
    toast({
      title: 'Notification Settings Saved',
      description: 'Your notification preferences have been updated',
    });
  };
  
  return (
    <AppLayout title="App Settings" description="Configure application settings">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Settings className="h-7 w-7 text-primary" />
              App Settings
            </h1>
            <p className="text-gray-500 mt-1">Configure application appearance and behavior</p>
          </div>
        </div>
        
        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          </TabsList>
          
          <TabsContent value="general" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>Configure basic application settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <select
                    id="language"
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="en">English</option>
                    <option value="fr">French</option>
                    <option value="es">Spanish</option>
                    <option value="de">German</option>
                    <option value="bn">Bengali</option>
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="currencyFormat">Currency Format</Label>
                  <select
                    id="currencyFormat"
                    value={currencyFormat}
                    onChange={(e) => setCurrencyFormat(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="usd">USD ($)</option>
                    <option value="eur">EUR (€)</option>
                    <option value="gbp">GBP (£)</option>
                    <option value="bdt">BDT (৳)</option>
                    <option value="inr">INR (₹)</option>
                  </select>
                </div>
                
                {currencyFormat === 'bdt' && (
                  <div className="space-y-2">
                    <Label htmlFor="exchangeRate">Exchange Rate (BDT to USD)</Label>
                    <div className="flex items-center space-x-2">
                      <input
                        id="exchangeRate"
                        type="number"
                        value={exchangeRate || 110}
                        onChange={(e) => setExchangeRate(parseFloat(e.target.value))}
                        placeholder="Enter exchange rate"
                        min="1"
                        step="0.01"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                      <span className="text-sm text-muted-foreground">1 USD = ? BDT</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Set the current exchange rate for converting between BDT and USD
                    </p>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="dateFormat">Date Format</Label>
                  <select
                    id="dateFormat"
                    value={dateFormat}
                    onChange={(e) => setDateFormat(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                    <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                    <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="timeFormat">Time Format</Label>
                  <select
                    id="timeFormat"
                    value={timeFormat}
                    onChange={(e) => setTimeFormat(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="12">12-hour (AM/PM)</option>
                    <option value="24">24-hour</option>
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="autoLogout">Auto Logout Time (minutes)</Label>
                  <div className="flex items-center space-x-4">
                    <Slider
                      id="autoLogout"
                      min={5}
                      max={60}
                      step={5}
                      value={[autoLogout]}
                      onValueChange={(value) => setAutoLogout(value[0])}
                      className="flex-1"
                    />
                    <span className="w-12 text-center">{autoLogout}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="analytics">Enable Analytics</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow collection of usage data to improve the application
                    </p>
                  </div>
                  <Switch
                    id="analytics"
                    checked={analytics}
                    onCheckedChange={setAnalytics}
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveGeneral}>Save Changes</Button>
              </CardFooter>
            </Card>
            
            {/* Date & Time Format Preview Card */}
            <FormatDemo />
          </TabsContent>
          
          <TabsContent value="appearance" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Appearance Settings</CardTitle>
                <CardDescription>Customize how the application looks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Theme</Label>
                  <div className="flex space-x-4">
                    <div 
                      className={`flex flex-col items-center space-y-2 cursor-pointer p-4 rounded-md ${theme === 'light' ? 'bg-primary/10 border border-primary' : 'bg-muted'}`}
                      onClick={() => setTheme('light')}
                    >
                      <Sun className="h-6 w-6" />
                      <span>Light</span>
                    </div>
                    <div 
                      className={`flex flex-col items-center space-y-2 cursor-pointer p-4 rounded-md ${theme === 'dark' ? 'bg-primary/10 border border-primary' : 'bg-muted'}`}
                      onClick={() => setTheme('dark')}
                    >
                      <Moon className="h-6 w-6" />
                      <span>Dark</span>
                    </div>
                    <div 
                      className={`flex flex-col items-center space-y-2 cursor-pointer p-4 rounded-md ${theme === 'system' ? 'bg-primary/10 border border-primary' : 'bg-muted'}`}
                      onClick={() => setTheme('system')}
                    >
                      <div className="h-6 w-6 flex">
                        <Sun className="h-6 w-3" />
                        <Moon className="h-6 w-3" />
                      </div>
                      <span>System</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fontSize">Font Size</Label>
                  <div className="flex items-center space-x-4">
                    <Slider
                      id="fontSize"
                      min={12}
                      max={24}
                      step={1}
                      value={[fontSize]}
                      onValueChange={(value) => setFontSize(value[0])}
                      className="flex-1"
                    />
                    <span className="w-12 text-center">{fontSize}px</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Sample text with the selected font size.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="density">Interface Density</Label>
                  <select
                    id="density"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="compact">Compact</option>
                    <option value="normal">Normal</option>
                    <option value="comfortable">Comfortable</option>
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="accentColor">Accent Color</Label>
                  <div className="grid grid-cols-6 gap-2">
                    {['#0ea5e9', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#ef4444'].map((color) => (
                      <div
                        key={color}
                        className="h-10 rounded-md cursor-pointer border"
                        style={{ backgroundColor: color }}
                        onClick={() => {
                          // Set accent color (in a real app)
                        }}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="animations">Enable Animations</Label>
                    <p className="text-sm text-muted-foreground">
                      Show animations throughout the interface
                    </p>
                  </div>
                  <Switch
                    id="animations"
                    defaultChecked
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSavePreferences}>Save Appearance</Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>Configure notification preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Enable Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive notifications about activities and updates
                    </p>
                  </div>
                  <Switch
                    checked={notifications}
                    onCheckedChange={setNotifications}
                  />
                </div>
                
                <div className="border rounded-md p-4 space-y-4">
                  <h3 className="font-medium flex items-center gap-1.5">
                    <BellRing className="h-4 w-4" />
                    System Notifications
                  </h3>
                  
                  <div className="space-y-3 ml-6">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="orderNotifications">New Orders</Label>
                      <Switch id="orderNotifications" defaultChecked disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="productionNotifications">Production Updates</Label>
                      <Switch id="productionNotifications" defaultChecked disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="inventoryNotifications">Inventory Alerts</Label>
                      <Switch id="inventoryNotifications" defaultChecked disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="userNotifications">User Activity</Label>
                      <Switch id="userNotifications" disabled={!notifications} />
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 space-y-4">
                  <h3 className="font-medium flex items-center gap-1.5">
                    <Bell className="h-4 w-4" />
                    Email Notifications
                  </h3>
                  
                  <div className="space-y-3 ml-6">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="dailySummary">Daily Summary</Label>
                      <Switch id="dailySummary" disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="weeklyReport">Weekly Report</Label>
                      <Switch id="weeklyReport" defaultChecked disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="importantAlerts">Important Alerts</Label>
                      <Switch id="importantAlerts" defaultChecked disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="marketingEmails">Marketing & Updates</Label>
                      <Switch 
                        id="marketingEmails" 
                        checked={marketingEmails}
                        onCheckedChange={setMarketingEmails}
                        disabled={!notifications} 
                      />
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 space-y-4">
                  <h3 className="font-medium flex items-center gap-1.5">
                    <CheckSquare className="h-4 w-4" />
                    Task Reminders
                  </h3>
                  
                  <div className="space-y-3 ml-6">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="dueDateReminders">Due Date Reminders</Label>
                      <Switch id="dueDateReminders" defaultChecked disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="assignmentReminders">Assignment Notifications</Label>
                      <Switch id="assignmentReminders" defaultChecked disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="commentNotifications">Comment Notifications</Label>
                      <Switch id="commentNotifications" disabled={!notifications} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="reminderTiming">Reminder Timing</Label>
                      <select
                        id="reminderTiming"
                        className="flex h-9 rounded-md border border-input bg-background px-3 py-1 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        disabled={!notifications}
                      >
                        <option value="1">1 hour before</option>
                        <option value="4">4 hours before</option>
                        <option value="24">1 day before</option>
                        <option value="48">2 days before</option>
                      </select>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Reset to Defaults</Button>
                <Button onClick={handleSaveNotifications}>Save Notification Settings</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}