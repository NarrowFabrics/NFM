import { useState } from 'react';
import AppLayout from '@/components/layout/app-layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { FileText, DollarSign, PercentSquare, Settings, Plus, Edit, Trash2, Calculator, BarChart4 } from 'lucide-react';

export default function PriceQuotationSettings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('rates');
  const [showAddRateDialog, setShowAddRateDialog] = useState(false);
  const [showAddTemplateDialog, setShowAddTemplateDialog] = useState(false);
  
  // Dummy data for demonstration
  const [exchangeRates, setExchangeRates] = useState([
    { id: 1, sourceCurrency: 'USD', targetCurrency: 'BDT', rate: 110.25, lastUpdated: '2025-03-20', isActive: true },
    { id: 2, sourceCurrency: 'EUR', targetCurrency: 'BDT', rate: 120.50, lastUpdated: '2025-03-20', isActive: true },
    { id: 3, sourceCurrency: 'GBP', targetCurrency: 'BDT', rate: 140.75, lastUpdated: '2025-03-20', isActive: true },
    { id: 4, sourceCurrency: 'USD', targetCurrency: 'INR', rate: 85.30, lastUpdated: '2025-03-20', isActive: false },
  ]);
  
  const [templates, setTemplates] = useState([
    { 
      id: 1, 
      name: 'Standard Quotation', 
      description: 'Default template for all fabric quotations',
      lastUpdated: '2025-03-15',
      isDefault: true
    },
    { 
      id: 2, 
      name: 'Premium Client Template', 
      description: 'Special pricing structure for premium clients',
      lastUpdated: '2025-03-10',
      isDefault: false
    },
    { 
      id: 3, 
      name: 'Wholesale Template', 
      description: 'Bulk order pricing with volume discounts',
      lastUpdated: '2025-03-05',
      isDefault: false
    },
  ]);
  
  const [markups, setMarkups] = useState([
    { id: 1, category: 'Standard Products', markup: 15, description: 'Regular fabric items' },
    { id: 2, category: 'Premium Products', markup: 25, description: 'High-end fabric products' },
    { id: 3, category: 'Custom Orders', markup: 30, description: 'Custom designed fabrics' },
    { id: 4, category: 'Bulk Orders', markup: 10, description: 'Large volume orders' },
  ]);

  const handleAddRate = () => {
    toast({
      title: 'Exchange Rate Added',
      description: 'New exchange rate has been successfully added',
    });
    setShowAddRateDialog(false);
  };

  const handleAddTemplate = () => {
    toast({
      title: 'Template Added',
      description: 'New quotation template has been successfully added',
    });
    setShowAddTemplateDialog(false);
  };

  const handleSaveMarkups = () => {
    toast({
      title: 'Markups Saved',
      description: 'Markup percentages have been updated',
    });
  };

  return (
    <AppLayout title="Price Quotation Settings" description="Configure price quotation settings">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <FileText className="h-7 w-7 text-primary" />
              Price Quotation Settings
            </h1>
            <p className="text-gray-500 mt-1">Configure currency rates, markups, and quotation templates</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="rates" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Exchange Rates
            </TabsTrigger>
            <TabsTrigger value="markups" className="flex items-center gap-2">
              <PercentSquare className="h-4 w-4" />
              Markup Percentages
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Quotation Templates
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rates" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Exchange Rates</CardTitle>
                  <CardDescription>Manage currency exchange rates for quotations</CardDescription>
                </div>
                <Button onClick={() => setShowAddRateDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Rate
                </Button>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Source Currency</TableHead>
                        <TableHead>Target Currency</TableHead>
                        <TableHead>Rate</TableHead>
                        <TableHead>Last Updated</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {exchangeRates.map((rate) => (
                        <TableRow key={rate.id}>
                          <TableCell className="font-medium">{rate.sourceCurrency}</TableCell>
                          <TableCell>{rate.targetCurrency}</TableCell>
                          <TableCell>{rate.rate.toFixed(2)}</TableCell>
                          <TableCell>{new Date(rate.lastUpdated).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Badge
                              variant={rate.isActive ? 'default' : 'secondary'}
                            >
                              {rate.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">
                  <BarChart4 className="h-4 w-4 mr-2" />
                  View Rate History
                </Button>
                <Button>
                  <Calculator className="h-4 w-4 mr-2" />
                  Sync Latest Rates
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="markups" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Markup Percentages</CardTitle>
                <CardDescription>Configure markup percentages for different product categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Category</TableHead>
                        <TableHead>Markup %</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {markups.map((markup) => (
                        <TableRow key={markup.id}>
                          <TableCell className="font-medium">{markup.category}</TableCell>
                          <TableCell>
                            <Input 
                              type="number" 
                              value={markup.markup} 
                              className="w-20 h-8"
                              onChange={(e) => {
                                // Update markup value
                              }}
                            />
                          </TableCell>
                          <TableCell>{markup.description}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <div className="flex justify-between mt-6">
                  <Button variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Category
                  </Button>
                  <Button onClick={handleSaveMarkups}>
                    Save Changes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="templates" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Quotation Templates</CardTitle>
                  <CardDescription>Manage templates for price quotations</CardDescription>
                </div>
                <Button onClick={() => setShowAddTemplateDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Template
                </Button>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Template Name</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Last Updated</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {templates.map((template) => (
                        <TableRow key={template.id}>
                          <TableCell className="font-medium">{template.name}</TableCell>
                          <TableCell>{template.description}</TableCell>
                          <TableCell>{new Date(template.lastUpdated).toLocaleDateString()}</TableCell>
                          <TableCell>
                            {template.isDefault && (
                              <Badge>Default</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <FileText className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add Exchange Rate Dialog */}
        <Dialog open={showAddRateDialog} onOpenChange={setShowAddRateDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Exchange Rate</DialogTitle>
              <DialogDescription>Add a new currency exchange rate</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="sourceCurrency" className="text-right">
                  Source Currency
                </Label>
                <select
                  id="sourceCurrency"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                >
                  <option value="USD">USD - US Dollar</option>
                  <option value="EUR">EUR - Euro</option>
                  <option value="GBP">GBP - British Pound</option>
                  <option value="JPY">JPY - Japanese Yen</option>
                </select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="targetCurrency" className="text-right">
                  Target Currency
                </Label>
                <select
                  id="targetCurrency"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                >
                  <option value="BDT">BDT - Bangladeshi Taka</option>
                  <option value="INR">INR - Indian Rupee</option>
                  <option value="PKR">PKR - Pakistani Rupee</option>
                  <option value="CNY">CNY - Chinese Yuan</option>
                </select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="rate" className="text-right">
                  Exchange Rate
                </Label>
                <div className="col-span-3 flex items-center gap-2">
                  <Input id="rate" type="number" step="0.01" placeholder="Enter exchange rate" />
                  <span className="text-sm text-gray-500">1 USD = ? BDT</span>
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="status" className="text-right">
                  Status
                </Label>
                <select
                  id="status"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddRateDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddRate}>Add Rate</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Add Template Dialog */}
        <Dialog open={showAddTemplateDialog} onOpenChange={setShowAddTemplateDialog}>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Add Quotation Template</DialogTitle>
              <DialogDescription>Create a new quotation template</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="templateName" className="text-right">
                  Template Name
                </Label>
                <Input id="templateName" placeholder="Template Name" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="templateDescription" className="text-right">
                  Description
                </Label>
                <Input id="templateDescription" placeholder="Template Description" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="templateContent" className="text-right pt-2">
                  Template Content
                </Label>
                <textarea
                  id="templateContent"
                  rows={6}
                  className="col-span-3 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  placeholder="Enter template content or JSON structure"
                ></textarea>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="col-start-2 col-span-3 flex items-center space-x-2">
                  <input type="checkbox" id="setDefault" className="rounded border-gray-300" />
                  <Label htmlFor="setDefault">Set as default template</Label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddTemplateDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddTemplate}>Add Template</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}