import { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import AppLayout from '@/components/layout/app-layout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useCurrency } from '@/contexts/CurrencyContext';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
// Command components for multi-select
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Plus, Edit, Trash, Trash2, AlertCircle, Settings, Box, ChevronLeft, ChevronRight, Pencil, Download, FileText, FileOutput, Table2, Columns as ColumnsIcon, Import, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { exportSectionData, exportToCSV, exportToExcel, exportToPDF, generateReport } from '@/lib/export-utils';

// Utility functions
const formatDate = (dateString: string) => {
  if (!dateString) return 'N/A';
  try {
    const date = new Date(dateString);
    // Format as DD-MM-YY
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Month is 0-indexed
    const year = date.getFullYear().toString().slice(-2);
    return `${day}-${month}-${year}`;
  } catch (error) {
    return dateString;
  }
};

const formatTime = (dateString: string) => {
  if (!dateString) return 'N/A';
  try {
    const date = new Date(dateString);
    // Format as mm-hh
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    return `${minutes}-${hours}`;
  } catch (error) {
    return '';
  }
};

// Format percentage for display
const formatPercentage = (value: number) => {
  return `${value}%`;
};

// Helper to get display name for active tab
const getActiveTabName = (tabId: string): string => {
  const tabNames: Record<string, string> = {
    'elastic-part': 'Elastic Parts',
    'production-unit': 'Production Units',
    'item': 'Items',
    'yarn-category': 'Yarn Categories',
    'yarn-count': 'Yarn Counts',
    'color-type': 'Color Types',
    'dyeing-charge': 'Dyeing Charges',
    'over-head-percent': 'Overhead Percentages',
    'profit-margin': 'Profit Margins'
  };
  return tabNames[tabId] || 'Settings';
};

// Helper function to get badge variant based on status
const getStatusBadgeVariant = (isActive: boolean): "default" | "destructive" | "outline" | "secondary" => {
  return isActive ? "default" : "destructive";
};

// Get tab title for display
const getTabTitle = (tab: string): string => {
  switch (tab) {
    case 'elastic-part': return 'Elastic Part';
    case 'production-unit': return 'Production Unit';
    case 'yarn-category': return 'Yarn Category';
    case 'yarn-count': return 'Yarn Count';
    case 'color-type': return 'Color Type';
    case 'dyeing-charge': return 'Dyeing Charge';
    case 'item': return 'Item';
    case 'over-head-percent': return 'Over-Head %';
    case 'profit-margin': return 'Profit Margin';
    default: return 'Item';
  }
};

interface FabricPart {
  id: number;
  name: string;
  is_active: boolean;
  created_at: string;
}

interface ProductionUnit {
  id: number;
  name: string;
  description: string;
  capacity: number;
  is_active: boolean;
  created_at: string;
}

export default function NarrowFabricsSettings() {
  const { toast } = useToast();
  const { exchangeRate, convertUsdToBdt, convertBdtToUsd, formatCurrency } = useCurrency();
  const [activeTab, setActiveTab] = useState('elastic-part');
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'table' | 'card'>('table');
  const [formError, setFormError] = useState<string | null>(null);
  const tabsRef = useRef<HTMLDivElement>(null);
  
  // Dialog states
  const [selectedItem, setSelectedItem] = useState<any>(null);
  
  // Import/Export functionality states
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isBulkDeleteDialogOpen, setIsBulkDeleteDialogOpen] = useState(false);
  
  // Column visibility state for each tab
  const [columnVisibility, setColumnVisibility] = useState({
    'elastic-part': { name: true, status: true, date: true, action: true },
    'production-unit': { name: true, description: true, capacity: true, status: true, date: true, action: true },
    'item': { name: true, unit: true, elasticPart: true, description: true, status: true, date: true, action: true },
    'yarn-category': { name: true, code: true, status: true, date: true, action: true },
    'yarn-count': { count: true, yarnCategory: true, yarnCode: true, priceBdt: true, priceUsd: true, description: true, status: true, date: true, action: true },
    'color-type': { name: true, description: true, status: true, date: true, action: true },
    'dyeing-charge': { name: true, yarnCategories: true, yarnCount: true, priceUsd: true, priceBdt: true, description: true, status: true, date: true, action: true },
    'over-head-percent': { productionUnit: true, itemName: true, overHeadPercent: true, description: true, status: true, date: true, action: true },
    'profit-margin': { productionUnit: true, itemName: true, profitMargin: true, description: true, status: true, date: true, action: true }
  });
  
  // Column configuration for each tab
  const columnConfig = {
    'elastic-part': [
      { key: 'name', label: 'Name' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'production-unit': [
      { key: 'name', label: 'Name' },
      { key: 'description', label: 'Description' },
      { key: 'capacity', label: 'Capacity' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'item': [
      { key: 'name', label: 'Name' },
      { key: 'unit', label: 'Unit' },
      { key: 'elasticPart', label: 'Elastic Part' },
      { key: 'description', label: 'Description' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'yarn-category': [
      { key: 'name', label: 'Name' },
      { key: 'code', label: 'Code' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'yarn-count': [
      { key: 'yarnCategory', label: 'Yarn Category' },
      { key: 'yarnCode', label: 'Yarn Code' },
      { key: 'count', label: 'Count' },
      { key: 'priceBdt', label: 'Price (BDT)' },
      { key: 'priceUsd', label: 'Price (USD)' },
      { key: 'description', label: 'Description' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'color-type': [
      { key: 'name', label: 'Name' },
      { key: 'description', label: 'Description' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'dyeing-charge': [
      { key: 'name', label: 'Name' },
      { key: 'yarnCategories', label: 'Yarn Categories' },
      { key: 'yarnCount', label: 'Yarn Count' },
      { key: 'priceUsd', label: 'Price (USD)' },
      { key: 'priceBdt', label: 'Price (BDT)' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'over-head-percent': [
      { key: 'productionUnit', label: 'Production Unit' },
      { key: 'itemName', label: 'Item Name' },
      { key: 'overHeadPercent', label: 'Overhead %' },
      { key: 'description', label: 'Description' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ],
    'profit-margin': [
      { key: 'productionUnit', label: 'Production Unit' },
      { key: 'itemName', label: 'Item Name' },
      { key: 'profitMargin', label: 'Profit Margin' },
      { key: 'description', label: 'Description' },
      { key: 'status', label: 'Status' },
      { key: 'date', label: 'Date' },
      { key: 'action', label: 'Action' }
    ]
  };

  // Mock data for elastic parts
  // Fetch fabric parts from the API
  const fabricPartsQuery = useQuery({
    queryKey: ['/api/settings/fabric-parts'],
    queryFn: async () => {
      const response = await fetch('/api/settings/fabric-parts');
      if (!response.ok) {
        throw new Error('Failed to fetch fabric parts');
      }
      const data = await response.json();
      return data.fabricParts || [];
    }
  });

  // Use fabricParts from the query result or empty array if loading/error
  const fabricParts = fabricPartsQuery.data || [];
  
  // Add fabric part mutation
  const addFabricPartMutation = useMutation({
    mutationFn: async (partData: { name: string; is_active: boolean }) => {
      const response = await fetch('/api/settings/fabric-parts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(partData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create fabric part');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate the fabric parts query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/settings/fabric-parts'] });
    }
  });
  
  // Update fabric part mutation
  const updateFabricPartMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: { name: string; is_active: boolean } }) => {
      const response = await fetch(`/api/settings/fabric-parts/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update fabric part');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings/fabric-parts'] });
    }
  });
  
  // Delete fabric part mutation
  const deleteFabricPartMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/settings/fabric-parts/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete fabric part');
      }
      
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings/fabric-parts'] });
    }
  });

  // Mock data for production units
  const [productionUnits, setProductionUnits] = useState<ProductionUnit[]>([
    { id: 1, name: 'Jacquard Loom', description: 'Main production line. Production Capacity 16000 YDS/Day by Total 19 M/C.', capacity: 100, is_active: true, created_at: '2025-03-20' },
    { id: 2, name: 'Needle Loom', description: 'Main production line. Production Capacity 35000 YDS/Day By total 36 M/C.', capacity: 80, is_active: true, created_at: '2025-03-20' },
    { id: 3, name: 'Crochet Machine', description: 'Main production line. Production Capacity 45000 YDS/Day By total 18 M/C.', capacity: 50, is_active: false, created_at: '2025-03-20' },
    { id: 4, name: 'Drawstring Machine', description: 'Main production line. Production Capacity 30000 YDS/Day By total 27 M/C.', capacity: 50, is_active: false, created_at: '2025-03-20' },
  ]);

  // Interface for Yarn Category
  interface YarnCategory {
    id: number;
    name: string;
    code: string;
    is_active: boolean;
    created_at: string;
  }

  // State for custom categories added via "Other" selection
  const [customCategories, setCustomCategories] = useState<YarnCategory[]>(() => {
    // Try to load from localStorage
    const saved = localStorage.getItem('customYarnCategories');
    return saved ? JSON.parse(saved) : [];
  });
  
  // Fetch yarn categories from API
  const yarnCategoriesQuery = useQuery({
    queryKey: ['/api/settings/yarn-categories'],
    queryFn: async () => {
      const response = await fetch('/api/settings/yarn-categories');
      if (!response.ok) {
        console.error('Failed to fetch yarn categories:', response.status);
        throw new Error('Failed to fetch yarn categories');
      }
      return response.json();
    }
  });
  
  // Store the categories data for easier access
  const yarnCategories = yarnCategoriesQuery.data?.categories || [];
  
  // Fallback categories if API fails or is empty
  const fallbackYarnCategories: YarnCategory[] = [
    { id: 1, name: 'Nylon', code: 'NYL', is_active: true, created_at: new Date().toISOString() },
    { id: 2, name: 'Polyester', code: 'PLY', is_active: true, created_at: new Date().toISOString() },
    { id: 3, name: 'Cotton', code: 'CTN', is_active: true, created_at: new Date().toISOString() },
    { id: 4, name: 'CVC', code: 'CVC', is_active: true, created_at: new Date().toISOString() },
    { id: 5, name: 'PC', code: 'PC', is_active: true, created_at: new Date().toISOString() },
    { id: 6, name: 'Rubber', code: 'RBR', is_active: true, created_at: new Date().toISOString() },
    { id: 7, name: 'Other', code: 'OTH', is_active: true, created_at: new Date().toISOString() }
  ];
  
  // Use fallback categories only if API returned no categories
  const effectiveYarnCategories = yarnCategories.length > 0 ? yarnCategories : fallbackYarnCategories;
  
  useEffect(() => {
    // If we got categories from API but customCategories still has data,
    // we need to migrate those to the database
    if (yarnCategories.length > 0 && customCategories.length > 0) {
      // Clear the localStorage custom categories since we're now using the database
      localStorage.removeItem('customYarnCategories');
      setCustomCategories([]);
    }
  }, [yarnCategories, customCategories]);
  
  // Add yarn category mutation
  const addYarnCategoryMutation = useMutation({
    mutationFn: async (categoryData: { name: string; code: string; is_active: boolean }) => {
      const response = await fetch('/api/settings/yarn-categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(categoryData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create yarn category');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate the categories query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/settings/yarn-categories'] });
    }
  });
  
  // Update yarn category mutation
  const updateYarnCategoryMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: { name: string; code: string; is_active: boolean } }) => {
      const response = await fetch(`/api/settings/yarn-categories/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update yarn category');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings/yarn-categories'] });
    }
  });
  
  // Delete yarn category mutation
  const deleteYarnCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/settings/yarn-categories/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete yarn category');
      }
      
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings/yarn-categories'] });
    }
  });

  // Interface for Yarn Count
  interface YarnCount {
    id: number;
    YarnCategoriesId: number; // Database field name
    yarnCategoryId?: number; // For form compatibility 
    YarnCategoriesName: string; // To store the name of the YarnCategories for display
    yarnCategoryName?: string; // For form compatibility
    yarnCode: string; // Added field for yarn code (auto-generated based on category)
    count: string;
    priceBdt: string; // Price in BDT per KG
    priceUsd: string; // Price in USD per KG
    description: string;
    is_active: boolean;
    created_at: string;
  }

  // Mock data for yarn counts - clearing as requested
  const [yarnCounts, setYarnCounts] = useState<YarnCount[]>([
    {
      id: 1,
      YarnCategoriesId: 1,
      YarnCategoriesName: 'Nylon',
      yarnCode: 'NYL-001',
      count: '70D/24F 1 NIM',
      priceBdt: '800.00',
      priceUsd: '7.20',
      description: 'Nylon yarn with normal impact modifier for standard applications',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 2,
      YarnCategoriesId: 1,
      YarnCategoriesName: 'Nylon',
      yarnCode: 'NYL-002',
      count: '70D/24F 2 SIM',
      priceBdt: '850.00',
      priceUsd: '7.70',
      description: 'Nylon yarn with strong impact modifier for durability',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 3,
      YarnCategoriesId: 1,
      YarnCategoriesName: 'Nylon',
      yarnCode: 'NYL-003',
      count: 'BRIGHT YARN',
      priceBdt: '820.00',
      priceUsd: '7.40',
      description: 'High-visibility bright nylon yarn for accent details',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 4,
      YarnCategoriesId: 1,
      YarnCategoriesName: 'Nylon',
      yarnCode: 'NYL-004',
      count: '100D/44F SD',
      priceBdt: '830.00',
      priceUsd: '7.55',
      description: 'Semi-dull nylon yarn for subtle appearance',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 5,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-001',
      count: '75D/36F NIM',
      priceBdt: '650.00',
      priceUsd: '5.90',
      description: 'Polyester yarn with normal impact modifier for general use',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 6,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-002',
      count: '75D/36F SIM',
      priceBdt: '675.00',
      priceUsd: '6.10',
      description: 'Polyester yarn with strong impact modifier for heavy-duty applications',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 7,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-003',
      count: '150D/48F NIM',
      priceBdt: '690.00',
      priceUsd: '6.25',
      description: 'Medium-weight polyester yarn with normal impact modifier',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 8,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-004',
      count: '150D/48F INT',
      description: 'Medium-weight polyester yarn with intermediate impact modifier',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 9,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-005',
      count: '150D/48F SIM',
      description: 'Medium-weight polyester yarn with strong impact modifier',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 10,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-006',
      count: '150D/48F HIM',
      description: 'Medium-weight polyester yarn with high impact modifier for extreme durability',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 11,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-007',
      count: 'BRIGHT',
      description: 'High-visibility bright polyester yarn for decorative elements',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 12,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-008',
      count: 'PP Yarn',
      description: 'Polypropylene yarn for specialized applications',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 13,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-009',
      count: '20/2 SPUN POLYESTER',
      description: 'Fine spun polyester yarn for detailed work',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 14,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-010',
      count: '40/2 SPUN POLYESTER',
      description: 'Medium spun polyester yarn for balanced performance',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 15,
      YarnCategoriesId: 2,
      YarnCategoriesName: 'Polyester',
      yarnCode: 'PLY-011',
      count: '50/2 SPUN POLYESTER',
      description: 'Heavy spun polyester yarn for strength',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 16,
      YarnCategoriesId: 3,
      YarnCategoriesName: 'Rubber',
      yarnCode: 'RBR-001',
      count: '38D Rubber',
      description: 'Light rubber yarn for gentle elasticity',
      is_active: true,
      created_at: '2025-03-24T00:00:00Z',
    },
    {
      id: 17,
      YarnCategoriesId: 3,
      YarnCategoriesName: 'Rubber',
      yarnCode: 'RBR-002',
      count: '42D Rubber',
      description: 'Medium rubber yarn for standard elasticity',
      is_active: true,
      created_at: '2025-03-24T00:00:00Z',
    },
    {
      id: 18,
      YarnCategoriesId: 3,
      YarnCategoriesName: 'Rubber',
      yarnCode: 'RBR-003',
      count: '52D Rubber',
      description: 'Heavy rubber yarn for high elasticity',
      is_active: true,
      created_at: '2025-03-24T00:00:00Z',
    },

  ]);

  // Interface for Color Type
  interface ColorType {
    id: number;
    name: string;
    description: string;
    is_active: boolean;
    created_at: string;
  }

  interface DyeingCharge {
    id: number;
    name: string;
    yarnCategories: string;
    yarnCount: string;
    priceUsd: number;
    priceBdt: number;
    description: string;
    is_active: boolean;
    created_at: string;
  }

  // Color types from All Materials.csv
  const [colorTypes, setColorTypes] = useState<ColorType[]>([
    {
      id: 1,
      name: 'Raw White',
      description: 'Natural undyed color for base materials',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 2,
      name: 'Black',
      description: 'Deep black color suitable for a wide range of applications',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 3,
      name: 'Navy Blue',
      description: 'Deep blue color with slight purple undertone',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 4,
      name: 'Red',
      description: 'Bright red color for high visibility applications',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 5,
      name: 'Bright Red',
      description: 'Highly saturated red with excellent visibility',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 6,
      name: 'Maroon',
      description: 'Deep red-brown color for sophisticated applications',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 7,
      name: 'Golden Yellow',
      description: 'Rich yellow with gold undertones',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 8,
      name: 'Dark Grey',
      description: 'Deep charcoal color with blue undertones',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 9,
      name: 'Charcoal',
      description: 'Rich dark grey with warm undertones',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 10,
      name: 'Emerald Green',
      description: 'Rich medium green with blue undertones',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 11,
      name: 'Forest Green',
      description: 'Deep green with slight yellow undertones',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 12,
      name: 'Sky Blue',
      description: 'Light bright blue with slight green undertones',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 13,
      name: 'Royal Purple',
      description: 'Deep purple with blue undertones',
      is_active: true,
      created_at: '2025-03-24T00:00:00Z',
    }
  ]);

  // Mock data for dyeing charges
  const [dyeingCharges, setDyeingCharges] = useState<DyeingCharge[]>([
    {
      id: 1,
      name: 'Raw White',
      yarnCategories: 'Nylon',
      yarnCount: '70D/24F 2 SIM',
      priceUsd: 5.00,
      priceBdt: 550.00,
      description: 'Undyed yarn',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 2,
      name: 'Black',
      yarnCategories: 'Polyester',
      yarnCount: '150D/48F 2 SIM',
      priceUsd: 3.50,
      priceBdt: 385.00,
      description: 'Standard black dye',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 3,
      name: 'Navy Blue',
      yarnCategories: 'Polyester',
      yarnCount: '150D/48F 2 NIM',
      priceUsd: 3.75,
      priceBdt: 412.50,
      description: 'Deep navy blue dye',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 4,
      name: 'Black',
      yarnCategories: 'Nylon',
      yarnCount: '70D/24F 2 SIM',
      priceUsd: 6.50,
      priceBdt: 715.00,
      description: 'Premium black dye for nylon',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 5,
      name: 'Navy Blue',
      yarnCategories: 'Nylon',
      yarnCount: '70D/24F 2 SIM',
      priceUsd: 6.20,
      priceBdt: 682.00,
      description: 'Premium navy dye for nylon',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 6,
      name: 'Red',
      yarnCategories: 'Polyester',
      yarnCount: '150D/48F 2 SIM',
      priceUsd: 4.50,
      priceBdt: 495.00,
      description: 'Bright red dye, color-fast',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 7,
      name: 'Golden Yellow',
      yarnCategories: 'Cotton, Nylon, Polyester',
      yarnCount: '150D/48F 1 SIM',
      priceUsd: 7.00,
      priceBdt: 770.00,
      description: 'Premium gold yellow dye',
      is_active: true,
      created_at: '2025-03-20T00:00:00Z',
    },
    {
      id: 8,
      name: 'Emerald Green',
      yarnCategories: 'Polyester',
      yarnCount: '150D/48F 2 SIM',
      priceUsd: 4.75,
      priceBdt: 522.50,
      description: 'Rich green dye with blue undertones',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 9,
      name: 'Royal Purple',
      yarnCategories: 'Nylon',
      yarnCount: '70D/24F 2 SIM',
      priceUsd: 6.80,
      priceBdt: 748.00,
      description: 'Vibrant purple dye, high color retention',
      is_active: true,
      created_at: '2025-03-24T00:00:00Z',
    },
    {
      id: 10,
      name: 'Dark Grey',
      yarnCategories: 'Polyester',
      yarnCount: '75D/36F SIM',
      priceUsd: 3.80,
      priceBdt: 418.00,
      description: 'Sophisticated dark grey dye for polyester',
      is_active: true,
      created_at: '2025-03-21T00:00:00Z',
    },
    {
      id: 11,
      name: 'Bright Red',
      yarnCategories: 'Nylon',
      yarnCount: '100D/44F SD',
      priceUsd: 6.40,
      priceBdt: 704.00,
      description: 'High-visibility bright red dye',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 12,
      name: 'Maroon',
      yarnCategories: 'Polyester',
      yarnCount: '150D/48F HIM',
      priceUsd: 4.20,
      priceBdt: 462.00,
      description: 'Deep maroon dye for high-impact polyester',
      is_active: true,
      created_at: '2025-03-23T00:00:00Z',
    },
    {
      id: 13,
      name: 'Sky Blue',
      yarnCategories: 'Nylon',
      yarnCount: 'BRIGHT YARN',
      priceUsd: 5.90,
      priceBdt: 649.00,
      description: 'Bright sky blue for high-visibility applications',
      is_active: true,
      created_at: '2025-03-22T00:00:00Z',
    },
    {
      id: 14,
      name: 'Forest Green',
      yarnCategories: 'Polyester',
      yarnCount: '150D/48F INT',
      priceUsd: 4.10,
      priceBdt: 451.00,
      description: 'Deep forest green dye for intermediate polyester',
      is_active: true,
      created_at: '2025-03-24T00:00:00Z',
    },
    {
      id: 15,
      name: 'Charcoal',
      yarnCategories: 'Polyester',
      yarnCount: '20/2 SPUN POLYESTER',
      priceUsd: 3.95,
      priceBdt: 434.50,
      description: 'Deep charcoal dye for spun polyester',
      is_active: true,
      created_at: '2025-03-25T00:00:00Z',
    },

  ]);

  // Interface for Item
  interface Item {
    id: number;
    unit: string;
    name: string;
    elasticPart: string; // Will store comma-separated string for display
    elasticParts?: string[]; // New field for storing multiple parts
    description: string;
    is_active: boolean;
    created_at: string;
  }

  // Mock data for items
  const [items, setItems] = useState<Item[]>([
    { 
      id: 1, 
      unit: 'Jacquard Unit', 
      name: 'Jacquard Elastic', 
      elasticPart: 'Warp Yarn, Weft Yarn, Core/Elastic', 
      description: 'Main production line. We have total Jacquard machines.',
      is_active: true, 
      created_at: '2025-03-20' 
    },
    { 
      id: 2, 
      unit: 'Needle ', 
      name: 'Dyed Elastic', 
      elasticPart: 'Warp Yarn', 
      description: 'Secondary production line for dyed materials.',
      is_active: true, 
      created_at: '2025-03-05' 
    },
  ]);

  // Interface for OverHeadPercent
  interface OverHeadPercent {
    id: number;
    productionUnit: string;
    itemName: string;
    overHeadPercent: number;
    description: string;
    is_active: boolean;
    created_at: string;
  }

  // Mock data for overhead percentages
  const [overHeadPercents, setOverHeadPercents] = useState<OverHeadPercent[]>([
    {
      id: 1,
      productionUnit: 'Jacquard Unit',
      itemName: 'Jacquard Elastic',
      overHeadPercent: 15,
      description: 'Main production line. We have total Jacquard machines.',
      is_active: true,
      created_at: '2025-03-20'
    }
  ]);

  // Interface for ProfitMargin
  interface ProfitMargin {
    id: number;
    productionUnit: string;
    itemName: string;
    profitMargin: number;
    description: string;
    is_active: boolean;
    created_at: string;
  }

  // Mock data for profit margins
  const [profitMargins, setProfitMargins] = useState<ProfitMargin[]>([]);
  // Using a generic type for all of our item types to simplify type checking
  type ItemType = FabricPart | ProductionUnit | YarnCategory | YarnCount | ColorType | DyeingCharge | Item | OverHeadPercent | ProfitMargin;

  // Define form data type
  type FormDataType = {
    name: string;
    count: string;
    description: string;
    code: string; // Single elastic part (for backward compatibility)
    selectedElasticParts: string[]; // Multiple elastic parts selection
    is_active: boolean;
    yarnCategoryId: number;
    yarnCategoryName: string;
    yarnCategories: string;
    yarnCount: string;
    priceUsd: string;
    priceBdt: string;
    productionUnit: string;
    itemName: string;
    overHeadPercent: string;
    profitMargin: string;
  };
  
  const [currentItem, setCurrentItem] = useState<ItemType | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<'add' | 'edit'>('add');
  const [itemData, setItemData] = useState<any[]>([]);

  // Fetch items data
  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await fetch('/api/items');
        const data = await response.json();
        setItemData(data);
      } catch (error) {
        console.error('Error fetching items:', error);
      }
    };
    fetchItems();
  }, []);
  
  // Function to calculate column width based on the number of visible columns
  const getColumnWidth = (tabKey: keyof typeof columnVisibility): string => {
    const visibleColumns = Object.values(columnVisibility[tabKey]).filter(Boolean).length;
    if (visibleColumns === 0) return '100%';
    return `${Math.floor(100 / visibleColumns)}%`;
  };

  // Filter data based on search term
  const filterData = <T extends { name?: string; description?: string; itemName?: string; unit?: string; productionUnit?: string; code?: string; yarnCategories?: string }>(
    data: T[] | null | undefined,
    term: string
  ): T[] => {
    // First ensure data is an array
    if (!data || !Array.isArray(data)) return [];
    if (!term.trim()) return data;
    
    const lowercasedTerm = term.toLowerCase();
    return data.filter(item => {
      if (!item) return false;
      // Check all possible fields that might contain searchable text
      return (
        (item.name && item.name.toLowerCase().includes(lowercasedTerm)) ||
        (item.description && item.description.toLowerCase().includes(lowercasedTerm)) ||
        (item.itemName && item.itemName.toLowerCase().includes(lowercasedTerm)) ||
        (item.unit && item.unit.toLowerCase().includes(lowercasedTerm)) ||
        (item.productionUnit && item.productionUnit.toLowerCase().includes(lowercasedTerm)) ||
        (item.code && item.code.toLowerCase().includes(lowercasedTerm)) ||
        (item.yarnCategories && item.yarnCategories.toLowerCase().includes(lowercasedTerm))
      );
    });
  };
  
  // Handler for opening import dialog
  const handleOpenImportDialog = () => {
    setImportFile(null);
    setIsImportDialogOpen(true);
  };
  
  // Handler for importing data
  const handleImportData = async () => {
    if (!importFile) {
      toast({
        title: "Error",
        description: "Please select a file to import.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // This would be replaced with actual file parsing logic
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target?.result) {
          // Parse the CSV/Excel file content
          const content = event.target.result as string;
          
          // Simple CSV parsing (in real implementation, use a proper library)
          // This is just a placeholder implementation
          try {
            // Mock successful import
            const successMessage = `Successfully imported data for ${getActiveTabName(activeTab)}`;
            
            toast({
              title: "Import Successful",
              description: successMessage,
            });
            
            // Close the import dialog
            setIsImportDialogOpen(false);
            
            // Here we'd update the state with the imported data
            // For now, just show a success message
          } catch (error) {
            console.error("Error parsing file:", error);
            toast({
              title: "Import Error",
              description: "Failed to parse the import file. Please check the file format.",
              variant: "destructive",
            });
          }
        }
      };
      
      reader.onerror = () => {
        toast({
          title: "Import Error",
          description: "Failed to read the import file.",
          variant: "destructive",
        });
      };
      
      reader.readAsText(importFile);
    } catch (error) {
      console.error("Import error:", error);
      toast({
        title: "Import Error",
        description: "An error occurred during the import process.",
        variant: "destructive",
      });
    }
  };
  
  // Handler for bulk delete dialog
  const handleOpenBulkDeleteDialog = () => {
    setIsBulkDeleteDialogOpen(true);
  };
  
  // Handler for confirming bulk delete
  const handleBulkDelete = () => {
    let deleteMessage = "";
    
    // Delete all data for the active tab
    switch(activeTab) {
      case 'elastic-part':
        setFabricParts([]);
        deleteMessage = "All elastic parts have been deleted.";
        break;
      case 'production-unit':
        setProductionUnits([]);
        deleteMessage = "All production units have been deleted.";
        break;
      case 'item':
        setItems([]);
        deleteMessage = "All items have been deleted.";
        break;
      case 'yarn-category':
        // This should call a backend endpoint that deletes all yarn categories
        // For now, we'll show a toast warning since bulk delete isn't implemented in API
        toast({
          title: "Operation not supported",
          description: "Bulk deletion of yarn categories is not supported via the API. Please delete categories individually.",
          variant: "destructive"
        });
        return; // Exit early without closing dialog
        break;
      case 'yarn-count':
        setYarnCounts([]);
        deleteMessage = "All yarn counts have been deleted.";
        break;
      case 'color-type':
        setColorTypes([]);
        deleteMessage = "All color types have been deleted.";
        break;
      case 'dyeing-charge':
        setDyeingCharges([]);
        deleteMessage = "All dyeing charges have been deleted.";
        break;
      case 'over-head-percent':
        setOverHeadPercents([]);
        deleteMessage = "All overhead percentages have been deleted.";
        break;
      case 'profit-margin':
        setProfitMargins([]);
        deleteMessage = "All profit margins have been deleted.";
        break;
    }
    
    toast({
      title: "Deleted",
      description: deleteMessage,
    });
    
    setIsBulkDeleteDialogOpen(false);
  };
  
  // Export functionality for the active tab's data
  const handleExport = (format: 'csv' | 'excel' | 'pdf') => {
    const sectionName = getActiveTabName(activeTab);
    let dataToExport: any[] = [];
    
    // Get the right data based on active tab
    switch (activeTab) {
      case 'elastic-part':
        dataToExport = fabricParts;
        break;
      case 'production-unit':
        dataToExport = productionUnits;
        break;
      case 'yarn-category':
        dataToExport = yarnCategories;
        break;
      case 'yarn-count':
        dataToExport = yarnCounts;
        break;
      case 'color-type':
        dataToExport = colorTypes;
        break;
      case 'dyeing-charge':
        dataToExport = dyeingCharges;
        break;
      case 'item':
        dataToExport = items;
        break;
      case 'over-head-percent':
        dataToExport = overHeadPercents;
        break;
      case 'profit-margin':
        dataToExport = profitMargins;
        break;
      default:
        break;
    }
    
    // Apply any current filters
    if (searchTerm) {
      dataToExport = filterData(dataToExport, searchTerm);
    }
    
    // If no data, show a toast message
    if (dataToExport.length === 0) {
      toast({
        title: "No data to export",
        description: "There is no data available to export for this section.",
        variant: "destructive"
      });
      return;
    }
    
    // Export the data using our utility
    try {
      console.log(`Exporting ${sectionName} data in ${format} format`, {
        recordCount: dataToExport.length,
        sampleRecord: dataToExport.length > 0 ? 'Data exists' : 'No data'
      });
      
      // Pre-process the data based on the tab type
      const processedData = dataToExport.map(item => {
        const newItem: Record<string, any> = {...item};
        
        // Convert any complex objects or arrays to strings for easier handling
        Object.keys(newItem).forEach(key => {
          // Get the value in a type-safe way
          const value = newItem[key];
          
          // Handle boolean values
          if (typeof value === 'boolean') {
            newItem[key] = value ? 'Yes' : 'No';
          }
          
          // Handle arrays (like elasticParts in items)
          else if (Array.isArray(value)) {
            newItem[key] = value.join(', ');
          }
          
          // Handle dates
          else if (key === 'created_at' || key === 'updated_at' || key === 'date') {
            if (value) {
              try {
                const date = new Date(value as string);
                if (!isNaN(date.getTime())) {
                  newItem[key] = `${date.getDate().toString().padStart(2, '0')}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getFullYear().toString().slice(-2)}`;
                }
              } catch (e) {
                // Keep original if date parsing fails
              }
            }
          }
          
          // Ensure null or undefined values are converted to empty strings
          if (value === null || value === undefined) {
            newItem[key] = '';
          }
        });
        
        return newItem;
      });
      
      // Export the processed data
      exportSectionData(processedData, sectionName, format);
      
      toast({
        title: "Export successful",
        description: `${sectionName} data has been exported as ${format.toUpperCase()}.`,
      });
    } catch (error) {
      console.error('Error exporting data:', error);
      
      // More detailed error logging
      if (error instanceof Error) {
        console.error('Error name:', error.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
      }
      
      toast({
        title: "Export failed",
        description: "There was an error exporting the data. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  // Generate a complete report containing data from all tabs
  const handleGenerateReport = () => {
    // Compile datasets from all tabs
    const datasets = [
      { data: fabricParts, title: "Elastic Parts" },
      { data: productionUnits, title: "Production Units" },
      { data: yarnCategories, title: "Yarn Categories" },
      { data: yarnCounts, title: "Yarn Counts" },
      { data: colorTypes, title: "Color Types" },
      { data: dyeingCharges, title: "Dyeing Charges" },
      { data: items, title: "Items" },
      { data: overHeadPercents, title: "Overhead Percentages" },
      { data: profitMargins, title: "Profit Margins" }
    ].filter(dataset => dataset.data.length > 0); // Only include non-empty datasets
    
    if (datasets.length === 0) {
      toast({
        title: "No data to export",
        description: "There is no data available to generate a report.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      console.log('Generating comprehensive report with datasets:', datasets.map(d => d.title));
      
      // Pre-process each dataset
      const processedDatasets = datasets.map(dataset => {
        // Process the data in each dataset
        const processedData = dataset.data.map(item => {
          const newItem = {...item};
          
          // Convert any complex objects or arrays to strings for easier handling
          Object.keys(newItem).forEach(key => {
            // Get the value in a type-safe way
            const value = newItem[key];
            
            // Handle boolean values
            if (typeof value === 'boolean') {
              newItem[key] = value ? 'Yes' : 'No';
            }
            
            // Handle arrays
            else if (Array.isArray(value)) {
              newItem[key] = value.join(', ');
            }
            
            // Handle dates
            else if (key === 'created_at' || key === 'updated_at' || key === 'date') {
              if (value) {
                try {
                  const date = new Date(value as string);
                  if (!isNaN(date.getTime())) {
                    newItem[key] = `${date.getDate().toString().padStart(2, '0')}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getFullYear().toString().slice(-2)}`;
                  }
                } catch (e) {
                  // Keep original if date parsing fails
                }
              }
            }
            
            // Ensure null or undefined values are converted to empty strings
            if (value === null || value === undefined) {
              newItem[key] = '';
            }
          });
          
          return newItem;
        });
        
        return {
          ...dataset,
          data: processedData
        };
      });
      
      // Use current date for the filename
      const filename = `narrow_fabrics_report_${new Date().toISOString().split('T')[0]}.pdf`;
      
      // Generate the report with processed data
      generateReport(processedDatasets, "Narrow Fabrics Settings Report", filename);
      
      toast({
        title: "Report generated successfully",
        description: "A comprehensive report has been generated with data from all sections.",
      });
    } catch (error) {
      console.error('Error generating report:', error);
      
      // More detailed error logging
      if (error instanceof Error) {
        console.error('Error name:', error.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
      }
      
      toast({
        title: "Report generation failed",
        description: "There was an error generating the report. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Dialog state (keep existing)
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState<FormDataType>({
    name: '',
    count: '',
    description: '',
    code: '',
    selectedElasticParts: [], // Added for multi-select
    is_active: true,
    yarnCategoryId: 0,
    yarnCategoryName: '',
    yarnCategories: '',
    yarnCount: '',
    priceUsd: '',
    priceBdt: '',
    productionUnit: '',
    itemName: '',
    overHeadPercent: '',
    profitMargin: '',
  });
  
  // Handler functions
  const openAddDialog = () => {
    setDialogMode('add');
    setFormData({
      name: '',
      count: '',
      description: '',
      code: '',
      selectedElasticParts: [], // Initialize with empty array
      is_active: true,
      yarnCategoryId: 0,
      yarnCategoryName: '',
      yarnCategories: '',
      yarnCount: '',
      priceUsd: '',
      priceBdt: '',
      productionUnit: '',
      itemName: '',
      overHeadPercent: '',
      profitMargin: '',
    });
    setFormError(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (item: any) => {
    setDialogMode('edit');
    setCurrentItem(item as ItemType);
    setFormData({
      name: item.name || '',
      count: item.count || '',
      description: item.description || '',
      code: item.code || '',
      selectedElasticParts: item.elastic_parts || [],
      is_active: item.is_active ?? true,
      yarnCategoryId: item.yarn_category_id || 0,
      yarnCategoryName: item.yarn_category_name || '',
      yarnCategories: item.yarn_categories || '',
      yarnCount: item.yarn_count || '',
      priceUsd: item.price_usd?.toString() || '',
      priceBdt: item.price_bdt?.toString() || '',
      productionUnit: item.production_unit || '',
      itemName: item.item_name || '',
      overHeadPercent: item.over_head_percent?.toString() || '',
      profitMargin: item.profit_margin?.toString() || '',
    });

    // Handle different data structures based on the active tab
    if (activeTab === 'yarn-count') {
      // When editing a yarn count, use the correct properties
      // Since there's a mismatch between DB property names and form field names,
      // we need to accommodate both naming conventions
      setFormData({
        name: item.name || '',
        count: item.count || '',
        description: item.description || '',
        code: item.code || '',
        selectedElasticParts: [], // Add empty array for consistency
        is_active: item.is_active,
        // For DB compatibility - try both naming conventions
        yarnCategoryId: item.YarnCategoriesId || item.yarnCategoryId || 0,
        yarnCategoryName: item.YarnCategoriesName || item.yarnCategoryName || '',
        // Include yarnCode for display purposes only - it's auto-generated
        priceBdt: item.priceBdt || '',
        priceUsd: item.priceUsd || '',
        yarnCategories: '',
        yarnCount: '',
        productionUnit: '',
        itemName: '',
        overHeadPercent: '',
        profitMargin: '',
      });
    } else if (activeTab === 'dyeing-charge') {
      setFormData({
        name: item.name || '',
        count: '',
        description: item.description || '',
        code: '',
        selectedElasticParts: [], // Add empty array for consistency
        is_active: item.is_active,
        yarnCategoryId: 0,
        yarnCategoryName: '',
        yarnCategories: item.yarnCategories || '',
        yarnCount: item.yarnCount || '',
        priceUsd: item.priceUsd ? String(item.priceUsd) : '',
        priceBdt: item.priceBdt ? String(item.priceBdt) : '',
        productionUnit: '',
        itemName: '',
        overHeadPercent: '',
        profitMargin: '',
      });
    } else if (activeTab === 'over-head-percent') {
      setFormData({
        name: '',
        count: '',
        description: item.description || '',
        code: '',
        selectedElasticParts: [], // Add empty array for consistency
        is_active: item.is_active,
        yarnCategoryId: 0,
        yarnCategoryName: '',
        yarnCategories: '',
        yarnCount: '',
        priceUsd: '',
        priceBdt: '',
        productionUnit: item.productionUnit || '',
        itemName: item.itemName || '',
        overHeadPercent: item.overHeadPercent ? String(item.overHeadPercent) : '',
        profitMargin: '',
      });
    } else if (activeTab === 'profit-margin') {
      setFormData({
        name: '',
        count: '',
        description: item.description || '',
        code: '',
        selectedElasticParts: [], // Add empty array for consistency
        is_active: item.is_active,
        yarnCategoryId: 0,
        yarnCategoryName: '',
        yarnCategories: '',
        yarnCount: '',
        priceUsd: '',
        priceBdt: '',
        productionUnit: item.productionUnit || '',
        itemName: item.itemName || '',
        overHeadPercent: '',
        profitMargin: item.profitMargin ? String(item.profitMargin) : '',
      });
    } else if (activeTab === 'item') {
      // For item tab, we need to set the unit and elastic part dropdowns
      // Convert from comma-separated string to array if necessary
      let elasticPartsArray: string[] = [];
      if (item.elasticParts) {
        // Use existing array if available
        elasticPartsArray = [...item.elasticParts];
      } else if (item.elasticPart) {
        // Convert from comma-separated string
        elasticPartsArray = item.elasticPart.split(', ').map((part: string) => part.trim());
      }
      
      setFormData({
        name: item.name || '',
        count: item.unit || '', // Unit is stored in count for items
        description: item.description || '',
        code: item.elasticPart || '', // Elastic part is stored in code for items (for backward compatibility)
        selectedElasticParts: elasticPartsArray, // Set the elastic parts array for checkboxes
        is_active: item.is_active,
        yarnCategoryId: 0,
        yarnCategoryName: '',
        yarnCategories: '',
        yarnCount: '',
        priceUsd: '',
        priceBdt: '',
        productionUnit: '',
        itemName: '',
        overHeadPercent: '',
        profitMargin: '',
      });
    } else {
      setFormData({
        name: item.name || '',
        count: item.capacity ? String(item.capacity) : '',
        description: item.description || '',
        code: item.code || '',
        selectedElasticParts: [], // Initialize with empty array for other tabs
        is_active: item.is_active,
        yarnCategoryId: 0,
        yarnCategoryName: '',
        yarnCategories: '',
        yarnCount: '',
        priceUsd: '',
        priceBdt: '',
        productionUnit: '',
        itemName: '',
        overHeadPercent: '',
        profitMargin: '',
      });
    }

    setFormError(null);
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      // Validate form
      setFormError(null);

      // Only check for name field for tabs that use the name field directly
      // We exclude yarn-count, over-head-percent, and profit-margin tabs
      if (activeTab !== 'yarn-count' && 
          activeTab !== 'over-head-percent' && 
          activeTab !== 'profit-margin' && 
          !formData.name.trim()) {
        setFormError("Name is required");
        return;
      }

      if (activeTab === 'elastic-part') {
        if (dialogMode === 'add') {
          // First check if a part with this name already exists
          const partExists = fabricParts.some(part => 
            part.name.toLowerCase() === formData.name.toLowerCase().trim()
          );
          
          if (partExists) {
            setFormError(`An elastic part with the name "${formData.name}" already exists. Please use a different name.`);
            return; // Don't close dialog or proceed
          }
          
          try {
            // Use the mutation to save the fabric part to the server
            await addFabricPartMutation.mutateAsync({
              name: formData.name.trim(),
              is_active: formData.is_active
            });
            
            toast({
              title: "Success",
              description: "Elastic part was created successfully.",
            });
          } catch (error) {
            console.error('Error saving elastic part:', error);
            // Check if it's a duplicate key error
            if (error instanceof Error && error.message.includes('duplicate')) {
              setFormError(`An elastic part with this name already exists. Please use a different name.`);
            } else {
              toast({
                title: "Error",
                description: "Failed to create elastic part. Please try again.",
                variant: "destructive"
              });
            }
            return; // Don't close dialog on error
          }
        } else if (currentItem) {
          try {
            // Use update mutation to update fabric part
            await updateFabricPartMutation.mutateAsync({
              id: currentItem.id,
              data: {
                name: formData.name,
                is_active: formData.is_active
              }
            });
            
            toast({
              title: "Success",
              description: "Elastic part was updated successfully.",
            });
          } catch (error) {
            console.error('Error updating elastic part:', error);
            toast({
              title: "Error",
              description: "Failed to update elastic part. Please try again.",
              variant: "destructive"
            });
            return; // Don't close dialog on error
          }
        }
      } else if (activeTab === 'production-unit') {
        if (dialogMode === 'add') {
          // Add new production unit
          const newUnit: ProductionUnit = {
            id: Math.max(0, ...productionUnits.map(p => p.id)) + 1,
            name: formData.name,
            description: formData.description || 'No description',
            capacity: parseInt(formData.count) || 0,
            is_active: formData.is_active,
            created_at: new Date().toISOString().split('T')[0]
          };

          setProductionUnits([...productionUnits, newUnit]);

          toast({
            title: "Success",
            description: "Production unit was created successfully.",
          });
        } else if (currentItem) {
          // Edit existing production unit
          const updatedUnits = productionUnits.map(unit => 
            unit.id === currentItem.id 
              ? { 
                  ...unit, 
                  name: formData.name, 
                  description: formData.description || unit.description,
                  capacity: parseInt(formData.count) || unit.capacity,
                  is_active: formData.is_active 
                }
              : unit
          );

          setProductionUnits(updatedUnits);

          toast({
            title: "Success",
            description: "Production unit was updated successfully.",
          });
        }
      } else if (activeTab === 'item') {
        // Validate required fields for Item
        if (!formData.count) {
          setFormError("Unit is required");
          return;
        }

        // Check if either elasticPart code or selectedElasticParts array has values
        const hasElasticParts = formData.code || (formData.selectedElasticParts && formData.selectedElasticParts.length > 0);
        
        if (!hasElasticParts) {
          setFormError("At least one Elastic Part is required");
          return;
        }

        // Convert selected parts array to comma-separated string for display
        const elasticPartsString = formData.selectedElasticParts && formData.selectedElasticParts.length > 0 
          ? formData.selectedElasticParts.join(', ')
          : formData.code; // Fallback to single selection if multiple not available

        if (dialogMode === 'add') {
          // Add new item
          const newItem: Item = {
            id: Math.max(0, ...items.map(i => i.id)) + 1,
            unit: formData.count,
            name: formData.name,
            elasticPart: elasticPartsString, // Use the joined string for display
            elasticParts: [...formData.selectedElasticParts], // Store the actual array of parts
            description: formData.description || 'No description',
            is_active: formData.is_active,
            created_at: new Date().toISOString().split('T')[0]
          };

          setItems([...items, newItem]);

          toast({
            title: "Success",
            description: "Item was created successfully.",
          });
        } else if (currentItem) {
          // Edit existing item
          const updatedItems = items.map(item => 
            item.id === currentItem.id 
              ? { 
                  ...item, 
                  unit: formData.count, // Use selected unit from dropdown
                  name: formData.name,
                  elasticPart: elasticPartsString, // Use the joined string for display
                  elasticParts: [...formData.selectedElasticParts], // Store the actual array of parts
                  description: formData.description || item.description,
                  is_active: formData.is_active 
                }
              : item
          );

          setItems(updatedItems);

          toast({
            title: "Success",
            description: "Item was updated successfully.",
          });
        }
      } else if (activeTab === 'yarn-category') {
        // Auto-generate category code if empty
        let categoryCode = formData.code.trim();
        if (!categoryCode) {
          // Generate code from name
          const name = formData.name.trim();
          const words = name.split(/\s+/).filter(w => w.length > 0);
          if (words.length > 0) {
            if (words.length >= 3) {
              categoryCode = (words[0][0] + words[1][0] + words[2][0]).toUpperCase();
            } else if (words.length === 2) {
              categoryCode = (words[0][0] + words[1].substring(0, 2)).toUpperCase();
            } else {
              categoryCode = words[0].substring(0, 3).toUpperCase();
            }
            // Update the form data
            setFormData({...formData, code: categoryCode});
          } else {
            setFormError("Category name is required to generate code");
            return;
          }
        }
        
        // Ensure the code is at least 1 character
        if (categoryCode.length < 1) {
          setFormError("Category code should be at least 1 character");
          return;
        }

        if (dialogMode === 'add') {
          try {
            await addYarnCategoryMutation.mutateAsync({
              name: formData.name,
              code: formData.code.toUpperCase(),
              is_active: formData.is_active
            });
            
            toast({
              title: "Success",
              description: "Yarn category was created successfully.",
            });
          } catch (error) {
            console.error('Error saving yarn category:', error);
            toast({
              title: "Error",
              description: "Failed to create yarn category. Please try again.",
              variant: "destructive"
            });
            return; // Don't close dialog on error
          }
        } else if (currentItem) {
          try {
            // Update yarn category via API
            await updateYarnCategoryMutation.mutateAsync({
              id: currentItem.id,
              data: {
                name: formData.name,
                code: formData.code.toUpperCase(),
                is_active: formData.is_active
              }
            });
            
            // The API update should handle all necessary database changes
            
            // Update references in yarn counts for immediate UI update
            // Note: The next data refresh will get the updated values from the API
            const updatedYarnCounts = yarnCounts.map(count => {
              if (count.yarnCategoryId === currentItem.id || count.YarnCategoriesId === currentItem.id) {
                return {
                  ...count,
                  yarnCategoryName: formData.name,
                  YarnCategoriesName: formData.name
                };
              }
              return count;
            });
            setYarnCounts(updatedYarnCounts);
            
            toast({
              title: "Success",
              description: "Yarn category was updated successfully.",
            });
          } catch (error) {
            console.error('Error updating yarn category:', error);
            toast({
              title: "Error",
              description: "Failed to update yarn category. Please try again.",
              variant: "destructive"
            });
            return; // Don't close dialog on error
          }
        }
      } else if (activeTab === 'yarn-count') {
        if (!formData.count.trim()) {
          setFormError("Yarn count is required");
          return;
        }

        if (formData.yarnCategoryId === 0) {
          setFormError("Please select a yarn category");
          return;
        }
        
        // Validate price fields if they're provided
        if (formData.priceBdt && (isNaN(parseFloat(formData.priceBdt as string)) || parseFloat(formData.priceBdt as string) < 0)) {
          setFormError("Price in BDT must be a valid positive number");
          return;
        }
        
        if (formData.priceUsd && (isNaN(parseFloat(formData.priceUsd as string)) || parseFloat(formData.priceUsd as string) < 0)) {
          setFormError("Price in USD must be a valid positive number");
          return;
        }

        if (dialogMode === 'add') {
          // Generate yarn code based on category
          let prefix = 'OTH'; // Default prefix
          let customCategoryAdded = false;
          let customCategoryCode = '';
          
          // Check if this is an "Other" category with a specification provided
          // If so, we'll add it as a custom category for future use
          if (formData.yarnCategoryName === 'Other' && formData.description && formData.description.trim()) {
            // Get custom material name from the description field
            const customMaterial = formData.description.trim();
            
            // Only add if this custom material doesn't already exist
            const existingCategory = [...effectiveYarnCategories, ...customCategories].find(
              cat => cat.name.toLowerCase() === customMaterial.toLowerCase()
            );
            
            if (!existingCategory) {
              // Generate a code for this custom material (up to 3 chars)
              let code = '';
              // Split by spaces and use first letters
              const words = customMaterial.split(' ');
              if (words.length >= 3) {
                // If 3+ words, take first letter of each word
                code = (words[0][0] + words[1][0] + words[2][0]).toUpperCase();
              } else if (words.length === 2) {
                // If 2 words, take first letter + first two letters of second word
                code = (words[0][0] + words[1].substring(0, 2)).toUpperCase();
              } else {
                // If 1 word, take first 3 letters
                code = words[0].substring(0, 3).toUpperCase();
              }
              
              // Create the new custom category
              const newCustomCategory: YarnCategory = {
                id: Math.max(0, ...effectiveYarnCategories.map(c => c.id), ...customCategories.map(c => c.id)) + 1,
                name: customMaterial,
                code: code,
                is_active: true,
                created_at: new Date().toISOString()
              };
              
              // Update custom categories state
              const updatedCustomCategories = [...customCategories, newCustomCategory];
              setCustomCategories(updatedCustomCategories);
              
              // Save to localStorage for persistence
              localStorage.setItem('customYarnCategories', JSON.stringify(updatedCustomCategories));
              
              // Update form data to use this new category instead of "Other"
              formData.yarnCategoryName = customMaterial;
              formData.YarnCategoriesName = customMaterial;
              
              // Save the custom category code to use as prefix
              customCategoryCode = code;
              customCategoryAdded = true;
              
              toast({
                title: "New Material Added",
                description: `Added "${customMaterial}" to the yarn categories.`,
              });
            }
          }
          
          // Determine the prefix for the yarn code
          if (formData.yarnCategoryName === 'Nylon') {
            prefix = 'NYL';
          } else if (formData.yarnCategoryName === 'Polyester') {
            prefix = 'PLY';
          } else if (formData.yarnCategoryName === 'Cotton') {
            prefix = 'CTN';
          } else if (formData.yarnCategoryName === 'CVC') {
            prefix = 'CVC';
          } else if (formData.yarnCategoryName === 'PC') {
            prefix = 'PC';
          } else if (formData.yarnCategoryName === 'Rubber') {
            prefix = 'RBR';
          } else if (customCategoryAdded && customCategoryCode) {
            // Use the code from the newly added custom category
            prefix = customCategoryCode;
          } else if (formData.yarnCategoryName !== 'Other') {
            // Check if it's one of our custom categories
            const customCategory = customCategories.find(c => c.name === formData.yarnCategoryName);
            if (customCategory) {
              prefix = customCategory.code;
            }
          }
          
          // Find the highest existing code number for this category to determine next number
          const existingCodes = yarnCounts
            .filter(c => c.yarnCode && c.yarnCode.startsWith(prefix))
            .map(c => {
              const match = c.yarnCode.match(/\d+/);
              return match ? parseInt(match[0], 10) : 0;
            });
          
          const nextNumber = existingCodes.length > 0 ? Math.max(...existingCodes) + 1 : 1;
          const yarnCode = `${prefix}-${nextNumber.toString().padStart(3, '0')}`;
          
          // Add new yarn count
          const newCount: YarnCount = {
            id: Math.max(0, ...yarnCounts.map(c => c.id)) + 1,
            YarnCategoriesId: formData.yarnCategoryId, // Correct property name for DB
            yarnCategoryId: formData.yarnCategoryId, // For form compatibility
            YarnCategoriesName: formData.yarnCategoryName, // Correct property name for DB
            yarnCategoryName: formData.yarnCategoryName, // For form compatibility
            yarnCode: yarnCode, // Auto-generated code
            count: formData.count.trim(),
            priceBdt: formData.priceBdt,
            priceUsd: formData.priceUsd,
            description: formData.description || 'No description',
            is_active: formData.is_active,
            created_at: new Date().toISOString().split('T')[0]
          };

          setYarnCounts([...yarnCounts, newCount]);

          toast({
            title: "Success",
            description: "Yarn count was created successfully.",
          });
        } else if (currentItem) {
          // For edit mode, we need to check if the yarn category changed
          const oldCount = yarnCounts.find(c => c.id === currentItem.id);
          const categoryChanged = oldCount && oldCount.YarnCategoriesName !== formData.yarnCategoryName;
          
          // If category changed, generate a new yarn code
          let updatedYarnCode = (oldCount as YarnCount).yarnCode;
          
          if (categoryChanged) {
            // Generate new yarn code based on new category
            let prefix = 'OTH'; // Default prefix
            if (formData.yarnCategoryName === 'Nylon') {
              prefix = 'NYL';
            } else if (formData.yarnCategoryName === 'Polyester') {
              prefix = 'PLY';
            } else if (formData.yarnCategoryName === 'Cotton') {
              prefix = 'CTN';
            } else if (formData.yarnCategoryName === 'CVC') {
              prefix = 'CVC';
            } else if (formData.yarnCategoryName === 'PC') {
              prefix = 'PC';
            } else if (formData.yarnCategoryName === 'Rubber') {
              prefix = 'RBR';
            } else if (formData.yarnCategoryName !== 'Other') {
              // Check if it's one of our custom categories
              const customCategory = customCategories.find(c => c.name === formData.yarnCategoryName);
              if (customCategory) {
                prefix = customCategory.code;
              }
            }
            
            // Find the highest existing code number for this category to determine next number
            const existingCodes = yarnCounts
              .filter(c => c.yarnCode && c.yarnCode.startsWith(prefix))
              .map(c => {
                const match = c.yarnCode.match(/\d+/);
                return match ? parseInt(match[0], 10) : 0;
              });
            
            const nextNumber = existingCodes.length > 0 ? Math.max(...existingCodes) + 1 : 1;
            updatedYarnCode = `${prefix}-${nextNumber.toString().padStart(3, '0')}`;
          }
          
          // Edit existing yarn count
          const updatedCounts = yarnCounts.map(count => 
            count.id === currentItem.id 
              ? { 
                  ...count, 
                  YarnCategoriesId: formData.yarnCategoryId, // Correct DB property
                  yarnCategoryId: formData.yarnCategoryId, // Form compatibility
                  YarnCategoriesName: formData.yarnCategoryName, // Correct DB property
                  yarnCategoryName: formData.yarnCategoryName, // Form compatibility
                  yarnCode: updatedYarnCode, // Use updated code if category changed
                  count: formData.count.trim(),
                  priceBdt: formData.priceBdt,
                  priceUsd: formData.priceUsd,
                  description: formData.description || count.description,
                  is_active: formData.is_active 
                }
              : count
          );

          setYarnCounts(updatedCounts);

          toast({
            title: "Success",
            description: "Yarn count was updated successfully.",
          });
        }
      } else if (activeTab === 'color-type') {
        if (!formData.name.trim()) {
          setFormError("Color name is required");
          return;
        }

        if (dialogMode === 'add') {
          // Add new color type
          const newColorType: ColorType = {
            id: Math.max(0, ...colorTypes.map(c => c.id)) + 1,
            name: formData.name.trim(),
            description: formData.description || 'No description',
            is_active: formData.is_active,
            created_at: new Date().toISOString().split('T')[0]
          };

          setColorTypes([...colorTypes, newColorType]);

          toast({
            title: "Success",
            description: "Color type was created successfully.",
          });
        } else if (currentItem) {
          // Edit existing color type
          const updatedColorTypes = colorTypes.map(colorType => 
            colorType.id === currentItem.id 
              ? { 
                  ...colorType, 
                  name: formData.name.trim(),
                  description: formData.description || colorType.description,
                  is_active: formData.is_active 
                }
              : colorType
          );

          setColorTypes(updatedColorTypes);

          toast({
            title: "Success",
            description: "Color type was updated successfully.",
          });
        }
      } else if (activeTab === 'dyeing-charge') {
        if (!formData.name.trim()) {
          setFormError("Color name is required");
          return;
        }

        // Add validation for pricing fields
        const priceUsd = parseFloat(formData.priceUsd as unknown as string);
        const priceBdt = parseFloat(formData.priceBdt as unknown as string);

        if (isNaN(priceUsd) || priceUsd <= 0) {
          setFormError("Price in USD must be a positive number");
          return;
        }

        if (isNaN(priceBdt) || priceBdt <= 0) {
          setFormError("Price in BDT must be a positive number");
          return;
        }

        if (!formData.yarnCount || !formData.yarnCategories) {
          setFormError("Yarn count and categories are required");
          return;
        }

        if (dialogMode === 'add') {
          // Add new dyeing charge
          const newCharge: DyeingCharge = {
            id: Math.max(0, ...dyeingCharges.map(c => c.id)) + 1,
            name: formData.name.trim(),
            yarnCategories: formData.yarnCategories,
            yarnCount: formData.yarnCount,
            priceUsd: priceUsd,
            priceBdt: priceBdt,
            description: formData.description || 'No description',
            is_active: formData.is_active,
            created_at: new Date().toISOString().split('T')[0]
          };

          setDyeingCharges([...dyeingCharges, newCharge]);

          toast({
            title: "Success",
            description: "Dyeing charge was created successfully.",
          });
        } else if (currentItem) {
          // Edit existing dyeing charge
          const updatedCharges = dyeingCharges.map(charge => 
            charge.id === currentItem.id 
              ? { 
                  ...charge, 
                  name: formData.name.trim(),
                  yarnCategories: formData.yarnCategories,
                  yarnCount: formData.yarnCount,
                  priceUsd: priceUsd,
                  priceBdt: priceBdt,
                  description: formData.description || charge.description,
                  is_active: formData.is_active 
                }
              : charge
          );

          setDyeingCharges(updatedCharges);

          toast({
            title: "Success",
            description: "Dyeing charge was updated successfully.",
          });
        }
      } else if (activeTab === 'over-head-percent') {
        // Validate required fields
        if (!formData.productionUnit) {
          setFormError("Production unit is required");
          return;
        }

        if (!formData.itemName) {
          setFormError("Item name is required");
          return;
        }

        const overHeadValue = parseFloat(formData.overHeadPercent);
        if (isNaN(overHeadValue) || overHeadValue < 0 || overHeadValue > 100) {
          setFormError("Overhead percentage must be a positive number between 0 and 100");
          return;
        }

        if (dialogMode === 'add') {
          // Add new overhead percentage
          const newOverhead: OverHeadPercent = {
            id: Math.max(0, ...overHeadPercents.map(o => o.id)) + 1,
            productionUnit: formData.productionUnit,
            itemName: formData.itemName,
            overHeadPercent: overHeadValue,
            description: formData.description || 'No description',
            is_active: formData.is_active,
            created_at: new Date().toISOString().split('T')[0]
          };

          try {
            // Save to server first
            const response = await fetch('/api/settings/overhead-percents', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                productionUnit: formData.productionUnit,
                itemName: formData.itemName,
                overHeadPercent: overHeadValue,
                description: formData.description || 'No description',
                is_active: formData.is_active
              }),
            });

            if (!response.ok) {
              throw new Error('Failed to save overhead percentage to server');
            }

            const savedItem = await response.json();
            
            // Then update local state with the saved item from server (including real ID)
            setOverHeadPercents([...overHeadPercents, savedItem]);

            toast({
              title: "Success",
              description: "Overhead percentage was created successfully and saved to server.",
            });
          } catch (error) {
            console.error('Error saving overhead percentage:', error);
            // Still update local state as fallback
            setOverHeadPercents([...overHeadPercents, newOverhead]);
            
            toast({
              title: "Warning",
              description: "Overhead percentage was created locally but could not be saved to server. Changes may be lost on page refresh.",
              variant: "destructive"
            });
          }
        } else if (currentItem) {
          // Edit existing overhead percentage
          const updatedOverheads = overHeadPercents.map(overhead => 
            overhead.id === currentItem.id 
              ? { 
                  ...overhead,
                  productionUnit: formData.productionUnit,
                  itemName: formData.itemName,
                  overHeadPercent: overHeadValue,
                  description: formData.description || overhead.description,
                  is_active: formData.is_active 
                }
              : overhead
          );

          setOverHeadPercents(updatedOverheads);

          toast({
            title: "Success",
            description: "Overhead percentage was updated successfully.",
          });
        }
      } else if (activeTab === 'profit-margin') {
        // Validate required fields
        if (!formData.productionUnit) {
          setFormError("Production unit is required");
          return;
        }

        if (!formData.itemName) {
          setFormError("Item name is required");
          return;
        }

        const profitValue = parseFloat(formData.profitMargin);
        if (isNaN(profitValue) || profitValue < 0) {
          setFormError("Profit margin must be a positive number");
          return;
        }

        if (dialogMode === 'add') {
          // Add new profit margin
          const newProfit: ProfitMargin = {
            id: Math.max(0, ...profitMargins.map(p => p.id)) + 1,
            productionUnit: formData.productionUnit,
            itemName: formData.itemName,
            profitMargin: profitValue,
            description: formData.description || 'No description',
            is_active: formData.is_active,
            created_at: new Date().toISOString().split('T')[0]
          };

          try {
            // Save to server first
            const response = await fetch('/api/settings/profit-margins', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                production_unit: formData.productionUnit,
                item_name: formData.itemName,
                profit_margin: profitValue,
                description: formData.description || 'No description',
                is_active: formData.is_active
              }),
            });

            if (!response.ok) {
              throw new Error('Failed to save profit margin to server');
            }

            const savedItem = await response.json();
            
            // Then update local state with the saved item from server (including real ID)
            setProfitMargins([...profitMargins, savedItem]);

            toast({
              title: "Success",
              description: "Profit margin was created successfully and saved to server.",
            });
          } catch (error) {
            console.error('Error saving profit margin:', error);
            // Still update local state as fallback
            setProfitMargins([...profitMargins, newProfit]);
            
            toast({
              title: "Warning",
              description: "Profit margin was created locally but could not be saved to server. Changes may be lost on page refresh.",
              variant: "destructive"
            });
          }
        } else if (currentItem) {
          // Edit existing profit margin
          try {
            // Update server first
            const response = await fetch(`/api/settings/profit-margins/${currentItem.id}`, {
              method: 'PATCH',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                production_unit: formData.productionUnit,
                item_name: formData.itemName,
                profit_margin: profitValue,
                description: formData.description || 'No description',
                is_active: formData.is_active
              }),
            });

            if (!response.ok) {
              throw new Error('Failed to update profit margin on server');
            }

            const updatedItem = await response.json();
            
            // Then update local state with the updated item from server
            const updatedProfits = profitMargins.map(profit => 
              profit.id === currentItem.id ? updatedItem : profit
            );

            setProfitMargins(updatedProfits);

            toast({
              title: "Success",
              description: "Profit margin was updated successfully on server.",
            });
          } catch (error) {
            console.error('Error updating profit margin:', error);
            
            // Still update local state as fallback
            const updatedProfits = profitMargins.map(profit => 
              profit.id === currentItem.id 
                ? { 
                    ...profit,
                    productionUnit: formData.productionUnit,
                    itemName: formData.itemName,
                    profitMargin: profitValue,
                    description: formData.description || profit.description,
                    is_active: formData.is_active 
                  }
                : profit
            );

            setProfitMargins(updatedProfits);

            toast({
              title: "Warning",
              description: "Profit margin was updated locally but could not be saved to server. Changes may be lost on page refresh.",
              variant: "destructive"
            });
          }
        }
      }

      setIsDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem with your request.",
        variant: "destructive",
      });
    }
  };

  const openDeleteDialog = (item: any) => {
    setCurrentItem(item as ItemType);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!currentItem) return;

    const id = currentItem.id;

    // Check which tab we're on to determine which collection to update
    if (activeTab === 'elastic-part') {
      try {
        await deleteFabricPartMutation.mutateAsync(id);
        toast({
          title: "Success",
          description: "Elastic part was deleted successfully.",
        });
      } catch (error) {
        console.error('Error deleting elastic part:', error);
        toast({
          title: "Error",
          description: "Failed to delete elastic part. Please try again.",
          variant: "destructive"
        });
      }
    } else if (activeTab === 'production-unit') {
      setProductionUnits(productionUnits.filter(unit => unit.id !== id));
      toast({
        title: "Success",
        description: "Production unit was deleted successfully.",
      });
    } else if (activeTab === 'item') {
      setItems(items.filter(item => item.id !== id));
      toast({
        title: "Success",
        description: "Item was deleted successfully.",
      });
    } else if (activeTab === 'yarn-category') {
      try {
        await deleteYarnCategoryMutation.mutateAsync(id);
        toast({
          title: "Success",
          description: "Yarn category was deleted successfully.",
        });
      } catch (error) {
        console.error('Error deleting yarn category:', error);
        toast({
          title: "Error",
          description: "Failed to delete yarn category. Please try again.",
          variant: "destructive"
        });
      }
    } else if (activeTab === 'yarn-count') {
      setYarnCounts(yarnCounts.filter(count => count.id !== id));
      toast({
        title: "Success",
        description: "Yarn count was deleted successfully.",
      });
    } else if (activeTab === 'color-type') {
      setColorTypes(colorTypes.filter(colorType => colorType.id !== id));
      toast({
        title: "Success",
        description: "Color type was deleted successfully.",
      });
    } else if (activeTab === 'dyeing-charge') {
      setDyeingCharges(dyeingCharges.filter(charge => charge.id !== id));
      toast({
        title: "Success",
        description: "Dyeing charge was deleted successfully.",
      });
    } else if (activeTab === 'over-head-percent') {
      setOverHeadPercents(overHeadPercents.filter(item => item.id !== id));
      toast({
        title: "Success",
        description: "Overhead percentage was deleted successfully.",
      });
    } else if (activeTab === 'profit-margin') {
      try {
        // Delete from server first
        const response = await fetch(`/api/settings/profit-margins/${id}`, {
          method: 'DELETE',
        });

        if (!response.ok) {
          throw new Error('Failed to delete profit margin from server');
        }

        // Then update local state if server delete was successful
        setProfitMargins(profitMargins.filter(item => item.id !== id));
        
        toast({
          title: "Success",
          description: "Profit margin was deleted successfully from server.",
        });
      } catch (error) {
        console.error('Error deleting profit margin:', error);
        
        // Still update local state as fallback
        setProfitMargins(profitMargins.filter(item => item.id !== id));
        
        toast({
          title: "Warning",
          description: "Profit margin was removed locally but could not be deleted from server.",
          variant: "destructive"
        });
      }
    }

    setDeleteDialogOpen(false);
  };

  return (
    <AppLayout title="Narrow Fabrics Settings" description="Manage settings for narrow fabrics">
      <div className="w-full p-0 sm:p-6">
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 px-4 sm:px-0">
          {/* Dropdown Menu for Tab Selection */}
          <div className="space-y-2">
            <label htmlFor="tabSelect" className="block text-xl font-extrabold text-gray-800 dark:text-gray-200">
              Select Setting Category
            </label>
            <Select value={activeTab} onValueChange={setActiveTab}>
              <SelectTrigger className="w-full h-12 text-base bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all pl-4 pr-8">
                <SelectValue placeholder="Select a setting" className="flex-1 truncate" />
              </SelectTrigger>
              <SelectContent className="max-h-[400px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                <SelectGroup>
                  <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2 border-b border-blue-100 dark:border-gray-700">Setting Categories</SelectLabel>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-1 p-2">
                    <SelectItem value="elastic-part" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Elastic Part</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="production-unit" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Production Unit</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="item" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Item</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="yarn-category" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Yarn Category</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="yarn-count" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Yarn Count</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="color-type" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Color Type</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="dyeing-charge" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Dyeing Charge</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="over-head-percent" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Over-Head %</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="profit-margin" className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer rounded-md">
                      <div className="flex items-center">
                        <span className="font-medium">Profit Margin</span>
                      </div>
                    </SelectItem>
                  </div>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          {/* Search Bar */}
          <div className="space-y-2">
            <label htmlFor="searchInput" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Search
            </label>
            <div className="relative">
              <Input
                id="searchInput"
                type="text"
                placeholder="Search by name, description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-10"
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
        
        {/* Export Options and Actions */}
        <div className="flex flex-wrap gap-2 justify-between items-center mb-4 px-4 sm:px-0">
          <div className="flex flex-col xs:flex-row gap-2 items-start xs:items-center">
            <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 xs:mb-0">
              Export {getActiveTabName(activeTab)}:
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-1 h-9"
                onClick={() => handleExport('csv')}
              >
                <FileText className="h-4 w-4" />
                <span>CSV</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-1 h-9"
                onClick={() => handleExport('excel')}
              >
                <Table2 className="h-4 w-4" />
                <span>Excel</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-1 h-9"
                onClick={() => handleExport('pdf')}
              >
                <FileOutput className="h-4 w-4" />
                <span>PDF</span>
              </Button>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm" 
              className="flex items-center gap-1 bg-slate-50 dark:bg-slate-900 h-9"
              onClick={handleGenerateReport}
            >
              <Download className="h-4 w-4" />
              <span>Generate Complete Report</span>
            </Button>
            
            {/* Import Data Button */}
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1 h-9"
              onClick={handleOpenImportDialog}
            >
              <Upload className="h-4 w-4" />
              <span>Import {getActiveTabName(activeTab)}</span>
            </Button>
            
            {/* Delete All Button */}
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1 h-9 text-destructive hover:text-destructive"
              onClick={handleOpenBulkDeleteDialog}
            >
              <Trash2 className="h-4 w-4" />
              <span>Delete All</span>
            </Button>
            
            {/* Column Selector */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="flex items-center gap-1 h-9">
                  <ColumnsIcon className="h-4 w-4" />
                  <span>Select Columns</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
                  <h4 className="text-sm font-medium mb-2">Show/Hide Columns</h4>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                    {columnConfig[activeTab as keyof typeof columnConfig]?.map((column) => (
                      <div key={column.key} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`column-${column.key}`} 
                          checked={columnVisibility[activeTab as keyof typeof columnVisibility][column.key as keyof typeof columnVisibility[keyof typeof columnVisibility]]} 
                          onCheckedChange={(checked) => {
                            setColumnVisibility(prev => ({
                              ...prev,
                              [activeTab]: {
                                ...prev[activeTab as keyof typeof columnVisibility],
                                [column.key]: !!checked
                              }
                            }));
                          }}
                        />
                        <label 
                          htmlFor={`column-${column.key}`}
                          className="text-sm font-medium cursor-pointer"
                        >
                          {column.label}
                        </label>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between mt-3 pt-3 border-t border-gray-100 dark:border-gray-700">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        // Reset to show all columns
                        const allColumnsVisible = Object.fromEntries(
                          columnConfig[activeTab as keyof typeof columnConfig]?.map(
                            column => [column.key, true]
                          ) || []
                        );
                        
                        setColumnVisibility(prev => ({
                          ...prev,
                          [activeTab]: allColumnsVisible
                        }));
                      }}
                    >
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        // Save settings (this would typically save to localStorage or backend)
                        toast({
                          title: "Columns updated",
                          description: "Your column preferences have been saved."
                        });
                      }}
                    >
                      Apply
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
        
        {/* View Mode Toggle */}
        <div className="flex justify-end items-center mb-4 px-4 sm:px-0">
          <div className="flex space-x-2">
            <Button 
              variant={viewMode === 'table' ? 'default' : 'outline'} 
              size="sm" 
              onClick={() => setViewMode('table')}
              className="flex items-center gap-1 h-9"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="3" y1="9" x2="21" y2="9"></line>
                <line x1="3" y1="15" x2="21" y2="15"></line>
                <line x1="9" y1="3" x2="9" y2="21"></line>
                <line x1="15" y1="3" x2="15" y2="21"></line>
              </svg>
              Table
            </Button>
            <Button 
              variant={viewMode === 'card' ? 'default' : 'outline'} 
              size="sm" 
              onClick={() => setViewMode('card')}
              className="flex items-center gap-1 h-9"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
              </svg>
              Cards
            </Button>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-slate-900 border border-blue-100 dark:border-gray-700 rounded-md overflow-hidden shadow-sm">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            
            {/* Tab Navigation - Hidden as requested */}
            <TabsList className="hidden">
              <TabsTrigger value="elastic-part">Elastic Part</TabsTrigger>
              <TabsTrigger value="production-unit">Production Unit</TabsTrigger>
              <TabsTrigger value="item">Item</TabsTrigger>
              <TabsTrigger value="yarn-category">Yarn Category</TabsTrigger>
              <TabsTrigger value="yarn-count">Yarn Count</TabsTrigger>
              <TabsTrigger value="color-type">Color Type</TabsTrigger>
              <TabsTrigger value="dyeing-charge">Dyeing Charge</TabsTrigger>
              <TabsTrigger value="over-head-percent">Over-Head %</TabsTrigger>
              <TabsTrigger value="profit-margin">Profit Margin</TabsTrigger>
            </TabsList>

          {/* Sample Tab Content - Repeat similar structure for other tabs */}
          <TabsContent value="elastic-part">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Elastic Parts</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage elastic parts configuration
                  </CardDescription>
                </div>
                <Button onClick={openAddDialog} className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700">
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter the data based on search term */}
                      {viewMode === 'table' ? (
                        <div className="overflow-x-auto w-full">
                          <Table className="w-full divide-y">
                            <TableHeader>
                              <TableRow className="bg-gray-50 dark:bg-gray-800">
                                {columnVisibility['elastic-part'].name && (
                                  <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('elastic-part')}}>
                                    Name
                                  </TableHead>
                                )}
                                {columnVisibility['elastic-part'].status && (
                                  <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('elastic-part')}}>
                                    Status
                                  </TableHead>
                                )}
                                {columnVisibility['elastic-part'].date && (
                                  <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('elastic-part')}}>
                                    Date
                                  </TableHead>
                                )}
                                {columnVisibility['elastic-part'].action && (
                                  <TableHead className="py-2 px-2 text-right text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('elastic-part')}}>
                                    Action
                                  </TableHead>
                                )}
                              </TableRow>
                            </TableHeader>
                            <TableBody className="divide-y">
                              {filterData(fabricParts, searchTerm).map((part) => (
                                <TableRow key={part.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                                  {columnVisibility['elastic-part'].name && (
                                    <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                      {part.name}
                                    </TableCell>
                                  )}
                                  {columnVisibility['elastic-part'].status && (
                                    <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                      <Badge variant={getStatusBadgeVariant(part.is_active)}>
                                        {part.is_active ? 'Active' : 'Inactive'}
                                      </Badge>
                                    </TableCell>
                                  )}
                                  {columnVisibility['elastic-part'].date && (
                                    <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                      {new Date(part.created_at).toLocaleDateString()}
                                    </TableCell>
                                  )}
                                  {columnVisibility['elastic-part'].action && (
                                    <TableCell className="py-1 px-2 text-xs sm:text-sm text-right">
                                      <div className="flex gap-1 sm:gap-2 justify-end">
                                        <Button 
                                          variant="ghost" 
                                          size="sm" 
                                          onClick={() => openEditDialog(part)} 
                                          className="h-7 sm:h-8 w-7 sm:w-8 p-0 flex items-center justify-center text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                                          aria-label="Edit"
                                        >
                                          <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                                        </Button>
                                        <Button 
                                          variant="ghost" 
                                          size="sm" 
                                          onClick={() => openDeleteDialog(part)}
                                          className="h-7 sm:h-8 w-7 sm:w-8 p-0 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50"
                                          aria-label="Delete"
                                        >
                                          <Trash className="h-3 w-3 sm:h-4 sm:w-4" />
                                        </Button>
                                      </div>
                                    </TableCell>
                                  )}
                                </TableRow>
                              ))}
                              {filterData(fabricParts, searchTerm).length === 0 && (
                                <TableRow>
                                  <TableCell 
                                    colSpan={Object.values(columnVisibility['elastic-part']).filter(Boolean).length} 
                                    className="py-6 text-center text-sm text-gray-500"
                                  >
                                    {searchTerm ? 'No matches found for your search.' : 'No items found. Click "Add New" to create one.'}
                                  </TableCell>
                                </TableRow>
                              )}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                          {filterData(fabricParts, searchTerm).map((part) => (
                            <div 
                              key={part.id} 
                              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-shadow"
                            >
                              <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                                <div className="font-medium truncate">{part.name}</div>
                                <Badge variant={getStatusBadgeVariant(part.is_active)}>
                                  {part.is_active ? 'Active' : 'Inactive'}
                                </Badge>
                              </div>
                              <div className="p-4 text-sm text-gray-600 dark:text-gray-300">
                                <div className="flex justify-between items-center mb-2">
                                  <span className="text-xs text-gray-500">Created</span>
                                  <span className="text-xs">{new Date(part.created_at).toLocaleDateString()}</span>
                                </div>
                                <div className="flex justify-end mt-4 space-x-2">
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    onClick={() => openEditDialog(part)} 
                                    className="h-8 px-2 text-xs"
                                  >
                                    <Edit className="h-3 w-3 mr-1" /> Edit
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    onClick={() => openDeleteDialog(part)}
                                    className="h-8 px-2 text-xs text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                                  >
                                    <Trash className="h-3 w-3 mr-1" /> Delete
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                          {filterData(fabricParts, searchTerm).length === 0 && (
                            <div className="col-span-full py-8 text-center text-sm text-gray-500">
                              {searchTerm ? 'No matches found for your search.' : 'No items found. Click "Add New" to create one.'}
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

          {/* Production Unit Tab */}
          <TabsContent value="production-unit">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Production Units</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage production units and capacity
                  </CardDescription>
                </div>
                <Button onClick={openAddDialog} className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700">
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter data based on search term and display in table or card view */}
                {viewMode === 'table' ? (
                  <div className="overflow-x-auto w-full">
                    <Table className="w-full table-fixed divide-y">
                      <TableHeader>
                        <TableRow className="bg-gray-50 dark:bg-gray-800">
                          {columnVisibility['production-unit'].name && (
                            <TableHead className="py-2 px-2 text-left text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[25%]">
                              Name
                            </TableHead>
                          )}
                          {columnVisibility['production-unit'].status && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[15%]">
                              Status
                            </TableHead>
                          )}
                          {columnVisibility['production-unit'].capacity && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[15%]">
                              Capacity
                            </TableHead>
                          )}
                          {columnVisibility['production-unit'].description && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[25%]">
                              Description
                            </TableHead>
                          )}
                          {columnVisibility['production-unit'].date && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[15%]">
                              Date
                            </TableHead>
                          )}
                          {columnVisibility['production-unit'].action && (
                            <TableHead className="py-2 px-2 text-right text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[15%]">
                              Action
                            </TableHead>
                          )}
                        </TableRow>
                      </TableHeader>
                      <TableBody className="divide-y">
                        {filterData(productionUnits, searchTerm).map((unit) => (
                          <TableRow key={unit.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                            {columnVisibility['production-unit'].name && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-left">
                                {unit.name}
                              </TableCell>
                            )}
                            {columnVisibility['production-unit'].status && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                <Badge variant={getStatusBadgeVariant(unit.is_active)}>
                                  {unit.is_active ? 'Active' : 'Inactive'}
                                </Badge>
                              </TableCell>
                            )}
                            {columnVisibility['production-unit'].capacity && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {unit.capacity} YDS/day
                              </TableCell>
                            )}
                            {columnVisibility['production-unit'].description && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {unit.description}
                              </TableCell>
                            )}
                            {columnVisibility['production-unit'].date && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {new Date(unit.created_at).toLocaleDateString()}
                              </TableCell>
                            )}
                            {columnVisibility['production-unit'].action && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm text-right">
                                <div className="flex gap-1 sm:gap-2 justify-end">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => openEditDialog(unit)} 
                                    className="h-7 sm:h-8 w-7 sm:w-8 p-0 flex items-center justify-center text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                                    aria-label="Edit"
                                  >
                                    <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => openDeleteDialog(unit)}
                                    className="h-7 sm:h-8 w-7 sm:w-8 p-0 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50"
                                    aria-label="Delete"
                                  >
                                    <Trash className="h-3 w-3 sm:h-4 sm:w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            )}
                          </TableRow>
                        ))}
                        {filterData(productionUnits, searchTerm).length === 0 && (
                          <TableRow>
                            <TableCell 
                              colSpan={Object.values(columnVisibility['production-unit']).filter(Boolean).length} 
                              className="py-6 text-center text-sm text-gray-500"
                            >
                              {searchTerm ? 'No matches found for your search.' : 'No production units found. Click "Add New" to create one.'}
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {filterData(productionUnits, searchTerm).map((unit) => (
                      <div 
                        key={unit.id} 
                        className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-shadow"
                      >
                        <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                          <div className="font-medium truncate">{unit.name}</div>
                          <Badge variant={getStatusBadgeVariant(unit.is_active)}>
                            {unit.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                        <div className="p-4 text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-xs text-gray-500">Capacity:</span>
                            <span className="text-xs font-medium">{unit.capacity} YDS/day</span>
                          </div>
                          <div className="mt-2 mb-4">
                            <p className="text-xs line-clamp-2">{unit.description}</p>
                          </div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-xs text-gray-500">Created:</span>
                            <span className="text-xs">{new Date(unit.created_at).toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-end mt-4 space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => openEditDialog(unit)} 
                              className="h-8 px-2 text-xs"
                            >
                              <Edit className="h-3 w-3 mr-1" /> Edit
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => openDeleteDialog(unit)}
                              className="h-8 px-2 text-xs text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                            >
                              <Trash className="h-3 w-3 mr-1" /> Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {filterData(productionUnits, searchTerm).length === 0 && (
                      <div className="col-span-full py-8 text-center text-sm text-gray-500">
                        {searchTerm ? 'No matches found for your search.' : 'No production units found. Click "Add New" to create one.'}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Item Tab */}
          <TabsContent value="item">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Items</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage production items
                  </CardDescription>
                </div>
                <Button onClick={openAddDialog} className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700">
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {viewMode === 'table' ? (
                  <div className="overflow-x-auto w-full">
                    <Table className="w-full table-fixed divide-y">
                      <TableHeader>
                        <TableRow className="bg-gray-50 dark:bg-gray-800">
                          {columnVisibility['item'].unit && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[20%]">
                              Unit
                            </TableHead>
                          )}
                          {columnVisibility['item'].name && (
                            <TableHead className="py-2 px-2 text-left text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[20%]">
                              Name
                            </TableHead>
                          )}
                          {columnVisibility['item'].elasticPart && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[20%]">
                            Elastic Part
                            </TableHead>
                          )}
                          {columnVisibility['item'].description && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[15%]">
                              Description
                            </TableHead>
                          )}
                          {columnVisibility['item'].status && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[15%]">
                              Status
                            </TableHead>
                          )}
                          {columnVisibility['item'].date && (
                            <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[10%]">
                              Date
                            </TableHead>
                          )}
                          {columnVisibility['item'].action && (
                            <TableHead className="py-2 px-2 text-right text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200 w-[15%]">
                              Action
                            </TableHead>
                          )}
                        </TableRow>
                      </TableHeader>
                      <TableBody className="divide-y">
                        {filterData(items, searchTerm).map((item) => (
                          <TableRow key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                            {columnVisibility['item'].unit && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {item.unit}
                              </TableCell>
                            )}
                            {columnVisibility['item'].name && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-left">
                                {item.name}
                              </TableCell>
                            )}
                            {columnVisibility['item'].elasticPart && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {item.elasticPart}
                              </TableCell>
                            )}
                            {columnVisibility['item'].description && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {item.description}
                              </TableCell>
                            )}
                            {columnVisibility['item'].status && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                <Badge variant={getStatusBadgeVariant(item.is_active)}>
                                  {item.is_active ? 'Active' : 'Inactive'}
                                </Badge>
                              </TableCell>
                            )}
                            {columnVisibility['item'].date && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {new Date(item.created_at).toLocaleDateString()}
                              </TableCell>
                            )}
                            {columnVisibility['item'].action && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm text-right">
                                <div className="flex gap-1 sm:gap-2 justify-end">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => openEditDialog(item)} 
                                    className="h-7 sm:h-8 w-7 sm:w-8 p-0 flex items-center justify-center text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                                    aria-label="Edit"
                                  >
                                    <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => openDeleteDialog(item)} 
                                    className="h-7 sm:h-8 w-7 sm:w-8 p-0 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50"
                                    aria-label="Delete"
                                  >
                                    <Trash className="h-3 w-3 sm:h-4 sm:w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            )}
                          </TableRow>
                        ))}
                        {filterData(items, searchTerm).length === 0 && (
                          <TableRow>
                            <TableCell 
                              colSpan={Object.values(columnVisibility['item']).filter(Boolean).length} 
                              className="py-6 text-center text-sm text-gray-500"
                            >
                              {searchTerm ? 'No matches found for your search.' : 'No items found. Click "Add New" to create one.'}
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {filterData(items, searchTerm).map((item) => (
                      <div 
                        key={item.id} 
                        className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-shadow"
                      >
                        <div className="p-4 border-b border-gray-100 dark:border-gray-700">
                          <div className="flex items-center justify-between mb-2">
                            <div className="font-medium truncate">{item.name}</div>
                            <Badge variant={getStatusBadgeVariant(item.is_active)}>
                              {item.is_active ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                          <div className="text-xs text-gray-500">{item.unit}</div>
                        </div>
                        <div className="p-4 text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-xs text-gray-500">Elastic Part:</span>
                            <span className="text-xs">{item.elasticPart}</span>
                          </div>
                          <div className="mt-2 mb-3">
                            <p className="text-xs line-clamp-2">{item.description}</p>
                          </div>
                          <div className="flex justify-between items-center mb-4">
                            <span className="text-xs text-gray-500">Created:</span>
                            <span className="text-xs">{new Date(item.created_at).toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-end mt-2 space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => openEditDialog(item)} 
                              className="h-8 px-2 text-xs"
                            >
                              <Edit className="h-3 w-3 mr-1" /> Edit
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => openDeleteDialog(item)}
                              className="h-8 px-2 text-xs text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                            >
                              <Trash className="h-3 w-3 mr-1" /> Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {filterData(items, searchTerm).length === 0 && (
                      <div className="col-span-full py-8 text-center text-sm text-gray-500">
                        {searchTerm ? 'No matches found for your search.' : 'No items found. Click "Add New" to create one.'}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Yarn Category Tab */}
          <TabsContent value="yarn-category">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Yarn Categories</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage yarn categories and codes
                  </CardDescription>
                </div>
                <Button onClick={openAddDialog} className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700">
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter the data based on search term */}
                <div className="overflow-x-auto w-full">
                  <Table className="w-full divide-y">
                    <TableHeader>
                      <TableRow className="bg-gray-50 dark:bg-gray-800">
                        {columnVisibility['yarn-category'].name && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-category')}}>
                            Category Name
                          </TableHead>
                        )}
                        {columnVisibility['yarn-category'].code && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-category')}}>
                            Code
                          </TableHead>
                        )}
                        {columnVisibility['yarn-category'].status && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-category')}}>
                            Status
                          </TableHead>
                        )}
                        {columnVisibility['yarn-category'].date && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-category')}}>
                            Date
                          </TableHead>
                        )}
                        {columnVisibility['yarn-category'].action && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-category')}}>
                            Action
                          </TableHead>
                        )}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {effectiveYarnCategories.map((category) => (
                        <TableRow key={category.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                          {columnVisibility['yarn-category'].name && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {category.name}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-category'].code && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              <span className="inline-flex px-2 py-1 rounded-md bg-gray-100 text-gray-800 text-xs font-medium">
                                {category.code}
                              </span>
                            </TableCell>
                          )}
                          {columnVisibility['yarn-category'].status && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              <Badge variant={getStatusBadgeVariant(category.is_active)}>
                                {category.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility['yarn-category'].date && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {formatDate(category.created_at)}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-category'].action && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm text-center">
                              <div className="flex justify-center items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => openEditDialog(category)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-500"
                                  onClick={() => openDeleteDialog(category)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                      {yarnCategories.length === 0 && (
                        <TableRow>
                          <TableCell 
                            colSpan={Object.values(columnVisibility['yarn-category']).filter(Boolean).length}
                            className="text-center py-4 text-sm text-slate-500"
                          >
                            No yarn categories found. Click "Add New" to get started.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Yarn Count Tab */}
          <TabsContent value="yarn-count">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Yarn Counts</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage yarn counts and specifications
                  </CardDescription>
                </div>
                <Button onClick={openAddDialog} className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700">
                  <Plus className="mr-2 h-4 w-4" /> Add New Yarn Count
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter the data based on search term */}
                <div className="overflow-x-auto w-full">
                  <Table className="w-full divide-y">
                    <TableHeader>
                      <TableRow className="bg-gray-50 dark:bg-gray-800">
                        {columnVisibility['yarn-count'].yarnCategory && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Yarn Category
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].yarnCode && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Yarn Code
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].count && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Count
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].priceBdt && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Price (BDT)
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].priceUsd && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Price (USD)
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].description && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Description
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].status && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Status
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].date && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Date
                          </TableHead>
                        )}
                        {columnVisibility['yarn-count'].action && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('yarn-count')}}>
                            Action
                          </TableHead>
                        )}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {yarnCounts.map((count) => (
                        <TableRow key={count.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                          {columnVisibility['yarn-count'].yarnCategory && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {count.YarnCategoriesName || ""}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].yarnCode && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {count.yarnCode || ""}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].count && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {count.count}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].priceBdt && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {count.priceBdt ? formatCurrency(parseFloat(count.priceBdt), 'BDT') : '-'}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].priceUsd && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {count.priceUsd ? formatCurrency(parseFloat(count.priceUsd), 'USD') : '-'}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].description && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {count.description}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].status && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              <Badge variant={getStatusBadgeVariant(count.is_active)}>
                                {count.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].date && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {formatDate(count.created_at)}
                            </TableCell>
                          )}
                          {columnVisibility['yarn-count'].action && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm text-center">
                              <div className="flex justify-center items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => openEditDialog(count)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-500"
                                  onClick={() => openDeleteDialog(count)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                      {yarnCounts.length === 0 && (
                        <TableRow>
                          <TableCell 
                            colSpan={Object.values(columnVisibility['yarn-count']).filter(Boolean).length} 
                            className="text-center py-4 text-sm text-slate-500"
                          >
                            No yarn counts found. Click "Add New Yarn Count" to get started.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Color Type Tab */}
          <TabsContent value="color-type">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Color Types</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage yarn by color tape
                  </CardDescription>
                </div>
                <Button onClick={openAddDialog} className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700">
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter the data based on search term */}
                <div className="overflow-x-auto w-full">
                  <Table className="w-full divide-y">
                    <TableHeader>
                      <TableRow className="bg-gray-50 dark:bg-gray-800">
                        {columnVisibility['color-type'].name && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('color-type')}}>
                            Color Name
                          </TableHead>
                        )}
                        {columnVisibility['color-type'].description && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('color-type')}}>
                            Description
                          </TableHead>
                        )}
                        {columnVisibility['color-type'].status && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('color-type')}}>
                            Status
                          </TableHead>
                        )}
                        {columnVisibility['color-type'].date && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('color-type')}}>
                            Date
                          </TableHead>
                        )}
                        {columnVisibility['color-type'].action && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('color-type')}}>
                            Action
                          </TableHead>
                        )}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {colorTypes.map((colorType) => (
                        <TableRow key={colorType.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                          {columnVisibility['color-type'].name && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {colorType.name}
                            </TableCell>
                          )}
                          {columnVisibility['color-type'].description && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {colorType.description}
                            </TableCell>
                          )}
                          {columnVisibility['color-type'].status && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              <Badge variant={getStatusBadgeVariant(colorType.is_active)}>
                                {colorType.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility['color-type'].date && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {formatDate(colorType.created_at)}
                            </TableCell>
                          )}
                          {columnVisibility['color-type'].action && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm text-center">
                              <div className="flex justify-center items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => openEditDialog(colorType)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-500"
                                  onClick={() => openDeleteDialog(colorType)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                      {colorTypes.length === 0 && (
                        <TableRow>
                          <TableCell 
                            colSpan={Object.values(columnVisibility['color-type']).filter(Boolean).length} 
                            className="text-center py-4 text-sm text-slate-500"
                          >
                            No color types found. Click "Add New" to get started.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Dyeing Charge Tab */}
          <TabsContent value="dyeing-charge">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Dyeing Charge</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage Yarn Price by Color Tape
                  </CardDescription>
                </div>
                <Button 
                  onClick={() => {
                    setActiveTab("dyeing-charge");
                    setDialogMode("add");
                    setFormData({
                      name: '',
                      count: '',
                      description: 'Dyed Yarn',
                      code: '',
                      selectedElasticParts: [],
                      is_active: true,
                      yarnCategoryId: 0,
                      yarnCategoryName: '',
                      yarnCategories: '',
                      yarnCount: '',
                      priceUsd: '',
                      priceBdt: '',
                      productionUnit: '',
                      itemName: '',
                      overHeadPercent: '',
                      profitMargin: '',
                    });
                    setFormError(null);
                    setIsDialogOpen(true);
                  }}
                  className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700"
                >
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter the data based on search term */}
                <div className="overflow-x-auto w-full">
                  <Table className="w-full divide-y">
                    <TableHeader>
                      <TableRow className="bg-gray-50 dark:bg-gray-800">
                        {columnVisibility['dyeing-charge'].name && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Color Name
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].yarnCategories && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Yarn Categories
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].yarnCount && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Yarn Count
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].priceUsd && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Dyeing Price Per Kg USD
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].priceBdt && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Dyeing Price Per Kg BDT
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].description && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Description
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].status && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Status
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].date && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Date
                          </TableHead>
                        )}
                        {columnVisibility['dyeing-charge'].action && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('dyeing-charge')}}>
                            Action
                          </TableHead>
                        )}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {dyeingCharges.length > 0 ? (
                        dyeingCharges.map((charge) => (
                          <TableRow key={charge.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                            {columnVisibility['dyeing-charge'].name && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {charge.name}
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].yarnCategories && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {charge.yarnCategories}
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].yarnCount && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {charge.yarnCount}
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].priceUsd && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {charge.priceUsd ? formatCurrency(parseFloat(charge.priceUsd), 'USD') : '-'}
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].priceBdt && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {charge.priceBdt ? formatCurrency(parseFloat(charge.priceBdt), 'BDT') : '-'}
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].description && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {charge.description}
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].status && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                <Badge variant={getStatusBadgeVariant(charge.is_active)}>
                                  {charge.is_active ? 'Active' : 'Inactive'}
                                </Badge>
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].date && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                                {formatDate(charge.created_at)}
                              </TableCell>
                            )}
                            {columnVisibility['dyeing-charge'].action && (
                              <TableCell className="py-1 px-2 text-xs sm:text-sm text-center">
                                <div className="flex justify-center items-center gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => openEditDialog(charge)}
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 text-red-500"
                                    onClick={() => openDeleteDialog(charge)}
                                  >
                                    <Trash className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            )}
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell 
                            colSpan={Object.values(columnVisibility['dyeing-charge']).filter(Boolean).length} 
                            className="text-center py-4 text-sm text-slate-500"
                          >
                            No dyeing charges found. Click "Add New" to get started.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Over-Head Percent Tab */}
          <TabsContent value="over-head-percent">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Over-Head %</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage item-wise overhead percentage for production calculations.
                  </CardDescription>
                </div>
                <Button 
                  className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700"
                  onClick={() => {
                    setActiveTab("over-head-percent");
                    setDialogMode("add");
                    setFormData({
                      name: '',
                      count: '',
                      description: '',
                      code: '',
                      selectedElasticParts: [], // Add empty array for consistency
                      is_active: true,
                      yarnCategoryId: 0,
                      yarnCategoryName: '',
                      yarnCategories: '',
                      yarnCount: '',
                      priceUsd: '',
                      priceBdt: '',
                      productionUnit: '',
                      itemName: '',
                      overHeadPercent: '15',
                      profitMargin: '',
                    });
                    setFormError(null);
                    setIsDialogOpen(true);
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter the data based on search term */}
                <div className="overflow-x-auto w-full">
                  <Table className="w-full divide-y">
                    <TableHeader>
                      <TableRow className="bg-gray-50 dark:bg-gray-800">
                        {columnVisibility['over-head-percent'].productionUnit && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('over-head-percent')}}>
                            Production Unit
                          </TableHead>
                        )}
                        {columnVisibility['over-head-percent'].itemName && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('over-head-percent')}}>
                            Item Name
                          </TableHead>
                        )}
                        {columnVisibility['over-head-percent'].overHeadPercent && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('over-head-percent')}}>
                            Over-Head %
                          </TableHead>
                        )}
                        {columnVisibility['over-head-percent'].description && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('over-head-percent')}}>
                            Description
                          </TableHead>
                        )}
                        {columnVisibility['over-head-percent'].status && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('over-head-percent')}}>
                            Status
                          </TableHead>
                        )}
                        {columnVisibility['over-head-percent'].date && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('over-head-percent')}}>
                            Date
                          </TableHead>
                        )}
                        {columnVisibility['over-head-percent'].action && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('over-head-percent')}}>
                            Action
                          </TableHead>
                        )}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {overHeadPercents.map((item) => (
                        <TableRow key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                          {columnVisibility['over-head-percent'].productionUnit && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.productionUnit}
                            </TableCell>
                          )}
                          {columnVisibility['over-head-percent'].itemName && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.itemName}
                            </TableCell>
                          )}
                          {columnVisibility['over-head-percent'].overHeadPercent && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.overHeadPercent}%
                            </TableCell>
                          )}
                          {columnVisibility['over-head-percent'].description && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.description}
                            </TableCell>
                          )}
                          {columnVisibility['over-head-percent'].status && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              <Badge variant={getStatusBadgeVariant(item.is_active)}>
                                {item.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility['over-head-percent'].date && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {formatDate(item.created_at)}
                            </TableCell>
                          )}
                          {columnVisibility['over-head-percent'].action && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm text-center">
                              <div className="flex justify-center items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => {
                                    setActiveTab("over-head-percent");
                                    openEditDialog({
                                      ...item,
                                      productionUnit: item.productionUnit,
                                      itemName: item.itemName,
                                      overHeadPercent: String(item.overHeadPercent)
                                    });
                                  }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-500"
                                  onClick={() => {
                                    setCurrentItem(item as ItemType);
                                    setDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                      {overHeadPercents.length === 0 && (
                        <TableRow>
                          <TableCell 
                            colSpan={Object.values(columnVisibility['over-head-percent']).filter(Boolean).length} 
                            className="text-center py-4 text-sm text-slate-500"
                          >
                            No overhead percentages found. Click "Add New" to get started.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profit Margin Tab */}
          <TabsContent value="profit-margin">
            <Card className="shadow-md rounded-lg border border-gray-200 dark:border-gray-700 w-full max-w-full">
              <CardHeader className="flex flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <CardTitle className="text-xl font-bold">Profit Margin</CardTitle>
                  <CardDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Manage item-wise profit margin percentage for pricing calculations.
                  </CardDescription>
                </div>
                <Button 
                  className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700"
                  onClick={() => {
                    setActiveTab("profit-margin");
                    setDialogMode("add");
                    setFormData({
                      name: '',
                      count: '',
                      description: '',
                      code: '',
                      selectedElasticParts: [], // Add empty array for consistency
                      is_active: true,
                      yarnCategoryId: 0,
                      yarnCategoryName: '',
                      yarnCategories: '',
                      yarnCount: '',
                      priceUsd: '',
                      priceBdt: '',
                      productionUnit: '',
                      itemName: '',
                      overHeadPercent: '',
                      profitMargin: '25'
                    });
                    setFormError(null);
                    setIsDialogOpen(true);
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
              </CardHeader>
              <CardContent className="p-1 sm:p-4">
                {/* Filter the data based on search term */}
                <div className="overflow-x-auto w-full">
                  <Table className="w-full divide-y">
                    <TableHeader>
                      <TableRow className="bg-gray-50 dark:bg-gray-800">
                        {columnVisibility['profit-margin'].productionUnit && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('profit-margin')}}>
                            Production Unit
                          </TableHead>
                        )}
                        {columnVisibility['profit-margin'].itemName && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('profit-margin')}}>
                            Item Name
                          </TableHead>
                        )}
                        {columnVisibility['profit-margin'].profitMargin && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('profit-margin')}}>
                            Profit Margin %
                          </TableHead>
                        )}
                        {columnVisibility['profit-margin'].description && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('profit-margin')}}>
                            Description
                          </TableHead>
                        )}
                        {columnVisibility['profit-margin'].status && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('profit-margin')}}>
                            Status
                          </TableHead>
                        )}
                        {columnVisibility['profit-margin'].date && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('profit-margin')}}>
                            Date
                          </TableHead>
                        )}
                        {columnVisibility['profit-margin'].action && (
                          <TableHead className="py-2 px-2 text-center text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-200" style={{width: getColumnWidth('profit-margin')}}>
                            Action
                          </TableHead>
                        )}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {profitMargins.map((item) => (
                        <TableRow key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                          {columnVisibility['profit-margin'].productionUnit && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.production_unit || item.productionUnit}
                            </TableCell>
                          )}
                          {columnVisibility['profit-margin'].itemName && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.item_name || item.itemName}
                            </TableCell>
                          )}
                          {columnVisibility['profit-margin'].profitMargin && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.profit_margin || item.profitMargin}%
                            </TableCell>
                          )}
                          {columnVisibility['profit-margin'].description && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {item.description}
                            </TableCell>
                          )}
                          {columnVisibility['profit-margin'].status && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              <Badge variant={getStatusBadgeVariant(item.is_active)}>
                                {item.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility['profit-margin'].date && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm truncate whitespace-nowrap text-center">
                              {formatDate(item.created_at)}
                            </TableCell>
                          )}
                          {columnVisibility['profit-margin'].action && (
                            <TableCell className="py-1 px-2 text-xs sm:text-sm text-center">
                              <div className="flex justify-center items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => {
                                    setActiveTab("profit-margin");
                                    openEditDialog({
                                      ...item,
                                      productionUnit: item.production_unit || item.productionUnit,
                                      itemName: item.item_name || item.itemName,
                                      profitMargin: String(item.profit_margin || item.profitMargin)
                                    });
                                  }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-500"
                                  onClick={() => {
                                    setCurrentItem(item as ItemType);
                                    setDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                      {profitMargins.length === 0 && (
                        <TableRow>
                          <TableCell 
                            colSpan={Object.values(columnVisibility['profit-margin']).filter(Boolean).length}
                            className="text-center py-4 text-sm text-slate-500"
                          >
                            No profit margins found. Click "Add New" to get started.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
        </div>
      </div>

      {/* Dialog for adding/editing items */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md rounded-lg overflow-hidden border-0 shadow-lg max-w-[95%]">
          <DialogHeader className="bg-slate-50 dark:bg-gray-900 p-6 rounded-t-lg border-b border-slate-200 dark:border-slate-700">
              <DialogTitle className="text-xl font-bold">
                {activeTab === 'yarn-count' && dialogMode === 'add' ? 'Add New Yarn Count' : 
                 (dialogMode === 'add' ? 'Add New' : 'Edit')}{' '}
                {activeTab === 'elastic-part' && 'Elastic Part'}
                {activeTab === 'production-unit' && 'Production Unit'}
                {activeTab === 'yarn-category' && 'Yarn Category'}
                {activeTab === 'yarn-count' && dialogMode !== 'add' && 'Yarn Count'}
                {activeTab === 'color-type' && 'Color Type'}
                {activeTab === 'dyeing-charge' && 'Dyeing Charge'}
                {activeTab === 'item' && 'Item'}
                {activeTab === 'over-head-percent' && 'Over-Head %'}
                {activeTab === 'profit-margin' && 'Profit Margin'}
              </DialogTitle>
              <DialogDescription className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {activeTab === 'elastic-part' 
                  ? (dialogMode === 'add' 
                      ? 'Add a new elastic part to your collection.' 
                      : 'Edit the existing elastic part details.')
                  : activeTab === 'production-unit'
                    ? (dialogMode === 'add' 
                        ? 'Add a new production unit with capacity information.' 
                        : 'Edit the existing production unit details.')
                    : activeTab === 'item'
                      ? (dialogMode === 'add' 
                          ? 'Add a new item with unit and elastic part information.' 
                          : 'Edit the existing item details.')
                    : activeTab === 'yarn-category'
                      ? (dialogMode === 'add'
                          ? 'Add a new yarn category with code identifier.'
                          : 'Edit the existing yarn category details.')
                      : activeTab === 'yarn-count'
                        ? (dialogMode === 'add'
                            ? 'Add a new yarn count with specifications.'
                            : 'Edit the existing yarn count details.')
                        : activeTab === 'color-type'
                          ? (dialogMode === 'add'
                              ? 'Add a new color type for yarn classification.'
                              : 'Edit the existing color type details.')
                          : activeTab === 'dyeing-charge'
                            ? (dialogMode === 'add'
                                ? 'Add a new dyeing charge for yarn color processing.'
                                : 'Edit the existing dyeing charge details.')
                            : activeTab === 'over-head-percent'
                              ? (dialogMode === 'add'
                                  ? 'Add a new overhead percentage for production calculations.'
                                  : 'Edit the existing overhead percentage details.')
                              : activeTab === 'profit-margin'
                                ? (dialogMode === 'add'
                                    ? 'Add a new profit margin setting for pricing calculations.'
                                    : 'Edit the existing profit margin details.')
                                : (dialogMode === 'add' 
                                    ? 'Add a new item to your collection.' 
                                    : 'Edit the existing item details.')
                }
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-5 sm:gap-6 p-4 sm:p-6">
              {formError && (
                <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-md flex items-start gap-2">
                  <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {activeTab !== 'yarn-count' && activeTab !== 'over-head-percent' && activeTab !== 'profit-margin' && (
                <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                  <Label htmlFor="name" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                    Name
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => {
                      const name = e.target.value;
                      let code = formData.code;
                      
                      // Auto-generate 3-letter code for yarn category when tab is yarn-category
                      if (activeTab === 'yarn-category') {
                        // Extract first letters from each word, up to 3 letters
                        const words = name.split(/\s+/).filter(w => w.length > 0);
                        if (words.length > 0) {
                          if (words.length >= 3) {
                            // If 3+ words, take first letter from each of the first 3 words
                            code = (words[0][0] + words[1][0] + words[2][0]).toUpperCase();
                          } else if (words.length === 2) {
                            // If 2 words, take first letter from first word and first 2 letters from second word
                            code = (words[0][0] + words[1].substring(0, 2)).toUpperCase();
                          } else {
                            // If 1 word, take first 3 letters
                            code = words[0].substring(0, 3).toUpperCase();
                          }
                        }
                      }
                      
                      setFormData({...formData, name: name, code: code});
                    }}
                    className="sm:col-span-3 rounded-md text-base h-12"
                    placeholder="Enter name"
                  />
                </div>
              )}

              {activeTab === 'yarn-count' && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="yarnCategory" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Yarn Category
                    </Label>
                    <Select
                      value={formData.yarnCategoryId === 0 ? '' : formData.yarnCategoryId.toString()}
                      onValueChange={(value) => {
                        const selectedCategory = yarnCategories.find(cat => cat.id.toString() === value);
                        
                        // Generate yarn code based on selected category
                        let yarnCode = '';
                        if (selectedCategory) {
                          // Get the category code prefix
                          const prefix = selectedCategory.code || 'OTH';
                          
                          // Find existing codes with this prefix to generate a sequential number
                          const existingCodes = yarnCounts
                            .filter(item => item.yarnCode && item.yarnCode.startsWith(prefix))
                            .map(item => item.yarnCode);
                          
                          // Generate next sequential number
                          let maxNumber = 0;
                          existingCodes.forEach(code => {
                            const match = code.match(`${prefix}-(\\d+)`);
                            if (match && match[1]) {
                              const num = parseInt(match[1]);
                              if (num > maxNumber) {
                                maxNumber = num;
                              }
                            }
                          });
                          
                          // Format the yarn code as PREFIX-001, PREFIX-002, etc.
                          yarnCode = `${prefix}-${(maxNumber + 1).toString().padStart(3, '0')}`;
                        }
                        
                        setFormData({
                          ...formData, 
                          yarnCategoryId: parseInt(value),
                          yarnCategoryName: selectedCategory ? selectedCategory.name : '',
                          yarnCode: yarnCode // Add the generated yarn code to formData
                        });
                      }}
                    >
                      <SelectTrigger className="sm:col-span-3 rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                        <SelectValue placeholder="Select a yarn category" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                        <SelectGroup>
                          <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Yarn Categories</SelectLabel>
                          <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                            {yarnCategories.length > 0 ? (
                              yarnCategories.map(category => (
                                <SelectItem 
                                  key={category.id} 
                                  value={category.id.toString()}
                                  className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                >
                                  <div className="flex items-center">
                                    <span className="font-medium">{category.name}</span>
                                    <span className="ml-2 text-xs opacity-70">({category.code})</span>
                                  </div>
                                </SelectItem>
                              ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500 italic">No categories available</div>
                            )}
                          </div>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {formData.yarnCategoryName === 'Other' && (
                    <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                      <Label htmlFor="otherSpecification" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                        Specify Other
                      </Label>
                      <Input
                        id="otherSpecification"
                        value={formData.description || ''}
                        onChange={(e) => setFormData({...formData, description: e.target.value})}
                        className="sm:col-span-3 rounded-md text-base h-12"
                        placeholder="Specify the material type"
                      />
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="yarnCode" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Yarn Code
                    </Label>
                    {dialogMode === 'edit' ? (
                      <Input
                        id="yarnCode"
                        value={(currentItem as YarnCount)?.yarnCode || ''}
                        readOnly
                        disabled
                        className="sm:col-span-3 rounded-md text-base h-12 bg-gray-100"
                      />
                    ) : (
                      <div className="sm:col-span-3 flex items-center h-12 px-3 rounded-md bg-gray-50 border border-gray-200 text-gray-500">
                        <span>Auto-generated based on category</span>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="count" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Yarn Count
                    </Label>
                    <Input
                      id="count"
                      value={formData.count}
                      onChange={(e) => setFormData({...formData, count: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter count (e.g. 20s, 30s)"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="priceBdt" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Price (BDT)
                    </Label>
                    <Input
                      id="priceBdt"
                      type="number"
                      step="0.01"
                      value={formData.priceBdt}
                      onChange={(e) => {
                        const bdtValue = e.target.value;
                        // Auto-calculate USD price from BDT input
                        let usdValue = '';
                        if (bdtValue && !isNaN(parseFloat(bdtValue))) {
                          usdValue = convertBdtToUsd(parseFloat(bdtValue)).toFixed(2);
                        }
                        setFormData({
                          ...formData, 
                          priceBdt: bdtValue,
                          priceUsd: usdValue
                        });
                      }}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter price in BDT per KG"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="priceUsd" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Price (USD)
                    </Label>
                    <Input
                      id="priceUsd"
                      type="number"
                      step="0.01"
                      value={formData.priceUsd}
                      onChange={(e) => {
                        const usdValue = e.target.value;
                        // Auto-calculate BDT price from USD input
                        let bdtValue = '';
                        if (usdValue && !isNaN(parseFloat(usdValue))) {
                          bdtValue = convertUsdToBdt(parseFloat(usdValue)).toFixed(2);
                        }
                        setFormData({
                          ...formData, 
                          priceUsd: usdValue,
                          priceBdt: bdtValue
                        });
                      }}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter price in USD per KG"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="description" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Description
                    </Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter description"
                    />
                  </div>
                </>
              )}

              {activeTab === 'production-unit' && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="count" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Capacity
                    </Label>
                    <Input
                      id="count"
                      type="number"
                      value={formData.count}
                      onChange={(e) => setFormData({...formData, count: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Units per day"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="description" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Description
                    </Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter description"
                    />
                  </div>
                </>
              )}

              {activeTab === 'item' && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="count" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Unit
                    </Label>
                    <div className="sm:col-span-3">
                      <Select
                        value={formData.count}
                        onValueChange={(value) => setFormData({...formData, count: value})}
                      >
                        <SelectTrigger className="rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                          <SelectValue placeholder="Select production unit" />
                        </SelectTrigger>
                        <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                          <SelectGroup>
                            <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Production Units</SelectLabel>
                            <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                              {productionUnits.length > 0 ? (
                                productionUnits.map((unit) => (
                                  <SelectItem 
                                    key={unit.id} 
                                    value={unit.name}
                                    className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                  >
                                    <div className="flex items-center">
                                      <span className="font-medium">{unit.name}</span>
                                      {unit.capacity && (
                                        <span className="ml-2 text-xs opacity-70">({unit.capacity} YDS/day)</span>
                                      )}
                                    </div>
                                  </SelectItem>
                                ))
                              ) : (
                                <div className="px-3 py-2 text-sm text-gray-500 italic">No production units available</div>
                              )}
                            </div>
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="code" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Elastic Parts
                    </Label>
                    <div className="sm:col-span-3">
                      <div className="space-y-2">
                        {fabricParts.map((part) => (
                          <div key={part.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`elastic-part-${part.id}`}
                              checked={formData.selectedElasticParts?.includes(part.name)}
                              onCheckedChange={(checked) => {
                                const currentParts = formData.selectedElasticParts || [];
                                const newParts = checked
                                  ? [...currentParts, part.name]
                                  : currentParts.filter(p => p !== part.name);
                                setFormData({...formData, selectedElasticParts: newParts});
                              }}
                            />
                            <label
                              htmlFor={`elastic-part-${part.id}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {part.name}
                            </label>
                          </div>
                        ))}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Select one or more elastic parts for this item
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="description" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Description
                    </Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter description"
                    />
                  </div>
                </>
              )}

              {activeTab === 'yarn-category' && (
                <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                  <Label htmlFor="code" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                    Category Code
                  </Label>
                  <div className="sm:col-span-3">
                    <Input
                      id="code"
                      value={formData.code}
                      onChange={(e) => setFormData({...formData, code: e.target.value.toUpperCase()})}
                      className="rounded-md text-base h-12 w-full"
                      placeholder="Auto-generated from name"
                      maxLength={3}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Auto-generated 3-letter code from name. You can edit if needed.
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'color-type' && (
                <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                  <Label htmlFor="description" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                    Description
                  </Label>
                  <Input
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="sm:col-span-3 rounded-md text-base h-12"
                    placeholder="Enter color description"
                  />
                </div>
              )}

              {activeTab === 'dyeing-charge' && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="colorName" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Color Name
                    </Label>
                    <Input
                      id="colorName"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter color name"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="yarnCategories" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Yarn Categories
                    </Label>
                    <Select
                      value={formData.yarnCategories}
                      onValueChange={(value) => {
                        setFormData({...formData, yarnCategories: value});
                      }}
                    >
                      <SelectTrigger className="sm:col-span-3 rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                        <SelectValue placeholder="Select a yarn category" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                        <SelectGroup>
                          <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Yarn Categories</SelectLabel>
                          <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                            {yarnCategories.length > 0 ? (
                              yarnCategories.map(category => (
                                <SelectItem 
                                  key={category.id} 
                                  value={category.name}
                                  className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                >
                                  <div className="flex items-center justify-between w-full">
                                    <span className="font-medium">{category.name}</span>
                                    <span className="ml-2 text-xs px-2 py-0.5 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded">{category.code}</span>
                                  </div>
                                </SelectItem>
                              ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500 italic">No categories available</div>
                            )}
                          </div>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="yarnCount" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Yarn Count
                    </Label>
                    <Select
                      value={formData.yarnCount}
                      onValueChange={(value) => {
                        setFormData({...formData, yarnCount: value});
                      }}
                    >
                      <SelectTrigger className="sm:col-span-3 rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                        <SelectValue placeholder="Select a yarn count" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                        <SelectGroup>
                          <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Yarn Counts</SelectLabel>
                          <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                            {yarnCounts.length > 0 ? (
                              yarnCounts.map(count => (
                                <SelectItem 
                                  key={count.id} 
                                  value={count.count}
                                  className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                >
                                  <div className="flex items-center">
                                    <span className="font-medium">{count.count}</span>
                                    {count.YarnCategoriesName && (
                                      <span className="ml-2 text-xs px-2 py-0.5 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-full">{count.YarnCategoriesName}</span>
                                    )}
                                  </div>
                                </SelectItem>
                              ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500 italic">No yarn counts available</div>
                            )}
                          </div>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="priceUsd" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Price (USD)
                    </Label>
                    <Input
                      id="priceUsd"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.priceUsd}
                      onChange={(e) => {
                        const usdValue = e.target.value;
                        // Auto-calculate BDT price from USD input
                        let bdtValue = '';
                        if (usdValue && !isNaN(parseFloat(usdValue))) {
                          bdtValue = convertUsdToBdt(parseFloat(usdValue)).toFixed(2);
                        }
                        setFormData({
                          ...formData, 
                          priceUsd: usdValue,
                          priceBdt: bdtValue
                        });
                      }}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter price in USD"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="priceBdt" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Price (BDT)
                    </Label>
                    <Input
                      id="priceBdt"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.priceBdt}
                      onChange={(e) => {
                        const bdtValue = e.target.value;
                        // Auto-calculate USD price from BDT input
                        let usdValue = '';
                        if (bdtValue && !isNaN(parseFloat(bdtValue))) {
                          usdValue = convertBdtToUsd(parseFloat(bdtValue)).toFixed(2);
                        }
                        setFormData({
                          ...formData, 
                          priceBdt: bdtValue,
                          priceUsd: usdValue
                        });
                      }}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter price in BDT"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="description" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Description
                    </Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter description"
                    />
                  </div>
                </>
              )}

              {activeTab === 'over-head-percent' && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="productionUnit" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Production Unit
                    </Label>
                    <Select
                      value={formData.productionUnit}
                      onValueChange={(value) => {
                        setFormData({...formData, productionUnit: value});
                      }}
                    >
                      <SelectTrigger className="sm:col-span-3 rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                        <SelectValue placeholder="Select production unit" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                        <SelectGroup>
                          <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Production Units</SelectLabel>
                          <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                            {Array.isArray(items) && items.length > 0 ? (
                              // Get unique unit values from items
                              [...new Set(items.map(item => item.unit))].map((unit, index) => (
                                <SelectItem 
                                  key={index} 
                                  value={unit}
                                  className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                >
                                  <div className="flex items-center">
                                    <span className="font-medium">{unit}</span>
                                  </div>
                                </SelectItem>
                              ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500 italic">No production units found</div>
                            )}
                          </div>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="itemName" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Item Name
                    </Label>
                    <Select
                      value={formData.itemName}
                      onValueChange={(value) => {
                        setFormData({...formData, itemName: value});
                      }}
                    >
                      <SelectTrigger className="sm:col-span-3 rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                        <SelectValue placeholder="Select item" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                        <SelectGroup>
                          <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Items</SelectLabel>
                          <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                            {Array.isArray(items) && items.length > 0 ? (
                              // Filter items by the selected production unit (unit)
                              items
                                .filter(item => !formData.productionUnit || item.unit === formData.productionUnit)
                                .map(item => (
                                  <SelectItem 
                                    key={item.id} 
                                    value={item.name}
                                    className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                  >
                                    <div className="flex items-center justify-between w-full">
                                      <span className="font-medium">{item.name}</span>
                                      <span className="ml-2 text-xs text-gray-500">{item.elasticPart ? `(${item.elasticPart})` : ''}</span>
                                    </div>
                                  </SelectItem>
                                ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500 italic">No items found</div>
                            )}
                          </div>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="overHeadPercent" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Over-Head %
                    </Label>
                    <Input
                      id="overHeadPercent"
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={formData.overHeadPercent}
                      onChange={(e) => setFormData({...formData, overHeadPercent: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter overhead percentage"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="description" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Description
                    </Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter description"
                    />
                  </div>
                </>
              )}

              {activeTab === 'profit-margin' && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="productionUnit" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Production Unit
                    </Label>
                    <Select
                      value={formData.productionUnit}
                      onValueChange={(value) => setFormData({ ...formData, productionUnit: value })}
                    >
                      <SelectTrigger className="sm:col-span-3 rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                        <SelectValue placeholder="Select production unit" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                        <SelectGroup>
                          <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Production Units</SelectLabel>
                          <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                            {Array.isArray(items) && items.length > 0 ? (
                              // Get unique unit values from items
                              [...new Set(items.map(item => item.unit))].map((unit, index) => (
                                <SelectItem 
                                  key={index} 
                                  value={unit}
                                  className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                >
                                  <div className="flex items-center">
                                    <span className="font-medium">{unit}</span>
                                  </div>
                                </SelectItem>
                              ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500 italic">No production units found</div>
                            )}
                          </div>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="itemName" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Item Name
                    </Label>
                    <Select
                      value={formData.itemName}
                      onValueChange={(value) => setFormData({ ...formData, itemName: value })}
                    >
                      <SelectTrigger className="sm:col-span-3 rounded-md text-base h-12 bg-white dark:bg-gray-800 border-blue-200 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition-all">
                        <SelectValue placeholder="Select item name" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px] overflow-y-auto border-blue-100 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-md shadow-md">
                        <SelectGroup>
                          <SelectLabel className="text-sm font-semibold text-blue-600 dark:text-blue-400 px-3 py-2">Items</SelectLabel>
                          <div className="max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-transparent">
                            {Array.isArray(items) && items.length > 0 ? (
                              // Filter items by the selected production unit (unit)
                              items
                                .filter(item => !formData.productionUnit || item.unit === formData.productionUnit)
                                .map(item => (
                                  <SelectItem 
                                    key={item.id} 
                                    value={item.name}
                                    className="transition-colors hover:bg-blue-50 dark:hover:bg-gray-700 py-2.5 pl-3 pr-2 text-sm cursor-pointer"
                                  >
                                    <div className="flex items-center justify-between w-full">
                                      <span className="font-medium">{item.name}</span>
                                      <span className="ml-2 text-xs text-gray-500">{item.elasticPart ? `(${item.elasticPart})` : ''}</span>
                                    </div>
                                  </SelectItem>
                                ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500 italic">No items found</div>
                            )}
                          </div>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="profitMargin" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Profit Margin %
                    </Label>
                    <Input
                      id="profitMargin"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.profitMargin}
                      onChange={(e) => setFormData({ ...formData, profitMargin: e.target.value })}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter profit margin percentage"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                    <Label htmlFor="description" className="text-base font-medium sm:text-right mb-1 sm:mb-0">
                      Description
                    </Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="sm:col-span-3 rounded-md text-base h-12"
                      placeholder="Enter description"
                    />
                  </div>
                </>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-4">
                <Label className="text-base font-medium sm:text-right mb-1 sm:mb-0">Status</Label>
                <div className="flex items-center space-x-4 sm:col-span-3">
                  <Checkbox
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, is_active: checked as boolean })
                    }
                    className="h-6 w-6"
                  />
                  <label
                    htmlFor="is_active"
                    className="text-base font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Active
                  </label>
                </div>
              </div>
            </div>

            <DialogFooter className="flex flex-col sm:flex-row gap-3 sm:gap-4 bg-gray-50 dark:bg-gray-800 p-4 sm:p-6 rounded-b-lg">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="sm:order-1 order-2 rounded-md h-12 text-base font-medium w-full sm:w-auto">
                Cancel
              </Button>
              <Button onClick={handleSave} className="sm:order-2 order-1 rounded-md h-12 text-base font-medium w-full sm:w-auto">Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete confirmation dialog */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure you want to delete this {getTabTitle(activeTab).toLowerCase()}?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete this record from the system.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Import Data Dialog */}
        <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Import {getActiveTabName(activeTab)} Data</DialogTitle>
              <DialogDescription>
                Upload a CSV or Excel file to import data for {getActiveTabName(activeTab)}.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="flex flex-col gap-2">
                <Label htmlFor="importFile">Choose file to import</Label>
                <Input 
                  id="importFile" 
                  type="file" 
                  accept=".csv,.xlsx,.xls" 
                  onChange={(e) => e.target.files && setImportFile(e.target.files[0])}
                />
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Supported formats: CSV, Excel (.xlsx, .xls)
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsImportDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleImportData} disabled={!importFile}>
                Import
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Bulk Delete Confirmation Dialog */}
        <AlertDialog open={isBulkDeleteDialogOpen} onOpenChange={setIsBulkDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete All {getActiveTabName(activeTab)} Data?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete ALL {getActiveTabName(activeTab).toLowerCase()} records from the system.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleBulkDelete} className="bg-red-600 hover:bg-red-700">
                Delete All
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
    </AppLayout>
  );
}