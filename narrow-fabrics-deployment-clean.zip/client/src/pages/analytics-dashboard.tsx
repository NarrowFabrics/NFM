import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import AppLayout from "@/components/layout/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { exportToCSV, exportToExcel, exportToPDF } from "@/lib/export-utils";
import { Separator } from "@/components/ui/separator";

// Types for dashboard stats
interface DashboardStats {
  totalOrders: number;
  totalProductionPlans: number;
  totalMaterials: number;
  totalRevenue: number;
}

// Types for chart data
interface SalesData {
  month: string;
  orders: number;
  revenue: number;
}

interface MaterialData {
  category: string;
  count: number;
  value: number;
}

interface ProductionData {
  week: string;
  planned: number;
  completed: number;
}

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D"];

export default function AnalyticsDashboard() {
  const [timeRange, setTimeRange] = useState<"daily" | "weekly" | "monthly" | "yearly">("monthly");
  
  // Fetch dashboard stats from API
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    queryFn: () => apiRequest<DashboardStats>('/api/dashboard/stats'),
  });
  
  // Fetch sales data from API
  const { data: salesData, isLoading: salesLoading } = useQuery({
    queryKey: ['/api/dashboard/sales', timeRange],
    queryFn: () => apiRequest<SalesData[]>(`/api/dashboard/sales?timeRange=${timeRange}`),
  });
  
  // Fetch material data from API
  const { data: materialData, isLoading: materialLoading } = useQuery({
    queryKey: ['/api/dashboard/materials'],
    queryFn: () => apiRequest<MaterialData[]>('/api/dashboard/materials'),
  });
  
  // Fetch production data from API
  const { data: productionData, isLoading: productionLoading } = useQuery({
    queryKey: ['/api/dashboard/production', timeRange],
    queryFn: () => apiRequest<ProductionData[]>(`/api/dashboard/production?timeRange=${timeRange}`),
  });
  
  // Default/sample data to use while API is loading
  // This will be replaced with actual data from the API
  const defaultSalesData: SalesData[] = [
    { month: "Jan", orders: 0, revenue: 0 },
    { month: "Feb", orders: 0, revenue: 0 },
    { month: "Mar", orders: 0, revenue: 0 },
    { month: "Apr", orders: 0, revenue: 0 },
    { month: "May", orders: 0, revenue: 0 },
    { month: "Jun", orders: 0, revenue: 0 },
  ];
  
  const defaultMaterialData: MaterialData[] = [
    { category: "Yarn", count: 0, value: 0 },
    { category: "Fabric", count: 0, value: 0 },
    { category: "Elastic", count: 0, value: 0 },
    { category: "Other", count: 0, value: 0 },
  ];
  
  const defaultProductionData: ProductionData[] = [
    { week: "W1", planned: 0, completed: 0 },
    { week: "W2", planned: 0, completed: 0 },
    { week: "W3", planned: 0, completed: 0 },
    { week: "W4", planned: 0, completed: 0 },
  ];
  
  // Functions to handle data exports
  const handleExportSalesCSV = () => {
    if (salesData) {
      exportToCSV(salesData, `sales-data-${timeRange}`);
    }
  };
  
  const handleExportSalesExcel = () => {
    if (salesData) {
      exportToExcel(salesData, `sales-data-${timeRange}`);
    }
  };
  
  const handleExportSalesPDF = () => {
    if (salesData) {
      exportToPDF(
        salesData,
        `Sales Data (${timeRange})`,
        `sales-data-${timeRange}`,
        ['Month', 'Orders', 'Revenue'],
        (item) => [item.month, item.orders.toString(), `$${item.revenue.toFixed(2)}`]
      );
    }
  };
  
  return (
    <AppLayout title="Analytics Dashboard" description="Visualize your business data">
      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Get insights from your business data</p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                className="h-4 w-4 text-muted-foreground"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="m22 21-3-3m0 0-3 3m3-3v-6" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {statsLoading ? "..." : stats?.totalOrders || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                +12.5% from last month
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Production Plans</CardTitle>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                className="h-4 w-4 text-muted-foreground"
              >
                <rect width="20" height="14" x="2" y="5" rx="2" />
                <path d="M2 10h20" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {statsLoading ? "..." : stats?.totalProductionPlans || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                +7.2% from last month
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Materials</CardTitle>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                className="h-4 w-4 text-muted-foreground"
              >
                <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {statsLoading ? "..." : stats?.totalMaterials || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                +3.1% from last month
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                className="h-4 w-4 text-muted-foreground"
              >
                <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${statsLoading ? "..." : (stats?.totalRevenue || 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                +14.2% from last month
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Time Range Selector */}
        <div className="flex items-center mb-6">
          <div className="mr-4">
            <span className="text-sm font-medium">Time Range:</span>
          </div>
          <div className="flex space-x-2">
            <Button 
              variant={timeRange === "daily" ? "default" : "outline"} 
              size="sm" 
              onClick={() => setTimeRange("daily")}
            >
              Daily
            </Button>
            <Button 
              variant={timeRange === "weekly" ? "default" : "outline"} 
              size="sm" 
              onClick={() => setTimeRange("weekly")}
            >
              Weekly
            </Button>
            <Button 
              variant={timeRange === "monthly" ? "default" : "outline"} 
              size="sm" 
              onClick={() => setTimeRange("monthly")}
            >
              Monthly
            </Button>
            <Button 
              variant={timeRange === "yearly" ? "default" : "outline"} 
              size="sm" 
              onClick={() => setTimeRange("yearly")}
            >
              Yearly
            </Button>
          </div>
        </div>

        {/* Charts Tabs */}
        <Tabs defaultValue="sales" className="space-y-4">
          <TabsList>
            <TabsTrigger value="sales">Sales & Revenue</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="production">Production</TabsTrigger>
          </TabsList>
          
          {/* Sales & Revenue Tab */}
          <TabsContent value="sales" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Sales & Revenue</CardTitle>
                  <CardDescription>View your order and revenue data over time</CardDescription>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={handleExportSalesCSV}>
                    <Download className="mr-2 h-4 w-4" />
                    CSV
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExportSalesExcel}>
                    <Download className="mr-2 h-4 w-4" />
                    Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExportSalesPDF}>
                    <Download className="mr-2 h-4 w-4" />
                    PDF
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pl-2">
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={salesLoading ? defaultSalesData : salesData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="orders" name="Orders" fill="#8884d8" />
                      <Bar yAxisId="right" dataKey="revenue" name="Revenue ($)" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Materials Tab */}
          <TabsContent value="materials" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Material Distribution</CardTitle>
                <CardDescription>Inventory overview by category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={materialLoading ? defaultMaterialData : materialData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="count"
                        >
                          {(materialLoading ? defaultMaterialData : materialData)?.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} items`, 'Count']} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={materialLoading ? defaultMaterialData : materialData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {(materialLoading ? defaultMaterialData : materialData)?.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`$${value.toFixed(2)}`, 'Value']} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Production Tab */}
          <TabsContent value="production" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Production Performance</CardTitle>
                <CardDescription>Compare planned vs. completed production</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={productionLoading ? defaultProductionData : productionData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="week" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="planned" stroke="#8884d8" name="Planned Units" />
                      <Line type="monotone" dataKey="completed" stroke="#82ca9d" name="Completed Units" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}