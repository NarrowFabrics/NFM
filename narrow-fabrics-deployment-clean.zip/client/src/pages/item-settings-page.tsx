import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Edit, 
  Trash, 
  RefreshCw,
  Loader2,
  Sliders
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ItemSetting, insertItemSettingSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form schema
const formSchema = insertItemSettingSchema.extend({
  overhead_percentage: z.coerce.number().min(0, "Percentage must be at least 0").max(100, "Percentage cannot exceed 100"),
  consumption_percentage: z.coerce.number().min(0, "Percentage must be at least 0").max(100, "Percentage cannot exceed 100"),
});

type FormValues = z.infer<typeof formSchema>;

export default function ItemSettingsPage() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [activeFilter, setActiveFilter] = useState<boolean | null>(null);
  const [search, setSearch] = useState("");
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [editingItemSetting, setEditingItemSetting] = useState<ItemSetting | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [itemSettingToDelete, setItemSettingToDelete] = useState<number | null>(null);

  // Fetch item settings
  const {
    data: itemSettingsData,
    isLoading,
    refetch,
  } = useQuery<{ itemSettings: ItemSetting[]; total: number }>({
    queryKey: ["/api/item-settings", page, perPage, activeFilter],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, activeFilter] = queryKey;
      let url = `/api/item-settings?page=${page}&limit=${perPage}`;
      if (activeFilter !== null) url += `&activeOnly=${activeFilter}`;
      
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch item settings');
      }
      return res.json();
    },
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      item_name: "",
      overhead_percentage: 0,
      consumption_percentage: 0,
      is_active: true,
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest("POST", "/api/item-settings", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Item setting created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/item-settings"] });
      setIsFormDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: FormValues }) => {
      const res = await apiRequest("PUT", `/api/item-settings/${id}`, values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Item setting updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/item-settings"] });
      setIsFormDialogOpen(false);
      setEditingItemSetting(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/item-settings/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Item setting deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/item-settings"] });
      setIsDeleteDialogOpen(false);
      setItemSettingToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle create button click
  const handleCreate = () => {
    form.reset({
      item_name: "",
      overhead_percentage: 0,
      consumption_percentage: 0,
      is_active: true,
    });
    setEditingItemSetting(null);
    setIsFormDialogOpen(true);
  };

  // Handle edit button click
  const handleEdit = (itemSetting: ItemSetting) => {
    form.reset({
      item_name: itemSetting.item_name,
      overhead_percentage: Number(itemSetting.overhead_percentage),
      consumption_percentage: Number(itemSetting.consumption_percentage),
      is_active: itemSetting.is_active,
    });
    setEditingItemSetting(itemSetting);
    setIsFormDialogOpen(true);
  };

  // Handle delete button click
  const handleDeleteClick = (id: number) => {
    setItemSettingToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    if (itemSettingToDelete !== null) {
      deleteMutation.mutate(itemSettingToDelete);
    }
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    if (editingItemSetting) {
      updateMutation.mutate({ id: editingItemSetting.id, values });
    } else {
      createMutation.mutate(values);
    }
  };

  // Format percentage
  const formatPercentage = (value: number | string) => {
    return `${Number(value).toFixed(2)}%`;
  };

  // Table columns definition
  const columns = [
    {
      header: "ID",
      accessorKey: "id" as keyof ItemSetting,
    },
    {
      header: "Item Name",
      accessorKey: "item_name" as keyof ItemSetting,
      cell: ({ row }: { row: ItemSetting }) => (
        <div className="flex items-center space-x-2">
          <Sliders className="h-4 w-4 text-primary" />
          <span>{row.item_name}</span>
        </div>
      ),
    },
    {
      header: "Overhead %",
      accessorKey: "overhead_percentage" as keyof ItemSetting,
      cell: ({ row }: { row: ItemSetting }) => formatPercentage(row.overhead_percentage),
    },
    {
      header: "Consumption %",
      accessorKey: "consumption_percentage" as keyof ItemSetting,
      cell: ({ row }: { row: ItemSetting }) => formatPercentage(row.consumption_percentage),
    },
    {
      header: "Status",
      accessorKey: "is_active" as keyof ItemSetting,
      cell: ({ row }: { row: ItemSetting }) => (
        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
          row.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {row.is_active ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      header: "Actions",
      accessorKey: "id" as keyof ItemSetting,
      cell: ({ row }: { row: ItemSetting }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => handleEdit(row)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteClick(row.id)}>
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <AppLayout
      title="Item Settings"
      description="Manage overhead and consumption settings for items"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> New Item Setting
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant={activeFilter === null ? "default" : "outline"} 
              onClick={() => setActiveFilter(null)}
              className="h-10"
            >
              All
            </Button>
            <Button 
              variant={activeFilter === true ? "default" : "outline"} 
              onClick={() => setActiveFilter(true)}
              className="h-10"
            >
              Active Only
            </Button>
            <Button 
              variant={activeFilter === false ? "default" : "outline"} 
              onClick={() => setActiveFilter(false)}
              className="h-10"
            >
              Inactive Only
            </Button>
          </div>
        </div>
      </div>

      <DataTable
        data={itemSettingsData?.itemSettings || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          itemSettingsData
            ? {
                currentPage: page,
                totalPages: Math.ceil(itemSettingsData.total / perPage),
                totalItems: itemSettingsData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />

      {/* Create/Edit Form Dialog */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {editingItemSetting ? "Edit Item Setting" : "Create Item Setting"}
            </DialogTitle>
            <DialogDescription>
              {editingItemSetting
                ? "Update the item setting details below."
                : "Fill in the details to create a new item setting."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="item_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Item Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter item name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="overhead_percentage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Overhead Percentage</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormDescription>
                      The percentage of overhead applied to this item's cost.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="consumption_percentage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Consumption Percentage</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormDescription>
                      The percentage of material consumption for this item.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="is_active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Inactive item settings won't be available for selection.
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {(createMutation.isPending || updateMutation.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {editingItemSetting ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    editingItemSetting ? "Update Setting" : "Create Setting"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the item setting. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
