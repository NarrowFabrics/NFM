import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AreaChart, LineChart, BarChart, Tooltip, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Area, Line, Legend, Bar } from "recharts";
import { Cpu, HardDrive, Users, Clock, Database, Activity, RefreshCw, AlertCircle, MemoryStick as Memory } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import AppLayout from "@/components/layout/app-layout";

// Helper function to format bytes into human-readable format (KB, MB, GB)
const formatBytes = (bytes: number, decimals = 2) => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

// Type for system metrics summary data
type SystemMetricsSummary = {
  cpu: { current: number, average: number, peak: number },
  memory: { current: number, average: number, peak: number },
  disk: { current: number, available: number, total: number },
  performance: { responseTime: number, dbConnections: number, apiRequests: number, errors: number },
  users: { active: number }
};

// Type for detailed system metrics data
type SystemMetric = {
  id: number,
  timestamp: string,
  cpu_usage: number,
  memory_usage: number,
  memory_total: number,
  disk_usage: number,
  disk_total: number,
  active_users: number,
  response_time: number,
  db_connections: number,
  db_queries_per_second: number,
  api_requests_per_minute: number,
  error_count: number,
  metadata: Record<string, any>
};

// Component for displaying real-time system metrics
const PerformanceDashboard = () => {
  const [timeRange, setTimeRange] = useState<'hour' | 'day' | 'week' | 'month'>('hour');
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch system metrics summary
  const { 
    data: summary, 
    isLoading: isLoadingSummary, 
    refetch: refetchSummary 
  } = useQuery<SystemMetricsSummary>({
    queryKey: ['/api/system/metrics/summary'],
    queryFn: () => apiRequest('/api/system/metrics/summary'),
    refetchInterval: 60000, // Refetch every minute
  });

  // Fetch detailed system metrics
  const { 
    data: metrics, 
    isLoading: isLoadingMetrics, 
    refetch: refetchMetrics 
  } = useQuery<SystemMetric[]>({
    queryKey: ['/api/system/metrics', timeRange],
    queryFn: () => apiRequest(`/api/system/metrics?timeRange=${timeRange}`),
    refetchInterval: 60000, // Refetch every minute
  });

  // Format metrics data for charts by converting timestamp to readable format
  const formattedMetrics = metrics?.map(metric => ({
    ...metric,
    time: new Date(metric.timestamp).toLocaleTimeString(),
    date: new Date(metric.timestamp).toLocaleDateString(),
    formattedTimestamp: new Date(metric.timestamp).toLocaleString(),
  })) || [];

  // Handle refresh button click
  const handleRefresh = () => {
    refetchSummary();
    refetchMetrics();
  };

  return (
    <AppLayout title="Performance Dashboard" description="Real-time system metrics and performance monitoring">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h1 className="text-2xl font-bold">System Performance Dashboard</h1>
          <p className="text-muted-foreground">Monitor system resources and performance metrics in real-time</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={(value: any) => setTimeRange(value)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hour">Last Hour</SelectItem>
              <SelectItem value="day">Last 24 Hours</SelectItem>
              <SelectItem value="week">Last Week</SelectItem>
              <SelectItem value="month">Last Month</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleRefresh} variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="cpu">CPU</TabsTrigger>
          <TabsTrigger value="memory">Memory</TabsTrigger>
          <TabsTrigger value="disk">Disk</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* CPU Card */}
            <Card className="border-l-4 border-blue-500">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Cpu className="h-4 w-4" /> CPU
                  </CardTitle>
                  <span className={`text-lg font-bold ${summary?.cpu.current > 80 ? 'text-red-500' : summary?.cpu.current > 60 ? 'text-amber-500' : 'text-green-500'}`}>
                    {isLoadingSummary ? <Skeleton className="h-6 w-16" /> : `${summary?.cpu.current.toFixed(1)}%`}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Average</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : `${summary?.cpu.average.toFixed(1)}%`}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Peak</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : `${summary?.cpu.peak.toFixed(1)}%`}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Memory Card */}
            <Card className="border-l-4 border-purple-500">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Memory className="h-4 w-4" /> Memory
                  </CardTitle>
                  <span className={`text-lg font-bold ${summary?.memory.current > 80 ? 'text-red-500' : summary?.memory.current > 60 ? 'text-amber-500' : 'text-green-500'}`}>
                    {isLoadingSummary ? <Skeleton className="h-6 w-16" /> : `${summary?.memory.current.toFixed(1)}%`}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Average</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : `${summary?.memory.average.toFixed(1)}%`}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Peak</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : `${summary?.memory.peak.toFixed(1)}%`}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disk Card */}
            <Card className="border-l-4 border-green-500">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <HardDrive className="h-4 w-4" /> Disk
                  </CardTitle>
                  <span className={`text-lg font-bold ${summary?.disk.current > 80 ? 'text-red-500' : summary?.disk.current > 60 ? 'text-amber-500' : 'text-green-500'}`}>
                    {isLoadingSummary ? <Skeleton className="h-6 w-16" /> : `${summary?.disk.current.toFixed(1)}%`}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Available</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : `${summary?.disk.available.toFixed(1)}%`}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Total</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : `${summary?.disk.total.toFixed(1)} GB`}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Active Users Card */}
            <Card className="border-l-4 border-amber-500">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Users className="h-4 w-4" /> Active Users
                  </CardTitle>
                  <span className="text-lg font-bold">
                    {isLoadingSummary ? <Skeleton className="h-6 w-10" /> : summary?.users.active}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Response Time</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : `${summary?.performance.responseTime.toFixed(2)} ms`}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">DB Connections</span>
                    <span>{isLoadingSummary ? <Skeleton className="h-4 w-12" /> : summary?.performance.dbConnections}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Performance Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* CPU & Memory Usage Chart */}
            <Card>
              <CardHeader>
                <CardTitle>CPU & Memory Usage</CardTitle>
                <CardDescription>Resource usage over time</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {isLoadingMetrics ? (
                  <div className="h-full w-full flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorMemory" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis 
                        dataKey="time" 
                        tick={{ fontSize: 12 }} 
                        tickFormatter={(value, index) => {
                          // Show fewer ticks for better readability
                          return index % 3 === 0 ? value : '';
                        }}
                      />
                      <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                      <CartesianGrid strokeDasharray="3 3" />
                      <Tooltip 
                        formatter={(value: any) => `${Number(value).toFixed(1)}%`}
                        labelFormatter={(label) => {
                          const metric = formattedMetrics.find(m => m.time === label);
                          return metric ? metric.formattedTimestamp : label;
                        }}
                      />
                      <Legend />
                      <Area type="monotone" dataKey="cpu_usage" name="CPU" stroke="#3b82f6" fillOpacity={1} fill="url(#colorCpu)" />
                      <Area type="monotone" dataKey="memory_usage" name="Memory" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorMemory)" />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Database & API Metrics Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Database & API Performance</CardTitle>
                <CardDescription>Request metrics over time</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {isLoadingMetrics ? (
                  <div className="h-full w-full flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="time" 
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value, index) => {
                          return index % 3 === 0 ? value : '';
                        }}
                      />
                      <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                      <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
                      <Tooltip 
                        formatter={(value: any, name: any) => {
                          if (name === 'DB Queries/s') {
                            return `${Number(value).toFixed(2)}/s`;
                          } else if (name === 'API Requests/min') {
                            return `${value}/min`;
                          } else if (name === 'Response Time') {
                            return `${Number(value).toFixed(2)} ms`;
                          }
                          return value;
                        }}
                        labelFormatter={(label) => {
                          const metric = formattedMetrics.find(m => m.time === label);
                          return metric ? metric.formattedTimestamp : label;
                        }}
                      />
                      <Legend />
                      <Line yAxisId="left" type="monotone" dataKey="db_queries_per_second" name="DB Queries/s" stroke="#10b981" activeDot={{ r: 8 }} />
                      <Line yAxisId="right" type="monotone" dataKey="api_requests_per_minute" name="API Requests/min" stroke="#f59e0b" activeDot={{ r: 8 }} />
                      <Line yAxisId="right" type="monotone" dataKey="response_time" name="Response Time" stroke="#ef4444" activeDot={{ r: 8 }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Error Monitoring Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-red-500" /> Error Monitoring
              </CardTitle>
              <CardDescription>System errors over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[200px]">
              {isLoadingMetrics ? (
                <div className="h-full w-full flex items-center justify-center">
                  <Skeleton className="h-full w-full" />
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value, index) => {
                        return index % 3 === 0 ? value : '';
                      }}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip 
                      formatter={(value: any) => `${value} errors`}
                      labelFormatter={(label) => {
                        const metric = formattedMetrics.find(m => m.time === label);
                        return metric ? metric.formattedTimestamp : label;
                      }}
                    />
                    <Legend />
                    <Bar dataKey="error_count" name="Errors" fill="#ef4444" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* CPU Tab - Detailed CPU metrics */}
        <TabsContent value="cpu" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>CPU Usage</CardTitle>
              <CardDescription>Detailed CPU usage over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              {isLoadingMetrics ? (
                <div className="h-full w-full flex items-center justify-center">
                  <Skeleton className="h-full w-full" />
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorCpuDetailed" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value, index) => {
                        return index % 2 === 0 ? value : '';
                      }}
                    />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip 
                      formatter={(value: any) => `${Number(value).toFixed(1)}%`}
                      labelFormatter={(label) => {
                        const metric = formattedMetrics.find(m => m.time === label);
                        return metric ? metric.formattedTimestamp : label;
                      }}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="cpu_usage" name="CPU Usage" stroke="#3b82f6" fillOpacity={1} fill="url(#colorCpuDetailed)" />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Current Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.cpu.current.toFixed(1)}%`}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      summary?.cpu.current > 80 ? 'bg-red-500' : 
                      summary?.cpu.current > 60 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`} 
                    style={{ width: `${summary?.cpu.current || 0}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.cpu.average.toFixed(1)}%`}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      summary?.cpu.average > 80 ? 'bg-red-500' : 
                      summary?.cpu.average > 60 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`} 
                    style={{ width: `${summary?.cpu.average || 0}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Peak Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.cpu.peak.toFixed(1)}%`}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      summary?.cpu.peak > 80 ? 'bg-red-500' : 
                      summary?.cpu.peak > 60 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`} 
                    style={{ width: `${summary?.cpu.peak || 0}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Memory Tab - Detailed memory metrics */}
        <TabsContent value="memory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Memory Usage</CardTitle>
              <CardDescription>Detailed memory usage over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              {isLoadingMetrics ? (
                <div className="h-full w-full flex items-center justify-center">
                  <Skeleton className="h-full w-full" />
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorMemoryDetailed" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value, index) => {
                        return index % 2 === 0 ? value : '';
                      }}
                    />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip 
                      formatter={(value: any) => `${Number(value).toFixed(1)}%`}
                      labelFormatter={(label) => {
                        const metric = formattedMetrics.find(m => m.time === label);
                        return metric ? metric.formattedTimestamp : label;
                      }}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="memory_usage" name="Memory Usage" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorMemoryDetailed)" />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Current Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.memory.current.toFixed(1)}%`}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      summary?.memory.current > 80 ? 'bg-red-500' : 
                      summary?.memory.current > 60 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`} 
                    style={{ width: `${summary?.memory.current || 0}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.memory.average.toFixed(1)}%`}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      summary?.memory.average > 80 ? 'bg-red-500' : 
                      summary?.memory.average > 60 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`} 
                    style={{ width: `${summary?.memory.average || 0}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Peak Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.memory.peak.toFixed(1)}%`}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      summary?.memory.peak > 80 ? 'bg-red-500' : 
                      summary?.memory.peak > 60 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`} 
                    style={{ width: `${summary?.memory.peak || 0}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Disk Tab - Detailed disk metrics */}
        <TabsContent value="disk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Disk Usage</CardTitle>
              <CardDescription>Detailed disk usage over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              {isLoadingMetrics ? (
                <div className="h-full w-full flex items-center justify-center">
                  <Skeleton className="h-full w-full" />
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorDiskDetailed" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value, index) => {
                        return index % 2 === 0 ? value : '';
                      }}
                    />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip 
                      formatter={(value: any) => `${Number(value).toFixed(1)}%`}
                      labelFormatter={(label) => {
                        const metric = formattedMetrics.find(m => m.time === label);
                        return metric ? metric.formattedTimestamp : label;
                      }}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="disk_usage" name="Disk Usage" stroke="#10b981" fillOpacity={1} fill="url(#colorDiskDetailed)" />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Storage Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.disk.current.toFixed(1)}%`}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                  <div 
                    className={`h-2.5 rounded-full ${
                      summary?.disk.current > 80 ? 'bg-red-500' : 
                      summary?.disk.current > 60 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`} 
                    style={{ width: `${summary?.disk.current || 0}%` }}
                  ></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Used</p>
                    <p className="text-lg font-medium">
                      {isLoadingSummary ? <Skeleton className="h-6 w-16" /> : `${summary?.disk.current.toFixed(1)}%`}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Available</p>
                    <p className="text-lg font-medium">
                      {isLoadingSummary ? <Skeleton className="h-6 w-16" /> : `${summary?.disk.available.toFixed(1)}%`}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Total Storage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-4">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.disk.total.toFixed(1)} GB`}
                </div>
                <Alert>
                  <AlertDescription>
                    Storage capacity monitoring helps ensure your application has sufficient disk space.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Performance Tab - Detailed performance metrics */}
        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Response Time</CardTitle>
                <CardDescription>API response time in milliseconds</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {isLoadingMetrics ? (
                  <div className="h-full w-full flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="time" 
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value, index) => {
                          return index % 2 === 0 ? value : '';
                        }}
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip 
                        formatter={(value: any) => `${Number(value).toFixed(2)} ms`}
                        labelFormatter={(label) => {
                          const metric = formattedMetrics.find(m => m.time === label);
                          return metric ? metric.formattedTimestamp : label;
                        }}
                      />
                      <Legend />
                      <Line type="monotone" dataKey="response_time" name="Response Time" stroke="#ef4444" activeDot={{ r: 8 }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Database Activity</CardTitle>
                <CardDescription>Database connections and queries per second</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {isLoadingMetrics ? (
                  <div className="h-full w-full flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="time" 
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value, index) => {
                          return index % 2 === 0 ? value : '';
                        }}
                      />
                      <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                      <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
                      <Tooltip 
                        formatter={(value: any, name: any) => {
                          if (name === 'DB Queries/s') {
                            return `${Number(value).toFixed(2)}/s`;
                          } else if (name === 'DB Connections') {
                            return value;
                          }
                          return value;
                        }}
                        labelFormatter={(label) => {
                          const metric = formattedMetrics.find(m => m.time === label);
                          return metric ? metric.formattedTimestamp : label;
                        }}
                      />
                      <Legend />
                      <Line yAxisId="left" type="monotone" dataKey="db_connections" name="DB Connections" stroke="#3b82f6" activeDot={{ r: 8 }} />
                      <Line yAxisId="right" type="monotone" dataKey="db_queries_per_second" name="DB Queries/s" stroke="#10b981" activeDot={{ r: 8 }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>API Activity</CardTitle>
              <CardDescription>API requests per minute and error count</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              {isLoadingMetrics ? (
                <div className="h-full w-full flex items-center justify-center">
                  <Skeleton className="h-full w-full" />
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={formattedMetrics} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value, index) => {
                        return index % 2 === 0 ? value : '';
                      }}
                    />
                    <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                    <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
                    <Tooltip 
                      formatter={(value: any, name: any) => {
                        if (name === 'API Requests/min') {
                          return `${value}/min`;
                        } else if (name === 'Errors') {
                          return value;
                        }
                        return value;
                      }}
                      labelFormatter={(label) => {
                        const metric = formattedMetrics.find(m => m.time === label);
                        return metric ? metric.formattedTimestamp : label;
                      }}
                    />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="api_requests_per_minute" name="API Requests/min" stroke="#f59e0b" activeDot={{ r: 8 }} />
                    <Line yAxisId="right" type="monotone" dataKey="error_count" name="Errors" stroke="#ef4444" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-4 w-4" /> Response Time
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : `${summary?.performance.responseTime.toFixed(2)} ms`}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-4 w-4" /> DB Connections
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : summary?.performance.dbConnections}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-4 w-4" /> API Requests/min
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingSummary ? <Skeleton className="h-8 w-20" /> : summary?.performance.apiRequests}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
};

export default PerformanceDashboard;