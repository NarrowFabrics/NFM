
import { AppLayout } from "@/components/layout/app-layout";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { Plus, RefreshCw } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

export default function DyeingChangePage() {
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [activeFilter, setActiveFilter] = useState<boolean | null>(null);

  const {
    data: dyeingChangeData,
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["/api/dyeing-change", page, perPage, activeFilter],
    queryFn: async () => {
      let url = `/api/dyeing-change?page=${page}&limit=${perPage}`;
      if (activeFilter !== null) url += `&activeOnly=${activeFilter}`;
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch dyeing change data');
      return res.json();
    },
  });

  return (
    <AppLayout
      title="Dyeing Change Settings"
      description="Manage dyeing change configurations"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={() => {}}>
            <Plus className="mr-2 h-4 w-4" /> New Dyeing Change
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
      </div>

      <DataTable
        data={dyeingChangeData?.items || []}
        columns={[]}
        isLoading={isLoading}
        pagination={
          dyeingChangeData
            ? {
                currentPage: page,
                totalPages: Math.ceil(dyeingChangeData.total / perPage),
                totalItems: dyeingChangeData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />
    </AppLayout>
  );
}
