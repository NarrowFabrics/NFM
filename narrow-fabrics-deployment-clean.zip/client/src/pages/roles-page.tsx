
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Role, Permission } from "@shared/schema";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, RefreshCw } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function RolesPage() {
  const { user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: roles, isLoading, refetch } = useQuery<Role[]>({
    queryKey: ["/api/roles"],
    enabled: !!user?.is_admin,
  });

  if (!user?.is_admin) {
    return (
      <AppLayout title="Access Denied" description="You do not have permission to view this page.">
        <Card className="p-6">
          <div className="text-center text-muted-foreground">
            This page is only accessible to administrators.
          </div>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Roles Management" description="Manage user roles and permissions">
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-4">
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" /> New Role
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
      </div>

      <Card className="p-6">
        {isLoading ? (
          <div className="text-center">Loading roles...</div>
        ) : (
          <div className="space-y-4">
            {roles?.map(role => (
              <div key={role.id} className="border rounded p-4">
                <h3 className="text-lg font-semibold">{role.name}</h3>
                <p className="text-sm text-muted-foreground">{role.description}</p>
                <div className="mt-2">
                  <h4 className="font-medium">Permissions:</h4>
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    {role.permissions.map(permission => (
                      <div key={permission} className="text-sm">{permission}</div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </AppLayout>
  );
}
