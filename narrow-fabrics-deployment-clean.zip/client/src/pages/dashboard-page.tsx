import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  ShoppingCart, 
  Factory, 
  Package, 
  DollarSign, 
  ArrowUp, 
  ArrowDown, 
  Check, 
  FileText, 
  Box, 
  User,
  Loader2,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  BarChart4,
  Activity
} from "lucide-react";
import { UserActivity, ProductionPlan, Order } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import NoticePanel from "@/components/ui/notice-panel";

type DashboardStats = {
  totalOrders: number;
  totalProductionPlans: number;
  totalMaterials: number;
  totalRevenue: number;
};

export default function DashboardPage() {
  // Fetch dashboard statistics
  const { data: stats, isLoading: isLoadingStats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  // Fetch recent activity
  const { data: activities, isLoading: isLoadingActivities } = useQuery<UserActivity[]>({
    queryKey: ["/api/dashboard/activity"],
  });

  // Fetch recent production plans
  const { data: productionPlans, isLoading: isLoadingPlans } = useQuery<ProductionPlan[]>({
    queryKey: ["/api/dashboard/production-plans"],
  });

  // Fetch recent orders
  const { data: orders, isLoading: isLoadingOrders } = useQuery<Order[]>({
    queryKey: ["/api/dashboard/orders"],
  });
  
  // Helper function to format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };
  
  // Helper function to get status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'bg-blue-100 text-blue-700 border border-blue-200';
      case 'completed':
        return 'bg-green-100 text-green-700 border border-green-200';
      case 'pending':
        return 'bg-amber-100 text-amber-700 border border-amber-200';
      case 'in progress':
        return 'bg-indigo-100 text-indigo-700 border border-indigo-200';
      case 'cancelled':
        return 'bg-red-100 text-red-700 border border-red-200';
      case 'on hold':
        return 'bg-orange-100 text-orange-700 border border-orange-200';
      default:
        return 'bg-gray-100 text-gray-700 border border-gray-200';
    }
  };
  
  // Helper function to get activity icon
  const getActivityIcon = (action: string) => {
    if (action.includes('order')) return <FileText className="text-white" />;
    if (action.includes('production')) return <Factory className="text-white" />;
    if (action.includes('material')) return <Box className="text-white" />;
    if (action.includes('user')) return <User className="text-white" />;
    if (action.includes('create')) return <Check className="text-white" />;
    if (action.includes('update')) return <Activity className="text-white" />;
    if (action.includes('delete')) return <AlertTriangle className="text-white" />;
    return <Check className="text-white" />;
  };
  
  // Helper function to get activity background color
  const getActivityBgColor = (action: string) => {
    if (action.includes('order')) return 'bg-blue-500';
    if (action.includes('production')) return 'bg-green-500';
    if (action.includes('material')) return 'bg-amber-500';
    if (action.includes('user')) return 'bg-purple-500';
    if (action.includes('create')) return 'bg-indigo-500';
    if (action.includes('update')) return 'bg-orange-500';
    if (action.includes('delete')) return 'bg-red-500';
    return 'bg-gray-500';
  };
  
  // Helper function to format date
  const formatDate = (dateString: string | Date | null | undefined) => {
    if (!dateString) return 'N/A';
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date instanceof Date 
      ? date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      : 'N/A';
  };
  
  // Helper function to get time ago
  const getTimeAgo = (dateString: string | Date | null | undefined) => {
    if (!dateString) return 'N/A';
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    if (!(date instanceof Date)) return 'N/A';
    
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    let interval = Math.floor(seconds / 31536000);
    if (interval >= 1) return `${interval}y ago`;
    
    interval = Math.floor(seconds / 2592000);
    if (interval >= 1) return `${interval}m ago`;
    
    interval = Math.floor(seconds / 86400);
    if (interval >= 1) return `${interval}d ago`;
    
    interval = Math.floor(seconds / 3600);
    if (interval >= 1) return `${interval}h ago`;
    
    interval = Math.floor(seconds / 60);
    if (interval >= 1) return `${interval}m ago`;
    
    return `${Math.floor(seconds)}s ago`;
  };

  return (
    <AppLayout 
      title="Dashboard" 
      description="Overview of production and orders"
    >
      {/* Notice Panel */}
      <NoticePanel />
      
      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {/* Total Orders Card */}
        <Card className="border-l-4 border-blue-500 overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-blue-100 to-transparent opacity-30 rounded-bl-full" />
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Orders</p>
                {isLoadingStats ? (
                  <div className="h-8 flex items-center mt-1">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <p className="text-2xl font-semibold mt-1 text-blue-700">{stats?.totalOrders || 0}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 shadow-sm">
                <ShoppingCart strokeWidth={1.5} />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={75} className="h-1.5 bg-blue-100" indicatorClassName="bg-blue-500" />
              <div className="flex justify-between mt-2 text-sm">
                <span className="text-green-600 font-medium flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1" />12%
                </span>
                <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                  Healthy
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Production Plans Card */}
        <Card className="border-l-4 border-green-500 overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-green-100 to-transparent opacity-30 rounded-bl-full" />
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Production Plans</p>
                {isLoadingStats ? (
                  <div className="h-8 flex items-center mt-1">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <p className="text-2xl font-semibold mt-1 text-green-700">{stats?.totalProductionPlans || 0}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 shadow-sm">
                <Factory strokeWidth={1.5} />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={60} className="h-1.5 bg-green-100" indicatorClassName="bg-green-500" />
              <div className="flex justify-between mt-2 text-sm">
                <span className="text-green-600 font-medium flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1" />8%
                </span>
                <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
                  Growing
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Materials Card */}
        <Card className="border-l-4 border-amber-500 overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-amber-100 to-transparent opacity-30 rounded-bl-full" />
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Materials</p>
                {isLoadingStats ? (
                  <div className="h-8 flex items-center mt-1">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <p className="text-2xl font-semibold mt-1 text-amber-700">{stats?.totalMaterials || 0}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-amber-600 shadow-sm">
                <Package strokeWidth={1.5} />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={85} className="h-1.5 bg-amber-100" indicatorClassName="bg-amber-500" />
              <div className="flex justify-between mt-2 text-sm">
                <span className="text-amber-700 font-medium flex items-center">
                  <BarChart4 className="h-4 w-4 mr-1" />85%
                </span>
                <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50">
                  Stocked
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Revenue Card */}
        <Card className="border-l-4 border-purple-500 overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-purple-100 to-transparent opacity-30 rounded-bl-full" />
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Revenue</p>
                {isLoadingStats ? (
                  <div className="h-8 flex items-center mt-1">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <p className="text-2xl font-semibold mt-1 text-purple-700">
                    {formatCurrency(stats?.totalRevenue || 0)}
                  </p>
                )}
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 shadow-sm">
                <DollarSign strokeWidth={1.5} />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={40} className="h-1.5 bg-purple-100" indicatorClassName="bg-purple-500" />
              <div className="flex justify-between mt-2 text-sm">
                <span className="text-red-600 font-medium flex items-center">
                  <TrendingDown className="h-4 w-4 mr-1" />3%
                </span>
                <Badge variant="outline" className="text-purple-600 border-purple-200 bg-purple-50">
                  <AlertTriangle className="h-3 w-3 mr-1" /> Attention
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts and Tables section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Production Plans */}
        <Card className="lg:col-span-2 border-t-4 border-green-500 overflow-hidden">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800 flex items-center">
              <Factory className="h-5 w-5 mr-2 text-green-500" strokeWidth={2} />
              Recent Production Plans
            </h2>
            <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
              {!isLoadingPlans && productionPlans ? productionPlans.length : 0} Plans
            </Badge>
          </div>
          <CardContent className="p-6">
            {isLoadingPlans ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Buyer</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price/Yard</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {productionPlans && productionPlans.length > 0 ? (
                      productionPlans.map((plan) => (
                        <tr key={plan.id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{plan.buyer_name}</td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700">{plan.item_name}</td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className="text-sm font-medium bg-green-50 text-green-700 rounded-full px-2 py-1">
                              {plan.quantity}
                            </span>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm font-semibold text-gray-900">
                            {formatCurrency(Number(plan.price_per_yard))}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(plan.status)}`}>
                              {plan.status.charAt(0).toUpperCase() + plan.status.slice(1)}
                            </span>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-4 py-8 text-center text-sm text-gray-500">
                          <div className="flex flex-col items-center">
                            <Factory className="h-10 w-10 text-gray-300 mb-2" />
                            No production plans found
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
            <div className="mt-4 flex justify-center">
              <Link href="/production-plans">
                <Button variant="outline" className="text-green-600 border-green-200 hover:bg-green-50">
                  View All Plans
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        {/* Activity Feed */}
        <Card className="border-t-4 border-purple-500 overflow-hidden">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800 flex items-center">
              <Activity className="h-5 w-5 mr-2 text-purple-500" strokeWidth={2} />
              Recent Activity
            </h2>
            <Badge variant="outline" className="text-purple-600 border-purple-200 bg-purple-50">
              {!isLoadingActivities && activities ? activities.length : 0} Events
            </Badge>
          </div>
          <CardContent className="p-6 bg-gradient-to-b from-white to-gray-50">
            {isLoadingActivities ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="flow-root">
                <ul className="-mb-8">
                  {activities && activities.length > 0 ? (
                    activities.map((activity, index) => (
                      <li key={activity.id}>
                        <div className="relative pb-8">
                          {index < activities.length - 1 && (
                            <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                          )}
                          <div className="relative flex space-x-3">
                            <div>
                              <span className={`h-8 w-8 rounded-full ${getActivityBgColor(activity.action)} flex items-center justify-center ring-8 ring-white shadow-sm`}>
                                {getActivityIcon(activity.action)}
                              </span>
                            </div>
                            <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                              <div>
                                <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                              </div>
                              <div className="text-right text-xs whitespace-nowrap">
                                <span className="inline-flex items-center rounded-md bg-gray-50 px-2 py-1 text-xs font-medium text-gray-600 ring-1 ring-inset ring-gray-200">
                                  {getTimeAgo(activity.timestamp?.toString())}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))
                  ) : (
                    <li className="py-8 text-center text-sm text-gray-500">
                      <div className="flex flex-col items-center">
                        <Activity className="h-10 w-10 text-gray-300 mb-2" />
                        No recent activity
                      </div>
                    </li>
                  )}
                </ul>
              </div>
            )}
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-purple-600 border-purple-200 hover:bg-purple-50">
                View All Activity
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Orders */}
      <Card className="mt-6 border-t-4 border-blue-500 overflow-hidden">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800 flex items-center">
            <ShoppingCart className="h-5 w-5 mr-2 text-blue-500" strokeWidth={2} />
            Recent Orders
          </h2>
          <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
            {!isLoadingOrders && orders ? orders.length : 0} Orders
          </Badge>
        </div>
        <CardContent className="p-6">
          {isLoadingOrders ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {orders && orders.length > 0 ? (
                    orders.map((order) => (
                      <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className="text-sm font-medium text-blue-600 bg-blue-50 rounded-full px-2 py-1">
                            #{order.id}
                          </span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{order.customer_name}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{formatDate(order.order_date?.toString())}</td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className="text-sm font-semibold text-gray-900">
                            {formatCurrency(Number(order.total_amount))}
                          </span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(order.status)}`}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">
                          <Link href={`/orders/${order.id}`}>
                            <Button variant="outline" size="sm" className="h-8 text-blue-600 border-blue-200 hover:bg-blue-50">
                              View
                            </Button>
                          </Link>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="px-4 py-8 text-center text-sm text-gray-500">
                        <div className="flex flex-col items-center">
                          <ShoppingCart className="h-10 w-10 text-gray-300 mb-2" />
                          No orders found
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
          <div className="mt-4 flex items-center justify-between">
            <div className="flex-1 flex justify-between sm:hidden">
              <Button variant="outline" disabled>
                Previous
              </Button>
              <Button variant="outline" disabled>
                Next
              </Button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing <span className="font-medium">1</span> to <span className="font-medium">
                    {orders?.length || 0}
                  </span> of <span className="font-medium">
                    {orders?.length || 0}
                  </span> results
                </p>
              </div>
              <div>
                <Link href="/orders">
                  <Button variant="outline" className="text-blue-600 border-blue-200 hover:bg-blue-50">
                    View All Orders
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </AppLayout>
  );
}
