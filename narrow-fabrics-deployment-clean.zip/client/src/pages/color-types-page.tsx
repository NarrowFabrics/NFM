import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { RefreshCw, Palette } from "lucide-react";
import { ColorType } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function ColorTypesPage() {
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [activeFilter, setActiveFilter] = useState<boolean | null>(null);
  const [search, setSearch] = useState("");

  // Fetch color types
  const {
    data: colorTypesData,
    isLoading,
    refetch,
  } = useQuery<{ colorTypes: ColorType[]; total: number }>({
    queryKey: ["/api/color-types", page, perPage, activeFilter],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, activeFilter] = queryKey;
      let url = `/api/color-types?page=${page}&limit=${perPage}`;
      if (activeFilter !== null) url += `&activeOnly=${activeFilter}`;

      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch color types');
      }
      return res.json();
    },
  });

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Table columns definition
  const columns = [
    {
      header: "ID",
      accessorKey: "id" as keyof ColorType,
    },
    {
      header: "Name",
      accessorKey: "name" as keyof ColorType,
      cell: ({ row }: { row: ColorType }) => (
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 rounded-full bg-primary flex items-center justify-center">
            <Palette className="h-2 w-2 text-white" />
          </div>
          <span>{row.name}</span>
        </div>
      )
    },
    {
      header: "Status",
      accessorKey: "is_active" as keyof ColorType,
      cell: ({ row }: { row: ColorType }) => (
        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
          row.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {row.is_active ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      header: "Created Date",
      accessorKey: "created_at" as keyof ColorType,
      cell: ({ row }: { row: ColorType }) => formatDate(row.created_at),
    },
  ];

  return (
    <AppLayout
      title="Color Types"
      description="View available color types"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>        
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant={activeFilter === null ? "default" : "outline"} 
              onClick={() => setActiveFilter(null)}
              className={`h-10 ${activeFilter === null ? 'bg-primary text-primary-foreground' : ''}`}
            >
              All
            </Button>
            <Button 
              variant={activeFilter === true ? "default" : "outline"} 
              onClick={() => setActiveFilter(true)}
              className={`h-10 ${activeFilter === true ? 'bg-primary text-primary-foreground' : ''}`}
            >
              Active Only
            </Button>
            <Button 
              variant={activeFilter === false ? "default" : "outline"} 
              onClick={() => setActiveFilter(false)}
              className={`h-10 ${activeFilter === false ? 'bg-primary text-primary-foreground' : ''}`}
            >
              Inactive Only
            </Button>
          </div>
        </div>
      </div>

      <DataTable
        data={colorTypesData?.colorTypes || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          colorTypesData
            ? {
                currentPage: page,
                totalPages: Math.ceil(colorTypesData.total / perPage),
                totalItems: colorTypesData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />
    </AppLayout>
  );
}