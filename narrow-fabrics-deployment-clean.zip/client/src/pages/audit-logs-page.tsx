import { useQuery } from "@tanstack/react-query";
import { UserActivity } from "@shared/schema";
import { DataTable } from "@/components/ui/data-table";
import { columns } from "@/components/audit-logs/columns";
import AppLayout from "@/components/layout/app-layout";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function AuditLogsPage() {
  const { user } = useAuth();

  const { data: activities, isLoading, error } = useQuery<UserActivity[]>({
    queryKey: ["/api/audit-logs"],
    enabled: !!user?.is_admin,
  });

  if (!user?.is_admin) {
    return (
      <AppLayout title="Access Denied" description="You do not have permission to view this page.">
        <Card className="p-6">
          <div className="text-center text-muted-foreground">
            This page is only accessible to administrators.
          </div>
        </Card>
      </AppLayout>
    );
  }

  if (isLoading) {
    return (
      <AppLayout title="Audit Logs" description="Loading audit logs...">
        <Card className="p-6">
          <div className="flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </Card>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout title="Audit Logs" description="Error loading audit logs">
        <Card className="p-6">
          <div className="text-center text-destructive">
            Error: {error.message}
          </div>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout 
      title="Audit Logs" 
      description="View all administrative actions performed in the system."
    >
      <Card className="p-6">
        <DataTable 
          columns={columns} 
          data={activities || []} 
          pageSize={10}
          searchKey="action"
        />
      </Card>
    </AppLayout>
  );
}