


import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { queryClient, apiRequest } from "../../lib/queryClient";
import { useToast } from "../../hooks/use-toast";
import { InsertMaterial, Material, ColorType, insertMaterialSchema } from "../../../../shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../../components/ui/dialog";
import { Button } from "../../components/ui/button";
import { 
  Table, TableBody, TableCell, TableHead, 
  TableHeader, TableRow 
} from "../../components/ui/table";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../../components/ui/form";
import { Input } from "../../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Card, CardContent } from "../../components/ui/card";
import { AlertCircle, Database, FileDown, Loader2, Plus, Trash2 } from "lucide-react";
import Sidebar from "../../components/layout/sidebar";

export default function MaterialsPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [currentMaterial, setCurrentMaterial] = useState<Material | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  const { data: materials, isLoading: materialsLoading } = useQuery<Material[]>({
    queryKey: ["/api/materials"],
  });

  const { data: colorTypes, isLoading: colorTypesLoading } = useQuery<ColorType[]>({
    queryKey: ["/api/color-types"],
  });

  const isLoading = materialsLoading || colorTypesLoading;

  const form = useForm<InsertMaterial>({
    resolver: zodResolver(insertMaterialSchema),
    defaultValues: {
      category: "Elastic/Core",
      yarn_name: "",
      color_type: "",
      price_per_kg: "0",
      properties: {
        count: "",
        specifications: []
      }
    }
  });

  const addMaterialMutation = useMutation({
    mutationFn: async (data: InsertMaterial) => {
      return await apiRequest({
        method: "POST", 
        endpoint: "/api/materials", 
        data: data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/materials"] });
      setDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Material added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add material",
        variant: "destructive",
      });
    },
  });

  // Import materials from CSV
  const importMaterials = async () => {
    try {
      setIsImporting(true);
      toast({
        title: "Import Started",
        description: "Importing materials from CSV files...",
      });

      const response = await fetch('/api/materials/import', {
        method: 'POST',
      });

      if (!response.ok) {
        throw new Error(`Import failed with status: ${response.status}`);
      }

      const result = await response.json();

      queryClient.invalidateQueries({ queryKey: ["/api/materials"] });

      toast({
        title: "Import Successful",
        description: `Imported ${result.stats?.total || 0} materials`,
      });
    } catch (error) {
      console.error('Import error:', error);
      toast({
        title: "Import Failed",
        description: "Failed to import materials. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  // Export functions
  const exportMaterials = async (format: 'pdf' | 'excel') => {
    try {
      toast({
        title: "Export Started",
        description: `Preparing ${format.toUpperCase()} export...`,
      });

      const response = await fetch(`/api/materials/export/${format}`, {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error(`Export failed with status: ${response.status}`);
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `Materials_Report.${format === 'excel' ? 'xlsx' : 'pdf'}`;
      document.body.appendChild(a);
      a.click();

      // Clean up by removing the element and revoking the object URL
      setTimeout(() => {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      }, 100);

      toast({
        title: "Export Successful",
        description: `Materials exported as ${format.toUpperCase()}`,
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: "Export Failed",
        description: "Failed to export materials. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Create a separate form for editing
  const editForm = useForm<InsertMaterial>({
    resolver: zodResolver(insertMaterialSchema),
    defaultValues: {
      category: "Elastic/Core",
      yarn_name: "",
      color_type: "",
      price_per_kg: "0",
      properties: {
        count: "",
        specifications: []
      }
    }
  });

  // Update Material Mutation
  const updateMaterialMutation = useMutation({
    mutationFn: async (data: { id: number, data: Partial<InsertMaterial> }) => {
      return await apiRequest({
        method: "PUT", 
        endpoint: `/api/materials/${data.id}`, 
        data: data.data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/materials"] });
      setEditDialogOpen(false);
      setCurrentMaterial(null);
      setIsEditing(false);
      editForm.reset();
      toast({
        title: "Success",
        description: "Material updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update material",
        variant: "destructive",
      });
    },
  });

  // Handle Edit Material
  const handleEditMaterial = (material: Material) => {
    setCurrentMaterial(material);
    setIsEditing(true);

    // Set form values based on the selected material
    editForm.reset({
      category: material.category,
      yarn_name: material.yarn_name,
      color_type: material.color_type,
      price_per_kg: material.price_per_kg.toString(),
      properties: material.properties || { count: "", specifications: [] }
    });

    setEditDialogOpen(true);
  };

  // Group the materials by category
  const materialsByCategory = materials?.reduce((acc, material) => {
    const category = material.category;
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(material);
    return acc;
  }, {} as Record<string, Material[]>) || {};

  if (isLoading) {
    return (
      <div className="flex min-h-screen">
        <Sidebar isOpen={true} onClose={() => {}} user={{} as any} />
        <main className="flex-1 p-8 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </main>
      </div>
    );
  }

  const getFilteredMaterials = () => {
    if (activeTab === "all") {
      return materials || [];
    }
    return materialsByCategory[activeTab] || [];
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar isOpen={true} onClose={() => {}} user={{} as any} />
      <main className="flex-1 p-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">{t("nav.materials")}</h1>
          <div className="flex gap-2">
            {/* Import button */}
            <Button 
              variant="outline" 
              onClick={importMaterials} 
              disabled={isImporting}
            >
              <Database className="h-4 w-4 mr-2" />
              {isImporting ? "Importing..." : "Import Materials"}
            </Button>
            {/* Export buttons */}
            <Button variant="outline" onClick={() => exportMaterials('pdf')}>
              <FileDown className="h-4 w-4 mr-2" />
              Export PDF
            </Button>
            <Button variant="outline" onClick={() => exportMaterials('excel')}>
              <FileDown className="h-4 w-4 mr-2" />
              Export Excel
            </Button>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Material
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Material</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit((data) => addMaterialMutation.mutate(data))} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Elastic/Core">
                                <div className="flex items-center gap-2">
                                  <div className="w-2 h-2 rounded-full bg-blue-500" />
                                  <span>Elastic/Core</span>
                                </div>
                              </SelectItem>
                              <SelectItem value="Cotton">
                                <div className="flex items-center gap-2">
                                  <div className="w-2 h-2 rounded-full bg-green-500" />
                                  <span>Cotton</span>
                                </div>
                              </SelectItem>
                              <SelectItem value="Nylon">
                                <div className="flex items-center gap-2">
                                  <div className="w-2 h-2 rounded-full bg-purple-500" />
                                  <span>Nylon</span>
                                </div>
                              </SelectItem>
                              <SelectItem value="Polyester">
                                <div className="flex items-center gap-2">
                                  <div className="w-2 h-2 rounded-full bg-orange-500" />
                                  <span>Polyester</span>
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="yarn_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Yarn Count</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="color_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Color Type</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select color type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {colorTypes?.filter(ct => ct.is_active).map((colorType) => (
                                <SelectItem key={colorType.id} value={colorType.name}>
                                  {colorType.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="price_per_kg"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price per KG</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" disabled={addMaterialMutation.isPending}>
                      {addMaterialMutation.isPending ? "Adding..." : "Add Material"}
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="p-1">
            <TabsTrigger value="all" className="relative">
              All Categories
            </TabsTrigger>
            <TabsTrigger value="Elastic/Core" className="relative">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <span>Elastic/Core</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="Cotton" className="relative">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>Cotton</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="Nylon" className="relative">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-purple-500" />
                <span>Nylon</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="Polyester" className="relative">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-orange-500" />
                <span>Polyester</span>
              </div>
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Legend for color coding */}
        <div className="bg-white dark:bg-gray-800 p-4 mb-4 rounded-lg border shadow-sm">
          <h3 className="font-medium mb-2">Material Categories</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
              <span className="text-sm">Elastic/Core</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-sm">Cotton</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500" />
              <span className="text-sm">Nylon</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-orange-500" />
              <span className="text-sm">Polyester</span>
            </div>
          </div>
        </div>

        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Category</TableHead>
                <TableHead>Yarn Count</TableHead>
                <TableHead>Color Type</TableHead>
                <TableHead>Price (USD)</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {getFilteredMaterials().map((material) => (
                <TableRow key={material.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${
                        material.category === "Elastic/Core" 
                          ? "bg-blue-500" 
                          : material.category === "Cotton" 
                            ? "bg-green-500" 
                            : material.category === "Nylon" 
                              ? "bg-purple-500" 
                              : "bg-orange-500"
                      }`} />
                      <span>{material.category}</span>
                    </div>
                  </TableCell>
                  <TableCell>{material.yarn_name}</TableCell>
                  <TableCell>
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                      {material.color_type}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className={`font-medium ${
                      parseFloat(material.price_per_kg.toString()) > 100 
                        ? "text-red-600" 
                        : parseFloat(material.price_per_kg.toString()) > 50 
                          ? "text-amber-600" 
                          : "text-green-600"
                    }`}>
                      ${parseFloat(material.price_per_kg.toString()).toFixed(2)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleEditMaterial(material)}
                    >
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {getFilteredMaterials().length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-4">
                    <div className="flex flex-col items-center justify-center text-muted-foreground">
                      <AlertCircle className="h-8 w-8 mb-2" />
                      <p>No materials found</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Edit Material Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Material</DialogTitle>
            </DialogHeader>
            <Form {...editForm}>
              <form 
                onSubmit={editForm.handleSubmit((data) => {
                  if (currentMaterial) {
                    updateMaterialMutation.mutate({
                      id: currentMaterial.id,
                      data: data
                    });
                  }
                })} 
                className="space-y-4"
              >
                <FormField
                  control={editForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Elastic/Core">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-blue-500" />
                              <span>Elastic/Core</span>
                            </div>
                          </SelectItem>
                          <SelectItem value="Cotton">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-green-500" />
                              <span>Cotton</span>
                            </div>
                          </SelectItem>
                          <SelectItem value="Nylon">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-purple-500" />
                              <span>Nylon</span>
                            </div>
                          </SelectItem>
                          <SelectItem value="Polyester">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-orange-500" />
                              <span>Polyester</span>
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="yarn_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Yarn Count</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="color_type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Color Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select color type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {colorTypes?.filter(ct => ct.is_active).map((colorType) => (
                            <SelectItem key={colorType.id} value={colorType.name}>
                              {colorType.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="price_per_kg"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price per KG</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={updateMaterialMutation.isPending}>
                  {updateMaterialMutation.isPending ? "Updating..." : "Update Material"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}