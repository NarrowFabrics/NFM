import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import AppLayout from "@/components/layout/app-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Loader2, User as UserIcon, Mail, Phone, Building, UserPlus, Save, Key, RefreshCw, Shield, Activity, Clock, Lock } from "lucide-react";

// Form validation schema
const profileFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone_number: z.string().optional(),
  job_role: z.string().optional(),
  organization_name: z.string().optional(),
  profile_image: z.string().optional(),
  theme_preference: z.string().optional(),
  time_format: z.string().optional(),
  date_format: z.string().optional(),
  language: z.string().optional(),
  notification_preferences: z.object({
    email: z.boolean().default(true),
    app: z.boolean().default(true),
  }).optional(),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

// Password change schema
const passwordFormSchema = z.object({
  current_password: z.string().min(1, { message: "Current password is required." }),
  new_password: z.string().min(8, { message: "Password must be at least 8 characters." }),
  confirm_password: z.string().min(8, { message: "Password must be at least 8 characters." }),
}).refine((data) => data.new_password === data.confirm_password, {
  message: "Passwords don't match",
  path: ["confirm_password"],
});

type PasswordFormValues = z.infer<typeof passwordFormSchema>;

export default function ProfilePage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  const [isUploading, setIsUploading] = useState(false);

  // Fetch current user profile
  const { data: user, isLoading: isLoadingUser, refetch } = useQuery({
    queryKey: ['/api/users/me'],
    queryFn: async () => {
      const res = await fetch('/api/users/me', { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch user profile');
      return res.json();
    }
  });

  // Profile update form
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone_number: "",
      job_role: "",
      organization_name: "",
      profile_image: "",
      theme_preference: "system",
      time_format: "24",
      date_format: "YYYY-MM-DD",
      language: "en",
      notification_preferences: {
        email: true,
        app: true,
      },
    },
  });

  // Password change form
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      current_password: "",
      new_password: "",
      confirm_password: "",
    },
  });

  // Update profile form when user data is loaded
  useState(() => {
    if (user) {
      profileForm.reset({
        name: user.name || "",
        email: user.email || "",
        phone_number: user.phone_number || "",
        job_role: user.job_role || "",
        organization_name: user.organization_name || "",
        profile_image: user.profile_image || "",
        theme_preference: user.theme_preference || "system",
        time_format: user.time_format || "24",
        date_format: user.date_format || "YYYY-MM-DD",
        language: user.language || "en",
        notification_preferences: {
          email: user.notification_preferences?.email ?? true,
          app: user.notification_preferences?.app ?? true,
        },
      });
    }
  });

  // Profile update mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (values: ProfileFormValues) => {
      const res = await fetch('/api/users/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
        credentials: 'include',
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to update profile');
      }
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Password change mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (values: PasswordFormValues) => {
      const res = await fetch('/api/users/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          current_password: values.current_password,
          new_password: values.new_password,
        }),
        credentials: 'include',
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to change password');
      }
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Password Changed",
        description: "Your password has been changed successfully.",
      });
      passwordForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Password Change Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle profile form submission
  function onProfileSubmit(data: ProfileFormValues) {
    updateProfileMutation.mutate(data);
  }

  // Handle password form submission
  function onPasswordSubmit(data: PasswordFormValues) {
    changePasswordMutation.mutate(data);
  }

  // Generate user initials for the avatar
  const getUserInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  // Handle profile picture upload
  const handleProfilePictureUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    // Simulating the upload
    setTimeout(() => {
      const randomColor = Math.floor(Math.random()*16777215).toString(16);
      const newImageUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(profileForm.getValues('name'))}&background=${randomColor}`;
      profileForm.setValue('profile_image', newImageUrl);
      setIsUploading(false);
      toast({
        title: "Profile Picture Updated",
        description: "Your profile picture has been updated successfully.",
      });
    }, 1500);
  };

  return (
    <AppLayout title="My Profile" description="View and manage your profile information">
      <div className="container mx-auto py-6 px-4 md:px-6 max-w-5xl">
        {isLoadingUser ? (
          <div className="flex justify-center items-center h-[50vh]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6 mb-8">
              <div className="relative">
                <Avatar className="h-24 w-24 border-4 border-primary/10">
                  <AvatarImage 
                    src={user?.profile_image || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || "User")}&background=random&size=200`} 
                    alt={user?.name || "User"} 
                  />
                  <AvatarFallback className="text-2xl">{getUserInitials(user?.name || "User")}</AvatarFallback>
                </Avatar>
                <label 
                  htmlFor="profile-upload" 
                  className="absolute bottom-0 right-0 bg-primary text-white p-1 rounded-full cursor-pointer hover:bg-primary/90 transition-colors"
                  title="Change profile picture"
                >
                  {isUploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <UserPlus className="h-4 w-4" />
                  )}
                </label>
                <input 
                  id="profile-upload" 
                  type="file" 
                  accept="image/*" 
                  onChange={handleProfilePictureUpload} 
                  className="hidden" 
                />
              </div>
              
              <div>
                <h1 className="text-3xl font-bold">{user?.name || "User Profile"}</h1>
                <div className="flex flex-col sm:flex-row gap-2 mt-2">
                  <div className="flex items-center text-gray-500">
                    <Mail className="h-4 w-4 mr-1.5" />
                    <span>{user?.email || "email@example.com"}</span>
                  </div>
                  {user?.phone_number && (
                    <div className="flex items-center text-gray-500">
                      <Phone className="h-4 w-4 mr-1.5" />
                      <span>{user.phone_number}</span>
                    </div>
                  )}
                  {user?.organization_name && (
                    <div className="flex items-center text-gray-500">
                      <Building className="h-4 w-4 mr-1.5" />
                      <span>{user.organization_name}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full md:w-auto grid-cols-2 md:inline-grid">
                <TabsTrigger value="profile" className="flex items-center gap-2">
                  <UserIcon className="h-4 w-4" />
                  <span>Profile Information</span>
                </TabsTrigger>
                <TabsTrigger value="security" className="flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  <span>Security</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="profile">
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Information</CardTitle>
                    <CardDescription>
                      Update your personal information and preferences
                    </CardDescription>
                  </CardHeader>
                  
                  <Form {...profileForm}>
                    <form onSubmit={profileForm.handleSubmit(onProfileSubmit)}>
                      <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={profileForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your full name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your email" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="phone_number"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Phone Number</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your phone number" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="job_role"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Job Role</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your job role" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={profileForm.control}
                            name="organization_name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Organization</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter your organization name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Separator />
                        
                        <div>
                          <h3 className="text-lg font-medium mb-4">Preferences</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                              control={profileForm.control}
                              name="language"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Language</FormLabel>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select language" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="en">English</SelectItem>
                                      <SelectItem value="fr">French</SelectItem>
                                      <SelectItem value="es">Spanish</SelectItem>
                                      <SelectItem value="de">German</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={profileForm.control}
                              name="theme_preference"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Theme</FormLabel>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select theme" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="light">Light</SelectItem>
                                      <SelectItem value="dark">Dark</SelectItem>
                                      <SelectItem value="system">System</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={profileForm.control}
                              name="time_format"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Time Format</FormLabel>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select time format" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="12">12-hour (AM/PM)</SelectItem>
                                      <SelectItem value="24">24-hour</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={profileForm.control}
                              name="date_format"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Date Format</FormLabel>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select date format" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      </CardContent>
                      
                      <CardFooter className="flex justify-between">
                        <Button 
                          variant="outline" 
                          type="button"
                          onClick={() => profileForm.reset()}
                        >
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Reset
                        </Button>
                        <Button 
                          type="submit"
                          disabled={updateProfileMutation.isPending}
                        >
                          {updateProfileMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              Save Changes
                            </>
                          )}
                        </Button>
                      </CardFooter>
                    </form>
                  </Form>
                </Card>
              </TabsContent>
              
              <TabsContent value="security">
                <Card>
                  <CardHeader>
                    <CardTitle>Change Password</CardTitle>
                    <CardDescription>
                      Update your password to maintain account security
                    </CardDescription>
                  </CardHeader>
                  
                  <Form {...passwordForm}>
                    <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)}>
                      <CardContent className="space-y-4">
                        <FormField
                          control={passwordForm.control}
                          name="current_password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Current Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Enter your current password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="new_password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>New Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Enter your new password" {...field} />
                              </FormControl>
                              <FormDescription>
                                Password must be at least 8 characters long
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="confirm_password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm New Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Confirm your new password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </CardContent>
                      
                      <CardFooter>
                        <Button 
                          type="submit"
                          className="ml-auto"
                          disabled={changePasswordMutation.isPending}
                        >
                          {changePasswordMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Changing Password...
                            </>
                          ) : (
                            <>
                              <Key className="mr-2 h-4 w-4" />
                              Change Password
                            </>
                          )}
                        </Button>
                      </CardFooter>
                    </form>
                  </Form>
                </Card>
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Login Activity</CardTitle>
                    <CardDescription>
                      View your recent login activity
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-start border-b pb-4">
                        <div className="flex items-start gap-4">
                          <Activity className="h-8 w-8 text-primary mt-1" />
                          <div>
                            <p className="font-medium">Current Login Session</p>
                            <p className="text-sm text-gray-500">Browser: Chrome 108.0.0 on Windows</p>
                            <p className="text-sm text-gray-500">IP Address: 192.168.1.1</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <p className="text-sm font-medium text-green-600">Active Now</p>
                          <Button variant="outline" size="sm" className="mt-2">
                            Logout
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-start border-b pb-4">
                        <div className="flex items-start gap-4">
                          <Clock className="h-6 w-6 text-gray-400 mt-1" />
                          <div>
                            <p className="font-medium">Previous Login</p>
                            <p className="text-sm text-gray-500">Browser: Safari on iPhone</p>
                            <p className="text-sm text-gray-500">IP Address: 192.168.1.5</p>
                          </div>
                        </div>
                        <p className="text-sm text-gray-500">April 2, 2025 at 10:23 AM</p>
                      </div>
                      
                      <div className="flex justify-between items-start">
                        <div className="flex items-start gap-4">
                          <Clock className="h-6 w-6 text-gray-400 mt-1" />
                          <div>
                            <p className="font-medium">Previous Login</p>
                            <p className="text-sm text-gray-500">Browser: Firefox 107.0 on Mac</p>
                            <p className="text-sm text-gray-500">IP Address: 192.168.1.10</p>
                          </div>
                        </div>
                        <p className="text-sm text-gray-500">March 30, 2025 at 3:45 PM</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </AppLayout>
  );
}