import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Edit, 
  Trash, 
  RefreshCw,
  Loader2,
  Ruler
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { UnitSetting, insertUnitSettingSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form schema
const formSchema = insertUnitSettingSchema;
type FormValues = z.infer<typeof formSchema>;

export default function UnitSettingsPage() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [activeFilter, setActiveFilter] = useState<boolean | null>(null);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [editingUnitSetting, setEditingUnitSetting] = useState<UnitSetting | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [unitSettingToDelete, setUnitSettingToDelete] = useState<number | null>(null);

  // Fetch unit settings
  const {
    data: unitSettingsData,
    isLoading,
    refetch,
  } = useQuery<{ unitSettings: UnitSetting[]; total: number }>({
    queryKey: ["/api/unit-settings", page, perPage, activeFilter],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, activeFilter] = queryKey;
      let url = `/api/unit-settings?page=${page}&limit=${perPage}`;
      if (activeFilter !== null) url += `&activeOnly=${activeFilter}`;
      
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch unit settings');
      }
      return res.json();
    },
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      unit_name: "",
      is_active: true,
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest("POST", "/api/unit-settings", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Unit setting created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/unit-settings"] });
      setIsFormDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: FormValues }) => {
      const res = await apiRequest("PUT", `/api/unit-settings/${id}`, values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Unit setting updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/unit-settings"] });
      setIsFormDialogOpen(false);
      setEditingUnitSetting(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/unit-settings/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Unit setting deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/unit-settings"] });
      setIsDeleteDialogOpen(false);
      setUnitSettingToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle create button click
  const handleCreate = () => {
    form.reset({
      unit_name: "",
      is_active: true,
    });
    setEditingUnitSetting(null);
    setIsFormDialogOpen(true);
  };

  // Handle edit button click
  const handleEdit = (unitSetting: UnitSetting) => {
    form.reset({
      unit_name: unitSetting.unit_name,
      is_active: unitSetting.is_active,
    });
    setEditingUnitSetting(unitSetting);
    setIsFormDialogOpen(true);
  };

  // Handle delete button click
  const handleDeleteClick = (id: number) => {
    setUnitSettingToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    if (unitSettingToDelete !== null) {
      deleteMutation.mutate(unitSettingToDelete);
    }
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    if (editingUnitSetting) {
      updateMutation.mutate({ id: editingUnitSetting.id, values });
    } else {
      createMutation.mutate(values);
    }
  };

  // Table columns definition
  const columns = [
    {
      header: "ID",
      accessorKey: "id" as keyof UnitSetting,
    },
    {
      header: "Unit Name",
      accessorKey: "unit_name" as keyof UnitSetting,
      cell: ({ row }: { row: UnitSetting }) => (
        <div className="flex items-center space-x-2">
          <Ruler className="h-4 w-4 text-primary" />
          <span>{row.unit_name}</span>
        </div>
      ),
    },
    {
      header: "Status",
      accessorKey: "is_active" as keyof UnitSetting,
      cell: ({ row }: { row: UnitSetting }) => (
        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
          row.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {row.is_active ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      header: "Actions",
      cell: ({ row }: { row: UnitSetting }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => handleEdit(row)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteClick(row.id)}>
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  // Common measurement units
  const commonUnits = ["Yard", "Meter", "Inch", "Centimeter", "Foot", "Piece", "Roll", "Pack"];

  return (
    <AppLayout
      title="Unit Settings"
      description="Manage measurement units for your products"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> New Unit Setting
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant={activeFilter === null ? "default" : "outline"} 
              onClick={() => setActiveFilter(null)}
              className="h-10"
            >
              All
            </Button>
            <Button 
              variant={activeFilter === true ? "default" : "outline"} 
              onClick={() => setActiveFilter(true)}
              className="h-10"
            >
              Active Only
            </Button>
            <Button 
              variant={activeFilter === false ? "default" : "outline"} 
              onClick={() => setActiveFilter(false)}
              className="h-10"
            >
              Inactive Only
            </Button>
          </div>
        </div>
      </div>

      <DataTable
        data={unitSettingsData?.unitSettings || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          unitSettingsData
            ? {
                currentPage: page,
                totalPages: Math.ceil(unitSettingsData.total / perPage),
                totalItems: unitSettingsData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />

      {/* Create/Edit Form Dialog */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingUnitSetting ? "Edit Unit Setting" : "Create Unit Setting"}
            </DialogTitle>
            <DialogDescription>
              {editingUnitSetting
                ? "Update the unit setting details below."
                : "Fill in the details to create a new unit setting."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="unit_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter unit name" 
                        {...field} 
                        list="common-units"
                      />
                    </FormControl>
                    <datalist id="common-units">
                      {commonUnits.map((unit) => (
                        <option key={unit} value={unit} />
                      ))}
                    </datalist>
                    <FormDescription>
                      For example: Yard, Meter, Inch, etc.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="is_active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Inactive units won't be available for selection.
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {(createMutation.isPending || updateMutation.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {editingUnitSetting ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    editingUnitSetting ? "Update Unit" : "Create Unit"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the unit setting. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
