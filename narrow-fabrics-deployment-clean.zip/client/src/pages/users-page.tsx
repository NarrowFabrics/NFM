import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Edit, 
  Trash, 
  RefreshCw,
  Loader2,
  Mail,
  User,
  Phone,
  Briefcase,
  Building,
  Shield,
  Clock,
  CheckCircle,
  XCircle,
  Search
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { User as SelectUser, insertUserSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Extended schema for validation
const formSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
  is_admin: z.boolean().default(false),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type FormValues = z.infer<typeof formSchema>;

export default function UsersPage() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [search, setSearch] = useState("");
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<SelectUser | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<number | null>(null);

  // Fetch users
  const {
    data: usersData,
    isLoading,
    refetch,
  } = useQuery<{ users: SelectUser[]; total: number }>({
    queryKey: ["/api/users", page, perPage, search],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, search] = queryKey;
      let url = `/api/users?page=${page}&limit=${perPage}`;
      if (search) url += `&search=${search}`;
      
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch users');
      }
      return res.json();
    },
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone_number: "",
      job_role: "",
      organization_name: "",
      username: "",
      password: "",
      confirmPassword: "",
      is_admin: false,
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const { confirmPassword, ...userData } = values;
      const res = await apiRequest("POST", "/api/register", userData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsFormDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: Partial<FormValues> }) => {
      // Only send fields that should be updated
      const { confirmPassword, password, ...restValues } = values;
      
      // Only include password if it was changed (not empty)
      const updateData = password ? { ...restValues, password } : restValues;
      
      const res = await apiRequest("PUT", `/api/users/${id}`, updateData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsFormDialogOpen(false);
      setEditingUser(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/users/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsDeleteDialogOpen(false);
      setUserToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle create button click
  const handleCreate = () => {
    form.reset({
      name: "",
      email: "",
      phone_number: "",
      job_role: "",
      organization_name: "",
      username: "",
      password: "",
      confirmPassword: "",
      is_admin: false,
    });
    setEditingUser(null);
    setIsFormDialogOpen(true);
  };

  // Handle edit button click
  const handleEdit = (user: SelectUser) => {
    form.reset({
      name: user.name,
      email: user.email,
      phone_number: user.phone_number,
      job_role: user.job_role,
      organization_name: user.organization_name,
      username: user.username,
      password: "", // We don't show the current password
      confirmPassword: "",
      is_admin: user.is_admin,
    });
    setEditingUser(user);
    setIsFormDialogOpen(true);
  };

  // Handle delete button click
  const handleDeleteClick = (id: number) => {
    setUserToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    if (userToDelete !== null) {
      deleteMutation.mutate(userToDelete);
    }
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    if (editingUser) {
      // For edit, only include fields that have been modified
      const changedValues: Partial<FormValues> = {};
      
      if (values.name !== editingUser.name) changedValues.name = values.name;
      if (values.email !== editingUser.email) changedValues.email = values.email;
      if (values.phone_number !== editingUser.phone_number) changedValues.phone_number = values.phone_number;
      if (values.job_role !== editingUser.job_role) changedValues.job_role = values.job_role;
      if (values.organization_name !== editingUser.organization_name) changedValues.organization_name = values.organization_name;
      if (values.username !== editingUser.username) changedValues.username = values.username;
      if (values.is_admin !== editingUser.is_admin) changedValues.is_admin = values.is_admin;
      
      // Only include password if it was changed (not empty)
      if (values.password && values.password === values.confirmPassword) {
        changedValues.password = values.password;
      }
      
      updateMutation.mutate({ id: editingUser.id, values: changedValues });
    } else {
      createMutation.mutate(values);
    }
  };

  // Format date
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Never";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get user initial for avatar
  const getUserInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Table columns definition
  const columns = [
    {
      header: "User",
      accessorKey: "name" as keyof SelectUser,
      cell: ({ row }: { row: SelectUser }) => (
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center">
            <span>{getUserInitials(row.name)}</span>
          </div>
          <div>
            <div className="font-medium">{row.name}</div>
            <div className="text-xs text-gray-500">{row.username}</div>
          </div>
        </div>
      ),
    },
    {
      header: "Contact",
      accessorKey: "email" as keyof SelectUser,
      cell: ({ row }: { row: SelectUser }) => (
        <div className="space-y-1">
          <div className="flex items-center text-sm">
            <Mail className="mr-2 h-3 w-3 text-gray-500" />
            {row.email}
          </div>
          <div className="flex items-center text-sm">
            <Phone className="mr-2 h-3 w-3 text-gray-500" />
            {row.phone_number}
          </div>
        </div>
      ),
    },
    {
      header: "Organization",
      accessorKey: "organization_name" as keyof SelectUser,
      cell: ({ row }: { row: SelectUser }) => (
        <div className="space-y-1">
          <div className="flex items-center text-sm">
            <Building className="mr-2 h-3 w-3 text-gray-500" />
            {row.organization_name}
          </div>
          <div className="flex items-center text-sm">
            <Briefcase className="mr-2 h-3 w-3 text-gray-500" />
            {row.job_role}
          </div>
        </div>
      ),
    },
    {
      header: "Status",
      cell: ({ row }: { row: SelectUser }) => (
        <div className="space-y-2">
          <div className="flex items-center">
            <span className={`flex items-center px-2 py-1 text-xs rounded-full ${
              row.is_admin ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'
            }`}>
              <Shield className="mr-1 h-3 w-3" />
              {row.is_admin ? 'Admin' : 'User'}
            </span>
          </div>
          <div className="flex items-center">
            <span className={`flex items-center px-2 py-1 text-xs rounded-full ${
              row.is_email_verified ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
            }`}>
              {row.is_email_verified ? (
                <><CheckCircle className="mr-1 h-3 w-3" /> Verified</>
              ) : (
                <><XCircle className="mr-1 h-3 w-3" /> Unverified</>
              )}
            </span>
          </div>
        </div>
      ),
    },
    {
      header: "Last Activity",
      cell: ({ row }: { row: SelectUser }) => (
        <div className="space-y-1 text-sm">
          <div className="flex items-center">
            <Clock className="mr-2 h-3 w-3 text-gray-500" />
            <span className="whitespace-nowrap">
              {formatDate(row.last_login_at)}
            </span>
          </div>
        </div>
      ),
    },
    {
      header: "Actions",
      cell: ({ row }: { row: SelectUser }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" onClick={() => handleEdit(row)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => handleDeleteClick(row.id)}
            disabled={row.is_admin} // Prevent deleting admin users
            className={row.is_admin ? "cursor-not-allowed opacity-50" : ""}
          >
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <AppLayout
      title="User Management"
      description="Manage user accounts and permissions"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> New User
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setPage(1);
              refetch();
            }}
            className="flex gap-2"
          >
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search users..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9"
              />
            </div>
            <Button type="submit">Search</Button>
          </form>
        </div>
      </div>

      <DataTable
        data={usersData?.users || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          usersData
            ? {
                currentPage: page,
                totalPages: Math.ceil(usersData.total / perPage),
                totalItems: usersData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />

      {/* Create/Edit Form Dialog */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingUser ? "Edit User" : "Create User"}
            </DialogTitle>
            <DialogDescription>
              {editingUser
                ? "Update the user details below."
                : "Fill in the details to create a new user."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="john@example.com" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="phone_number"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input placeholder="+1 (555) 123-4567" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="job_role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job Role</FormLabel>
                      <FormControl>
                        <Input placeholder="Manager" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="organization_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Organization Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Acme Corp" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="johndoe" 
                          {...field} 
                          disabled={editingUser !== null}
                        />
                      </FormControl>
                      {editingUser && (
                        <FormDescription>
                          Username cannot be changed
                        </FormDescription>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="is_admin"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 h-full">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Administrator</FormLabel>
                        <FormDescription>
                          Admins have full access to all features and settings
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{editingUser ? "New Password" : "Password"}</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder={editingUser ? "Leave blank to keep current" : "Password"} 
                          {...field} 
                        />
                      </FormControl>
                      {editingUser && (
                        <FormDescription>
                          Leave blank to keep the current password
                        </FormDescription>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder={editingUser ? "Leave blank to keep current" : "Confirm password"} 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {(createMutation.isPending || updateMutation.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {editingUser ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    editingUser ? "Update User" : "Create User"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the user and all associated data. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
