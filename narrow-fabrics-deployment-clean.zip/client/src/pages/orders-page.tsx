import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "@/components/layout/app-layout";
import { DataTable } from "@/components/ui/data-table";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Edit, 
  Trash, 
  RefreshCw,
  Eye,
  Loader2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Order, insertOrderSchema, ProductItem } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Extended schema for validation
const formSchema = insertOrderSchema.extend({
  customer_id: z.coerce.number().min(1, "Customer ID is required"),
  total_amount: z.coerce.number().min(0.01, "Total amount must be greater than 0"),
  delivery_date: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function OrdersPage() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<number | null>(null);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);

  // Fetch orders
  const {
    data: ordersData,
    isLoading,
    refetch,
  } = useQuery<{ orders: Order[], total: number }>({
    queryKey: ["/api/orders", page, perPage, selectedStatus, search],
    queryFn: async ({ queryKey }) => {
      const [_, page, perPage, status, search] = queryKey;
      let url = `/api/orders?page=${page}&limit=${perPage}`;
      if (status) url += `&status=${status}`;
      if (search) url += `&search=${search}`;
      
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Failed to fetch orders');
      }
      return res.json();
    },
  });

  // Fetch product items for order form
  const { data: productItemsData } = useQuery<{ productItems: ProductItem[], total: number }>({
    queryKey: ["/api/product-items"],
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest("POST", "/api/orders", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Order created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setIsFormDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: Partial<FormValues> }) => {
      const res = await apiRequest("PUT", `/api/orders/${id}`, values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Order updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setIsFormDialogOpen(false);
      setEditingOrder(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/orders/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Order deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setIsDeleteDialogOpen(false);
      setOrderToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      customer_id: 0,
      customer_name: "",
      status: "pending",
      total_amount: 0,
      delivery_date: "",
      notes: "",
    },
  });

  // Open the form dialog for creating
  const handleCreate = () => {
    form.reset({
      customer_id: 0,
      customer_name: "",
      status: "pending",
      total_amount: 0,
      delivery_date: "",
      notes: "",
    });
    setEditingOrder(null);
    setIsFormDialogOpen(true);
  };

  // Open the form dialog for editing
  const handleEdit = (order: Order) => {
    form.reset({
      customer_id: order.customer_id,
      customer_name: order.customer_name,
      status: order.status,
      total_amount: Number(order.total_amount),
      delivery_date: order.delivery_date ? new Date(order.delivery_date).toISOString().split('T')[0] : "",
      notes: order.notes || "",
    });
    setEditingOrder(order);
    setIsFormDialogOpen(true);
  };

  // Submit form (create or update)
  const onSubmit = (values: FormValues) => {
    if (editingOrder) {
      updateMutation.mutate({ id: editingOrder.id, values });
    } else {
      createMutation.mutate(values);
    }
  };

  // Open delete confirmation dialog
  const handleDeleteClick = (orderId: number) => {
    setOrderToDelete(orderId);
    setIsDeleteDialogOpen(true);
  };

  // Handle actual deletion after confirmation
  const handleDeleteConfirm = () => {
    if (orderToDelete) {
      deleteMutation.mutate(orderToDelete);
    }
  };

  // Format currency
  const formatCurrency = (amount: number | string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(Number(amount));
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Table columns definition
  const columns = [
    {
      header: "Order ID",
      accessorKey: "id" as keyof Order,
      cell: ({ row }: { row: Order }) => <span>#{row.id}</span>,
    },
    {
      header: "Customer",
      accessorKey: "customer_name" as keyof Order,
    },
    {
      header: "Date",
      accessorKey: "order_date" as keyof Order,
      cell: ({ row }: { row: Order }) => formatDate(row.order_date),
    },
    {
      header: "Amount",
      accessorKey: "total_amount" as keyof Order,
      cell: ({ row }: { row: Order }) => formatCurrency(row.total_amount),
    },
    {
      header: "Status",
      accessorKey: "status" as keyof Order,
      cell: ({ row }: { row: Order }) => (
        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full
          ${row.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
            row.status === 'processing' ? 'bg-blue-100 text-blue-800' :
            row.status === 'completed' ? 'bg-green-100 text-green-800' :
            'bg-red-100 text-red-800'}`}>
          {row.status.charAt(0).toUpperCase() + row.status.slice(1)}
        </span>
      ),
    },
    {
      header: "Actions",
      cell: ({ row }: { row: Order }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm">
            <Eye className="h-4 w-4 text-blue-500" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleEdit(row)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteClick(row.id)}>
            <Trash className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <AppLayout
      title="Orders"
      description="Manage your customer orders"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> New Order
          </Button>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <Select
            value={selectedStatus || "all"}
            onValueChange={(value) => {
              setSelectedStatus(value === "all" ? null : value);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="processing">Processing</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
          
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setPage(1);
              refetch();
            }}
            className="flex gap-2"
          >
            <Input
              placeholder="Search orders..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full sm:w-auto"
            />
            <Button type="submit">Search</Button>
          </form>
        </div>
      </div>

      <DataTable
        data={ordersData?.orders || []}
        columns={columns}
        isLoading={isLoading}
        pagination={
          ordersData
            ? {
                currentPage: page,
                totalPages: Math.ceil(ordersData.total / perPage),
                totalItems: ordersData.total,
                perPage: perPage,
                onPageChange: setPage,
                onPerPageChange: (newPerPage) => {
                  setPerPage(newPerPage);
                  setPage(1);
                },
              }
            : undefined
        }
      />

      {/* Create/Edit Form Dialog */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingOrder ? "Edit Order" : "Create Order"}
            </DialogTitle>
            <DialogDescription>
              {editingOrder
                ? "Update the order details below."
                : "Fill in the details to create a new order."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="customer_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer ID</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="Customer ID" 
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customer_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Customer name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="total_amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Total Amount</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          step="0.01"
                          placeholder="0.00" 
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <FormControl>
                        <Select 
                          value={field.value} 
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="processing">Processing</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="cancelled">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="delivery_date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Delivery Date</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Additional notes about the order"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {(createMutation.isPending || updateMutation.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {editingOrder ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    editingOrder ? "Update Order" : "Create Order"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the order. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
