import React, { createContext, useContext, useState, useEffect } from 'react';

interface FormatContextType {
  dateFormat: string;
  timeFormat: string;
  formatDate: (date: Date | string) => string;
  formatTime: (date: Date | string) => string;
  formatDateTime: (date: Date | string) => string;
}

const defaultDateFormat = 'MM/DD/YYYY';
const defaultTimeFormat = '12';

const FormatContext = createContext<FormatContextType>({
  dateFormat: defaultDateFormat,
  timeFormat: defaultTimeFormat,
  formatDate: () => '',
  formatTime: () => '',
  formatDateTime: () => '',
});

export const useFormatting = () => useContext(FormatContext);

interface FormatProviderProps {
  children: React.ReactNode;
}

export const FormatProvider: React.FC<FormatProviderProps> = ({ children }) => {
  const [dateFormat, setDateFormat] = useState<string>(defaultDateFormat);
  const [timeFormat, setTimeFormat] = useState<string>(defaultTimeFormat);

  // Load saved settings from localStorage on initial load
  useEffect(() => {
    const savedDateFormat = localStorage.getItem('dateFormat');
    const savedTimeFormat = localStorage.getItem('timeFormat');
    
    if (savedDateFormat) {
      setDateFormat(savedDateFormat);
    }
    
    if (savedTimeFormat) {
      setTimeFormat(savedTimeFormat);
    }
  }, []);

  // Helper function to format a date according to the user's preference
  const formatDate = (date: Date | string): string => {
    if (!date) return '';
    
    const d = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(d.getTime())) return ''; // Invalid date
    
    const year = d.getFullYear();
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    
    switch (dateFormat) {
      case 'MM/DD/YYYY':
        return `${month}/${day}/${year}`;
      case 'DD/MM/YYYY':
        return `${day}/${month}/${year}`;
      case 'YYYY-MM-DD':
        return `${year}-${month}-${day}`;
      default:
        return `${month}/${day}/${year}`;
    }
  };

  // Helper function to format a time according to the user's preference
  const formatTime = (date: Date | string): string => {
    if (!date) return '';
    
    const d = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(d.getTime())) return ''; // Invalid date
    
    const hours = d.getHours();
    const minutes = d.getMinutes().toString().padStart(2, '0');
    
    if (timeFormat === '24') {
      return `${hours.toString().padStart(2, '0')}:${minutes}`;
    } else {
      // 12-hour format
      const ampm = hours >= 12 ? 'PM' : 'AM';
      const displayHours = hours % 12 || 12; // Convert 0 to 12
      return `${displayHours}:${minutes} ${ampm}`;
    }
  };

  // Helper function to format a date and time together
  const formatDateTime = (date: Date | string): string => {
    return `${formatDate(date)} ${formatTime(date)}`;
  };

  const value = {
    dateFormat,
    timeFormat,
    formatDate,
    formatTime,
    formatDateTime,
  };

  return (
    <FormatContext.Provider value={value}>
      {children}
    </FormatContext.Provider>
  );
};