import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';

// Define the currency formatting options
interface CurrencyFormatOptions {
  showCode?: boolean;      // Whether to show the currency code (e.g., USD)
  showSymbol?: boolean;    // Whether to show the currency symbol (e.g., $)
  decimalPlaces?: number;  // Number of decimal places to show
  separateBySpace?: boolean; // Whether to separate symbol/code and amount with space
}

// Define the context shape
interface CurrencyContextType {
  currencyFormat: string;
  exchangeRate: number;
  updateCurrencyFormat: (format: string) => void;
  updateExchangeRate: (rate: number) => void;
  convertUsdToBdt: (usdAmount: number) => number;
  convertBdtToUsd: (bdtAmount: number) => number;
  formatCurrency: (amount: number | string, currencyCode?: string, options?: CurrencyFormatOptions) => string;
}

// Create the context with default values
const CurrencyContext = createContext<CurrencyContextType>({
  currencyFormat: 'usd',
  exchangeRate: 110, // Default exchange rate 1 USD = 110 BDT
  updateCurrencyFormat: () => {},
  updateExchangeRate: () => {},
  convertUsdToBdt: () => 0,
  convertBdtToUsd: () => 0,
  formatCurrency: () => '',
});

// Provider component
interface CurrencyProviderProps {
  children: ReactNode;
}

export const CurrencyProvider: React.FC<CurrencyProviderProps> = ({ children }) => {
  const [currencyFormat, setCurrencyFormat] = useState('usd');
  const [exchangeRate, setExchangeRate] = useState(110); // Default 1 USD = 110 BDT

  // Load saved settings from localStorage on component mount
  useEffect(() => {
    try {
      const savedFormat = localStorage.getItem('currencyFormat');
      const savedRate = localStorage.getItem('exchangeRate');
      
      if (savedFormat) {
        setCurrencyFormat(savedFormat);
      }
      
      if (savedRate) {
        setExchangeRate(parseFloat(savedRate));
      }
    } catch (error) {
      console.error('Error loading currency settings:', error);
    }
  }, []);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('currencyFormat', currencyFormat);
      localStorage.setItem('exchangeRate', exchangeRate.toString());
    } catch (error) {
      console.error('Error saving currency settings:', error);
    }
  }, [currencyFormat, exchangeRate]);

  // Convert USD to BDT
  const convertUsdToBdt = (usdAmount: number): number => {
    if (isNaN(usdAmount) || usdAmount <= 0) return 0;
    return parseFloat((usdAmount * exchangeRate).toFixed(2));
  };

  // Convert BDT to USD
  const convertBdtToUsd = (bdtAmount: number): number => {
    if (isNaN(bdtAmount) || bdtAmount <= 0) return 0;
    return parseFloat((bdtAmount / exchangeRate).toFixed(2));
  };

  // Update functions
  const updateCurrencyFormat = (format: string) => {
    setCurrencyFormat(format);
  };

  const updateExchangeRate = (rate: number) => {
    setExchangeRate(rate);
  };
  
  // Enhanced format currency function with flexible currency formatting options
  const formatCurrency = (
    amount: number | string, 
    currencyCode?: string,
    options?: CurrencyFormatOptions
  ): string => {
    if (typeof amount === 'string') {
      amount = parseFloat(amount);
    }
    
    if (isNaN(amount)) return '';
    
    // Use provided currency code or default to the context's currencyFormat
    const format = currencyCode ? currencyCode.toLowerCase() : currencyFormat.toLowerCase();
    
    // Default options
    const defaultOptions = {
      showCode: false,
      showSymbol: true,
      decimalPlaces: undefined, // Use currency-specific defaults
      separateBySpace: false
    };
    
    // Merge provided options with defaults
    const finalOptions = { ...defaultOptions, ...options };
    
    // Currency-specific settings
    const currencySettings: Record<string, { symbol: string, decimals: number }> = {
      usd: { symbol: '$', decimals: 2 },
      bdt: { symbol: '৳', decimals: 2 },
      eur: { symbol: '€', decimals: 2 },
      gbp: { symbol: '£', decimals: 2 },
      jpy: { symbol: '¥', decimals: 0 }, // JPY typically doesn't use decimal places
      cny: { symbol: '¥', decimals: 2 },
      inr: { symbol: '₹', decimals: 2 },
      krw: { symbol: '₩', decimals: 0 }, // KRW typically doesn't use decimal places
    };
    
    // Get currency settings or use defaults for unknown currencies
    const settings = currencySettings[format] || { 
      symbol: '', 
      decimals: 2 
    };
    
    // Use specified decimal places or currency default
    const decimals = finalOptions.decimalPlaces !== undefined 
      ? finalOptions.decimalPlaces 
      : settings.decimals;
    
    // Format the number with the appropriate decimal places
    const formattedAmount = amount.toFixed(decimals);
    
    // Build the formatted string based on options
    let result = '';
    
    // Add symbol if requested
    if (finalOptions.showSymbol && settings.symbol) {
      result += settings.symbol;
      if (finalOptions.separateBySpace) result += ' ';
    }
    
    // Add the amount
    result += formattedAmount;
    
    // Add code if requested
    if (finalOptions.showCode) {
      if (finalOptions.separateBySpace || result.length > 0) result += ' ';
      result += format.toUpperCase();
    }
    
    // If no symbol or code was specified, and the currency is not recognized,
    // append the currency code
    if (result === formattedAmount && !finalOptions.showCode) {
      result += ` ${format.toUpperCase()}`;
    }
    
    return result;
  };

  // Context value
  const value = {
    currencyFormat,
    exchangeRate,
    updateCurrencyFormat,
    updateExchangeRate,
    convertUsdToBdt,
    convertBdtToUsd,
    formatCurrency,
  };

  return (
    <CurrencyContext.Provider value={value}>
      {children}
    </CurrencyContext.Provider>
  );
};

// Custom hook to use the currency context
export const useCurrency = () => useContext(CurrencyContext);

export default CurrencyContext;