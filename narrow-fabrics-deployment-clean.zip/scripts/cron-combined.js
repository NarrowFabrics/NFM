/**
 * Combined Cron Jobs Script
 * 
 * This script runs multiple scheduled tasks:
 * 1. Collects system metrics
 * 2. Publishes scheduled notices
 * 
 * Usage: node scripts/cron-combined.js
 */
import pg from 'pg';
const { Pool } = pg;
import dotenv from 'dotenv';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get current file path for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env file
dotenv.config();

/**
 * Initialize database connection
 */
async function initDatabase() {
  // Check if we're using Neon database
  const databaseUrl = process.env.USE_NEON_DB === 'true' && process.env.NEON_DATABASE_URL 
    ? process.env.NEON_DATABASE_URL 
    : process.env.DATABASE_URL;
  
  if (!databaseUrl) {
    console.error('No database URL found. Please check your environment variables.');
    process.exit(1);
  }

  return new Pool({
    connectionString: databaseUrl,
  });
}

/**
 * Format date in YYYY-MM-DD format
 */
function formatDate(date) {
  return date.toISOString().split('T')[0];
}

/**
 * Format time in HH:MM format
 */
function formatTime(date) {
  return date.toTimeString().substring(0, 5);
}

/**
 * Collect system metrics and store them in the database
 */
async function collectSystemMetrics(pool) {
  console.log('Collecting system metrics...');
  
  try {
    // Get CPU usage (average load divided by number of CPUs)
    const cpuCount = os.cpus().length;
    const loadAvg = os.loadavg()[0];
    const cpuUsage = (loadAvg / cpuCount) * 100;
    
    // Get memory usage
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const usedMemory = totalMemory - freeMemory;
    const memoryUsage = (usedMemory / totalMemory) * 100;
    
    // Get disk usage (simulated for now)
    const diskTotal = 100;  // GB
    const diskUsage = 45;   // Percentage
    
    // Get active users (simulated for now)
    const activeUsers = Math.floor(Math.random() * 20) + 1;
    
    // Measure API response time (simulated for now)
    const responseTime = Math.floor(Math.random() * 200) + 50; // 50-250ms
    
    // Simulated DB metrics
    const dbConnections = Math.floor(Math.random() * 10) + 1;
    const dbQueriesPerSecond = Math.random() * 50;
    const apiRequestsPerMinute = Math.floor(Math.random() * 100);
    const errorCount = Math.floor(Math.random() * 5);
    
    // Insert metrics into database
    const result = await pool.query(
      `INSERT INTO system_metrics (
        cpu_usage, memory_usage, memory_total, disk_usage, disk_total,
        active_users, response_time, db_connections, db_queries_per_second,
        api_requests_per_minute, error_count, metadata
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *`,
      [
        parseFloat(cpuUsage.toFixed(2)),
        parseFloat(memoryUsage.toFixed(2)),
        parseFloat((totalMemory / (1024 * 1024 * 1024)).toFixed(2)), // Convert to GB
        diskUsage,
        diskTotal,
        activeUsers,
        responseTime,
        dbConnections,
        parseFloat(dbQueriesPerSecond.toFixed(2)),
        apiRequestsPerMinute,
        errorCount,
        JSON.stringify({})
      ]
    );
    
    console.log('System metrics collected and stored:', result.rows[0]);
    
    return result.rows[0];
  } catch (error) {
    console.error('Error collecting system metrics:', error);
    return null;
  }
}

/**
 * Check for scheduled notices and publish them if their time has come
 */
async function checkScheduledNotices(pool) {
  const now = new Date();
  
  console.log(`[${now.toISOString()}] Checking scheduled notices...`);
  console.log(`Current timestamp: ${now.toISOString()}`);
  
  try {
    // Find and publish notices that are scheduled for now or earlier
    const result = await pool.query(
      `UPDATE notices 
       SET is_published = true, updated_at = $1
       WHERE is_scheduled = true
       AND is_published = false
       AND start_date <= $1
       RETURNING id, title, start_date`,
      [now]
    );
    
    const publishedNotices = result.rows;
    
    if (publishedNotices.length > 0) {
      console.log(`Published ${publishedNotices.length} notices:`);
      publishedNotices.forEach(notice => {
        const scheduledDate = new Date(notice.start_date);
        console.log(`  - [${notice.id}] ${notice.title} (scheduled for ${scheduledDate.toLocaleString()})`);
      });
    } else {
      console.log('No notices to publish at this time.');
    }
    
    return {
      published: publishedNotices.length,
      notices: publishedNotices
    };
  } catch (error) {
    console.error('Error publishing scheduled notices:', error);
    return {
      published: 0,
      notices: []
    };
  }
}

/**
 * Main execution function
 */
async function main() {
  let pool;
  
  try {
    pool = await initDatabase();
    console.log('Database connection established.');
    
    // Run all cron jobs in sequence
    const metricsResult = await collectSystemMetrics(pool);
    const noticesResult = await checkScheduledNotices(pool);
    
    // Summary
    console.log('\nCron Jobs Summary:');
    console.log(`- System metrics collected: ${metricsResult ? 'Success' : 'Failed'}`);
    console.log(`- Notices published: ${noticesResult.published}`);
    
    console.log('\nAll scheduled tasks completed successfully.');
  } catch (error) {
    console.error('Error executing scheduled tasks:', error);
  } finally {
    if (pool) {
      await pool.end();
      console.log('Database connection closed.');
    }
  }
}

// Execute the main function
main();