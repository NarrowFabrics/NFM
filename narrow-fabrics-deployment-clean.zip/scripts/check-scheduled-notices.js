/**
 * Scheduled Notice Publisher Script
 * 
 * This script checks for notices that are scheduled to be published
 * and automatically publishes them when their scheduled date/time is reached.
 * 
 * Usage: node scripts/check-scheduled-notices.js
 */
import pg from 'pg';
const { Pool } = pg;
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get current file path for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env file
dotenv.config();

/**
 * Initialize database connection
 */
async function initDatabase() {
  // Check if we're using Neon database
  const databaseUrl = process.env.USE_NEON_DB === 'true' && process.env.NEON_DATABASE_URL 
    ? process.env.NEON_DATABASE_URL 
    : process.env.DATABASE_URL;
  
  if (!databaseUrl) {
    console.error('No database URL found. Please check your environment variables.');
    process.exit(1);
  }

  return new Pool({
    connectionString: databaseUrl,
  });
}

/**
 * Format date in YYYY-MM-DD format
 */
function formatDate(date) {
  return date.toISOString().split('T')[0];
}

/**
 * Format time in HH:MM format
 */
function formatTime(date) {
  return date.toTimeString().substring(0, 5);
}

/**
 * Check for scheduled notices and publish them if their time has come
 */
async function checkScheduledNotices(pool) {
  const now = new Date();
  
  console.log(`[${now.toISOString()}] Checking scheduled notices...`);
  console.log(`Current timestamp: ${now.toISOString()}`);
  
  try {
    // Find and publish notices that are scheduled for now or earlier
    const result = await pool.query(
      `UPDATE notices 
       SET is_published = true, updated_at = $1
       WHERE is_scheduled = true
       AND is_published = false
       AND start_date <= $1
       RETURNING id, title, start_date`,
      [now]
    );
    
    const publishedNotices = result.rows;
    
    if (publishedNotices.length > 0) {
      console.log(`Published ${publishedNotices.length} notices:`);
      publishedNotices.forEach(notice => {
        const scheduledDate = new Date(notice.start_date);
        console.log(`  - [${notice.id}] ${notice.title} (scheduled for ${scheduledDate.toLocaleString()})`);
      });
    } else {
      console.log('No notices to publish at this time.');
    }
    
    return {
      published: publishedNotices.length,
      notices: publishedNotices
    };
  } catch (error) {
    console.error('Error publishing scheduled notices:', error);
    return {
      published: 0,
      notices: []
    };
  }
}

/**
 * Main execution function
 */
async function main() {
  let pool;
  
  try {
    pool = await initDatabase();
    await checkScheduledNotices(pool);
    console.log('Check completed successfully.');
  } catch (error) {
    console.error('Error executing scheduled task:', error);
  } finally {
    if (pool) {
      await pool.end();
    }
  }
}

// Execute the main function
main();