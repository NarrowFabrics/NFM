/**
 * Cron job script to collect system metrics regularly
 * 
 * This script schedules the collection of system metrics at regular intervals
 * and can be run continuously in the background.
 * 
 * Usage: node scripts/cron-metrics.js
 */

import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

// Get current directory equivalent to __dirname in CommonJS
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Default interval is 1 minute (60000 ms)
const INTERVAL_MS = process.env.METRICS_INTERVAL_MS || 60000;

console.log(`Starting system metrics collection, running every ${INTERVAL_MS}ms`);

// Function to run the collection script
function collectMetrics() {
  console.log(`Running metrics collection at ${new Date().toISOString()}`);
  
  const metricsScript = path.join(__dirname, 'collect-system-metrics.js');
  const process = spawn('node', [metricsScript], { 
    stdio: 'inherit',
    detached: false
  });
  
  process.on('error', (error) => {
    console.error('Failed to start metrics collection process:', error);
  });
}

// Run immediately on start
collectMetrics();

// Then schedule to run at the specified interval
setInterval(collectMetrics, INTERVAL_MS);

console.log('Metrics collection scheduler is running. Press Ctrl+C to stop.');