#!/bin/bash

# Backup the file
cp server/storage.ts server/storage.ts.bak

# Update db. calls to db.query. calls
sed -i 's/db\.\([a-zA-Z]*\)(/{REPLACED}/g' server/storage.ts
sed -i 's/{REPLACED}/db.query.\1(/g' server/storage.ts

# Update standalone db. references 
sed -i 's/let query = db\./let query = db.query./g' server/storage.ts
sed -i 's/let countQuery = db\./let countQuery = db.query./g' server/storage.ts
sed -i 's/return db\./return db.query./g' server/storage.ts

# Count remaining instances that need fixing
echo "Remaining db. calls not fixed:"
grep -c "db\." server/storage.ts
