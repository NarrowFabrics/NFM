import 'dotenv/config';
import pg from 'pg';
const { Pool } = pg;

async function getDatabaseUrl() {
  // Use NEON_DATABASE_URL if available, otherwise fall back to DATABASE_URL
  return process.env.NEON_DATABASE_URL || process.env.DATABASE_URL;
}

async function updateNoticesTable() {
  console.log('Updating notices table...');
  
  const dbUrl = await getDatabaseUrl();
  if (!dbUrl) {
    throw new Error('Database URL not found in environment variables');
  }

  // Create a database connection
  const pool = new Pool({
    connectionString: dbUrl,
    ssl: dbUrl?.includes("localhost") ? false : { rejectUnauthorized: false }
  });

  try {
    // Define the columns to check and add if missing
    const columnsToAdd = [
      { name: 'is_scheduled', dataType: 'BOOLEAN NOT NULL DEFAULT false' },
      { name: 'department', dataType: 'TEXT' },
      { name: 'target_roles', dataType: 'TEXT' },
      { name: 'expires_at', dataType: 'TIMESTAMP' }
    ];

    // Check which columns exist in the notices table
    for (const column of columnsToAdd) {
      const columnExistsResult = await pool.query(`
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name='notices' AND column_name=$1
      `, [column.name]);

      // Add column if it doesn't exist
      if (columnExistsResult.rows.length === 0) {
        console.log(`Adding ${column.name} column to notices table...`);
        await pool.query(`
          ALTER TABLE notices
          ADD COLUMN ${column.name} ${column.dataType}
        `);
        console.log(`Added ${column.name} column successfully`);
      } else {
        console.log(`${column.name} column already exists`);
      }
    }

    // Verify the notices table structure
    const tableInfo = await pool.query(`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name='notices'
      ORDER BY ordinal_position
    `);
    
    console.log('Current notices table structure:');
    tableInfo.rows.forEach(row => {
      console.log(`${row.column_name} (${row.data_type}) ${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'}`);
    });

  } catch (error) {
    console.error('Error updating notices table:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

async function main() {
  try {
    await updateNoticesTable();
    console.log('Successfully updated notices table');
  } catch (error) {
    console.error('Failed to update notices table:', error);
    process.exit(1);
  }
}

main();