import { pgTable, text, serial, integer, boolean, timestamp, numeric, jsonb, varchar, foreignKey, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users and Roles
export const Permission = z.enum([
  "dashboard.view",
  "orders.view", "orders.create", "orders.edit", "orders.delete",
  "production.view", "production.create", "production.edit", "production.delete",
  "materials.view", "materials.create", "materials.edit", "materials.delete",
  "users.view", "users.create", "users.edit", "users.delete",
  "roles.view", "roles.create", "roles.edit", "roles.delete",
  "settings.view", "settings.edit",
  "audit.view"
]);

export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  permissions: text("permissions").array().notNull(),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

// Users table with role reference
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone_number: text("phone_number").notNull(),
  job_role: text("job_role").notNull(),
  organization_name: text("organization_name").notNull(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role_id: integer("role_id").references(() => roles.id),
  is_admin: boolean("is_admin").notNull().default(false),
  is_email_verified: boolean("is_email_verified").notNull().default(false),
  verification_token: text("verification_token"),
  created_at: timestamp("created_at").defaultNow(),
  last_login_at: timestamp("last_login_at"),
  last_activity_at: timestamp("last_activity_at")
});

export const usersRelations = relations(users, ({ one, many }) => ({
  role: one(roles, {
    fields: [users.role_id],
    references: [roles.id]
  }),
  activities: many(userActivities),
  productionPlans: many(productionPlans)
}));

export const userActivities = pgTable("user_activities", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(),
  details: jsonb("details").default({}),
  timestamp: timestamp("timestamp").defaultNow()
});

export const userActivitiesRelations = relations(userActivities, ({ one }) => ({
  user: one(users, {
    fields: [userActivities.user_id],
    references: [users.id]
  })
}));

export const itemUnits = pgTable("item_units", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(),
  description: text("description")
});

export const itemOverheads = pgTable("item_overheads", {
  id: serial("id").primaryKey(),
  item_name: varchar("item_name", { length: 100 }).notNull(),
  overhead_percentage: numeric("overhead_percentage", { precision: 5, scale: 2 }).notNull()
});

export const itemConsumptions = pgTable("item_consumptions", {
  id: serial("id").primaryKey(),
  item_name: varchar("item_name", { length: 100 }).notNull(),
  consumption_percentage: numeric("consumption_percentage", { precision: 5, scale: 2 }).notNull()
});

export const yarnTypes = pgTable("yarn_types", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  is_active: boolean("is_active").notNull().default(true)
});

export const colorTypes = pgTable("color_types", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow()
});

export const materials = pgTable("materials", {
  id: serial("id").primaryKey(),
  category: varchar("category", { length: 50 }).notNull(),
  yarn_name: varchar("yarn_name", { length: 100 }).notNull(),
  color_type: varchar("color_type", { length: 50 }).notNull(),
  price_per_kg: numeric("price_per_kg", { precision: 10, scale: 2 }).notNull(),
  properties: jsonb("properties").default({}),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

export const productItems = pgTable("product_items", {
  id: serial("id").primaryKey(),
  category: varchar("category", { length: 50 }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  specifications: jsonb("specifications").default([]),
  created_at: timestamp("created_at").defaultNow()
});

export const productionPlans = pgTable("production_plans", {
  id: serial("id").primaryKey(),
  buyer_name: varchar("buyer_name", { length: 100 }).notNull(),
  factory_name: varchar("factory_name", { length: 100 }).notNull(),
  item_unit: varchar("item_unit", { length: 50 }).notNull(),
  item_name: varchar("item_name", { length: 100 }).notNull(),
  quantity: integer("quantity").notNull(),
  price_per_yard: numeric("price_per_yard", { precision: 10, scale: 2 }).notNull(),
  machine_hours: integer("machine_hours").notNull(),
  created_at: timestamp("created_at").defaultNow(),
  created_by: integer("created_by").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("pending")
});

export const productionPlansRelations = relations(productionPlans, ({ one }) => ({
  creator: one(users, {
    fields: [productionPlans.created_by],
    references: [users.id]
  })
}));

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customer_id: integer("customer_id").notNull(),
  customer_name: varchar("customer_name", { length: 100 }).notNull(),
  order_date: timestamp("order_date").defaultNow(),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  total_amount: numeric("total_amount", { precision: 10, scale: 2 }).notNull(),
  delivery_date: timestamp("delivery_date"),
  notes: text("notes"),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

export const ordersRelations = relations(orders, ({ many }) => ({
  items: many(orderItems)
}));

export const partOfItems = pgTable("part_of_items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  is_active: boolean("is_active").notNull().default(true)
});

export const itemSettings = pgTable("item_settings", {
  id: serial("id").primaryKey(),
  item_name: varchar("item_name", { length: 100 }).notNull(),
  overhead_percentage: numeric("overhead_percentage", { precision: 5, scale: 2 }).notNull(),
  consumption_percentage: numeric("consumption_percentage", { precision: 5, scale: 2 }).notNull(),
  is_active: boolean("is_active").notNull().default(true)
});

export const dyeingChanges = pgTable("dyeing_changes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  color_type_id: integer("color_type_id").references(() => colorTypes.id),
  charge_per_kg: numeric("charge_per_kg", { precision: 10, scale: 2 }).notNull(),
  process_time_minutes: integer("process_time_minutes").notNull(),
  temperature_celsius: integer("temperature_celsius").notNull(),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

export const dyeingChangesRelations = relations(dyeingChanges, ({ one }) => ({
  colorType: one(colorTypes, {
    fields: [dyeingChanges.color_type_id],
    references: [colorTypes.id]
  })
}));

export const dyeingCharges = pgTable("dyeing_charges", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  charge_per_kg: numeric("charge_per_kg", { precision: 10, scale: 2 }).notNull(),
  is_active: boolean("is_active").notNull().default(true)
});

export const unitSettings = pgTable("unit_settings", {
  id: serial("id").primaryKey(),
  unit_name: varchar("unit_name", { length: 100 }).notNull().unique(),
  production_rate: numeric("production_rate", { precision: 10, scale: 2 }).default("0"),
  is_active: boolean("is_active").notNull().default(true)
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  order_id: integer("order_id").notNull().references(() => orders.id),
  product_item_id: integer("product_item_id").notNull().references(() => productItems.id),
  quantity: integer("quantity").notNull(),
  price_per_unit: numeric("price_per_unit", { precision: 10, scale: 2 }).notNull(),
  total_price: numeric("total_price", { precision: 10, scale: 2 }).notNull(),
  specifications: jsonb("specifications").default({})
});

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.order_id],
    references: [orders.id]
  }),
  productItem: one(productItems, {
    fields: [orderItems.product_item_id],
    references: [productItems.id]
  })
}));

export const productionUnitSettingFormSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(1, "Name is required"),
  description: z.string(),
  unit_type: z.string().min(1, "Unit type is required"),
  capacity: z.number().min(0, "Capacity must be positive"),
  status: z.enum(["active", "inactive", "maintenance"]),
  maintenance_schedule: z.string().optional(),
  last_maintenance: z.date().optional(),
  created_at: z.date().optional(),
  updated_at: z.date().optional()
});

export type ProductionUnitSettingForm = z.infer<typeof productionUnitSettingFormSchema>;
export type InsertProductionUnitSettingForm = Omit<ProductionUnitSettingForm, "id" | "created_at" | "updated_at">;


export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  is_email_verified: true,
  verification_token: true,
  created_at: true,
  last_login_at: true,
  last_activity_at: true
});

export const insertItemUnitSchema = createInsertSchema(itemUnits).omit({ id: true });
export const insertYarnTypeSchema = createInsertSchema(yarnTypes).omit({ id: true });
export const insertColorTypeSchema = createInsertSchema(colorTypes).omit({ id: true, created_at: true });
export const insertMaterialSchema = createInsertSchema(materials).omit({ id: true, created_at: true, updated_at: true });
export const insertProductItemSchema = createInsertSchema(productItems).omit({ id: true, created_at: true });
export const insertProductionPlanSchema = createInsertSchema(productionPlans).omit({ id: true, created_at: true });
export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, order_date: true, created_at: true, updated_at: true });
export const insertOrderItemSchema = createInsertSchema(orderItems).omit({ id: true });
export const insertItemSettingSchema = createInsertSchema(itemSettings).omit({ id: true });
export const insertDyeingChargeSchema = createInsertSchema(dyeingCharges).omit({ id: true });
export const insertUnitSettingSchema = createInsertSchema(unitSettings).omit({ id: true });
export const insertUserActivitySchema = createInsertSchema(userActivities).omit({ id: true, timestamp: true });

export type Permission = z.infer<typeof Permission>;

export type InsertRole = typeof roles.$inferInsert;
export type Role = typeof roles.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertItemUnit = z.infer<typeof insertItemUnitSchema>;
export type ItemUnit = typeof itemUnits.$inferSelect;

export type InsertYarnType = z.infer<typeof insertYarnTypeSchema>;
export type YarnType = typeof yarnTypes.$inferSelect;

export type InsertColorType = z.infer<typeof insertColorTypeSchema>;
export type ColorType = typeof colorTypes.$inferSelect;

export type InsertMaterial = z.infer<typeof insertMaterialSchema>;
export type Material = typeof materials.$inferSelect;

export type InsertProductItem = z.infer<typeof insertProductItemSchema>;
export type ProductItem = typeof productItems.$inferSelect;

export type InsertProductionPlan = z.infer<typeof insertProductionPlanSchema>;
export type ProductionPlan = typeof productionPlans.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

export type InsertItemSetting = z.infer<typeof insertItemSettingSchema>;
export type ItemSetting = typeof itemSettings.$inferSelect;

export type InsertDyeingCharge = z.infer<typeof insertDyeingChargeSchema>;
export type DyeingChange = typeof dyeingChanges.$inferSelect;
export type InsertDyeingChange = typeof dyeingChanges.$inferInsert;
export type DyeingCharge = typeof dyeingCharges.$inferSelect;

export type InsertUnitSetting = z.infer<typeof insertUnitSettingSchema>;
export type UnitSetting = typeof unitSettings.$inferSelect;

export type InsertUserActivity = z.infer<typeof insertUserActivitySchema>;
export type UserActivity = typeof userActivities.$inferSelect;

export const rolesRelations = relations(roles, ({ many }) => ({
  users: many(users)
}));

// Narrow Fabrics Settings Tables

// Add fabric parts table (like elastic parts)
export const fabricParts = pgTable("fabric_parts", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Add production unit settings table
export const productionUnitSettings = pgTable("production_unit_settings", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  description: text("description"),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Add yarn categories table
export const yarnCategories = pgTable("yarn_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Add yarn types table
export const fabricYarnTypes = pgTable("fabric_yarn_types", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Add yarn count table
export const yarnCounts = pgTable("yarn_counts", {
  id: serial("id").primaryKey(),
  count: varchar("count", { length: 50 }).notNull().unique(),
  description: text("description"),
  price_bdt: numeric("price_bdt", { precision: 10, scale: 2 }),
  price_usd: numeric("price_usd", { precision: 10, scale: 2 }),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Add yarn prices table
export const yarnPrices = pgTable("yarn_prices", {
  id: serial("id").primaryKey(),
  yarn_type_id: integer("yarn_type_id").references(() => fabricYarnTypes.id),
  price_per_kg: numeric("price_per_kg", { precision: 10, scale: 2 }).notNull(),
  effective_date: timestamp("effective_date").defaultNow(),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Add profit margins table
export const profitMargins = pgTable("profit_margins", {
  id: serial("id").primaryKey(),
  production_unit: varchar("production_unit", { length: 100 }).notNull(),
  item_name: varchar("item_name", { length: 100 }).notNull(),
  profit_margin: numeric("profit_margin", { precision: 5, scale: 2 }).notNull(),
  description: text("description"),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Backup system tables
export const backups = pgTable("backups", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  description: text("description"),
  file_size: integer("file_size").notNull(),
  backup_type: text("backup_type").notNull(), // full, differential, partial
  version: text("version").notNull(),
  is_encrypted: boolean("is_encrypted").default(false),
  is_compressed: boolean("is_compressed").default(false),
  tables_included: text("tables_included").array(), // For partial backups
  storage_path: text("storage_path").notNull(),
  created_by: integer("created_by").references(() => users.id),
  created_at: timestamp("created_at").defaultNow(),
  retention_period: integer("retention_period"), // Days to keep backup
  is_auto: boolean("is_auto").default(false), // Is auto-generated
});

export const backupSchedules = pgTable("backup_schedules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  frequency: text("frequency").notNull(), // daily, weekly, monthly
  day_of_week: integer("day_of_week"), // 0-6 for weekly
  day_of_month: integer("day_of_month"), // 1-31 for monthly
  time_of_day: varchar("time_of_day", { length: 8 }).notNull(), // HH:MM:SS format
  backup_type: text("backup_type").notNull(), // full, differential, partial
  tables_to_include: text("tables_to_include").array(), // For partial backups
  is_encrypted: boolean("is_encrypted").default(false),
  is_compressed: boolean("is_compressed").default(false),
  retention_period: integer("retention_period").notNull(), // Days to keep backup
  is_active: boolean("is_active").default(true),
  created_by: integer("created_by").references(() => users.id),
  created_at: timestamp("created_at").defaultNow(),
  last_run: timestamp("last_run"),
  next_run: timestamp("next_run"),
});

export const backupNotifications = pgTable("backup_notifications", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id),
  email_notification: boolean("email_notification").default(false),
  push_notification: boolean("push_notification").default(false),
  notify_on_success: boolean("notify_on_success").default(true),
  notify_on_failure: boolean("notify_on_failure").default(true),
  created_at: timestamp("created_at").defaultNow(),
});

export const backupVersions = pgTable("backup_versions", {
  id: serial("id").primaryKey(),
  backup_id: integer("backup_id").references(() => backups.id),
  version_number: integer("version_number").notNull(),
  changes_description: text("changes_description"),
  created_at: timestamp("created_at").defaultNow(),
});

// Notice system tables
export const notices = pgTable("notices", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  priority: text("priority").notNull().default("normal"), // 'low', 'normal', 'high', 'urgent'
  start_date: text("start_date"), // YYYY-MM-DD format for scheduled date
  start_time: text("start_time"), // HH:MM format for scheduled time
  end_date: text("end_date"), // YYYY-MM-DD format for end date (optional)
  end_time: text("end_time"), // HH:MM format for end time (optional)
  is_published: boolean("is_published").notNull().default(false),
  is_scheduled: boolean("is_scheduled").notNull().default(false),
  created_by: integer("created_by").notNull().references(() => users.id),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at"),
  department: text("department"), // Optional department targeting
  target_roles: text("target_roles"), // Comma-separated list of role IDs
});

// Create insert schemas for new tables
export const insertFabricPartSchema = createInsertSchema(fabricParts).omit({ id: true, created_at: true });
export const insertProductionUnitSettingSchema = createInsertSchema(productionUnitSettings).omit({ id: true, created_at: true });
export const insertYarnCategorySchema = createInsertSchema(yarnCategories).omit({ id: true, created_at: true });
export const insertFabricYarnTypeSchema = createInsertSchema(fabricYarnTypes).omit({ id: true, created_at: true });
export const insertYarnCountSchema = createInsertSchema(yarnCounts).omit({ id: true, created_at: true });
export const insertYarnPriceSchema = createInsertSchema(yarnPrices).omit({ id: true, created_at: true });
export const insertProfitMarginSchema = createInsertSchema(profitMargins).omit({ id: true, created_at: true });

// Create types for new tables
export type FabricPart = typeof fabricParts.$inferSelect;
export type InsertFabricPart = z.infer<typeof insertFabricPartSchema>;

export type ProductionUnitSettingDb = typeof productionUnitSettings.$inferSelect;
export type InsertProductionUnitSettingDb = z.infer<typeof insertProductionUnitSettingSchema>;

export type YarnCategory = typeof yarnCategories.$inferSelect;
export type InsertYarnCategory = z.infer<typeof insertYarnCategorySchema>;

export type FabricYarnType = typeof fabricYarnTypes.$inferSelect;
export type InsertFabricYarnType = z.infer<typeof insertFabricYarnTypeSchema>;

export type YarnCount = typeof yarnCounts.$inferSelect;
export type InsertYarnCount = z.infer<typeof insertYarnCountSchema>;

export type YarnPrice = typeof yarnPrices.$inferSelect;
export type InsertYarnPrice = z.infer<typeof insertYarnPriceSchema>;

export type ProfitMargin = typeof profitMargins.$inferSelect;
export type InsertProfitMargin = z.infer<typeof insertProfitMarginSchema>;

// Backup system types
export const insertBackupSchema = createInsertSchema(backups).omit({ id: true, created_at: true });
export const insertBackupScheduleSchema = createInsertSchema(backupSchedules).omit({ id: true, created_at: true, last_run: true, next_run: true });
export const insertBackupNotificationSchema = createInsertSchema(backupNotifications).omit({ id: true, created_at: true });
export const insertBackupVersionSchema = createInsertSchema(backupVersions).omit({ id: true, created_at: true });
// Create the base schema first
const baseNoticeSchema = createInsertSchema(notices).omit({ id: true, created_at: true, updated_at: true });

// Then modify it to handle string dates for API requests
export const insertNoticeSchema = baseNoticeSchema.extend({
  // Date fields in YYYY-MM-DD format
  start_date: z.string().optional(),
  end_date: z.string().optional(),
  // Time fields in HH:MM format
  start_time: z.string().optional(),
  end_time: z.string().optional(),
  // Handle target_roles as either string or string array and convert to comma-separated string
  target_roles: z.union([
    z.string(),
    z.array(z.string()).transform(arr => arr.join(',')),
    z.undefined()
  ]).optional(),
  // Ensure department is optional
  department: z.string().optional().or(z.literal('')),
});

export type Backup = typeof backups.$inferSelect;
export type InsertBackup = z.infer<typeof insertBackupSchema>;

export type BackupSchedule = typeof backupSchedules.$inferSelect;
export type InsertBackupSchedule = z.infer<typeof insertBackupScheduleSchema>;

export type BackupNotification = typeof backupNotifications.$inferSelect;
export type InsertBackupNotification = z.infer<typeof insertBackupNotificationSchema>;

export type BackupVersion = typeof backupVersions.$inferSelect;
export type InsertBackupVersion = z.infer<typeof insertBackupVersionSchema>;

// Notice types
export type Notice = typeof notices.$inferSelect;
export type InsertNotice = z.infer<typeof insertNoticeSchema>;

// Price quotation system
export const priceQuotations = pgTable("price_quotations", {
  id: serial("id").primaryKey(),
  reference_no: varchar("reference_no", { length: 50 }).notNull(),
  customer_type: varchar("customer_type", { length: 50 }),
  customer_name: varchar("customer_name", { length: 100 }).notNull(),
  customer_contact: varchar("customer_contact", { length: 100 }),
  customer_email: varchar("customer_email", { length: 100 }),
  customer_address: text("customer_address"),
  
  contact_person: varchar("contact_person", { length: 100 }),
  contact_designation: varchar("contact_designation", { length: 100 }),
  
  inquiry_type: varchar("inquiry_type", { length: 50 }),
  production_unit: varchar("production_unit", { length: 100 }).notNull(),
  item_name: varchar("item_name", { length: 100 }).notNull(),
  size_width: numeric("size_width", { precision: 10, scale: 2 }),
  size_unit: varchar("size_unit", { length: 10 }).default("MM"),
  weight_gram_yds: numeric("weight_gram_yds", { precision: 10, scale: 2 }),
  length_unit: varchar("length_unit", { length: 10 }).default("YDS"),
  
  price_per_unit: numeric("price_per_unit", { precision: 10, scale: 2 }),
  price_currency: varchar("price_currency", { length: 10 }).default("USD"),
  additional_price_percentage: numeric("additional_price_percentage", { precision: 5, scale: 2 }).default("0"),
  payment_terms: varchar("payment_terms", { length: 50 }),
  delivery_terms: varchar("delivery_terms", { length: 50 }),
  remarks: text("remarks"),
  article_number: varchar("article_number", { length: 100 }),
  
  elastic_parts_data: jsonb("elastic_parts_data").default([]),
  
  created_by: integer("created_by").references(() => users.id),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
  is_active: boolean("is_active").notNull().default(true)
});

export const insertPriceQuotationSchema = createInsertSchema(priceQuotations).omit({ 
  id: true, 
  created_at: true, 
  updated_at: true 
});

export type PriceQuotation = typeof priceQuotations.$inferSelect;
export type InsertPriceQuotation = z.infer<typeof insertPriceQuotationSchema>;

// System Metrics for Real-time Performance Monitoring
export const systemMetrics = pgTable("system_metrics", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").defaultNow(),
  cpu_usage: numeric("cpu_usage", { precision: 5, scale: 2 }).notNull(),
  memory_usage: numeric("memory_usage", { precision: 5, scale: 2 }).notNull(),
  memory_total: numeric("memory_total", { precision: 10, scale: 2 }).notNull(),
  disk_usage: numeric("disk_usage", { precision: 5, scale: 2 }).notNull(),
  disk_total: numeric("disk_total", { precision: 10, scale: 2 }).notNull(),
  active_users: integer("active_users").notNull(),
  response_time: numeric("response_time", { precision: 10, scale: 2 }).notNull(),
  db_connections: integer("db_connections").notNull(),
  db_queries_per_second: numeric("db_queries_per_second", { precision: 10, scale: 2 }).notNull(),
  api_requests_per_minute: integer("api_requests_per_minute").notNull(),
  error_count: integer("error_count").notNull(),
  metadata: jsonb("metadata").default({})
});

export const insertSystemMetricSchema = createInsertSchema(systemMetrics).omit({ 
  id: true, 
  timestamp: true
});

export type SystemMetric = typeof systemMetrics.$inferSelect;
export type InsertSystemMetric = z.infer<typeof insertSystemMetricSchema>;