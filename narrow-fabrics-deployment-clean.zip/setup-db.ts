import pg from 'pg';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
import path from 'path';

// Load environment variables from .env file
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const { Pool } = pg;

async function main() {
  console.log('Setting up database...');
  console.log('USE_NEON_DB:', process.env.USE_NEON_DB);
  
  try {
    // Determine which database URL to use
    const useNeonDb = process.env.USE_NEON_DB === 'true';
    const connectionString = useNeonDb && process.env.NEON_DATABASE_URL 
      ? process.env.NEON_DATABASE_URL 
      : process.env.DATABASE_URL;
    
    console.log(`Using ${useNeonDb ? 'Neon cloud' : 'local'} database for setup`);
    
    // Use the pg Pool for direct queries with SSL for Neon
    const pool = new Pool({ 
      connectionString, 
      ssl: useNeonDb ? { rejectUnauthorized: false } : undefined 
    });
    
    // Create the schema directly using the schema definition
    console.log('Creating database schema...');
    
    // Use direct queries to create tables in the right order
    await pool.query(`
      CREATE TABLE IF NOT EXISTS "users" (
        "id" SERIAL PRIMARY KEY,
        "name" TEXT NOT NULL,
        "email" TEXT NOT NULL UNIQUE,
        "phone_number" TEXT NOT NULL,
        "job_role" TEXT NOT NULL,
        "organization_name" TEXT NOT NULL,
        "username" TEXT NOT NULL UNIQUE,
        "password" TEXT NOT NULL,
        "role_id" INTEGER,
        "is_admin" BOOLEAN NOT NULL DEFAULT false,
        "is_email_verified" BOOLEAN NOT NULL DEFAULT false,
        "verification_token" TEXT,
        "created_at" TIMESTAMP DEFAULT NOW(),
        "last_login_at" TIMESTAMP,
        "last_activity_at" TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS "user_activities" (
        "id" SERIAL PRIMARY KEY,
        "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
        "action" VARCHAR(100) NOT NULL,
        "details" JSONB DEFAULT '{}',
        "timestamp" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "item_units" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(50) NOT NULL UNIQUE,
        "description" TEXT
      );
      
      CREATE TABLE IF NOT EXISTS "item_overheads" (
        "id" SERIAL PRIMARY KEY,
        "item_name" VARCHAR(100) NOT NULL,
        "overhead_percentage" DECIMAL(5,2) NOT NULL
      );
      
      CREATE TABLE IF NOT EXISTS "item_consumptions" (
        "id" SERIAL PRIMARY KEY,
        "item_name" VARCHAR(100) NOT NULL,
        "consumption_percentage" DECIMAL(5,2) NOT NULL
      );
      
      CREATE TABLE IF NOT EXISTS "yarn_types" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true
      );
      
      CREATE TABLE IF NOT EXISTS "color_types" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(50) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "materials" (
        "id" SERIAL PRIMARY KEY,
        "category" VARCHAR(50) NOT NULL,
        "yarn_name" VARCHAR(100) NOT NULL,
        "color_type" VARCHAR(50) NOT NULL,
        "price_per_kg" DECIMAL(10,2) NOT NULL,
        "properties" JSONB DEFAULT '{}',
        "created_at" TIMESTAMP DEFAULT NOW(),
        "updated_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "product_items" (
        "id" SERIAL PRIMARY KEY,
        "category" VARCHAR(50) NOT NULL,
        "name" VARCHAR(100) NOT NULL,
        "specifications" JSONB DEFAULT '[]',
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "production_plans" (
        "id" SERIAL PRIMARY KEY,
        "buyer_name" VARCHAR(100) NOT NULL,
        "factory_name" VARCHAR(100) NOT NULL,
        "item_unit" VARCHAR(50) NOT NULL,
        "item_name" VARCHAR(100) NOT NULL,
        "quantity" INTEGER NOT NULL,
        "price_per_yard" DECIMAL(10,2) NOT NULL,
        "machine_hours" INTEGER NOT NULL,
        "created_at" TIMESTAMP DEFAULT NOW(),
        "created_by" INTEGER NOT NULL,
        "status" VARCHAR(20) NOT NULL DEFAULT 'pending'
      );
      
      CREATE TABLE IF NOT EXISTS "orders" (
        "id" SERIAL PRIMARY KEY,
        "customer_id" INTEGER NOT NULL,
        "customer_name" VARCHAR(100) NOT NULL,
        "order_date" TIMESTAMP DEFAULT NOW(),
        "status" VARCHAR(20) NOT NULL DEFAULT 'pending',
        "total_amount" DECIMAL(10,2) NOT NULL,
        "delivery_date" TIMESTAMP,
        "notes" TEXT,
        "created_at" TIMESTAMP DEFAULT NOW(),
        "updated_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "part_of_items" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true
      );
      
      CREATE TABLE IF NOT EXISTS "item_settings" (
        "id" SERIAL PRIMARY KEY,
        "item_name" VARCHAR(100) NOT NULL,
        "overhead_percentage" DECIMAL(5,2) NOT NULL,
        "consumption_percentage" TEXT NOT NULL,
        "is_active" BOOLEAN NOT NULL DEFAULT true
      );
      
      CREATE TABLE IF NOT EXISTS "dyeing_charges" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL,
        "charge_per_kg" DECIMAL(10,2) NOT NULL,
        "is_active" BOOLEAN NOT NULL DEFAULT true
      );
      
      CREATE TABLE IF NOT EXISTS "dyeing_changes" (
        "id" SERIAL PRIMARY KEY,
        "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
        "change_description" TEXT NOT NULL,
        "change_date" TIMESTAMP DEFAULT NOW(),
        "yarn_type_id" INTEGER,
        "color_type_id" INTEGER,
        "material_id" INTEGER
      );
      
      CREATE TABLE IF NOT EXISTS "unit_settings" (
        "id" SERIAL PRIMARY KEY,
        "unit_name" VARCHAR(100) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true
      );
      
      CREATE TABLE IF NOT EXISTS "order_items" (
        "id" SERIAL PRIMARY KEY,
        "order_id" INTEGER NOT NULL REFERENCES "orders"("id"),
        "product_item_id" INTEGER NOT NULL REFERENCES "product_items"("id"),
        "quantity" INTEGER NOT NULL,
        "price_per_unit" DECIMAL(10,2) NOT NULL,
        "total_price" DECIMAL(10,2) NOT NULL,
        "specifications" JSONB DEFAULT '{}'
      );
      
      CREATE TABLE IF NOT EXISTS "roles" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(50) NOT NULL UNIQUE,
        "description" TEXT,
        "permissions" TEXT[] NOT NULL DEFAULT '{}',
        "created_at" TIMESTAMP DEFAULT NOW(),
        "updated_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "yarn_categories" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "code" VARCHAR(20) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "fabric_parts" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "production_unit_settings" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "description" TEXT,
        "capacity" INTEGER NOT NULL,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "fabric_yarn_types" (
        "id" SERIAL PRIMARY KEY,
        "name" VARCHAR(100) NOT NULL UNIQUE,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "yarn_counts" (
        "id" SERIAL PRIMARY KEY,
        "count" VARCHAR(50) NOT NULL UNIQUE,
        "description" TEXT,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "yarn_prices" (
        "id" SERIAL PRIMARY KEY,
        "yarn_type_id" INTEGER NOT NULL,
        "price_per_kg" DECIMAL(10,2) NOT NULL,
        "currency" VARCHAR(10) NOT NULL DEFAULT 'USD',
        "effective_date" TIMESTAMP DEFAULT NOW(),
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS "profit_margins" (
        "id" SERIAL PRIMARY KEY,
        "item_id" INTEGER NOT NULL,
        "margin_percentage" DECIMAL(5,2) NOT NULL,
        "is_active" BOOLEAN NOT NULL DEFAULT true,
        "created_at" TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Add default admin role
    await pool.query(`
      INSERT INTO roles (name, permissions, description)
      VALUES ('Admin', 
        ARRAY['dashboard.view', 'orders.view', 'orders.create', 'orders.edit', 'orders.delete', 
              'production.view', 'production.create', 'production.edit', 'production.delete', 
              'materials.view', 'materials.create', 'materials.edit', 'materials.delete', 
              'users.view', 'users.create', 'users.edit', 'users.delete', 
              'roles.view', 'roles.create', 'roles.edit', 'roles.delete', 
              'settings.view', 'settings.edit', 'audit.view'], 
        'Administrator with full access')
      ON CONFLICT (name) DO NOTHING
      RETURNING id;
    `);
    
    // Check for environment variables for admin credentials
    if (!process.env.ADMIN_PASSWORD || !process.env.ADMIN_EMAIL || !process.env.ADMIN_USERNAME) {
      console.warn('Admin credentials not found in environment variables. Skipping admin user creation.');
      console.warn('To create an admin user, set ADMIN_PASSWORD, ADMIN_EMAIL, and ADMIN_USERNAME environment variables.');
    } else {
      // Generate hash for admin password from environment
      const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
      
      // Add default admin user with role_id
      await pool.query(`
        WITH admin_role AS (
          SELECT id FROM roles WHERE name = 'Admin'
        )
        INSERT INTO users (name, email, phone_number, job_role, organization_name, username, password, role_id, is_admin, is_email_verified)
        VALUES ($1, $2, $3, $4, $5, $6, $7, (SELECT id FROM admin_role), true, true)
        ON CONFLICT (username) DO NOTHING;
      `, [
        process.env.ADMIN_NAME || 'Admin User',
        process.env.ADMIN_EMAIL,
        process.env.ADMIN_PHONE || '1234567890',
        process.env.ADMIN_JOB_ROLE || 'Administrator', 
        process.env.ADMIN_ORG || 'Organization',
        process.env.ADMIN_USERNAME,
        hashedPassword
      ]);
      console.log('Admin user created or already exists');
    }
    
    console.log('Database setup completed successfully');
    
    // Close the pool
    await pool.end();
  } catch (e) {
    console.error('Database setup error:', e);
  }
}

main().catch(console.error);