#!/bin/bash

# RENDER DEPLOYMENT BUILD SCRIPT
# This script prepares your app for deployment on Render.com

echo "===== Starting Render deployment build process ====="

# Step 1: Install all dependencies
echo "Installing dependencies..."
npm install

# Step 2: Build the application
echo "Building the application..."
npm run build

echo "===== Build process completed successfully ====="