const fs = require('fs');
const path = require('path');

// Read the file
const filePath = 'client/src/pages/settings/narrow-fabrics-settings.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// Replace all instances of handleDelete with openDeleteDialog
content = content.replace(/onClick=\{\(\) => handleDelete\((\w+)\.id\)\}/g, 'onClick={() => openDeleteDialog($1)}');

// Write the file back
fs.writeFileSync(filePath, content);
console.log('File updated successfully');
