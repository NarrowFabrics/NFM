import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './shared/schema';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import { eq } from 'drizzle-orm';
import path from 'path';
import * as bcrypt from 'bcrypt';

async function main() {
  console.log('Starting database setup...');
  
  // Connect to the database using the DATABASE_URL environment variable
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    console.error('DATABASE_URL environment variable is not set');
    process.exit(1);
  }
  
  console.log('Connecting to database...');
  const sql = postgres(connectionString, { max: 1 });
  const db = drizzle(sql, { schema });
  
  try {
    console.log('Setting up essential tables...');
    
    // Create tables directly using SQL for essential tables - executing separately
    console.log('Creating roles table...');
    await sql`
      CREATE TABLE IF NOT EXISTS roles (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        permissions TEXT[] NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `;
    
    console.log('Creating users table...');
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone_number TEXT NOT NULL,
        job_role TEXT NOT NULL,
        organization_name TEXT NOT NULL,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role_id INTEGER REFERENCES roles(id),
        is_admin BOOLEAN NOT NULL DEFAULT FALSE,
        is_email_verified BOOLEAN NOT NULL DEFAULT FALSE,
        verification_token TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        last_login_at TIMESTAMP,
        last_activity_at TIMESTAMP
      );
    `;
    
    console.log('Creating price_quotations table...');
    await sql`
      CREATE TABLE IF NOT EXISTS price_quotations (
        id SERIAL PRIMARY KEY,
        reference_no VARCHAR(50) NOT NULL,
        customer_type VARCHAR(50),
        customer_name VARCHAR(100) NOT NULL,
        customer_contact VARCHAR(100),
        customer_email VARCHAR(100),
        customer_address TEXT,
        contact_person VARCHAR(100),
        contact_designation VARCHAR(100),
        inquiry_type VARCHAR(50),
        production_unit VARCHAR(100) NOT NULL,
        item_name VARCHAR(100) NOT NULL,
        size_width NUMERIC(10, 2),
        size_unit VARCHAR(10) DEFAULT 'MM',
        weight_gram_yds NUMERIC(10, 2),
        length_unit VARCHAR(10) DEFAULT 'YDS',
        price_per_unit NUMERIC(10, 2),
        price_currency VARCHAR(10) DEFAULT 'USD',
        additional_price_percentage NUMERIC(5, 2) DEFAULT '0',
        payment_terms VARCHAR(50),
        delivery_terms VARCHAR(50),
        remarks TEXT,
        article_number VARCHAR(100),
        elastic_parts_data JSONB DEFAULT '[]',
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        is_active BOOLEAN NOT NULL DEFAULT TRUE
      );
    `;
    
    // Check if admin role exists
    const existingAdminRole = await db.query.roles.findFirst({
      where: eq(schema.roles.name, 'Admin')
    });
    
    // Create admin role if it doesn't exist
    if (!existingAdminRole) {
      console.log('Creating admin role...');
      await db.insert(schema.roles).values({
        name: 'Admin',
        description: 'Administrator with all permissions',
        permissions: Object.values(schema.Permission.enum)
      });
    }
    
    // Check if admin users exist
    const existingAdminUser = await db.query.users.findFirst({
      where: eq(schema.users.username, 'admin')
    });
    
    const existingMasudUser = await db.query.users.findFirst({
      where: eq(schema.users.username, 'MasudIZ')
    });
    
    // Get the admin role ID
    const adminRole = await db.query.roles.findFirst({
      where: eq(schema.roles.name, 'Admin')
    });
    
    if (!adminRole) {
      throw new Error('Admin role not found');
    }
    
    // Check for environment variables for admin credentials
    if (!process.env.ADMIN_PASSWORD || !process.env.ADMIN_EMAIL || !process.env.ADMIN_USERNAME) {
      console.warn('Admin credentials not found in environment variables.');
      console.warn('To create an admin user, set ADMIN_PASSWORD, ADMIN_EMAIL, and ADMIN_USERNAME environment variables.');
    } else if (!existingAdminUser) {
      console.log('Creating default admin user from environment variables...');
      
      // Hash the password from environment
      const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
      
      // Insert the admin user
      await db.insert(schema.users).values({
        name: process.env.ADMIN_NAME || 'Administrator',
        email: process.env.ADMIN_EMAIL,
        phone_number: process.env.ADMIN_PHONE || '123-456-7890',
        job_role: process.env.ADMIN_JOB_ROLE || 'System Administrator',
        organization_name: process.env.ADMIN_ORG || 'Your Organization',
        username: process.env.ADMIN_USERNAME,
        password: hashedPassword,
        role_id: adminRole.id,
        is_admin: true,
        is_email_verified: true
      });
      console.log('Admin user created successfully');
    }
    
    // Check for environment variables for secondary admin credentials
    if (!process.env.SECONDARY_ADMIN_PASSWORD || !process.env.SECONDARY_ADMIN_EMAIL || !process.env.SECONDARY_ADMIN_USERNAME) {
      console.log('No secondary admin credentials found in environment variables.');
    } else if (!existingMasudUser) {
      console.log('Creating secondary admin user from environment variables...');
      
      // Hash the password from environment
      const secondaryPassword = await bcrypt.hash(process.env.SECONDARY_ADMIN_PASSWORD, 10);
      
      // Insert the secondary admin user
      await db.insert(schema.users).values({
        name: process.env.SECONDARY_ADMIN_NAME || 'Secondary Admin',
        email: process.env.SECONDARY_ADMIN_EMAIL,
        phone_number: process.env.SECONDARY_ADMIN_PHONE || '123-456-7890',
        job_role: process.env.SECONDARY_ADMIN_JOB_ROLE || 'System Administrator',
        organization_name: process.env.SECONDARY_ADMIN_ORG || 'Your Organization',
        username: process.env.SECONDARY_ADMIN_USERNAME,
        password: secondaryPassword,
        role_id: adminRole.id,
        is_admin: true,
        is_email_verified: true
      });
    }
    
    console.log('Database setup completed successfully!');
  } catch (error) {
    console.error('Error setting up database:', error);
  } finally {
    await sql.end();
  }
}

main().catch(console.error);