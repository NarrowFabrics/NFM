#!/bin/bash

# RENDER DEPLOYMENT START SCRIPT
# This script starts your app on Render.com

echo "===== Starting application ====="

# Set production environment
export NODE_ENV=production

# Start the application
echo "Running the application..."
npm start