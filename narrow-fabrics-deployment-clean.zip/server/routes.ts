import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, hashPassword } from "./auth";
import { initializeDatabase, db, pool } from "./db";
import { apiRouter } from "./routes/index";
// All Google Drive and GitHub integrations have been removed
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  insertYarnTypeSchema, insertColorTypeSchema, insertMaterialSchema, 
  insertProductItemSchema, insertProductionPlanSchema, insertOrderSchema, 
  insertOrderItemSchema, insertItemSettingSchema, insertUnitSettingSchema,
  insertDyeingChargeSchema, insertItemUnitSchema, insertNoticeSchema
} from "@shared/schema";
import { z } from "zod";
import { askClaude } from "./lib/claude";
import multer from "multer";
import * as fs from "fs";
import * as path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize database connection
  await initializeDatabase();
  
  // Set up authentication routes
  setupAuth(app);
  
  // Check user authentication middleware
  const ensureAuthenticated = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Authentication required" });
  };
  
  // Check admin authorization middleware
  const ensureAdmin = (req: any, res: any, next: any) => {
    if (req.isAuthenticated() && req.user.is_admin) {
      return next();
    }
    res.status(403).json({ message: "Admin privileges required" });
  };
  
  // Register API routes
  apiRouter.use(ensureAuthenticated);
  app.use('/api', apiRouter);
  
  // Google Drive auth routes temporarily disabled
  // // Mount Google Drive auth routes at root level (without authentication)
  // // These need to be at root level for OAuth2 callback to work
  // app.use(driveAuthRouter);

  // Dashboard
  // Server health check endpoint - doesn't require authentication
  app.get("/api/health-check", async (_req, res) => {
    try {
      // Check if database connection is working
      const client = await pool.connect();
      try {
        const dbCheck = await client.query('SELECT NOW() as timestamp');
        
        res.json({
          status: "ok",
          message: "Server is running",
          timestamp: dbCheck.rows[0].timestamp
        });
      } finally {
        client.release(); // Always release the client back to the pool
      }
    } catch (error) {
      console.error("Health check failed:", error);
      res.status(500).json({
        status: "error",
        message: "Server error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/dashboard/stats", ensureAuthenticated, async (req, res, next) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/dashboard/activity", ensureAuthenticated, async (req, res, next) => {
    try {
      const recentActivity = await storage.getRecentUserActivities(10);
      res.json(recentActivity);
    } catch (error) {
      next(error);
    }
  });
  
  // System Metrics API endpoints
  app.get("/api/system/metrics/summary", ensureAuthenticated, async (req, res, next) => {
    try {
      const summary = await storage.getSystemMetricsSummary();
      res.json(summary);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/system/metrics", ensureAuthenticated, async (req, res, next) => {
    try {
      const { timeRange, limit } = req.query;
      
      // Validate timeRange parameter
      const validTimeRanges = ['hour', 'day', 'week', 'month'];
      const validatedTimeRange = validTimeRanges.includes(timeRange as string) 
        ? (timeRange as 'hour' | 'day' | 'week' | 'month') 
        : 'hour';
      
      // Validate limit parameter
      const parsedLimit = parseInt(limit as string) || 60;
      const validatedLimit = Math.min(Math.max(parsedLimit, 1), 500); // Between 1 and 500
      
      const metrics = await storage.getSystemMetrics(validatedTimeRange, validatedLimit);
      res.json(metrics);
    } catch (error) {
      next(error);
    }
  });
  
  // Collect system metrics endpoint
  app.post("/api/system/metrics", ensureAuthenticated, async (req, res, next) => {
    try {
      // Check if user has permission
      if (!req.user!.is_admin) {
        return res.status(403).json({ error: "Permission denied" });
      }
      
      const { 
        cpu_usage, memory_usage, memory_total, disk_usage, disk_total,
        active_users, response_time, db_connections, db_queries_per_second,
        api_requests_per_minute, error_count, metadata
      } = req.body;
      
      const metric = await storage.createSystemMetric({
        cpu_usage,
        memory_usage,
        memory_total,
        disk_usage,
        disk_total,
        active_users,
        response_time,
        db_connections,
        db_queries_per_second,
        api_requests_per_minute,
        error_count,
        metadata: metadata || {}
      });
      
      res.status(201).json(metric);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/dashboard/production-plans", ensureAuthenticated, async (req, res, next) => {
    try {
      const recentPlans = await storage.getRecentProductionPlans(4);
      res.json(recentPlans);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/dashboard/orders", ensureAuthenticated, async (req, res, next) => {
    try {
      const recentOrders = await storage.getRecentOrders(4);
      res.json(recentOrders);
    } catch (error) {
      next(error);
    }
  });

  // User Activities
  app.get("/api/user/activities", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activities = await storage.getUserActivities(req.user!.id, page, limit);
      res.json(activities);
    } catch (error) {
      next(error);
    }
  });

  // Users Management (Admin only)
  app.get("/api/users", ensureAdmin, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const search = req.query.search as string;
      const users = await storage.listUsers(page, limit, search);
      res.json(users);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/users/:id", ensureAdmin, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      next(error);
    }
  });
  
  // Add new user (Admin only)
  app.post("/api/users", ensureAdmin, async (req, res, next) => {
    try {
      const { username, email, password, name, is_admin } = req.body;
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Hash the password
      const hashedPassword = await hashPassword(password);
      
      // Create the user with required fields
      // Providing default values for required fields that are not in the form yet
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        name,
        is_admin: is_admin || false,
        // Add required fields with default values
        phone_number: req.body.phone_number || "N/A",
        job_role: req.body.job_role || "Staff",
        organization_name: req.body.organization_name || "Default Organization"
      });
      
      // Log the activity
      await storage.createUserActivity(req.user!.id, "Created new user", { 
        createdUserId: user.id,
        createdUsername: username 
      });
      
      // Return the created user without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      next(error);
    }
  });

  app.put("/api/users/:id", ensureAdmin, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const userData = req.body;
      const updated = await storage.updateUser(id, userData);
      if (!updated) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated user", { userId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/ai/ask", ensureAuthenticated, async (req, res, next) => {
  try {
    const { prompt } = req.body;
    const response = await askClaude(prompt);
    res.json({ response });
  } catch (error) {
    next(error);
  }
});

  // Database backup and restore endpoints
  app.post("/api/database/backup", ensureAuthenticated, async (req, res, next) => {
    try {
      // Get all data from various tables
      const [
        users, 
        itemUnits, 
        yarnTypes, 
        colorTypes, 
        materials, 
        productItems, 
        productionPlans, 
        orders,
        itemSettings,
        dyeingCharges,
        unitSettings,
        fabricParts,
        productionUnitSettings,
        fabricYarnTypes,
        yarnCounts,
        yarnPrices,
        profitMargins
      ] = await Promise.all([
        db.query.users.findMany(),
        db.query.itemUnits.findMany(),
        db.query.yarnTypes.findMany(),
        db.query.colorTypes.findMany(),
        db.query.materials.findMany(),
        db.query.productItems.findMany(),
        db.query.productionPlans.findMany(),
        db.query.orders.findMany(),
        db.query.itemSettings.findMany(),
        db.query.dyeingCharges.findMany(),
        db.query.unitSettings.findMany(),
        db.query.fabricParts.findMany(),
        db.query.productionUnitSettings.findMany(),
        db.query.fabricYarnTypes.findMany(),
        db.query.yarnCounts.findMany(),
        db.query.yarnPrices.findMany(),
        db.query.profitMargins.findMany()
      ]);

      // Create a backup object with all data
      const backupData = {
        version: "1.0.0",
        timestamp: new Date().toISOString(),
        users,
        itemUnits,
        yarnTypes,
        colorTypes,
        materials,
        productItems,
        productionPlans,
        orders,
        itemSettings,
        dyeingCharges,
        unitSettings,
        fabricParts,
        productionUnitSettings,
        fabricYarnTypes,
        yarnCounts,
        yarnPrices,
        profitMargins
      };

      // Log the activity
      await storage.createUserActivity(req.user!.id, "Created database backup");
      
      // Return the backup data
      res.json(backupData);
    } catch (error) {
      next(error);
    }
  });

  // Set up multer for file upload
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 50 * 1024 * 1024, // 50MB max file size
    },
  });

  // Directory for storing backup files
  const backupDir = path.join(process.cwd(), 'backups');
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  app.post("/api/database/restore", ensureAuthenticated, ensureAdmin, upload.single('backupFile'), async (req, res, next) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No backup file uploaded" });
      }

      // Get the uploaded file content as JSON
      let backupData;
      try {
        backupData = JSON.parse(req.file.buffer.toString('utf-8'));
      } catch (e) {
        return res.status(400).json({ message: "Invalid JSON format in backup file" });
      }
      
      // Validate backup data structure
      if (!backupData || !backupData.version || !backupData.timestamp) {
        return res.status(400).json({ message: "Invalid backup data format" });
      }

      // Create auto-backup before restore
      const [
        users, 
        itemUnits, 
        yarnTypes, 
        colorTypes, 
        materials, 
        productItems, 
        productionPlans, 
        orders,
        itemSettings,
        dyeingCharges,
        unitSettings,
        fabricParts,
        productionUnitSettings,
        fabricYarnTypes,
        yarnCounts,
        yarnPrices,
        profitMargins
      ] = await Promise.all([
        db.query.users.findMany(),
        db.query.itemUnits.findMany(),
        db.query.yarnTypes.findMany(),
        db.query.colorTypes.findMany(),
        db.query.materials.findMany(),
        db.query.productItems.findMany(),
        db.query.productionPlans.findMany(),
        db.query.orders.findMany(),
        db.query.itemSettings.findMany(),
        db.query.dyeingCharges.findMany(),
        db.query.unitSettings.findMany(),
        db.query.fabricParts.findMany(),
        db.query.productionUnitSettings.findMany(),
        db.query.fabricYarnTypes.findMany(),
        db.query.yarnCounts.findMany(),
        db.query.yarnPrices.findMany(),
        db.query.profitMargins.findMany()
      ]);

      // Create a backup object with all current data
      const autoBackupData = {
        version: "1.0.0",
        timestamp: new Date().toISOString(),
        autoBackup: true,
        reason: "Pre-restore automatic backup",
        users,
        itemUnits,
        yarnTypes,
        colorTypes,
        materials,
        productItems,
        productionPlans,
        orders,
        itemSettings,
        dyeingCharges,
        unitSettings,
        fabricParts,
        productionUnitSettings,
        fabricYarnTypes,
        yarnCounts,
        yarnPrices,
        profitMargins
      };
      
      // Save auto-backup to file system
      const autoBackupFilename = `auto-backup-${new Date().toISOString().replace(/[:\.]/g, '-')}.json`;
      const autoBackupPath = path.join(backupDir, autoBackupFilename);
      fs.writeFileSync(autoBackupPath, JSON.stringify(autoBackupData, null, 2));

      // TODO: Implement actual restore functionality for all tables
      // This would involve clearing tables and re-inserting all the data from the backup file

      // For now, just simulate a successful restore
      
      // Log the activity
      await storage.createUserActivity(req.user!.id, "Restored database from backup", { 
        timestamp: backupData.timestamp,
        filename: req.file.originalname,
        filesize: req.file.size,
        autoBackup: autoBackupFilename
      });
      
      // Return success
      res.json({ 
        success: true, 
        message: "Database restored successfully",
        autoBackup: {
          filename: autoBackupFilename,
          path: autoBackupPath,
          timestamp: autoBackupData.timestamp
        }
      });
    } catch (error) {
      next(error);
    }
  });

app.delete("/api/users/:id", ensureAdmin, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteUser(id);
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted user", { userId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Item Units
  app.get("/api/item-units", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const itemUnits = await storage.listItemUnits(page, limit);
      res.json(itemUnits);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/item-units", ensureAuthenticated, async (req, res, next) => {
    try {
      const itemUnitData = insertItemUnitSchema.parse(req.body);
      const itemUnit = await storage.createItemUnit(itemUnitData);
      await storage.createUserActivity(req.user!.id, "Created item unit", { itemUnitId: itemUnit.id });
      res.status(201).json(itemUnit);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/item-units/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const itemUnit = await storage.getItemUnit(id);
      if (!itemUnit) {
        return res.status(404).json({ message: "Item unit not found" });
      }
      res.json(itemUnit);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/item-units/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const itemUnitData = req.body;
      const updated = await storage.updateItemUnit(id, itemUnitData);
      if (!updated) {
        return res.status(404).json({ message: "Item unit not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated item unit", { itemUnitId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/item-units/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteItemUnit(id);
      if (!deleted) {
        return res.status(404).json({ message: "Item unit not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted item unit", { itemUnitId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Yarn Types
  app.get("/api/yarn-types", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activeOnly = req.query.activeOnly === "true";
      const yarnTypes = await storage.listYarnTypes(page, limit, activeOnly);
      res.json(yarnTypes);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/yarn-types", ensureAuthenticated, async (req, res, next) => {
    try {
      const yarnTypeData = insertYarnTypeSchema.parse(req.body);
      const yarnType = await storage.createYarnType(yarnTypeData);
      await storage.createUserActivity(req.user!.id, "Created yarn type", { yarnTypeId: yarnType.id });
      res.status(201).json(yarnType);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/yarn-types/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const yarnType = await storage.getYarnType(id);
      if (!yarnType) {
        return res.status(404).json({ message: "Yarn type not found" });
      }
      res.json(yarnType);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/yarn-types/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const yarnTypeData = req.body;
      const updated = await storage.updateYarnType(id, yarnTypeData);
      if (!updated) {
        return res.status(404).json({ message: "Yarn type not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated yarn type", { yarnTypeId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/yarn-types/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteYarnType(id);
      if (!deleted) {
        return res.status(404).json({ message: "Yarn type not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted yarn type", { yarnTypeId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Color Types
  app.get("/api/color-types", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activeOnly = req.query.activeOnly === "true";
      const colorTypes = await storage.listColorTypes(page, limit, activeOnly);
      res.json(colorTypes);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/color-types", ensureAuthenticated, async (req, res, next) => {
    try {
      const colorTypeData = insertColorTypeSchema.parse(req.body);
      const colorType = await storage.createColorType(colorTypeData);
      await storage.createUserActivity(req.user!.id, "Created color type", { colorTypeId: colorType.id });
      res.status(201).json(colorType);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/color-types/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const colorType = await storage.getColorType(id);
      if (!colorType) {
        return res.status(404).json({ message: "Color type not found" });
      }
      res.json(colorType);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/color-types/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const colorTypeData = req.body;
      const updated = await storage.updateColorType(id, colorTypeData);
      if (!updated) {
        return res.status(404).json({ message: "Color type not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated color type", { colorTypeId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/color-types/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteColorType(id);
      if (!deleted) {
        return res.status(404).json({ message: "Color type not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted color type", { colorTypeId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Materials
  app.get("/api/materials", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const category = req.query.category as string;
      const materials = await storage.listMaterials(page, limit, category);
      res.json(materials);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/materials", ensureAuthenticated, async (req, res, next) => {
    try {
      const materialData = insertMaterialSchema.parse(req.body);
      const material = await storage.createMaterial(materialData);
      await storage.createUserActivity(req.user!.id, "Created material", { materialId: material.id });
      res.status(201).json(material);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/materials/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const material = await storage.getMaterial(id);
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }
      res.json(material);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/materials/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const materialData = req.body;
      const updated = await storage.updateMaterial(id, materialData);
      if (!updated) {
        return res.status(404).json({ message: "Material not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated material", { materialId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/materials/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteMaterial(id);
      if (!deleted) {
        return res.status(404).json({ message: "Material not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted material", { materialId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Product Items
  app.get("/api/product-items", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const category = req.query.category as string;
      const productItems = await storage.listProductItems(page, limit, category);
      res.json(productItems);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/product-items", ensureAuthenticated, async (req, res, next) => {
    try {
      const productItemData = insertProductItemSchema.parse(req.body);
      const productItem = await storage.createProductItem(productItemData);
      await storage.createUserActivity(req.user!.id, "Created product item", { productItemId: productItem.id });
      res.status(201).json(productItem);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/product-items/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const productItem = await storage.getProductItem(id);
      if (!productItem) {
        return res.status(404).json({ message: "Product item not found" });
      }
      res.json(productItem);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/product-items/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const productItemData = req.body;
      const updated = await storage.updateProductItem(id, productItemData);
      if (!updated) {
        return res.status(404).json({ message: "Product item not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated product item", { productItemId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/product-items/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteProductItem(id);
      if (!deleted) {
        return res.status(404).json({ message: "Product item not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted product item", { productItemId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Production Plans
  app.get("/api/production-plans", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const status = req.query.status as string;
      const productionPlans = await storage.listProductionPlans(page, limit, status);
      res.json(productionPlans);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/production-plans", ensureAuthenticated, async (req, res, next) => {
    try {
      const productionPlanData = {
        ...req.body,
        created_by: req.user!.id
      };
      const validatedData = insertProductionPlanSchema.parse(productionPlanData);
      const productionPlan = await storage.createProductionPlan(validatedData);
      await storage.createUserActivity(req.user!.id, "Created production plan", { productionPlanId: productionPlan.id });
      res.status(201).json(productionPlan);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/production-plans/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const productionPlan = await storage.getProductionPlan(id);
      if (!productionPlan) {
        return res.status(404).json({ message: "Production plan not found" });
      }
      res.json(productionPlan);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/production-plans/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const productionPlanData = req.body;
      const updated = await storage.updateProductionPlan(id, productionPlanData);
      if (!updated) {
        return res.status(404).json({ message: "Production plan not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated production plan", { productionPlanId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/production-plans/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteProductionPlan(id);
      if (!deleted) {
        return res.status(404).json({ message: "Production plan not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted production plan", { productionPlanId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Production Unit Settings
  app.get("/api/production-unit-settings", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const settings = await storage.listProductionUnitSettings(page, limit);
      res.json(settings);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/production-unit-settings", ensureAuthenticated, async (req, res, next) => {
    try {
      const settingData = req.body;
      const setting = await storage.createProductionUnitSetting(settingData);
      await storage.createUserActivity(req.user!.id, "Created production unit setting", { settingId: setting.id });
      res.status(201).json(setting);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/production-unit-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const setting = await storage.getProductionUnitSetting(id);
      if (!setting) {
        return res.status(404).json({ message: "Production unit setting not found" });
      }
      res.json(setting);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/production-unit-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const settingData = req.body;
      const updated = await storage.updateProductionUnitSetting(id, settingData);
      if (!updated) {
        return res.status(404).json({ message: "Production unit setting not found" });
      }
      await storage.createUserActivity(req.user!.id, "Updated production unit setting", { settingId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });


  // Roles management
  app.get("/api/roles", ensureAdmin, async (req, res, next) => {
    try {
      const roles = await storage.listRoles();
      res.json(roles);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/roles", ensureAdmin, async (req, res, next) => {
    try {
      const role = await storage.createRole(req.body);
      await storage.createUserActivity(req.user!.id, "Created role", { roleId: role.id });
      res.status(201).json(role);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/roles/:id", ensureAdmin, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const updated = await storage.updateRole(id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Role not found" });
      }
      await storage.createUserActivity(req.user!.id, "Updated role", { roleId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  // Add audit logs endpoint
  app.get("/api/audit-logs", ensureAdmin, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activities = await storage.getUserActivities(undefined, page, limit);

      if (!Array.isArray(activities)) {
        res.json([]);
        return;
      }

      // Get user names for the activities
      const userIds = [...new Set(activities.map(a => a.user_id))];
      const users = await Promise.all(userIds.map(id => storage.getUser(id)));
      const userMap = Object.fromEntries(users.filter(u => u).map(u => [u.id, u.name]));

      const activitiesWithNames = activities.map(activity => ({
        ...activity,
        user_name: userMap[activity.user_id] || `User ${activity.user_id}`
      }));

      res.json(activitiesWithNames);
    } catch (error) {
      next(error);
    }
  });

  // Orders
  app.get("/api/orders", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const status = req.query.status as string;
      const orders = await storage.listOrders(page, limit, status);
      res.json(orders);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/orders", ensureAuthenticated, async (req, res, next) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      await storage.createUserActivity(req.user!.id, "Created order", { orderId: order.id });
      res.status(201).json(order);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/orders/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Get order items
      const items = await storage.getOrderItems(id);
      res.json({ ...order, items });
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/orders/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const orderData = req.body;
      const updated = await storage.updateOrder(id, orderData);
      if (!updated) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated order", { orderId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/orders/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteOrder(id);
      if (!deleted) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted order", { orderId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Order Items
  app.post("/api/order-items", ensureAuthenticated, async (req, res, next) => {
    try {
      const orderItemData = insertOrderItemSchema.parse(req.body);
      const orderItem = await storage.createOrderItem(orderItemData);
      await storage.createUserActivity(req.user!.id, "Added order item", { orderItemId: orderItem.id, orderId: orderItem.order_id });
      res.status(201).json(orderItem);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/order-items/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteOrderItem(id);
      if (!deleted) {
        return res.status(404).json({ message: "Order item not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Removed order item", { orderItemId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Item Settings
  app.get("/api/item-settings", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activeOnly = req.query.activeOnly === "true";
      const itemSettings = await storage.listItemSettings(page, limit, activeOnly);
      res.json(itemSettings);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/item-settings", ensureAuthenticated, async (req, res, next) => {
    try {
      const itemSettingData = insertItemSettingSchema.parse(req.body);
      const itemSetting = await storage.createItemSetting(itemSettingData);
      await storage.createUserActivity(req.user!.id, "Created item setting", { itemSettingId: itemSetting.id });
      res.status(201).json(itemSetting);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/item-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const itemSetting = await storage.getItemSetting(id);
      if (!itemSetting) {
        return res.status(404).json({ message: "Item setting not found" });
      }
      res.json(itemSetting);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/item-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const itemSettingData = req.body;
      const updated = await storage.updateItemSetting(id, itemSettingData);
      if (!updated) {
        return res.status(404).json({ message: "Item setting not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated item setting", { itemSettingId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/item-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteItemSetting(id);
      if (!deleted) {
        return res.status(404).json({ message: "Item setting not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted item setting", { itemSettingId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Unit Settings
  app.get("/api/unit-settings", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activeOnly = req.query.activeOnly === "true";
      const unitSettings = await storage.listUnitSettings(page, limit, activeOnly);
      res.json(unitSettings);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/unit-settings/production", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const unitSettings = await storage.listProductionUnitSettings(page, limit);
      res.json(unitSettings);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/unit-settings", ensureAuthenticated, async (req, res, next) => {
    try {
      const unitSettingData = insertUnitSettingSchema.parse(req.body);
      const unitSetting = await storage.createUnitSetting(unitSettingData);
      await storage.createUserActivity(req.user!.id, "Created unit setting", { unitSettingId: unitSetting.id });
      res.status(201).json(unitSetting);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/unit-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const unitSetting = await storage.getUnitSetting(id);
      if (!unitSetting) {
        return res.status(404).json({ message: "Unit setting not found" });
      }
      res.json(unitSetting);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/unit-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const unitSettingData = req.body;
      const updated = await storage.updateUnitSetting(id, unitSettingData);
      if (!updated) {
        return res.status(404).json({ message: "Unit setting not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated unit setting", { unitSettingId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/unit-settings/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteUnitSetting(id);
      if (!deleted) {
        return res.status(404).json({ message: "Unit setting not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted unit setting", { unitSettingId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Dyeing Changes
  app.get("/api/dyeing-changes", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activeOnly = req.query.activeOnly === "true";
      const dyeingChanges = await storage.listDyeingChanges(page, limit, activeOnly);
      res.json(dyeingChanges);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/dyeing-changes", ensureAuthenticated, async (req, res, next) => {
    try {
      const dyeingChange = await storage.createDyeingChange(req.body);
      await storage.createUserActivity(req.user!.id, "Created dyeing change", { dyeingChangeId: dyeingChange.id });
      res.status(201).json(dyeingChange);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/dyeing-changes/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const dyeingChange = await storage.getDyeingChange(id);
      if (!dyeingChange) {
        return res.status(404).json({ message: "Dyeing change not found" });
      }
      res.json(dyeingChange);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/dyeing-changes/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const dyeingChangeData = req.body;
      const updated = await storage.updateDyeingChange(id, dyeingChangeData);
      if (!updated) {
        return res.status(404).json({ message: "Dyeing change not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated dyeing change", { dyeingChangeId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/dyeing-changes/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteDyeingChange(id);
      if (!deleted) {
        return res.status(404).json({ message: "Dyeing change not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted dyeing change", { dyeingChangeId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // Dyeing Charges
  app.get("/api/dyeing-charges", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activeOnly = req.query.activeOnly === "true";
      const dyeingCharges = await storage.listDyeingCharges(page, limit, activeOnly);
      res.json(dyeingCharges);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/dyeing-charges", ensureAuthenticated, async (req, res, next) => {
    try {
      const dyeingChargeData = insertDyeingChargeSchema.parse(req.body);
      const dyeingCharge = await storage.createDyeingCharge(dyeingChargeData);
      await storage.createUserActivity(req.user!.id, "Created dyeing charge", { dyeingChargeId: dyeingCharge.id });
      res.status(201).json(dyeingCharge);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/dyeing-charges/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const dyeingCharge = await storage.getDyeingCharge(id);
      if (!dyeingCharge) {
        return res.status(404).json({ message: "Dyeing charge not found" });
      }
      res.json(dyeingCharge);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/dyeing-charges/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const dyeingChargeData = req.body;
      const updated = await storage.updateDyeingCharge(id, dyeingChargeData);
      if (!updated) {
        return res.status(404).json({ message: "Dyeing charge not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated dyeing charge", { dyeingChargeId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/dyeing-charges/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteDyeingCharge(id);
      if (!deleted) {
        return res.status(404).json({ message: "Dyeing charge not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted dyeing charge", { dyeingChargeId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  // NARROW FABRICS ROUTES
  app.get("/api/narrow-fabrics/production-units", ensureAuthenticated, async (req, res, next) => {
    try {
      const { page = "1", limit = "50", activeOnly = "true" } = req.query;
      const result = await storage.listProductionUnitSettings(
        parseInt(page as string),
        parseInt(limit as string),
        activeOnly === "true"
      );
      return res.json({ settings: result.settings || [] });
    } catch (err) {
      next(err);
    }
  });
  
  app.get("/api/narrow-fabrics/items", ensureAuthenticated, async (req, res, next) => {
    try {
      const { page = "1", limit = "50", activeOnly = "true" } = req.query;
      const result = await storage.listFabricParts(
        parseInt(page as string),
        parseInt(limit as string),
        activeOnly === "true"
      );
      return res.json({ fabricParts: result.fabricParts || [] });
    } catch (err) {
      next(err);
    }
  });
  
  // Added new endpoint to provide mock item data for Price-quotation-page
  app.get("/api/items-data", ensureAuthenticated, async (req, res, next) => {
    try {
      // Get production unit from query parameter for filtering
      const productionUnit = req.query.productionUnit as string;
      
      // Base items data structure
      const allItems = [
        {
          id: 1,
          name: 'Jacquard Elastic',
          unit: 'Yards',
          productionUnit: 'Jacquard Loom',
          description: 'Jacquard elastic with customizable patterns',
          is_active: true,
          created_at: new Date().toISOString()
        },
        {
          id: 2,
          name: 'Needle Loom Elastic',
          unit: 'Yards',
          productionUnit: 'Needle Loom',
          description: 'Needle loom elastic with high durability',
          is_active: true,
          created_at: new Date().toISOString()
        },
        {
          id: 3,
          name: 'Dyed Elastic',
          unit: 'Yards',
          productionUnit: 'Dyeing Unit',
          description: 'Secondary production line for dyed materials',
          is_active: true,
          created_at: new Date().toISOString()
        },
        {
          id: 4,
          name: 'Hook & Loop Tape',
          unit: 'Yards',
          productionUnit: 'Hook & Loop Unit',
          description: 'Hook and loop fastening system',
          is_active: true,
          created_at: new Date().toISOString()
        },
        {
          id: 5,
          name: 'Zipper Tape',
          unit: 'Yards',
          productionUnit: 'Zipper Unit',
          description: 'Zipper tape for various applications',
          is_active: true,
          created_at: new Date().toISOString()
        }
      ];
      
      // Filter items based on production unit if provided
      let filteredItems = allItems;
      if (productionUnit) {
        filteredItems = allItems.filter(item => 
          item.productionUnit.toLowerCase() === productionUnit.toLowerCase());
      }
      
      return res.json({ items: filteredItems });
    } catch (err) {
      next(err);
    }
  });
  
  // Visualization API endpoints
  
  // Stats/KPI data for visualizations
  app.get("/api/stats/kpi", ensureAuthenticated, async (req, res, next) => {
    try {
      // Get basic stats from dashboard data
      const dashboardStats = await storage.getDashboardStats();
      
      // In the future, more data would come from the database
      // For now, we're combining real data with sample data for demonstration
      res.json({
        salesMetrics: {
          revenue: {
            current: dashboardStats.totalRevenue,
            previous: Math.floor(dashboardStats.totalRevenue * 0.85),
            trend: 'up',
            percentChange: 17.6
          },
          orders: {
            current: dashboardStats.totalOrders,
            previous: Math.floor(dashboardStats.totalOrders * 0.91),
            trend: 'up',
            percentChange: 9.9
          },
          averageOrderValue: {
            current: dashboardStats.totalOrders > 0 ? Math.floor(dashboardStats.totalRevenue / dashboardStats.totalOrders) : 0,
            previous: dashboardStats.totalOrders > 0 ? Math.floor((dashboardStats.totalRevenue * 0.85) / (dashboardStats.totalOrders * 0.91)) : 0,
            trend: 'up',
            percentChange: 7.0
          },
          conversionRate: {
            current: 3.2,
            previous: 2.8,
            trend: 'up',
            percentChange: 14.3
          }
        },
        operationalMetrics: {
          productionEfficiency: {
            current: 88,
            previous: 83,
            trend: 'up',
            percentChange: 6.0
          },
          materialWaste: {
            current: 3.2,
            previous: 3.8,
            trend: 'down',
            percentChange: 15.8
          },
          onTimeDelivery: {
            current: 92,
            previous: 88,
            trend: 'up',
            percentChange: 4.5
          },
          productionCost: {
            current: Math.floor(dashboardStats.totalRevenue * 0.6),
            previous: Math.floor(dashboardStats.totalRevenue * 0.65),
            trend: 'down',
            percentChange: 7.7
          }
        }
      });
      
      await storage.createUserActivity(req.user!.id, "Viewed KPI data");
    } catch (error) {
      next(error);
    }
  });
  
  // Recent orders for visualization
  app.get("/api/orders/recent", ensureAuthenticated, async (req, res, next) => {
    try {
      // Parse and validate limit parameter
      const limitParam = req.query.limit as string;
      const limit = limitParam ? parseInt(limitParam) : 10;
      
      // Ensure limit is a valid number
      if (isNaN(limit) || limit <= 0) {
        return res.status(400).json({ 
          error: "Invalid limit parameter. Must be a positive number." 
        });
      }
      
      // Get full order data directly instead of using getRecentOrders
      const { orders } = await storage.listOrders(1, limit);
      
      // Sort by order_date (most recent first)
      const sortedOrders = [...orders].sort((a, b) => {
        const dateA = new Date(a.order_date || 0);
        const dateB = new Date(b.order_date || 0);
        return dateB.getTime() - dateA.getTime();
      });
      
      // Add additional information - safer version with strict validation
      const processedOrders = await Promise.all(sortedOrders.map(async (order) => {
        try {
          // Skip this iteration if order is not valid
          if (!order || typeof order !== 'object') {
            console.warn("Invalid order object:", order);
            return null;
          }
          
          // Strictly ensure order.id is a valid integer before querying
          const orderId = order.id;
          
          if (typeof orderId === 'number' && Number.isInteger(orderId) && orderId > 0) {
            try {
              // Get order items count - wrapped in try/catch for additional safety
              const orderItems = await storage.getOrderItems(orderId);
              
              return {
                ...order,
                item_count: orderItems.length,
                formatted_date: new Date(order.order_date || Date.now()).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'short', 
                  day: 'numeric' 
                })
              };
            } catch (itemError) {
              console.error("Error fetching order items:", itemError, "Order ID:", orderId);
              return {
                ...order,
                item_count: 0,
                formatted_date: new Date(order.order_date || Date.now()).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'short', 
                  day: 'numeric' 
                })
              };
            }
          } else {
            console.warn("Invalid order ID found:", order.id, "Type:", typeof order.id);
            return {
              ...order,
              item_count: 0,
              formatted_date: new Date(order.order_date || Date.now()).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
              })
            };
          }
        } catch (err) {
          console.error("Error processing order:", err, "Order:", order);
          return {
            ...order,
            item_count: 0,
            formatted_date: new Date(order.order_date || Date.now()).toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'short', 
              day: 'numeric' 
            })
          };
        }
      }));
      
      // Filter out any null values that might have resulted from invalid orders
      const validOrders = processedOrders.filter(order => order !== null);
      
      res.json(validOrders);
    } catch (error) {
      console.error("Error in /api/orders/recent endpoint:", error);
      next(error);
    }
  });
  
  // Reports endpoints for various data types
  app.get("/api/reports/orders", ensureAuthenticated, async (req, res, next) => {
    try {
      const fromDate = req.query.fromDate ? new Date(req.query.fromDate as string) : undefined;
      const toDate = req.query.toDate ? new Date(req.query.toDate as string) : undefined;
      const status = req.query.status as string;
      
      // Get orders matching the filters
      const { orders: allOrders } = await storage.listOrders(1, 1000);
      
      // Filter by date and status if provided
      const filteredOrders = allOrders.filter(order => {
        let matches = true;
        
        if (fromDate && new Date(order.order_date) < fromDate) {
          matches = false;
        }
        
        if (toDate && new Date(order.order_date) > toDate) {
          matches = false;
        }
        
        if (status && status !== "All" && order.status !== status) {
          matches = false;
        }
        
        return matches;
      });
      
      // Add some calculated fields for the report
      const ordersWithDetails = await Promise.all(filteredOrders.map(async (order) => {
        try {
          // Strictly ensure order.id is a valid integer
          const orderId = order.id;
          if (typeof orderId === 'number' && Number.isInteger(orderId) && orderId > 0) {
            const orderItems = await storage.getOrderItems(orderId);
            return {
              ...order,
              item_count: orderItems.length,
              customer_name: order.customer_name || "N/A",
            };
          } else {
            console.warn("Invalid order ID in reports/orders:", order.id, "Type:", typeof order.id);
            return {
              ...order,
              item_count: 0,
              customer_name: order.customer_name || "N/A",
            };
          }
        } catch (err) {
          console.error("Error in reports/orders processing order:", err, "Order:", order);
          return {
            ...order,
            item_count: 0,
            customer_name: order.customer_name || "N/A",
          };
        }
      }));
      
      res.json(ordersWithDetails);
      
      await storage.createUserActivity(req.user!.id, "Generated orders report");
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/reports/inventory", ensureAuthenticated, async (req, res, next) => {
    try {
      const category = req.query.category as string;
      const stock = req.query.stock as string;
      
      const { materials: allMaterials } = await storage.listMaterials(1, 1000, category !== "All" ? category : undefined);
      
      // Filter by stock level if provided
      const filteredMaterials = allMaterials.filter(material => {
        if (!stock || stock === "All") return true;
        
        if (stock === "In Stock" && material.quantity > 0) return true;
        if (stock === "Low Stock" && material.quantity > 0 && material.quantity < 10) return true;
        if (stock === "Out of Stock" && material.quantity <= 0) return true;
        
        return false;
      });
      
      // Add calculated fields for the report
      const materialsWithDetails = filteredMaterials.map(material => ({
        ...material,
        total_value: material.quantity * (material.unit_price || 0),
        unit: "pcs" // Default unit
      }));
      
      res.json(materialsWithDetails);
      
      await storage.createUserActivity(req.user!.id, "Generated inventory report");
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/reports/production", ensureAuthenticated, async (req, res, next) => {
    try {
      const fromDate = req.query.fromDate ? new Date(req.query.fromDate as string) : undefined;
      const toDate = req.query.toDate ? new Date(req.query.toDate as string) : undefined;
      const status = req.query.status as string;
      
      const { productionPlans: allPlans } = await storage.listProductionPlans(1, 1000, 
        status !== "All" ? status : undefined);
      
      // Filter by date if provided
      const filteredPlans = allPlans.filter(plan => {
        let matches = true;
        
        if (fromDate && new Date(plan.start_date) < fromDate) {
          matches = false;
        }
        
        if (toDate && new Date(plan.end_date) > toDate) {
          matches = false;
        }
        
        return matches;
      });
      
      // Add calculated fields for the report
      const plansWithDetails = await Promise.all(filteredPlans.map(async (plan) => {
        try {
          // Get the product item associated with this plan - with strict validation
          let productItem = null;
          const productItemId = plan.product_item_id;
          
          if (typeof productItemId === 'number' && Number.isInteger(productItemId) && productItemId > 0) {
            productItem = await storage.getProductItem(productItemId);
          } else if (productItemId !== undefined) {
            console.warn("Invalid product_item_id in production plan:", productItemId, "Type:", typeof productItemId);
          }
              
          return {
            ...plan,
            product_name: productItem?.name || "Unknown Product",
            progress: plan.status === "Completed" ? 100 : 
                     plan.status === "In Progress" ? Math.floor(Math.random() * 60) + 20 : 
                     plan.status === "Planned" ? 0 : 0
          };
        } catch (err) {
          console.error("Error in reports/production processing plan:", err, "Plan:", plan);
          return {
            ...plan,
            product_name: "Unknown Product",
            progress: 0
          };
        }
      }));
      
      res.json(plansWithDetails);
      
      await storage.createUserActivity(req.user!.id, "Generated production report");
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/reports/financial", ensureAuthenticated, async (req, res, next) => {
    try {
      const fromDate = req.query.fromDate ? new Date(req.query.fromDate as string) : undefined;
      const toDate = req.query.toDate ? new Date(req.query.toDate as string) : undefined;
      const type = req.query.type as string;
      
      // For the financial report, we'll use order data as the basis for revenue
      const { orders } = await storage.listOrders(1, 1000);
      
      // Parse date and filter
      const filteredOrders = orders.filter(order => {
        const orderDate = new Date(order.order_date);
        
        let matches = true;
        
        if (fromDate && orderDate < fromDate) {
          matches = false;
        }
        
        if (toDate && orderDate > toDate) {
          matches = false;
        }
        
        return matches;
      });
      
      // Format for financial report
      const financialEntries = filteredOrders.map(order => ({
        id: order.id,
        date: new Date(order.order_date).toISOString().split('T')[0],
        type: "Revenue",
        category: "Sales",
        description: `Order #${order.id} - ${order.customer_name || 'Customer'}`,
        amount: order.total_amount || 0,
        balance: 0 // Will be calculated below
      }));
      
      // Sort by date
      financialEntries.sort((a, b) => a.date.localeCompare(b.date));
      
      // Calculate running balance
      let runningBalance = 0;
      const entriesWithBalance = financialEntries.map(entry => {
        runningBalance += entry.amount;
        return {
          ...entry,
          balance: runningBalance
        };
      });
      
      // Filter by type if needed
      const finalEntries = type && type !== "All" ? 
        entriesWithBalance.filter(entry => entry.type === type) : entriesWithBalance;
      
      res.json(finalEntries);
      
      await storage.createUserActivity(req.user!.id, "Generated financial report");
    } catch (error) {
      next(error);
    }
  });

  // Notice System API Routes
  app.get("/api/notices", ensureAuthenticated, async (req, res, next) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const activeOnly = req.query.activeOnly === "true";
      const notices = await storage.listNotices(page, limit, activeOnly);
      res.json(notices);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/notices/active", ensureAuthenticated, async (req, res, next) => {
    try {
      const activeNotices = await storage.getActiveNotices();
      res.json(activeNotices);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/notices/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notice ID" });
      }
      
      const notice = await storage.getNotice(id);
      if (!notice) {
        return res.status(404).json({ message: "Notice not found" });
      }
      res.json(notice);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/notices", ensureAuthenticated, async (req, res, next) => {
    try {
      const noticeData = insertNoticeSchema.parse({
        ...req.body,
        created_by: req.user!.id
      });
      
      const notice = await storage.createNotice(noticeData);
      await storage.createUserActivity(req.user!.id, "Created notice", { noticeId: notice.id });
      res.status(201).json(notice);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/notices/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notice ID" });
      }
      
      const noticeData = req.body;
      const updated = await storage.updateNotice(id, noticeData);
      if (!updated) {
        return res.status(404).json({ message: "Notice not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Updated notice", { noticeId: id });
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/notices/:id", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notice ID" });
      }
      
      const deleted = await storage.deleteNotice(id);
      if (!deleted) {
        return res.status(404).json({ message: "Notice not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Deleted notice", { noticeId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/notices/:id/publish", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notice ID" });
      }
      
      const published = await storage.publishNotice(id);
      if (!published) {
        return res.status(404).json({ message: "Notice not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Published notice", { noticeId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/notices/check-scheduled", ensureAuthenticated, async (req, res, next) => {
    try {
      const publishedNotices = await storage.publishScheduledNotices();
      
      // Log the activity if any notices were published
      if (publishedNotices.length > 0) {
        await storage.createUserActivity(
          req.user!.id,
          "Checked scheduled notices",
          { count: publishedNotices.length }
        );
      }
      
      res.json({ 
        success: true,
        published: publishedNotices.length,
        notices: publishedNotices.map(n => ({ id: n.id, title: n.title }))
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/notices/:id/unpublish", ensureAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notice ID" });
      }
      
      const unpublished = await storage.unpublishNotice(id);
      if (!unpublished) {
        return res.status(404).json({ message: "Notice not found" });
      }
      
      await storage.createUserActivity(req.user!.id, "Unpublished notice", { noticeId: id });
      res.json({ success: true });
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}