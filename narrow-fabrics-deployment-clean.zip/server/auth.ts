import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import { compare, hash } from "bcrypt";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  // Using bcrypt with salt rounds of 10
  return await hash(password, 10);
}

export async function comparePasswords(supplied: string, stored: string) {
  try {
    console.log("Password comparison - Supplied password length:", supplied.length);
    console.log("Password comparison - Stored hash:", stored.substring(0, 10) + "...");
    
    // If it's a bcrypt hash (starts with $2b$)
    if (stored.startsWith('$2')) {
      console.log("Using bcrypt comparison");
      const result = await compare(supplied, stored);
      console.log("bcrypt comparison result:", result);
      return result;
    }
    
    // Legacy scrypt comparison (if we have any old passwords)
    console.log("Using legacy scrypt comparison");
    const [hashed, salt] = stored.split(".");
    if (!hashed || !salt) {
      console.log("Missing hash or salt components");
      return false;
    }
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    const result = timingSafeEqual(hashedBuf, suppliedBuf);
    console.log("scrypt comparison result:", result);
    return result;
  } catch (error) {
    console.error("Password comparison error:", error);
    return false;
  }
}

export function setupAuth(app: Express) {
  // Ensure we have a session secret
  if (!process.env.SESSION_SECRET) {
    console.error("SESSION_SECRET environment variable is not set");
    throw new Error("SESSION_SECRET environment variable is required");
  }
  
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log("Login attempt for username:", username);
        const user = await storage.getUserByUsername(username);
        
        if (!user) {
          console.log("User not found in database");
          return done(null, false);
        }
        
        console.log("User found, comparing passwords");
        const passwordMatches = await comparePasswords(password, user.password);
        
        if (!passwordMatches) {
          console.log("Password comparison failed");
          return done(null, false);
        } else {
          console.log("Password comparison succeeded");
          // Update last login timestamp
          await storage.updateUserLastLogin(user.id);
          return done(null, user);
        }
      } catch (error) {
        console.error("Error during authentication:", error);
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
      });

      // Log this activity
      await storage.createUserActivity(user.id, "User registered");

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", passport.authenticate("local"), async (req, res) => {
    if (req.user) {
      await storage.createUserActivity(req.user.id, "User logged in");
    }
    res.status(200).json(req.user);
  });

  app.post("/api/logout", async (req, res, next) => {
    if (req.user) {
      await storage.createUserActivity((req.user as SelectUser).id, "User logged out");
    }
    
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
