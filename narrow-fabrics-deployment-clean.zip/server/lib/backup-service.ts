import { db } from '../db';
import { backups, backupSchedules, backupNotifications, backupVersions } from '../../shared/schema';
import { storage } from '../storage';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import * as zlib from 'zlib';

// Create backup directory if it doesn't exist
const backupDir = path.join(process.cwd(), 'backups');
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
}

export interface BackupOptions {
  description?: string;
  backupType: 'full' | 'differential' | 'partial';
  isEncrypted: boolean;
  isCompressed: boolean;
  encryptionKey?: string;
  tablesToInclude?: string[];
  userId: number;
  retentionPeriod?: number;
  isAuto: boolean;
}

/**
 * Create a full backup of the database
 */
export async function createBackup(options: BackupOptions): Promise<{ filename: string, path: string, size: number }> {
  try {
    // Get data from all tables or selected tables
    const tables: any = {};
    
    if (options.backupType === 'full' || !options.tablesToInclude) {
      // Full backup - get all tables
      const [
        usersData, 
        itemUnitsData, 
        yarnTypesData, 
        colorTypesData, 
        materialsData, 
        productItemsData, 
        productionPlansData, 
        ordersData,
        itemSettingsData,
        dyeingChargesData,
        unitSettingsData,
        fabricPartsData,
        productionUnitSettingsData,
        fabricYarnTypesData,
        yarnCountsData,
        yarnPricesData,
        profitMarginsData
      ] = await Promise.all([
        db.query.users.findMany(),
        db.query.itemUnits.findMany(),
        db.query.yarnTypes.findMany(),
        db.query.colorTypes.findMany(),
        db.query.materials.findMany(),
        db.query.productItems.findMany(),
        db.query.productionPlans.findMany(),
        db.query.orders.findMany(),
        db.query.itemSettings.findMany(),
        db.query.dyeingCharges.findMany(),
        db.query.unitSettings.findMany(),
        db.query.fabricParts.findMany(),
        db.query.productionUnitSettings.findMany(),
        db.query.fabricYarnTypes.findMany(),
        db.query.yarnCounts.findMany(),
        db.query.yarnPrices.findMany(),
        db.query.profitMargins.findMany()
      ]);

      tables.users = usersData;
      tables.itemUnits = itemUnitsData;
      tables.yarnTypes = yarnTypesData;
      tables.colorTypes = colorTypesData;
      tables.materials = materialsData;
      tables.productItems = productItemsData;
      tables.productionPlans = productionPlansData;
      tables.orders = ordersData;
      tables.itemSettings = itemSettingsData;
      tables.dyeingCharges = dyeingChargesData;
      tables.unitSettings = unitSettingsData;
      tables.fabricParts = fabricPartsData;
      tables.productionUnitSettings = productionUnitSettingsData;
      tables.fabricYarnTypes = fabricYarnTypesData;
      tables.yarnCounts = yarnCountsData;
      tables.yarnPrices = yarnPricesData;
      tables.profitMargins = profitMarginsData;
    } else {
      // Partial backup - only get selected tables
      for (const tableName of options.tablesToInclude) {
        if (db.query[tableName]) {
          const tableData = await db.query[tableName].findMany();
          tables[tableName] = tableData;
        }
      }
    }

    // Create the backup data object
    const backupData = {
      version: "1.0.0",
      timestamp: new Date().toISOString(),
      backupType: options.backupType,
      tablesToInclude: options.tablesToInclude || 'all',
      isEncrypted: options.isEncrypted,
      isCompressed: options.isCompressed,
      ...tables
    };

    // Convert the backup data to JSON
    let backupContent = JSON.stringify(backupData, null, 2);

    // Encrypt if needed
    if (options.isEncrypted && options.encryptionKey) {
      backupContent = encryptData(backupContent, options.encryptionKey);
    }

    // Compress if needed
    if (options.isCompressed) {
      backupContent = await compressData(backupContent);
    }

    // Create a unique filename
    const timestamp = new Date().toISOString().replace(/[:\.]/g, '-');
    const backupType = options.backupType;
    const filename = `backup-${backupType}-${timestamp}.json`;
    const backupPath = path.join(backupDir, filename);

    // Write the backup file
    fs.writeFileSync(backupPath, backupContent);

    // Get the file size
    const stats = fs.statSync(backupPath);
    const fileSize = stats.size;

    // Store backup metadata in the database
    const backupRecord = await db.insert(backups).values({
      filename,
      description: options.description || `${backupType} backup created on ${new Date().toLocaleString()}`,
      file_size: fileSize,
      backup_type: backupType,
      version: "1.0.0",
      is_encrypted: options.isEncrypted,
      is_compressed: options.isCompressed,
      tables_included: options.tablesToInclude,
      storage_path: backupPath,
      created_by: options.userId,
      retention_period: options.retentionPeriod,
      is_auto: options.isAuto
    }).returning();

    // Record activity
    await storage.createUserActivity(
      options.userId, 
      `Created ${backupType} backup`, 
      { filename, size: fileSize }
    );

    // If there are any users with notifications enabled, notify them
    const usersWithNotifications = await db.select().from(backupNotifications).where({
      notify_on_success: true
    });

    for (const userNotif of usersWithNotifications) {
      // Here we would send notifications, but for now we'll just log
      console.log(`Would send backup success notification to user ${userNotif.user_id}`);
      // In the future, implement email or push notifications here
    }

    // Cleanup old backups based on retention policy
    await cleanupOldBackups();

    return {
      filename,
      path: backupPath,
      size: fileSize
    };
  } catch (error) {
    console.error("Error creating backup:", error);

    // Notify users of failure if they have notifications enabled
    const usersWithNotifications = await db.select().from(backupNotifications).where({
      notify_on_failure: true
    });

    for (const userNotif of usersWithNotifications) {
      // Here we would send failure notifications
      console.log(`Would send backup failure notification to user ${userNotif.user_id}`);
    }

    throw error;
  }
}

/**
 * Restore the database from a backup file
 */
export async function restoreFromBackup(backupFilePath: string, userId: number, options?: {
  encryptionKey?: string;
  tablesToRestore?: string[];
}): Promise<boolean> {
  try {
    // Read the backup file
    let backupContent = fs.readFileSync(backupFilePath, 'utf-8');

    // Check if the backup is encrypted
    try {
      const backupData = JSON.parse(backupContent);
      
      // If we can parse it as JSON, it's not encrypted
      if (backupData.isEncrypted && options?.encryptionKey) {
        // We shouldn't get here if it's actually encrypted
        throw new Error("Backup is marked as encrypted but content is not encrypted");
      }
    } catch (e) {
      // If we can't parse it as JSON, it might be encrypted
      if (options?.encryptionKey) {
        backupContent = decryptData(backupContent, options.encryptionKey);
      } else {
        throw new Error("Backup file is encrypted but no encryption key provided");
      }
    }

    // Parse the backup data
    const backupData = JSON.parse(backupContent);

    // Check if the backup is compressed and decompress if needed
    if (backupData.isCompressed) {
      backupContent = await decompressData(backupContent);
      // Parse again after decompression
      const backupData = JSON.parse(backupContent);
    }

    // Create an automatic backup before restoring
    await createBackup({
      description: "Automatic backup before restore operation",
      backupType: "full",
      isEncrypted: false,
      isCompressed: true,
      userId,
      isAuto: true
    });

    // Determine which tables to restore
    const tablesToRestore = options?.tablesToRestore || Object.keys(backupData).filter(key => 
      key !== 'version' && 
      key !== 'timestamp' && 
      key !== 'backupType' && 
      key !== 'tablesToInclude' && 
      key !== 'isEncrypted' && 
      key !== 'isCompressed'
    );

    // TODO: Implement actual database restore logic for each table
    // This would involve clearing tables and re-inserting all the data from the backup file
    // For now, we'll just log what we would restore

    // Record activity
    await storage.createUserActivity(
      userId, 
      `Restored from backup`, 
      { filename: path.basename(backupFilePath), tables: tablesToRestore }
    );

    return true;
  } catch (error) {
    console.error("Error restoring from backup:", error);
    throw error;
  }
}

/**
 * Get scheduled backups that are due to run
 */
export async function getScheduledBackupsDue(): Promise<typeof backupSchedules.$inferSelect[]> {
  try {
    const now = new Date();
    
    // Get all active backup schedules
    const schedules = await db.select().from(backupSchedules).where({
      is_active: true
    });

    // Filter for schedules that are due
    const dueSchedules = schedules.filter(schedule => {
      if (!schedule.next_run) {
        return true; // Never run before, so it's due
      }
      
      const nextRunDate = new Date(schedule.next_run);
      return nextRunDate <= now;
    });

    return dueSchedules;
  } catch (error) {
    console.error("Error getting scheduled backups due:", error);
    throw error;
  }
}

/**
 * Run scheduled backup
 */
export async function runScheduledBackup(schedule: typeof backupSchedules.$inferSelect): Promise<void> {
  try {
    // Create the backup
    await createBackup({
      description: `Scheduled backup: ${schedule.name}`,
      backupType: schedule.backup_type as 'full' | 'differential' | 'partial',
      isEncrypted: schedule.is_encrypted,
      isCompressed: schedule.is_compressed,
      tablesToInclude: schedule.tables_to_include,
      userId: schedule.created_by,
      retentionPeriod: schedule.retention_period,
      isAuto: true
    });

    // Calculate the next run time based on frequency
    const now = new Date();
    let nextRun: Date;

    switch (schedule.frequency) {
      case 'daily':
        nextRun = new Date(now);
        nextRun.setDate(nextRun.getDate() + 1);
        break;
      case 'weekly':
        nextRun = new Date(now);
        const dayDiff = ((schedule.day_of_week || 0) - now.getDay() + 7) % 7;
        nextRun.setDate(nextRun.getDate() + (dayDiff === 0 ? 7 : dayDiff));
        break;
      case 'monthly':
        nextRun = new Date(now);
        nextRun.setMonth(nextRun.getMonth() + 1);
        if (schedule.day_of_month) {
          nextRun.setDate(Math.min(schedule.day_of_month, getLastDayOfMonth(nextRun)));
        }
        break;
      default:
        nextRun = new Date(now);
        nextRun.setDate(nextRun.getDate() + 1);
    }

    // Set the time of day from the schedule
    if (schedule.time_of_day) {
      const timeArr = schedule.time_of_day.split(':');
      nextRun.setHours(parseInt(timeArr[0]), parseInt(timeArr[1]), 0, 0);
    }

    // Update the schedule in the database
    await db.update(backupSchedules)
      .set({
        last_run: now,
        next_run: nextRun
      })
      .where({ id: schedule.id });

  } catch (error) {
    console.error(`Error running scheduled backup ${schedule.name}:`, error);
    
    // Notify users of failure if they have notifications enabled
    const usersWithNotifications = await db.select().from(backupNotifications).where({
      notify_on_failure: true
    });

    for (const userNotif of usersWithNotifications) {
      // Here we would send failure notifications
      console.log(`Would send scheduled backup failure notification to user ${userNotif.user_id}`);
    }
  }
}

/**
 * Clean up old backups based on retention policies
 */
async function cleanupOldBackups(): Promise<void> {
  try {
    // Get all backups with retention periods
    const backupsWithRetention = await db.select().from(backups).where({
      retention_period: { not: null }
    });

    const now = new Date();

    for (const backup of backupsWithRetention) {
      if (backup.retention_period) {
        const backupDate = new Date(backup.created_at);
        const expiryDate = new Date(backupDate);
        expiryDate.setDate(expiryDate.getDate() + backup.retention_period);

        // If the backup is expired, delete it
        if (expiryDate < now) {
          // Delete the file
          if (fs.existsSync(backup.storage_path)) {
            fs.unlinkSync(backup.storage_path);
          }

          // Delete the database record
          await db.delete(backups).where({ id: backup.id });

          console.log(`Deleted expired backup: ${backup.filename}`);
        }
      }
    }
  } catch (error) {
    console.error("Error cleaning up old backups:", error);
  }
}

/**
 * Create a differential backup (only changes since last full backup)
 */
export async function createDifferentialBackup(options: BackupOptions): Promise<{ filename: string, path: string, size: number }> {
  try {
    // Get the most recent full backup
    const latestFullBackup = await db.select().from(backups)
      .where({ backup_type: 'full' })
      .orderBy({ created_at: 'desc' })
      .limit(1);

    if (latestFullBackup.length === 0) {
      throw new Error("No full backup found to create differential backup from");
    }

    const fullBackupDate = new Date(latestFullBackup[0].created_at);
    
    // Get all data modified since the last full backup
    // This is a simplified approach; in a real implementation, you would track record changes
    const tables: any = {};
    
    const [
      usersData, 
      itemUnitsData, 
      // ... other tables
    ] = await Promise.all([
      db.query.users.findMany({ where: { updated_at: { gt: fullBackupDate } } }),
      db.query.itemUnits.findMany({ where: { updated_at: { gt: fullBackupDate } } }),
      // ... queries for other tables
    ]);

    tables.users = usersData;
    tables.itemUnits = itemUnitsData;
    // ... add other tables

    // Rest of backup creation follows the same pattern as full backup
    // with different metadata to indicate it's differential

    // Placeholder return until full implementation
    return await createBackup({
      ...options,
      description: `Differential backup since ${fullBackupDate.toLocaleString()}`,
      backupType: 'differential'
    });
  } catch (error) {
    console.error("Error creating differential backup:", error);
    throw error;
  }
}

/**
 * Encrypt data with AES-256
 */
function encryptData(data: string, key: string): string {
  try {
    // Create a key buffer from the provided key (must be 32 bytes for AES-256)
    const keyBuffer = Buffer.from(key.padEnd(32, '0').slice(0, 32));
    
    // Create initialization vector
    const iv = crypto.randomBytes(16);
    
    // Create cipher
    const cipher = crypto.createCipheriv('aes-256-cbc', keyBuffer, iv);
    
    // Encrypt the data
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    // Prepend the IV to the encrypted data (IV needs to be known for decryption)
    return iv.toString('hex') + ':' + encrypted;
  } catch (error) {
    console.error("Error encrypting data:", error);
    throw error;
  }
}

/**
 * Decrypt data with AES-256
 */
function decryptData(encryptedData: string, key: string): string {
  try {
    // Split the encrypted data to get the IV and the actual encrypted content
    const parts = encryptedData.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encryptedText = parts[1];
    
    // Create a key buffer from the provided key (must be 32 bytes for AES-256)
    const keyBuffer = Buffer.from(key.padEnd(32, '0').slice(0, 32));
    
    // Create decipher
    const decipher = crypto.createDecipheriv('aes-256-cbc', keyBuffer, iv);
    
    // Decrypt the data
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    console.error("Error decrypting data:", error);
    throw error;
  }
}

/**
 * Compress data using gzip
 */
async function compressData(data: string): Promise<string> {
  return new Promise((resolve, reject) => {
    zlib.gzip(data, (err, compressed) => {
      if (err) {
        reject(err);
      } else {
        resolve(compressed.toString('base64'));
      }
    });
  });
}

/**
 * Decompress data using gzip
 */
async function decompressData(compressedData: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const buffer = Buffer.from(compressedData, 'base64');
    zlib.gunzip(buffer, (err, decompressed) => {
      if (err) {
        reject(err);
      } else {
        resolve(decompressed.toString());
      }
    });
  });
}

/**
 * Get the last day of the month for a given date
 */
function getLastDayOfMonth(date: Date): number {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
}