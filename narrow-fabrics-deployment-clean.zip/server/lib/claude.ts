
import Anthropic from '@anthropic-ai/sdk';
import { type StreamingCompletion } from '@anthropic-ai/sdk/streaming';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export async function askClaude(prompt: string) {
  const message = await anthropic.messages.create({
    model: "claude-3-opus-20240229",
    max_tokens: 1024,
    messages: [{ role: "user", content: prompt }]
  });
  
  return message.content[0].text;
}

export async function streamClaude(prompt: string): Promise<StreamingCompletion> {
  const stream = await anthropic.messages.stream({
    model: "claude-3-opus-20240229",
    max_tokens: 1024,
    messages: [{ role: "user", content: prompt }]
  });

  return stream;
}
