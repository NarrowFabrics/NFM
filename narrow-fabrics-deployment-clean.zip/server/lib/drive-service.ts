import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';
import { Readable } from 'stream';

// These will be loaded from environment variables
let CLIENT_ID: string;
let CLIENT_SECRET: string;
let REDIRECT_URI: string;

// Scopes for Google Drive access
const SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.appdata'
];

/**
 * Initialize the Google Drive service with OAuth credentials
 */
export function initDriveService() {
  try {
    CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
    CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '';
    REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || 'http://localhost:5000/auth/google/callback';
    
    if (!CLIENT_ID || !CLIENT_SECRET) {
      console.warn('Google Drive credentials not configured. Some features may not work.');
    } else {
      console.log('Google Drive service initialized successfully.');
      console.log('Using redirect URI:', REDIRECT_URI);
      console.log('Using client ID:', CLIENT_ID.substring(0, 10) + '...');
    }
  } catch (error) {
    console.error('Failed to initialize Google Drive service:', error);
  }
}

/**
 * Create an OAuth2 client
 */
export function getOAuth2Client(): OAuth2Client {
  return new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
}

/**
 * Generate the authorization URL for user login
 */
export function getAuthUrl(): string {
  const oauth2Client = getOAuth2Client();
  
  // Log the actual client ID being used to help debug issues
  console.log('Starting Google auth flow...');
  const authUrl = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent' // Force to get refresh token every time
  });
  console.log('Generated auth URL:', authUrl);
  
  return authUrl;
}

/**
 * Exchange authorization code for tokens
 */
export async function getTokens(code: string) {
  const oauth2Client = getOAuth2Client();
  const { tokens } = await oauth2Client.getToken(code);
  return tokens;
}

/**
 * Create a drive client for a user with tokens
 */
export function createDriveClient(tokens: any) {
  const oauth2Client = getOAuth2Client();
  oauth2Client.setCredentials(tokens);
  return google.drive({ version: 'v3', auth: oauth2Client });
}

/**
 * Upload a file to Google Drive
 * @param drive - The authenticated drive client
 * @param fileData - The file data buffer or stream
 * @param filename - The name to give the file
 * @param mimeType - The MIME type of the file
 * @param folderId - Optional Google Drive folder ID to store the file in
 */
export async function uploadFile(
  drive: any, 
  fileData: Buffer | Readable, 
  filename: string, 
  mimeType: string,
  folderId?: string
) {
  const requestBody: any = {
    name: filename,
    mimeType: mimeType
  };
  
  if (folderId) {
    requestBody.parents = [folderId];
  }
  
  const media = {
    mimeType,
    body: fileData instanceof Buffer ? Readable.from(fileData) : fileData
  };
  
  try {
    const response = await drive.files.create({
      requestBody,
      media,
      fields: 'id,name,webViewLink'
    });
    
    return response.data;
  } catch (error) {
    console.error('Error uploading file to Google Drive:', error);
    throw error;
  }
}

/**
 * Download a file from Google Drive
 * @param drive - The authenticated drive client
 * @param fileId - The ID of the file to download
 */
export async function downloadFile(drive: any, fileId: string) {
  try {
    const response = await drive.files.get({
      fileId: fileId,
      alt: 'media'
    }, { responseType: 'stream' });
    
    return response.data;
  } catch (error) {
    console.error('Error downloading file from Google Drive:', error);
    throw error;
  }
}

/**
 * List files in a user's Google Drive
 * @param drive - The authenticated drive client
 * @param folderId - Optional Google Drive folder ID to list files from
 */
export async function listFiles(drive: any, folderId?: string) {
  try {
    const query = folderId ? `'${folderId}' in parents` : undefined;
    
    const response = await drive.files.list({
      q: query,
      fields: 'files(id, name, mimeType, webViewLink, createdTime, modifiedTime, size)',
      orderBy: 'modifiedTime desc'
    });
    
    return response.data.files;
  } catch (error) {
    console.error('Error listing files from Google Drive:', error);
    throw error;
  }
}

/**
 * Create a folder in Google Drive
 * @param drive - The authenticated drive client
 * @param folderName - The name of the folder to create
 * @param parentFolderId - Optional parent folder ID
 */
export async function createFolder(drive: any, folderName: string, parentFolderId?: string) {
  const requestBody: any = {
    name: folderName,
    mimeType: 'application/vnd.google-apps.folder'
  };
  
  if (parentFolderId) {
    requestBody.parents = [parentFolderId];
  }
  
  try {
    const response = await drive.files.create({
      requestBody,
      fields: 'id,name,webViewLink'
    });
    
    return response.data;
  } catch (error) {
    console.error('Error creating folder in Google Drive:', error);
    throw error;
  }
}

/**
 * Delete a file from Google Drive
 * @param drive - The authenticated drive client
 * @param fileId - The ID of the file to delete
 */
export async function deleteFile(drive: any, fileId: string) {
  try {
    await drive.files.delete({
      fileId
    });
    return true;
  } catch (error) {
    console.error('Error deleting file from Google Drive:', error);
    throw error;
  }
}

/**
 * Generate a public sharing link for a file
 * @param drive - The authenticated drive client
 * @param fileId - The ID of the file to share
 * @param role - The role to grant (reader, writer, commenter)
 */
export async function shareFile(drive: any, fileId: string, role: 'reader' | 'writer' | 'commenter' = 'reader') {
  try {
    await drive.permissions.create({
      fileId,
      requestBody: {
        role,
        type: 'anyone'
      }
    });
    
    const file = await drive.files.get({
      fileId,
      fields: 'webViewLink, webContentLink'
    });
    
    return file.data;
  } catch (error) {
    console.error('Error sharing file from Google Drive:', error);
    throw error;
  }
}