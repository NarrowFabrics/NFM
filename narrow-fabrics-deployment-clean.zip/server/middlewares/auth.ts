import { Request, Response, NextFunction } from 'express';

// Add user property to Express Request
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        username: string;
        email: string;
        role: string;
        is_admin: boolean;
        permissions?: string[];
      };
    }
  }
}

// Authentication middleware
export const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  // Session-based authentication
  if (req.session && req.session.user) {
    req.user = req.session.user;
    return next();
  }
  
  // For API routes, return 401 Unauthorized
  return res.status(401).json({
    error: 'Authentication required',
    message: 'You must be logged in to access this resource'
  });
};

// Authorization middleware for specific permissions
export const hasPermission = (permission: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    // First check authentication
    if (!req.user) {
      return res.status(401).json({ 
        error: 'Authentication required',
        message: 'You must be logged in to access this resource'
      });
    }
    
    // Admin users have all permissions
    if (req.user.is_admin) {
      return next();
    }
    
    // Check if user has the specific permission
    if (req.user.permissions && req.user.permissions.includes(permission)) {
      return next();
    }
    
    // If we get here, user doesn't have required permission
    return res.status(403).json({
      error: 'Permission denied',
      message: `You don't have the necessary permission: ${permission}`
    });
  };
};