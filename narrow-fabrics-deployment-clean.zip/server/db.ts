import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import { exec } from 'child_process';
import { promisify } from 'util';
import dotenv from 'dotenv';
import path from 'path';

// Load environment variables from .env file
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

// For Replit-specific environment variable access
async function getEnvVar(name: string): Promise<string | undefined> {
  try {
    if (process.env[name]) {
      return process.env[name];
    }
    
    const execPromise = promisify(exec);
    const { stdout } = await execPromise(`echo $${name}`);
    const value = stdout.trim();
    return value || undefined;
  } catch (error) {
    console.error(`Error getting environment variable ${name}:`, error);
    return undefined;
  }
}

// Create the PostgreSQL connection pool
let pool: pg.Pool | undefined;

// Function to initialize the pool
async function createPool(): Promise<pg.Pool> {
  // Get environment variables for database connections
  let neonUrl = process.env.NEON_DATABASE_URL || await getEnvVar('NEON_DATABASE_URL');
  const localUrl = process.env.DATABASE_URL || await getEnvVar('DATABASE_URL');
  
  // Check if neonUrl is in a valid format (not binary or hex encoded)
  if (neonUrl && /\\x[0-9a-fA-F]{2}/.test(neonUrl)) {
    console.warn("NEON_DATABASE_URL appears to be binary or hex encoded, which is invalid");
    console.warn("Please provide a proper PostgreSQL connection string in the format:");
    console.warn("postgresql://username:password@hostname/database");
    // Clear the invalid URL so we fall back to local
    neonUrl = undefined;
  }
  
  // Validate the URL format if it exists
  if (neonUrl) {
    try {
      // Make sure the URL is a valid PostgreSQL connection string
      const url = new URL(neonUrl);
      if (url.protocol !== 'postgresql:') {
        console.warn(`Invalid protocol in NEON_DATABASE_URL: ${url.protocol}`);
        neonUrl = undefined;
      }
    } catch (error) {
      console.warn("Invalid NEON_DATABASE_URL format:", error.message);
      neonUrl = undefined;
    }
  }
  
  // Debug environment variables
  console.log("Environment variables:");
  console.log("USE_NEON_DB:", process.env.USE_NEON_DB);
  console.log("NEON_DATABASE_URL exists:", !!neonUrl);
  console.log("DATABASE_URL exists:", !!localUrl);
  
  let connectionString: string | undefined;
  let useNeonDb = process.env.USE_NEON_DB === 'true';
  
  // Use Neon database if USE_NEON_DB is set to true or if no local URL is available
  if (useNeonDb && neonUrl) {
    connectionString = neonUrl;
    useNeonDb = true;
    console.log("Using Neon cloud database for connection (prioritized)");
  } else if (localUrl) {
    connectionString = localUrl;
    useNeonDb = false;
    console.log("Using local PostgreSQL database for connection");
  } else if (neonUrl) {
    // Try Neon as fallback
    connectionString = neonUrl;
    useNeonDb = true;
    console.log("Using Neon cloud database for connection (fallback)");
  } else {
    console.warn("No database URLs found");
  }

  if (!connectionString) {
    throw new Error("No database connection string available. Please set DATABASE_URL or NEON_DATABASE_URL environment variables");
  }

  console.log("Connecting to database...");
  
  // Configure the connection pool
  return new pg.Pool({ 
    connectionString,
    // Enable SSL for Neon Database, optional for local PostgreSQL
    ssl: (useNeonDb || process.env.REQUIRE_SSL === 'true') ? {
      rejectUnauthorized: false
    } : undefined
  });
}

// Initialize pool asynchronously
(async () => {
  try {
    pool = await createPool();
    console.log("Database pool created successfully");
  } catch (err) {
    console.error("Failed to create database pool:", err);
  }
})();

// Create a placeholder for the drizzle instance that we'll initialize in initializeDatabase
let _db: ReturnType<typeof drizzle>;

// Export a getter function for the db that ensures it's initialized
export const db = {
  get query() {
    if (!_db) {
      throw new Error("Database not initialized yet. Call initializeDatabase() first.");
    }
    return _db;
  },
  get schema() {
    if (!_db) {
      throw new Error("Database not initialized yet. Call initializeDatabase() first.");
    }
    return _db.query;
  }
};

// Export the pool for direct query access
export { pool };

export async function initializeDatabase() {
  try {
    console.log("Initializing database connection...");

    // Make sure pool is initialized
    if (!pool) {
      console.log("Pool not initialized yet, initializing now...");
      pool = await createPool();
    }

    // Initialize the drizzle instance
    _db = drizzle(pool);

    // Test the connection
    const client = await pool.connect();
    try {
      const result = await client.query("SELECT NOW()");
      console.log("Database connection successful", result.rows[0]);

      // Check if tables exist or need to be created
      const tablesExist = await client.query("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'users')");
      if (!tablesExist.rows[0].exists) {
        console.log("Tables don't exist yet. Run 'npm run db:push' to create them.");
      } else {
        console.log("Database tables exist and are ready to use.");
      }
    } finally {
      client.release(); // Release the client back to the pool
    }

    return true;
  } catch (error) {
    console.error("Database initialization error:", error);
    throw error;
  }
}