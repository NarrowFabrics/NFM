import {
  users, userActivities, itemUnits, yarnTypes, colorTypes, 
  materials, productItems, productionPlans, orders, orderItems,
  partOfItems, itemSettings, dyeingCharges, dyeingChanges, unitSettings,
  fabricParts, productionUnitSettings, fabricYarnTypes, yarnCounts, yarnPrices, profitMargins,
  priceQuotations, notices, systemMetrics,
  type User, type InsertUser, type ItemUnit, type InsertItemUnit,
  type YarnType, type InsertYarnType, type ColorType, type InsertColorType,
  type Material, type InsertMaterial, type ProductItem, type InsertProductItem,
  type ProductionPlan, type InsertProductionPlan, type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem, type InsertUserActivity, type UserActivity,
  type ItemSetting, type InsertItemSetting, type DyeingChange, type InsertDyeingChange, type DyeingCharge, type InsertDyeingCharge,
  type UnitSetting, type InsertUnitSetting,
  type FabricPart, type InsertFabricPart,
  type ProductionUnitSettingDb as ProductionUnitSetting, 
  type InsertProductionUnitSettingDb as InsertProductionUnitSetting,
  type FabricYarnType, type InsertFabricYarnType,
  type YarnCount, type InsertYarnCount,
  type YarnPrice, type InsertYarnPrice,
  type ProfitMargin, type InsertProfitMargin,
  type PriceQuotation, type InsertPriceQuotation,
  type Notice, type InsertNotice,
  type SystemMetric, type InsertSystemMetric
} from "@shared/schema";
import { db, pool } from "./db";
import { eq, desc, and, like, sql, asc } from "drizzle-orm";
import session from "express-session";
import createMemoryStore from "memorystore";

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  listUsers(page?: number, limit?: number, search?: string): Promise<{ users: User[], total: number }>;
  updateUserLastLogin(id: number): Promise<boolean>;
  
  // Yarn Categories
  createYarnCategory(category: InsertYarnCategory): Promise<YarnCategory>;
  getYarnCategory(id: number): Promise<YarnCategory | undefined>;
  updateYarnCategory(id: number, categoryData: Partial<InsertYarnCategory>): Promise<YarnCategory | undefined>;
  deleteYarnCategory(id: number): Promise<boolean>;
  listYarnCategories(page?: number, limit?: number, activeOnly?: boolean): Promise<{ categories: YarnCategory[], total: number }>;
  
  // Price Quotations
  createPriceQuotation(quotation: InsertPriceQuotation): Promise<PriceQuotation>;
  getPriceQuotation(id: number): Promise<PriceQuotation | undefined>;
  updatePriceQuotation(id: number, quotationData: Partial<InsertPriceQuotation>): Promise<PriceQuotation | undefined>;
  deletePriceQuotation(id: number): Promise<boolean>;
  listPriceQuotations(page?: number, limit?: number, filter?: string): Promise<{ quotations: PriceQuotation[], total: number }>;
  
  // User activities
  createUserActivity(userId: number, action: string, details?: Record<string, any>): Promise<UserActivity>;
  getUserActivities(userId: number, page?: number, limit?: number): Promise<{ activities: UserActivity[], total: number }>;
  getRecentUserActivities(limit?: number): Promise<UserActivity[]>;
  
  // Item Units
  createItemUnit(itemUnit: InsertItemUnit): Promise<ItemUnit>;
  getItemUnit(id: number): Promise<ItemUnit | undefined>;
  updateItemUnit(id: number, itemUnitData: Partial<InsertItemUnit>): Promise<ItemUnit | undefined>;
  deleteItemUnit(id: number): Promise<boolean>;
  listItemUnits(page?: number, limit?: number): Promise<{ itemUnits: ItemUnit[], total: number }>;
  
  // Yarn Types
  createYarnType(yarnType: InsertYarnType): Promise<YarnType>;
  getYarnType(id: number): Promise<YarnType | undefined>;
  updateYarnType(id: number, yarnTypeData: Partial<InsertYarnType>): Promise<YarnType | undefined>;
  deleteYarnType(id: number): Promise<boolean>;
  listYarnTypes(page?: number, limit?: number, activeOnly?: boolean): Promise<{ yarnTypes: YarnType[], total: number }>;
  
  // Color Types
  createColorType(colorType: InsertColorType): Promise<ColorType>;
  getColorType(id: number): Promise<ColorType | undefined>;
  updateColorType(id: number, colorTypeData: Partial<InsertColorType>): Promise<ColorType | undefined>;
  deleteColorType(id: number): Promise<boolean>;
  listColorTypes(page?: number, limit?: number, activeOnly?: boolean): Promise<{ colorTypes: ColorType[], total: number }>;
  
  // Materials
  createMaterial(material: InsertMaterial): Promise<Material>;
  getMaterial(id: number): Promise<Material | undefined>;
  updateMaterial(id: number, materialData: Partial<InsertMaterial>): Promise<Material | undefined>;
  deleteMaterial(id: number): Promise<boolean>;
  listMaterials(page?: number, limit?: number, category?: string): Promise<{ materials: Material[], total: number }>;
  
  // Product Items
  createProductItem(productItem: InsertProductItem): Promise<ProductItem>;
  getProductItem(id: number): Promise<ProductItem | undefined>;
  updateProductItem(id: number, productItemData: Partial<InsertProductItem>): Promise<ProductItem | undefined>;
  deleteProductItem(id: number): Promise<boolean>;
  listProductItems(page?: number, limit?: number, category?: string): Promise<{ productItems: ProductItem[], total: number }>;
  
  // Production Plans
  createProductionPlan(productionPlan: InsertProductionPlan): Promise<ProductionPlan>;
  getProductionPlan(id: number): Promise<ProductionPlan | undefined>;
  updateProductionPlan(id: number, productionPlanData: Partial<InsertProductionPlan>): Promise<ProductionPlan | undefined>;
  deleteProductionPlan(id: number): Promise<boolean>;
  listProductionPlans(page?: number, limit?: number, status?: string): Promise<{ productionPlans: ProductionPlan[], total: number }>;
  getRecentProductionPlans(limit?: number): Promise<ProductionPlan[]>;
  
  // Orders
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  updateOrder(id: number, orderData: Partial<InsertOrder>): Promise<Order | undefined>;
  deleteOrder(id: number): Promise<boolean>;
  listOrders(page?: number, limit?: number, status?: string): Promise<{ orders: Order[], total: number }>;
  getRecentOrders(limit?: number): Promise<Order[]>;
  
  // Order Items
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  deleteOrderItem(id: number): Promise<boolean>;
  
  // Item Settings
  createItemSetting(itemSetting: InsertItemSetting): Promise<ItemSetting>;
  getItemSetting(id: number): Promise<ItemSetting | undefined>;
  updateItemSetting(id: number, itemSettingData: Partial<InsertItemSetting>): Promise<ItemSetting | undefined>;
  deleteItemSetting(id: number): Promise<boolean>;
  listItemSettings(page?: number, limit?: number, activeOnly?: boolean): Promise<{ itemSettings: ItemSetting[], total: number }>;
  
  // Dyeing Charges
  createDyeingCharge(dyeingCharge: InsertDyeingCharge): Promise<DyeingCharge>;
  getDyeingCharge(id: number): Promise<DyeingCharge | undefined>;
  updateDyeingCharge(id: number, dyeingChargeData: Partial<InsertDyeingCharge>): Promise<DyeingCharge | undefined>;
  deleteDyeingCharge(id: number): Promise<boolean>;
  // Dyeing Changes
  createDyeingChange(dyeingChange: InsertDyeingChange): Promise<DyeingChange>;
  getDyeingChange(id: number): Promise<DyeingChange | undefined>;
  updateDyeingChange(id: number, dyeingChangeData: Partial<InsertDyeingChange>): Promise<DyeingChange | undefined>;
  deleteDyeingChange(id: number): Promise<boolean>;
  listDyeingChanges(page?: number, limit?: number, activeOnly?: boolean): Promise<{ dyeingChanges: DyeingChange[], total: number }>;

  listDyeingCharges(page?: number, limit?: number, activeOnly?: boolean): Promise<{ dyeingCharges: DyeingCharge[], total: number }>;
  
  // Unit Settings
  createUnitSetting(unitSetting: InsertUnitSetting): Promise<UnitSetting>;
  getUnitSetting(id: number): Promise<UnitSetting | undefined>;
  updateUnitSetting(id: number, unitSettingData: Partial<InsertUnitSetting>): Promise<UnitSetting | undefined>;
  deleteUnitSetting(id: number): Promise<boolean>;
  listUnitSettings(page?: number, limit?: number, activeOnly?: boolean): Promise<{ unitSettings: UnitSetting[], total: number }>;
  
  // Dashboard data
  getDashboardStats(): Promise<{
    totalOrders: number;
    totalProductionPlans: number;
    totalMaterials: number;
    totalRevenue: number;
  }>;

  // Narrow Fabric Settings - Fabric Parts
  createFabricPart(part: InsertFabricPart): Promise<FabricPart>;
  getFabricPart(id: number): Promise<FabricPart | undefined>;
  updateFabricPart(id: number, partData: Partial<InsertFabricPart>): Promise<FabricPart | undefined>;
  deleteFabricPart(id: number): Promise<boolean>;
  listFabricParts(page?: number, limit?: number, activeOnly?: boolean): Promise<{ fabricParts: FabricPart[], total: number }>;

  // Narrow Fabric Settings - Production Unit Settings
  createProductionUnitSetting(setting: InsertProductionUnitSetting): Promise<ProductionUnitSetting>;
  getProductionUnitSetting(id: number): Promise<ProductionUnitSetting | undefined>;
  updateProductionUnitSetting(id: number, settingData: Partial<InsertProductionUnitSetting>): Promise<ProductionUnitSetting | undefined>;
  deleteProductionUnitSetting(id: number): Promise<boolean>;
  listProductionUnitSettings(page?: number, limit?: number, activeOnly?: boolean): Promise<{ settings: ProductionUnitSetting[], total: number }>;

  // Narrow Fabric Settings - Fabric Yarn Types
  createFabricYarnType(yarnType: InsertFabricYarnType): Promise<FabricYarnType>;
  getFabricYarnType(id: number): Promise<FabricYarnType | undefined>;
  updateFabricYarnType(id: number, yarnTypeData: Partial<InsertFabricYarnType>): Promise<FabricYarnType | undefined>;
  deleteFabricYarnType(id: number): Promise<boolean>;
  listFabricYarnTypes(page?: number, limit?: number, activeOnly?: boolean): Promise<{ yarnTypes: FabricYarnType[], total: number }>;

  // Narrow Fabric Settings - Yarn Counts
  createYarnCount(count: InsertYarnCount): Promise<YarnCount>;
  getYarnCount(id: number): Promise<YarnCount | undefined>;
  updateYarnCount(id: number, countData: Partial<InsertYarnCount>): Promise<YarnCount | undefined>;
  deleteYarnCount(id: number): Promise<boolean>;
  listYarnCounts(page?: number, limit?: number, activeOnly?: boolean): Promise<{ counts: YarnCount[], total: number }>;

  // Narrow Fabric Settings - Yarn Prices
  createYarnPrice(price: InsertYarnPrice): Promise<YarnPrice>;
  getYarnPrice(id: number): Promise<YarnPrice | undefined>;
  updateYarnPrice(id: number, priceData: Partial<InsertYarnPrice>): Promise<YarnPrice | undefined>;
  deleteYarnPrice(id: number): Promise<boolean>;
  listYarnPrices(page?: number, limit?: number, activeOnly?: boolean): Promise<{ prices: YarnPrice[], total: number }>;
  
  // Narrow Fabric Settings - Profit Margins
  createProfitMargin(margin: InsertProfitMargin): Promise<ProfitMargin>;
  getProfitMargin(id: number): Promise<ProfitMargin | undefined>;
  updateProfitMargin(id: number, marginData: Partial<InsertProfitMargin>): Promise<ProfitMargin | undefined>;
  deleteProfitMargin(id: number): Promise<boolean>;
  listProfitMargins(page?: number, limit?: number, activeOnly?: boolean): Promise<{ margins: ProfitMargin[], total: number }>;
  
  // Notice System
  createNotice(notice: InsertNotice): Promise<Notice>;
  getNotice(id: number): Promise<Notice | undefined>;
  updateNotice(id: number, noticeData: Partial<InsertNotice>): Promise<Notice | undefined>;
  deleteNotice(id: number): Promise<boolean>;
  listNotices(page?: number, limit?: number, activeOnly?: boolean): Promise<{ notices: Notice[], total: number }>;
  getActiveNotices(): Promise<Notice[]>;
  publishNotice(id: number): Promise<boolean>;
  unpublishNotice(id: number): Promise<boolean>;
  
  // System Metrics - Real-time Performance Monitoring
  createSystemMetric(metric: InsertSystemMetric): Promise<SystemMetric>;
  getLatestSystemMetric(): Promise<SystemMetric | undefined>;
  getSystemMetrics(timeRange?: 'hour' | 'day' | 'week' | 'month', limit?: number): Promise<SystemMetric[]>;
  getSystemMetricsSummary(): Promise<{
    cpu: { current: number, average: number, peak: number },
    memory: { current: number, average: number, peak: number },
    disk: { current: number, available: number, total: number },
    performance: { responseTime: number, dbConnections: number, apiRequests: number, errors: number },
    users: { active: number }
  }>;
  collectSystemMetrics(): Promise<SystemMetric>;
  publishScheduledNotices(): Promise<{ published: number, notices: any[] }>;
}

export class DatabaseStorage implements IStorage {
  // Session store
  sessionStore: session.Store;
  db = db; // Database instance

  constructor() {
    // Use memory store for session storage
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    console.log("Using memory store for session storage");
  }

  // User Management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.query.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      // For PostgreSQL, use case-insensitive comparison with ILIKE
      const result = await pool.query(
        'SELECT * FROM users WHERE username ILIKE $1',
        [username]
      );
      return result.rows[0] || undefined;
    } catch (error) {
      console.error("Error in getUserByUsername:", error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.query
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db.query.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.query.delete(users).where(eq(users.id, id));
    return result.count > 0;
  }

  async listUsers(page = 1, limit = 10, search?: string): Promise<{ users: User[], total: number }> {
    let query = db.query.select().from(users);
    
    if (search) {
      query = query.where(
        sql`(${users.name} ILIKE ${`%${search}%`} OR 
             ${users.email} ILIKE ${`%${search}%`} OR 
             ${users.username} ILIKE ${`%${search}%`})`
      );
    }
    
    const total = await db.query.select({ count: sql<number>`count(*)` }).from(users);
    const offset = (page - 1) * limit;
    const usersList = await query.limit(limit).offset(offset).orderBy(desc(users.created_at));
    
    return { users: usersList, total: total[0].count || 0 };
  }

  async updateUserLastLogin(id: number): Promise<boolean> {
    const now = new Date();
    const [updatedUser] = await db.query
      .update(users)
      .set({ 
        last_login_at: now,
        last_activity_at: now
      })
      .where(eq(users.id, id))
      .returning();
    return !!updatedUser;
  }

  // User Activities
  async createUserActivity(userId: number, action: string, details: Record<string, any> = {}): Promise<UserActivity> {
    const [activity] = await db.query
      .insert(userActivities)
      .values({
        user_id: userId,
        action,
        details
      })
      .returning();
    return activity;
  }

  async getUserActivities(userId: number, page = 1, limit = 10): Promise<{ activities: UserActivity[], total: number }> {
    const total = await db.query
      .select({ count: sql<number>`count(*)` })
      .from(userActivities)
      .where(eq(userActivities.user_id, userId));
    
    const offset = (page - 1) * limit;
    const activities = await db.query
      .select()
      .from(userActivities)
      .where(eq(userActivities.user_id, userId))
      .orderBy(desc(userActivities.timestamp))
      .limit(limit)
      .offset(offset);
    
    return { activities, total: total[0].count || 0 };
  }

  async getRecentUserActivities(limit = 5): Promise<UserActivity[]> {
    return db.query.select()
      .from(userActivities)
      .orderBy(desc(userActivities.timestamp))
      .limit(limit);
  }

  // Item Units
  async createItemUnit(itemUnit: InsertItemUnit): Promise<ItemUnit> {
    const [newItemUnit] = await db.query.insert(itemUnits)
      .values(itemUnit)
      .returning();
    return newItemUnit;
  }

  async getItemUnit(id: number): Promise<ItemUnit | undefined> {
    const [itemUnit] = await db.query.select()
      .from(itemUnits)
      .where(eq(itemUnits.id, id));
    return itemUnit;
  }

  async updateItemUnit(id: number, itemUnitData: Partial<InsertItemUnit>): Promise<ItemUnit | undefined> {
    const [updatedItemUnit] = await db.query.update(itemUnits)
      .set(itemUnitData)
      .where(eq(itemUnits.id, id))
      .returning();
    return updatedItemUnit;
  }

  async deleteItemUnit(id: number): Promise<boolean> {
    const result = await db.query.delete(itemUnits)
      .where(eq(itemUnits.id, id));
    return result.count > 0;
  }

  async listItemUnits(page = 1, limit = 10): Promise<{ itemUnits: ItemUnit[], total: number }> {
    const total = await db.query.select({ count: sql<number>`count(*)` })
      .from(itemUnits);
    
    const offset = (page - 1) * limit;
    const itemUnitsList = await db.query.select()
      .from(itemUnits)
      .orderBy(asc(itemUnits.name))
      .limit(limit)
      .offset(offset);
    
    return { itemUnits: itemUnitsList, total: total[0].count || 0 };
  }

  // Yarn Types
  async createYarnType(yarnType: InsertYarnType): Promise<YarnType> {
    const [newYarnType] = await db.query.insert(yarnTypes)
      .values(yarnType)
      .returning();
    return newYarnType;
  }

  async getYarnType(id: number): Promise<YarnType | undefined> {
    const [yarnType] = await db.query.select()
      .from(yarnTypes)
      .where(eq(yarnTypes.id, id));
    return yarnType;
  }

  async updateYarnType(id: number, yarnTypeData: Partial<InsertYarnType>): Promise<YarnType | undefined> {
    const [updatedYarnType] = await db.query.update(yarnTypes)
      .set(yarnTypeData)
      .where(eq(yarnTypes.id, id))
      .returning();
    return updatedYarnType;
  }

  async deleteYarnType(id: number): Promise<boolean> {
    const result = await db.query.delete(yarnTypes)
      .where(eq(yarnTypes.id, id));
    return result.count > 0;
  }

  async listYarnTypes(page = 1, limit = 10, activeOnly = false): Promise<{ yarnTypes: YarnType[], total: number }> {
    let query = db.query.select().from(yarnTypes);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(yarnTypes);
    
    if (activeOnly) {
      query = query.where(eq(yarnTypes.is_active, true));
      countQuery = countQuery.where(eq(yarnTypes.is_active, true));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const yarnTypesList = await query
      .orderBy(asc(yarnTypes.name))
      .limit(limit)
      .offset(offset);
    
    return { yarnTypes: yarnTypesList, total: total[0].count || 0 };
  }

  // Color Types
  async createColorType(colorType: InsertColorType): Promise<ColorType> {
    const [newColorType] = await db.query.insert(colorTypes)
      .values(colorType)
      .returning();
    return newColorType;
  }

  async getColorType(id: number): Promise<ColorType | undefined> {
    const [colorType] = await db.query.select()
      .from(colorTypes)
      .where(eq(colorTypes.id, id));
    return colorType;
  }

  async updateColorType(id: number, colorTypeData: Partial<InsertColorType>): Promise<ColorType | undefined> {
    const [updatedColorType] = await db.query.update(colorTypes)
      .set(colorTypeData)
      .where(eq(colorTypes.id, id))
      .returning();
    return updatedColorType;
  }

  async deleteColorType(id: number): Promise<boolean> {
    const result = await db.query.delete(colorTypes)
      .where(eq(colorTypes.id, id));
    return result.count > 0;
  }

  async listColorTypes(page = 1, limit = 10, activeOnly = false): Promise<{ colorTypes: ColorType[], total: number }> {
    let query = db.query.select().from(colorTypes);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(colorTypes);
    
    if (activeOnly) {
      query = query.where(eq(colorTypes.is_active, true));
      countQuery = countQuery.where(eq(colorTypes.is_active, true));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const colorTypesList = await query
      .orderBy(asc(colorTypes.name))
      .limit(limit)
      .offset(offset);
    
    return { colorTypes: colorTypesList, total: total[0].count || 0 };
  }

  // Materials
  async createMaterial(material: InsertMaterial): Promise<Material> {
    const now = new Date();
    const [newMaterial] = await db.query.insert(materials)
      .values({
        ...material,
        created_at: now,
        updated_at: now
      })
      .returning();
    return newMaterial;
  }

  async getMaterial(id: number): Promise<Material | undefined> {
    const [material] = await db.query.select()
      .from(materials)
      .where(eq(materials.id, id));
    return material;
  }

  async updateMaterial(id: number, materialData: Partial<InsertMaterial>): Promise<Material | undefined> {
    const [updatedMaterial] = await db.query.update(materials)
      .set({
        ...materialData,
        updated_at: new Date()
      })
      .where(eq(materials.id, id))
      .returning();
    return updatedMaterial;
  }

  async deleteMaterial(id: number): Promise<boolean> {
    const result = await db.query.delete(materials)
      .where(eq(materials.id, id));
    return result.count > 0;
  }

  async listMaterials(page = 1, limit = 10, category?: string): Promise<{ materials: Material[], total: number }> {
    let query = db.query.select().from(materials);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(materials);
    
    if (category) {
      query = query.where(eq(materials.category, category));
      countQuery = countQuery.where(eq(materials.category, category));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const materialsList = await query
      .orderBy(desc(materials.created_at))
      .limit(limit)
      .offset(offset);
    
    return { materials: materialsList, total: total[0].count || 0 };
  }

  // Product Items
  async createProductItem(productItem: InsertProductItem): Promise<ProductItem> {
    const [newProductItem] = await db.query.insert(productItems)
      .values(productItem)
      .returning();
    return newProductItem;
  }

  async getProductItem(id: number): Promise<ProductItem | undefined> {
    const [productItem] = await db.query.select()
      .from(productItems)
      .where(eq(productItems.id, id));
    return productItem;
  }

  async updateProductItem(id: number, productItemData: Partial<InsertProductItem>): Promise<ProductItem | undefined> {
    const [updatedProductItem] = await db.query.update(productItems)
      .set(productItemData)
      .where(eq(productItems.id, id))
      .returning();
    return updatedProductItem;
  }

  async deleteProductItem(id: number): Promise<boolean> {
    const result = await db.query.delete(productItems)
      .where(eq(productItems.id, id));
    return result.count > 0;
  }

  async listProductItems(page = 1, limit = 10, category?: string): Promise<{ productItems: ProductItem[], total: number }> {
    let query = db.query.select().from(productItems);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(productItems);
    
    if (category) {
      query = query.where(eq(productItems.category, category));
      countQuery = countQuery.where(eq(productItems.category, category));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const productItemsList = await query
      .orderBy(asc(productItems.name))
      .limit(limit)
      .offset(offset);
    
    return { productItems: productItemsList, total: total[0].count || 0 };
  }

  // Production Plans
  async createProductionPlan(productionPlan: InsertProductionPlan): Promise<ProductionPlan> {
    const [newProductionPlan] = await db.query.insert(productionPlans)
      .values(productionPlan)
      .returning();
    return newProductionPlan;
  }

  async getProductionPlan(id: number): Promise<ProductionPlan | undefined> {
    const [productionPlan] = await db.query.select()
      .from(productionPlans)
      .where(eq(productionPlans.id, id));
    return productionPlan;
  }

  async updateProductionPlan(id: number, productionPlanData: Partial<InsertProductionPlan>): Promise<ProductionPlan | undefined> {
    const [updatedProductionPlan] = await db.query.update(productionPlans)
      .set(productionPlanData)
      .where(eq(productionPlans.id, id))
      .returning();
    return updatedProductionPlan;
  }

  async deleteProductionPlan(id: number): Promise<boolean> {
    const result = await db.query.delete(productionPlans)
      .where(eq(productionPlans.id, id));
    return result.count > 0;
  }

  async listProductionPlans(page = 1, limit = 10, status?: string): Promise<{ productionPlans: ProductionPlan[], total: number }> {
    let query = db.query.select().from(productionPlans);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(productionPlans);
    
    if (status) {
      query = query.where(eq(productionPlans.status, status));
      countQuery = countQuery.where(eq(productionPlans.status, status));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const productionPlansList = await query
      .orderBy(desc(productionPlans.created_at))
      .limit(limit)
      .offset(offset);
    
    return { productionPlans: productionPlansList, total: total[0].count || 0 };
  }

  async getRecentProductionPlans(limit = 5): Promise<ProductionPlan[]> {
    return db.query.select()
      .from(productionPlans)
      .orderBy(desc(productionPlans.created_at))
      .limit(limit);
  }

  // Orders
  async createOrder(order: InsertOrder): Promise<Order> {
    const now = new Date();
    const [newOrder] = await db.query.insert(orders)
      .values({
        ...order,
        created_at: now,
        updated_at: now
      })
      .returning();
    return newOrder;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    // Ensure id is a valid integer
    if (typeof id !== 'number' || isNaN(id) || !Number.isInteger(id)) {
      console.warn(`Invalid order ID provided to getOrder: ${id}`);
      return undefined;
    }
    
    const [order] = await db.query.select()
      .from(orders)
      .where(eq(orders.id, id));
    return order;
  }

  async updateOrder(id: number, orderData: Partial<InsertOrder>): Promise<Order | undefined> {
    const [updatedOrder] = await db.query.update(orders)
      .set({
        ...orderData,
        updated_at: new Date()
      })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  async deleteOrder(id: number): Promise<boolean> {
    const result = await db.query.delete(orders)
      .where(eq(orders.id, id));
    return result.count > 0;
  }

  async listOrders(page = 1, limit = 10, status?: string): Promise<{ orders: Order[], total: number }> {
    let query = db.query.select().from(orders);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(orders);
    
    if (status) {
      query = query.where(eq(orders.status, status));
      countQuery = countQuery.where(eq(orders.status, status));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const ordersList = await query
      .orderBy(desc(orders.created_at))
      .limit(limit)
      .offset(offset);
    
    return { orders: ordersList, total: total[0].count || 0 };
  }

  async getRecentOrders(limit = 5): Promise<Order[]> {
    return db.query.select()
      .from(orders)
      .orderBy(desc(orders.created_at))
      .limit(limit);
  }

  // Order Items
  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const [newOrderItem] = await db.query.insert(orderItems)
      .values(orderItem)
      .returning();
    return newOrderItem;
  }

  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    // Ensure orderId is a valid integer
    if (typeof orderId !== 'number' || isNaN(orderId) || !Number.isInteger(orderId)) {
      console.warn(`Invalid order ID provided to getOrderItems: ${orderId}`);
      return [];
    }
    
    return db.query.select()
      .from(orderItems)
      .where(eq(orderItems.order_id, orderId));
  }

  async deleteOrderItem(id: number): Promise<boolean> {
    const result = await db.query.delete(orderItems)
      .where(eq(orderItems.id, id));
    return result.count > 0;
  }

  // Item Settings
  async createItemSetting(itemSetting: InsertItemSetting): Promise<ItemSetting> {
    const [newItemSetting] = await db.query.insert(itemSettings)
      .values(itemSetting)
      .returning();
    return newItemSetting;
  }

  async getItemSetting(id: number): Promise<ItemSetting | undefined> {
    const [itemSetting] = await db.query.select()
      .from(itemSettings)
      .where(eq(itemSettings.id, id));
    return itemSetting;
  }

  async updateItemSetting(id: number, itemSettingData: Partial<InsertItemSetting>): Promise<ItemSetting | undefined> {
    const [updatedItemSetting] = await db.query.update(itemSettings)
      .set(itemSettingData)
      .where(eq(itemSettings.id, id))
      .returning();
    return updatedItemSetting;
  }

  async deleteItemSetting(id: number): Promise<boolean> {
    const result = await db.query.delete(itemSettings)
      .where(eq(itemSettings.id, id));
    return result.count > 0;
  }

  async listItemSettings(page = 1, limit = 10, activeOnly = false): Promise<{ itemSettings: ItemSetting[], total: number }> {
    let query = db.query.select().from(itemSettings);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(itemSettings);
    
    if (activeOnly) {
      query = query.where(eq(itemSettings.is_active, true));
      countQuery = countQuery.where(eq(itemSettings.is_active, true));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const itemSettingsList = await query
      .orderBy(asc(itemSettings.item_name))
      .limit(limit)
      .offset(offset);
    
    return { itemSettings: itemSettingsList, total: total[0].count || 0 };
  }

  // Dyeing Charges
  async createDyeingCharge(dyeingCharge: InsertDyeingCharge): Promise<DyeingCharge> {
    const [newDyeingCharge] = await db.query.insert(dyeingCharges)
      .values(dyeingCharge)
      .returning();
    return newDyeingCharge;
  }

  async getDyeingCharge(id: number): Promise<DyeingCharge | undefined> {
    const [dyeingCharge] = await db.query.select()
      .from(dyeingCharges)
      .where(eq(dyeingCharges.id, id));
    return dyeingCharge;
  }

  async updateDyeingCharge(id: number, dyeingChargeData: Partial<InsertDyeingCharge>): Promise<DyeingCharge | undefined> {
    const [updatedDyeingCharge] = await db.query.update(dyeingCharges)
      .set(dyeingChargeData)
      .where(eq(dyeingCharges.id, id))
      .returning();
    return updatedDyeingCharge;
  }

  async deleteDyeingCharge(id: number): Promise<boolean> {
    const result = await db.query.delete(dyeingCharges)
      .where(eq(dyeingCharges.id, id));
    return result.count > 0;
  }

  async listDyeingCharges(page = 1, limit = 10, activeOnly = false): Promise<{ dyeingCharges: DyeingCharge[], total: number }> {
    let query = db.query.select().from(dyeingCharges);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(dyeingCharges);
    
    if (activeOnly) {
      query = query.where(eq(dyeingCharges.is_active, true));
      countQuery = countQuery.where(eq(dyeingCharges.is_active, true));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const dyeingChargesList = await query
      .orderBy(asc(dyeingCharges.name))
      .limit(limit)
      .offset(offset);
    
    return { dyeingCharges: dyeingChargesList, total: total[0].count || 0 };
  }

  // Dyeing Changes
  async createDyeingChange(dyeingChange: InsertDyeingChange): Promise<DyeingChange> {
    const [newDyeingChange] = await db.query.insert(dyeingChanges)
      .values(dyeingChange)
      .returning();
    return newDyeingChange;
  }

  async getDyeingChange(id: number): Promise<DyeingChange | undefined> {
    const [dyeingChange] = await db.query.select()
      .from(dyeingChanges)
      .where(eq(dyeingChanges.id, id));
    return dyeingChange;
  }

  async updateDyeingChange(id: number, dyeingChangeData: Partial<InsertDyeingChange>): Promise<DyeingChange | undefined> {
    const [updatedDyeingChange] = await db.query.update(dyeingChanges)
      .set({
        ...dyeingChangeData,
        updated_at: new Date()
      })
      .where(eq(dyeingChanges.id, id))
      .returning();
    return updatedDyeingChange;
  }

  async deleteDyeingChange(id: number): Promise<boolean> {
    const result = await db.query.delete(dyeingChanges)
      .where(eq(dyeingChanges.id, id));
    return result.count > 0;
  }

  async listDyeingChanges(page = 1, limit = 10, activeOnly = false): Promise<{ dyeingChanges: DyeingChange[], total: number }> {
    let query = db.query.select().from(dyeingChanges);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(dyeingChanges);
    
    if (activeOnly) {
      query = query.where(eq(dyeingChanges.is_active, true));
      countQuery = countQuery.where(eq(dyeingChanges.is_active, true));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const dyeingChangesList = await query
      .orderBy(desc(dyeingChanges.created_at))
      .limit(limit)
      .offset(offset);
    
    return { dyeingChanges: dyeingChangesList, total: total[0].count || 0 };
  }

  // Unit Settings
  async createUnitSetting(unitSetting: InsertUnitSetting): Promise<UnitSetting> {
    const [newUnitSetting] = await db.query.insert(unitSettings)
      .values(unitSetting)
      .returning();
    return newUnitSetting;
  }

  async getUnitSetting(id: number): Promise<UnitSetting | undefined> {
    const [unitSetting] = await db.query.select()
      .from(unitSettings)
      .where(eq(unitSettings.id, id));
    return unitSetting;
  }

  async updateUnitSetting(id: number, unitSettingData: Partial<InsertUnitSetting>): Promise<UnitSetting | undefined> {
    const [updatedUnitSetting] = await db.query.update(unitSettings)
      .set(unitSettingData)
      .where(eq(unitSettings.id, id))
      .returning();
    return updatedUnitSetting;
  }

  async deleteUnitSetting(id: number): Promise<boolean> {
    const result = await db.query.delete(unitSettings)
      .where(eq(unitSettings.id, id));
    return result.count > 0;
  }

  async listUnitSettings(page = 1, limit = 10, activeOnly = false): Promise<{ unitSettings: UnitSetting[], total: number }> {
    let query = db.query.select().from(unitSettings);
    let countQuery = db.query.select({ count: sql<number>`count(*)` }).from(unitSettings);
    
    if (activeOnly) {
      query = query.where(eq(unitSettings.is_active, true));
      countQuery = countQuery.where(eq(unitSettings.is_active, true));
    }
    
    const total = await countQuery;
    const offset = (page - 1) * limit;
    const unitSettingsList = await query
      .orderBy(asc(unitSettings.unit_name))
      .limit(limit)
      .offset(offset);
    
    return { unitSettings: unitSettingsList, total: total[0].count || 0 };
  }

  // Dashboard stats
  async getDashboardStats(): Promise<{
    totalOrders: number;
    totalProductionPlans: number;
    totalMaterials: number;
    totalRevenue: number;
  }> {
    const ordersCount = await db.query.select({ count: sql<number>`count(*)` }).from(orders);
    const plansCount = await db.query.select({ count: sql<number>`count(*)` }).from(productionPlans);
    const materialsCount = await db.query.select({ count: sql<number>`count(*)` }).from(materials);
    
    const revenueResult = await db.query.select({
      total: sql<string>`SUM(${orders.total_amount})`
    }).from(orders);
    
    return {
      totalOrders: ordersCount[0].count || 0,
      totalProductionPlans: plansCount[0].count || 0,
      totalMaterials: materialsCount[0].count || 0,
      totalRevenue: Number(revenueResult[0].total) || 0
    };
  }

  // Narrow Fabric Settings - Fabric Parts
  async createFabricPart(part: InsertFabricPart): Promise<FabricPart> {
    const result = await pool.query(
      'INSERT INTO fabric_parts (name, is_active, created_at) VALUES ($1, $2, NOW()) RETURNING *',
      [part.name, part.is_active]
    );
    return result.rows[0];
  }

  async getFabricPart(id: number): Promise<FabricPart | undefined> {
    const result = await pool.query(
      'SELECT * FROM fabric_parts WHERE id = $1',
      [id]
    );
    return result.rows[0] || undefined;
  }

  async updateFabricPart(id: number, partData: Partial<InsertFabricPart>): Promise<FabricPart | undefined> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Build dynamic SET clauses based on the fields provided
    if (partData.name !== undefined) {
      setClauses.push(`name = $${paramIndex++}`);
      values.push(partData.name);
    }

    if (partData.is_active !== undefined) {
      setClauses.push(`is_active = $${paramIndex++}`);
      values.push(partData.is_active);
    }

    if (setClauses.length === 0) {
      return this.getFabricPart(id);
    }

    // Add the id to the values array
    values.push(id);

    const result = await pool.query(
      `UPDATE fabric_parts SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );

    return result.rows[0];
  }

  async deleteFabricPart(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM fabric_parts WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rowCount > 0;
  }

  async listFabricParts(page = 1, limit = 10, activeOnly = false): Promise<{ fabricParts: FabricPart[], total: number }> {
    const offset = (page - 1) * limit;
    
    // Add the active filter if requested
    const whereClause = activeOnly ? 'WHERE is_active = true' : '';
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM fabric_parts ${whereClause} ORDER BY id DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM fabric_parts ${whereClause}`
    );
    
    return {
      fabricParts: result.rows,
      total: Number(countResult.rows[0]?.count || 0)
    };
  }

  // Narrow Fabric Settings - Production Unit Settings
  async createProductionUnitSetting(setting: InsertProductionUnitSetting): Promise<ProductionUnitSetting> {
    const result = await pool.query(
      'INSERT INTO production_unit_settings (name, description, is_active, created_at) VALUES ($1, $2, $3, NOW()) RETURNING *',
      [setting.name, setting.description, setting.is_active]
    );
    return result.rows[0];
  }

  async getProductionUnitSetting(id: number): Promise<ProductionUnitSetting | undefined> {
    const result = await pool.query(
      'SELECT * FROM production_unit_settings WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  async updateProductionUnitSetting(id: number, settingData: Partial<InsertProductionUnitSetting>): Promise<ProductionUnitSetting | undefined> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Build dynamic SET clauses based on the fields provided
    if (settingData.name !== undefined) {
      setClauses.push(`name = $${paramIndex++}`);
      values.push(settingData.name);
    }

    if (settingData.description !== undefined) {
      setClauses.push(`description = $${paramIndex++}`);
      values.push(settingData.description);
    }

    if (settingData.is_active !== undefined) {
      setClauses.push(`is_active = $${paramIndex++}`);
      values.push(settingData.is_active);
    }

    if (setClauses.length === 0) {
      return this.getProductionUnitSetting(id);
    }

    // Add the id to the values array
    values.push(id);

    const result = await pool.query(
      `UPDATE production_unit_settings SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );

    return result.rows[0];
  }

  async deleteProductionUnitSetting(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM production_unit_settings WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rowCount > 0;
  }

  async listProductionUnitSettings(page = 1, limit = 10, activeOnly = false): Promise<{ settings: ProductionUnitSetting[], total: number }> {
    const offset = (page - 1) * limit;
    
    // Add the active filter if requested
    const whereClause = activeOnly ? 'WHERE is_active = true' : '';
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM production_unit_settings ${whereClause} ORDER BY id DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM production_unit_settings ${whereClause}`
    );
    
    return {
      settings: result.rows,
      total: parseInt(countResult.rows[0].count)
    };
  }

  // Narrow Fabric Settings - Fabric Yarn Types
  async createFabricYarnType(yarnType: InsertFabricYarnType): Promise<FabricYarnType> {
    const result = await pool.query(
      'INSERT INTO fabric_yarn_types (name, is_active, created_at) VALUES ($1, $2, NOW()) RETURNING *',
      [yarnType.name, yarnType.is_active]
    );
    return result.rows[0];
  }

  async getFabricYarnType(id: number): Promise<FabricYarnType | undefined> {
    const result = await pool.query(
      'SELECT * FROM fabric_yarn_types WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  async updateFabricYarnType(id: number, yarnTypeData: Partial<InsertFabricYarnType>): Promise<FabricYarnType | undefined> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Build dynamic SET clauses based on the fields provided
    if (yarnTypeData.name !== undefined) {
      setClauses.push(`name = $${paramIndex++}`);
      values.push(yarnTypeData.name);
    }

    if (yarnTypeData.is_active !== undefined) {
      setClauses.push(`is_active = $${paramIndex++}`);
      values.push(yarnTypeData.is_active);
    }

    if (setClauses.length === 0) {
      return this.getFabricYarnType(id);
    }

    // Add the id to the values array
    values.push(id);

    const result = await pool.query(
      `UPDATE fabric_yarn_types SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );

    return result.rows[0];
  }

  async deleteFabricYarnType(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM fabric_yarn_types WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rowCount > 0;
  }

  async listFabricYarnTypes(page = 1, limit = 10, activeOnly = false): Promise<{ yarnTypes: FabricYarnType[], total: number }> {
    const offset = (page - 1) * limit;
    
    // Add the active filter if requested
    const whereClause = activeOnly ? 'WHERE is_active = true' : '';
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM fabric_yarn_types ${whereClause} ORDER BY id DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM fabric_yarn_types ${whereClause}`
    );
    
    return {
      yarnTypes: result.rows,
      total: parseInt(countResult.rows[0].count)
    };
  }
  
  // Yarn Categories implementation
  async createYarnCategory(category: InsertYarnCategory): Promise<YarnCategory> {
    const result = await pool.query(
      'INSERT INTO yarn_categories (name, code, is_active, created_at) VALUES ($1, $2, $3, NOW()) RETURNING *',
      [category.name, category.code, category.is_active]
    );
    return result.rows[0];
  }

  async getYarnCategory(id: number): Promise<YarnCategory | undefined> {
    const result = await pool.query(
      'SELECT * FROM yarn_categories WHERE id = $1',
      [id]
    );
    return result.rows[0] || undefined;
  }

  async updateYarnCategory(id: number, categoryData: Partial<InsertYarnCategory>): Promise<YarnCategory | undefined> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    if (categoryData.name !== undefined) {
      setClauses.push(`name = $${paramIndex++}`);
      values.push(categoryData.name);
    }
    
    if (categoryData.code !== undefined) {
      setClauses.push(`code = $${paramIndex++}`);
      values.push(categoryData.code);
    }
    
    if (categoryData.is_active !== undefined) {
      setClauses.push(`is_active = $${paramIndex++}`);
      values.push(categoryData.is_active);
    }

    if (setClauses.length === 0) {
      return this.getYarnCategory(id); // No changes to make
    }

    values.push(id); // Add id as the last parameter
    
    const result = await pool.query(
      `UPDATE yarn_categories SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );
    
    return result.rows[0] || undefined;
  }

  async deleteYarnCategory(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM yarn_categories WHERE id = $1',
      [id]
    );
    return result.rowCount > 0;
  }

  async listYarnCategories(page = 1, limit = 10, activeOnly = false): Promise<{ categories: YarnCategory[], total: number }> {
    const offset = (page - 1) * limit;
    
    // Add the active filter if requested
    const whereClause = activeOnly ? 'WHERE is_active = true' : '';
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM yarn_categories ${whereClause} ORDER BY id DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM yarn_categories ${whereClause}`
    );
    
    return {
      categories: result.rows,
      total: parseInt(countResult.rows[0].count)
    };
  }

  // Narrow Fabric Settings - Yarn Counts
  async createYarnCount(count: InsertYarnCount): Promise<YarnCount> {
    const result = await pool.query(
      'INSERT INTO yarn_counts (count, description, price_bdt, price_usd, is_active, created_at) VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING *',
      [count.count, count.description, count.price_bdt, count.price_usd, count.is_active]
    );
    return result.rows[0];
  }

  async getYarnCount(id: number): Promise<YarnCount | undefined> {
    const result = await pool.query(
      'SELECT * FROM yarn_counts WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  async updateYarnCount(id: number, countData: Partial<InsertYarnCount>): Promise<YarnCount | undefined> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Build dynamic SET clauses based on the fields provided
    if (countData.count !== undefined) {
      setClauses.push(`count = $${paramIndex++}`);
      values.push(countData.count);
    }

    if (countData.description !== undefined) {
      setClauses.push(`description = $${paramIndex++}`);
      values.push(countData.description);
    }
    
    if (countData.price_bdt !== undefined) {
      setClauses.push(`price_bdt = $${paramIndex++}`);
      values.push(countData.price_bdt);
    }
    
    if (countData.price_usd !== undefined) {
      setClauses.push(`price_usd = $${paramIndex++}`);
      values.push(countData.price_usd);
    }

    if (countData.is_active !== undefined) {
      setClauses.push(`is_active = $${paramIndex++}`);
      values.push(countData.is_active);
    }

    if (setClauses.length === 0) {
      return this.getYarnCount(id);
    }

    // Add the id to the values array
    values.push(id);

    const result = await pool.query(
      `UPDATE yarn_counts SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );

    return result.rows[0];
  }

  async deleteYarnCount(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM yarn_counts WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rowCount > 0;
  }

  async listYarnCounts(page = 1, limit = 10, activeOnly = false): Promise<{ counts: YarnCount[], total: number }> {
    const offset = (page - 1) * limit;
    
    // Add the active filter if requested
    const whereClause = activeOnly ? 'WHERE is_active = true' : '';
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM yarn_counts ${whereClause} ORDER BY id DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM yarn_counts ${whereClause}`
    );
    
    return {
      counts: result.rows,
      total: parseInt(countResult.rows[0].count)
    };
  }

  // Narrow Fabric Settings - Yarn Prices
  async createYarnPrice(price: InsertYarnPrice): Promise<YarnPrice> {
    const result = await pool.query(
      'INSERT INTO yarn_prices (yarn_type_id, price_per_kg, effective_date, is_active, created_at) VALUES ($1, $2, $3, $4, NOW()) RETURNING *',
      [price.yarn_type_id, price.price_per_kg, price.effective_date, price.is_active]
    );
    return result.rows[0];
  }

  async getYarnPrice(id: number): Promise<YarnPrice | undefined> {
    const result = await pool.query(
      'SELECT * FROM yarn_prices WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  async updateYarnPrice(id: number, priceData: Partial<InsertYarnPrice>): Promise<YarnPrice | undefined> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Build dynamic SET clauses based on the fields provided
    if (priceData.yarn_type_id !== undefined) {
      setClauses.push(`yarn_type_id = $${paramIndex++}`);
      values.push(priceData.yarn_type_id);
    }

    if (priceData.price_per_kg !== undefined) {
      setClauses.push(`price_per_kg = $${paramIndex++}`);
      values.push(priceData.price_per_kg);
    }

    if (priceData.effective_date !== undefined) {
      setClauses.push(`effective_date = $${paramIndex++}`);
      values.push(priceData.effective_date);
    }

    if (priceData.is_active !== undefined) {
      setClauses.push(`is_active = $${paramIndex++}`);
      values.push(priceData.is_active);
    }

    if (setClauses.length === 0) {
      return this.getYarnPrice(id);
    }

    // Add the id to the values array
    values.push(id);

    const result = await pool.query(
      `UPDATE yarn_prices SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );

    return result.rows[0];
  }

  async deleteYarnPrice(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM yarn_prices WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rowCount > 0;
  }

  async listYarnPrices(page = 1, limit = 10, activeOnly = false): Promise<{ prices: YarnPrice[], total: number }> {
    const offset = (page - 1) * limit;
    
    // Add the active filter if requested
    const whereClause = activeOnly ? 'WHERE is_active = true' : '';
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM yarn_prices ${whereClause} ORDER BY id DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM yarn_prices ${whereClause}`
    );
    
    return {
      prices: result.rows,
      total: parseInt(countResult.rows[0].count)
    };
  }
  
  // Narrow Fabric Settings - Profit Margins
  async createProfitMargin(margin: InsertProfitMargin): Promise<ProfitMargin> {
    const result = await pool.query(
      'INSERT INTO profit_margins (production_unit, item_name, profit_margin, description, is_active, created_at) VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING *',
      [margin.production_unit, margin.item_name, margin.profit_margin, margin.description, margin.is_active]
    );
    return result.rows[0];
  }

  async getProfitMargin(id: number): Promise<ProfitMargin | undefined> {
    const result = await pool.query(
      'SELECT * FROM profit_margins WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  async updateProfitMargin(id: number, marginData: Partial<InsertProfitMargin>): Promise<ProfitMargin | undefined> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Build dynamic SET clauses based on the fields provided
    if (marginData.production_unit !== undefined) {
      setClauses.push(`production_unit = $${paramIndex++}`);
      values.push(marginData.production_unit);
    }

    if (marginData.item_name !== undefined) {
      setClauses.push(`item_name = $${paramIndex++}`);
      values.push(marginData.item_name);
    }

    if (marginData.profit_margin !== undefined) {
      setClauses.push(`profit_margin = $${paramIndex++}`);
      values.push(marginData.profit_margin);
    }

    if (marginData.description !== undefined) {
      setClauses.push(`description = $${paramIndex++}`);
      values.push(marginData.description);
    }

    if (marginData.is_active !== undefined) {
      setClauses.push(`is_active = $${paramIndex++}`);
      values.push(marginData.is_active);
    }

    if (setClauses.length === 0) {
      return this.getProfitMargin(id);
    }

    // Add the id to the values array
    values.push(id);

    const result = await pool.query(
      `UPDATE profit_margins SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );

    return result.rows[0];
  }

  async deleteProfitMargin(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM profit_margins WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rowCount > 0;
  }

  async listProfitMargins(page = 1, limit = 10, activeOnly = false): Promise<{ margins: ProfitMargin[], total: number }> {
    const offset = (page - 1) * limit;
    
    // Add the active filter if requested
    const whereClause = activeOnly ? 'WHERE is_active = true' : '';
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM profit_margins ${whereClause} ORDER BY id DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM profit_margins ${whereClause}`
    );
    
    return {
      margins: result.rows,
      total: parseInt(countResult.rows[0].count)
    };
  }
  
  // Notice System Implementation
  async createNotice(notice: InsertNotice): Promise<Notice> {
    const now = new Date();
    
    const result = await pool.query(
      `INSERT INTO notices (
        title, content, priority, start_date, end_date, 
        is_published, is_scheduled, created_by, created_at, 
        updated_at, department, target_roles
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *`,
      [
        notice.title,
        notice.content,
        notice.priority || 'normal',
        notice.start_date || now,
        notice.end_date,
        notice.is_published || false,
        notice.is_scheduled || false,
        notice.created_by,
        now,
        now,
        notice.department,
        notice.target_roles
      ]
    );
    
    return result.rows[0];
  }

  async getNotice(id: number): Promise<Notice | undefined> {
    if (typeof id !== 'number' || isNaN(id) || !Number.isInteger(id)) {
      console.warn(`Invalid notice ID provided: ${id}`);
      return undefined;
    }
    
    const result = await pool.query(
      'SELECT * FROM notices WHERE id = $1',
      [id]
    );
    
    return result.rows[0] || undefined;
  }

  async updateNotice(id: number, noticeData: Partial<InsertNotice>): Promise<Notice | undefined> {
    const now = new Date();
    
    // Get the current notice to merge with updates
    const currentNotice = await this.getNotice(id);
    if (!currentNotice) {
      return undefined;
    }
    
    // Construct the SQL update fields dynamically based on what's provided
    const updates: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;
    
    // Define the fields that can be updated
    const fields: (keyof InsertNotice)[] = [
      'title', 'content', 'priority', 'start_date', 'end_date',
      'is_published', 'is_scheduled', 'department', 'target_roles'
    ];
    
    // Add each field that's present in the update data
    fields.forEach(field => {
      if (field in noticeData) {
        updates.push(`${field} = $${paramIndex}`);
        values.push(noticeData[field]);
        paramIndex++;
      }
    });
    
    // Always update the updated_at timestamp
    updates.push(`updated_at = $${paramIndex}`);
    values.push(now);
    paramIndex++;
    
    // Add the ID as the last parameter
    values.push(id);
    
    // Execute the update query
    const result = await pool.query(
      `UPDATE notices SET ${updates.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      values
    );
    
    return result.rows[0] || undefined;
  }

  async deleteNotice(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM notices WHERE id = $1',
      [id]
    );
    
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async listNotices(page = 1, limit = 10, activeOnly = false): Promise<{ notices: Notice[], total: number }> {
    const offset = (page - 1) * limit;
    
    let whereClause = '';
    const queryParams: any[] = [];
    
    if (activeOnly) {
      const now = new Date().toISOString();
      whereClause = `
        WHERE is_published = true 
        AND start_date <= $1
        AND (end_date IS NULL OR end_date >= $1)
      `;
      queryParams.push(now);
    }
    
    // Add pagination parameters
    queryParams.push(limit, offset);
    
    // Query for paginated results
    const result = await pool.query(
      `SELECT * FROM notices ${whereClause} 
       ORDER BY start_date DESC, priority DESC 
       LIMIT $${queryParams.length - 1} OFFSET $${queryParams.length}`,
      queryParams
    );
    
    // Query for total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as count FROM notices ${whereClause}`,
      activeOnly ? [new Date().toISOString()] : []
    );
    
    return {
      notices: result.rows,
      total: parseInt(countResult.rows[0].count)
    };
  }

  async getActiveNotices(): Promise<Notice[]> {
    const now = new Date().toISOString();
    
    const result = await pool.query(
      `SELECT * FROM notices 
       WHERE is_published = true 
       AND start_date <= $1
       AND (end_date IS NULL OR end_date >= $1)
       ORDER BY priority DESC, start_date DESC`,
      [now]
    );
    
    return result.rows;
  }

  async publishNotice(id: number): Promise<boolean> {
    const result = await pool.query(
      `UPDATE notices 
       SET is_published = true, updated_at = $1 
       WHERE id = $2 
       RETURNING *`,
      [new Date(), id]
    );
    
    return result.rows.length > 0;
  }

  async publishScheduledNotices(): Promise<{ published: number, notices: any[] }> {
    const now = new Date();
    const currentDate = now.toISOString().split('T')[0]; // YYYY-MM-DD
    const currentTime = now.toTimeString().substring(0, 5); // HH:MM
    
    console.log(`Checking scheduled notices at ${currentDate} ${currentTime}`);
    
    // Find and publish notices that are scheduled for now or earlier
    const result = await pool.query(
      `UPDATE notices 
       SET is_published = true, updated_at = $1
       WHERE is_scheduled = true
       AND is_published = false
       AND start_date <= $2
       AND start_time <= $3
       RETURNING id, title, start_date, start_time`,
      [now, currentDate, currentTime]
    );
    
    const publishedNotices = result.rows;
    console.log(`Published ${publishedNotices.length} notices`);
    
    return {
      published: publishedNotices.length,
      notices: publishedNotices
    };
  }
  
  async collectSystemMetrics(): Promise<SystemMetric> {
    console.log('Collecting system metrics...');
    
    try {
      const os = require('os');
      
      // Get CPU usage (average load divided by number of CPUs)
      const cpuCount = os.cpus().length;
      const loadAvg = os.loadavg()[0];
      const cpuUsage = (loadAvg / cpuCount) * 100;
      
      // Get memory usage
      const totalMemory = os.totalmem();
      const freeMemory = os.freemem();
      const usedMemory = totalMemory - freeMemory;
      const memoryUsage = (usedMemory / totalMemory) * 100;
      
      // Get disk usage (simulated for now)
      const diskTotal = 100;  // GB
      const diskUsage = 45;   // Percentage
      
      // Get active users (simulated for now)
      const activeUsers = Math.floor(Math.random() * 20) + 1;
      
      // Measure API response time (simulated for now)
      const responseTime = Math.floor(Math.random() * 200) + 50; // 50-250ms
      
      // Simulated DB metrics
      const dbConnections = Math.floor(Math.random() * 10) + 1;
      const dbQueriesPerSecond = Math.random() * 50;
      const apiRequestsPerMinute = Math.floor(Math.random() * 100);
      const errorCount = Math.floor(Math.random() * 5);
      
      // Insert metrics into database
      const [metric] = await db.query.insert(systemMetrics).values({
        cpu_usage: parseFloat(cpuUsage.toFixed(2)),
        memory_usage: parseFloat(memoryUsage.toFixed(2)),
        memory_total: parseFloat((totalMemory / (1024 * 1024 * 1024)).toFixed(2)), // Convert to GB
        disk_usage: diskUsage,
        disk_total: diskTotal,
        active_users: activeUsers,
        response_time: responseTime,
        db_connections: dbConnections,
        db_queries_per_second: parseFloat(dbQueriesPerSecond.toFixed(2)),
        api_requests_per_minute: apiRequestsPerMinute,
        error_count: errorCount,
        metadata: {}
      }).returning();
      
      console.log('System metrics collected and stored.');
      
      return metric;
    } catch (error) {
      console.error('Error collecting system metrics:', error);
      throw error;
    }
  }

  async unpublishNotice(id: number): Promise<boolean> {
    const result = await pool.query(
      `UPDATE notices 
       SET is_published = false, updated_at = $1 
       WHERE id = $2 
       RETURNING *`,
      [new Date(), id]
    );
    
    return result.rows.length > 0;
  }

  // System Metrics Implementation
  async createSystemMetric(metric: InsertSystemMetric): Promise<SystemMetric> {
    const [newMetric] = await db.query.insert(systemMetrics)
      .values(metric)
      .returning();
    return newMetric;
  }

  async getLatestSystemMetric(): Promise<SystemMetric | undefined> {
    const [latestMetric] = await db.query.select()
      .from(systemMetrics)
      .orderBy(desc(systemMetrics.timestamp))
      .limit(1);
    return latestMetric;
  }

  async getSystemMetrics(timeRange: 'hour' | 'day' | 'week' | 'month' = 'hour', limit = 60): Promise<SystemMetric[]> {
    // Calculate the start date based on time range
    const now = new Date();
    let startDate: Date;
    
    switch (timeRange) {
      case 'hour':
        startDate = new Date(now.getTime() - 60 * 60 * 1000); // 1 hour ago
        break;
      case 'day':
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000); // 1 day ago
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); // 1 week ago
        break;
      case 'month':
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
        break;
      default:
        startDate = new Date(now.getTime() - 60 * 60 * 1000); // Default to 1 hour
    }

    try {
      const result = await pool.query(
        `SELECT * FROM system_metrics
         WHERE timestamp >= $1
         ORDER BY timestamp DESC
         LIMIT $2`,
        [startDate, limit]
      );
      return result.rows;
    } catch (error) {
      console.error("Error in getSystemMetrics:", error);
      return []; // Return empty array in case of error
    }
  }

  async getSystemMetricsSummary(): Promise<{
    cpu: { current: number, average: number, peak: number },
    memory: { current: number, average: number, peak: number },
    disk: { current: number, available: number, total: number },
    performance: { responseTime: number, dbConnections: number, apiRequests: number, errors: number },
    users: { active: number }
  }> {
    try {
      // Get latest metrics
      const latestResult = await pool.query(
        `SELECT * FROM system_metrics ORDER BY timestamp DESC LIMIT 1`
      );
      const latest = latestResult.rows[0];
      
      // Get average metrics from last hour
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      const avgResult = await pool.query(`
        SELECT 
          AVG(cpu_usage) as avg_cpu,
          AVG(memory_usage) as avg_memory,
          AVG(response_time) as avg_response,
          MAX(cpu_usage) as peak_cpu,
          MAX(memory_usage) as peak_memory
        FROM system_metrics
        WHERE timestamp >= $1
      `, [oneHourAgo]);
      
      // Get the latest metrics (or defaults if no metrics exist)
      const avgMetrics = avgResult.rows[0] || { 
        avg_cpu: 0, 
        avg_memory: 0, 
        avg_response: 0,
        peak_cpu: 0,
        peak_memory: 0
      };
      
      // If no metrics exist yet, provide reasonable defaults
      if (!latest) {
        return {
          cpu: { current: 0, average: 0, peak: 0 },
          memory: { current: 0, average: 0, peak: 0 },
          disk: { current: 0, available: 0, total: 100 },
          performance: { responseTime: 0, dbConnections: 0, apiRequests: 0, errors: 0 },
          users: { active: 0 }
        };
      }
      
      // Format the response
      return {
        cpu: {
          current: Number(latest.cpu_usage),
          average: Number(avgMetrics.avg_cpu),
          peak: Number(avgMetrics.peak_cpu)
        },
        memory: {
          current: Number(latest.memory_usage),
          average: Number(avgMetrics.avg_memory),
          peak: Number(avgMetrics.peak_memory)
        },
        disk: {
          current: Number(latest.disk_usage),
          available: 100 - Number(latest.disk_usage),
          total: Number(latest.disk_total)
        },
        performance: {
          responseTime: Number(latest.response_time),
          dbConnections: Number(latest.db_connections),
          apiRequests: Number(latest.api_requests_per_minute),
          errors: Number(latest.error_count)
        },
        users: {
          active: Number(latest.active_users)
        }
      };
    } catch (error) {
      console.error("Error in getSystemMetricsSummary:", error);
      // Return default values in case of error
      return {
        cpu: { current: 0, average: 0, peak: 0 },
        memory: { current: 0, average: 0, peak: 0 },
        disk: { current: 0, available: 0, total: 100 },
        performance: { responseTime: 0, dbConnections: 0, apiRequests: 0, errors: 0 },
        users: { active: 0 }
      };
    }
  }

  // Price Quotation Operations
  async createPriceQuotation(quotation: InsertPriceQuotation): Promise<PriceQuotation> {
    const [newQuotation] = await db.query.insert(priceQuotations)
      .values(quotation)
      .returning();
    return newQuotation;
  }

  async getPriceQuotation(id: number): Promise<PriceQuotation | undefined> {
    const [quotation] = await db.query.select()
      .from(priceQuotations)
      .where(eq(priceQuotations.id, id));
    return quotation;
  }

  async updatePriceQuotation(id: number, quotationData: Partial<InsertPriceQuotation>): Promise<PriceQuotation | undefined> {
    const [updatedQuotation] = await db.query.update(priceQuotations)
      .set({ ...quotationData, updated_at: new Date() })
      .where(eq(priceQuotations.id, id))
      .returning();
    return updatedQuotation;
  }

  async deletePriceQuotation(id: number): Promise<boolean> {
    const result = await db.query.delete(priceQuotations)
      .where(eq(priceQuotations.id, id));
    return result.count > 0;
  }

  async listPriceQuotations(page = 1, limit = 10, filter?: string): Promise<{ quotations: PriceQuotation[], total: number }> {
    let query = db.query.select().from(priceQuotations);
    
    if (filter) {
      query = query.where(
        sql`(${priceQuotations.reference_no} ILIKE ${`%${filter}%`} OR 
             ${priceQuotations.customer_name} ILIKE ${`%${filter}%`} OR 
             ${priceQuotations.production_unit} ILIKE ${`%${filter}%`} OR
             ${priceQuotations.item_name} ILIKE ${`%${filter}%`})`
      );
    }
    
    const total = await db.query.select({ count: sql<number>`count(*)` }).from(priceQuotations);
    const offset = (page - 1) * limit;
    const quotationsList = await query
      .limit(limit)
      .offset(offset)
      .orderBy(desc(priceQuotations.created_at));
    
    return { quotations: quotationsList, total: total[0].count || 0 };
  }
}

export const storage = new DatabaseStorage();
