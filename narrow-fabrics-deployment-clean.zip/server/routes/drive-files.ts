import { Router } from 'express';
import multer from 'multer';
import { 
  createDriveClient,
  uploadFile,
  downloadFile,
  deleteFile,
  createFolder,
  shareFile
} from '../lib/drive-service';
import { Readable } from 'stream';
import { storage as dbStorage } from '../storage';
import { db } from '../db';

// Set up multer for handling file uploads
const multerStorage = multer.memoryStorage();
const upload = multer({ 
  storage: multerStorage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

const router = Router();

// Middleware to check Google Drive authentication
function requireDriveAuth(req, res, next) {
  if (!req.session.driveTokens) {
    return res.status(401).json({ 
      message: 'Not authenticated with Google Drive',
      authenticated: false
    });
  }
  next();
}

// Upload a file to Google Drive
router.post('/api/drive/upload', requireDriveAuth, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file provided' });
    }
    
    const drive = createDriveClient(req.session.driveTokens);
    
    const { filename, mimetype, buffer } = req.file;
    const folderId = req.body.folderId;
    
    const fileData = await uploadFile(
      drive, 
      buffer, 
      filename, 
      mimetype, 
      folderId
    );
    
    // Track user activity
    if (req.user && req.user.id) {
      await dbStorage.createUserActivity(
        req.user.id, 
        'Uploaded file to Google Drive', 
        { fileName: filename, fileId: fileData.id }
      );
    }
    
    res.status(201).json({
      message: 'File uploaded successfully',
      file: fileData
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).json({ 
      message: 'Failed to upload file',
      error: error.message
    });
  }
});

// Download a file from Google Drive
router.get('/api/drive/download/:fileId', requireDriveAuth, async (req, res) => {
  try {
    const drive = createDriveClient(req.session.driveTokens);
    const fileId = req.params.fileId;
    
    // Get file metadata to get the name
    const fileMetadata = await drive.files.get({
      fileId,
      fields: 'name,mimeType'
    });
    
    const fileStream = await downloadFile(drive, fileId);
    
    // Set headers
    res.setHeader('Content-Type', fileMetadata.data.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${fileMetadata.data.name}"`);
    
    // Pipe the file stream to the response
    fileStream.pipe(res);
  } catch (error) {
    console.error('Error downloading file:', error);
    res.status(500).json({ 
      message: 'Failed to download file',
      error: error.message
    });
  }
});

// Delete a file from Google Drive
router.delete('/api/drive/files/:fileId', requireDriveAuth, async (req, res) => {
  try {
    const drive = createDriveClient(req.session.driveTokens);
    const fileId = req.params.fileId;
    
    await deleteFile(drive, fileId);
    
    // Track user activity
    if (req.user && req.user.id) {
      await dbStorage.createUserActivity(
        req.user.id, 
        'Deleted file from Google Drive', 
        { fileId }
      );
    }
    
    res.json({
      message: 'File deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting file:', error);
    res.status(500).json({ 
      message: 'Failed to delete file',
      error: error.message
    });
  }
});

// Create a folder in Google Drive
router.post('/api/drive/folders', requireDriveAuth, async (req, res) => {
  try {
    const drive = createDriveClient(req.session.driveTokens);
    const { folderName, parentFolderId } = req.body;
    
    if (!folderName) {
      return res.status(400).json({ message: 'Folder name is required' });
    }
    
    const folder = await createFolder(drive, folderName, parentFolderId);
    
    // Track user activity
    if (req.user && req.user.id) {
      await dbStorage.createUserActivity(
        req.user.id, 
        'Created folder in Google Drive', 
        { folderName, folderId: folder.id }
      );
    }
    
    res.status(201).json({
      message: 'Folder created successfully',
      folder
    });
  } catch (error) {
    console.error('Error creating folder:', error);
    res.status(500).json({ 
      message: 'Failed to create folder',
      error: error.message
    });
  }
});

// Make a file publicly shareable
router.post('/api/drive/share/:fileId', requireDriveAuth, async (req, res) => {
  try {
    const drive = createDriveClient(req.session.driveTokens);
    const fileId = req.params.fileId;
    const { role = 'reader' } = req.body;
    
    const sharedFile = await shareFile(drive, fileId, role);
    
    // Track user activity
    if (req.user && req.user.id) {
      await dbStorage.createUserActivity(
        req.user.id, 
        'Shared file from Google Drive', 
        { fileId }
      );
    }
    
    res.json({
      message: 'File shared successfully',
      file: sharedFile
    });
  } catch (error) {
    console.error('Error sharing file:', error);
    res.status(500).json({ 
      message: 'Failed to share file',
      error: error.message
    });
  }
});

// Export database to Google Drive
router.post('/api/drive/export-db', requireDriveAuth, async (req, res) => {
  try {
    const drive = createDriveClient(req.session.driveTokens);
    // db is imported at the top
    
    // Get data from the database
    const tables = [
      'users', 'roles', 'user_activities', 'item_units', 'yarn_types', 
      'color_types', 'materials', 'product_items', 'production_plans', 
      'orders', 'order_items', 'item_settings', 'dyeing_charges', 'unit_settings'
    ];
    
    const exportData: Record<string, any[]> = {};
    
    for (const table of tables) {
      const result = await db.query(`SELECT * FROM ${table}`);
      exportData[table] = result.rows;
    }
    
    // Convert to JSON string
    const jsonData = JSON.stringify(exportData, null, 2);
    const buffer = Buffer.from(jsonData);
    
    // Create timestamp for filename
    const timestamp = new Date().toISOString().replace(/:/g, '-').substring(0, 19);
    const filename = `database_backup_${timestamp}.json`;
    
    // Upload to Google Drive
    const fileData = await uploadFile(
      drive, 
      buffer, 
      filename, 
      'application/json'
    );
    
    // Track user activity
    if (req.user && req.user.id) {
      // dbStorage is imported at the top
      await dbStorage.createUserActivity(
        req.user.id, 
        'Exported database to Google Drive', 
        { fileName: filename, fileId: fileData.id }
      );
    }
    
    res.json({
      message: 'Database exported successfully',
      file: fileData
    });
  } catch (error) {
    console.error('Error exporting database:', error);
    res.status(500).json({ 
      message: 'Failed to export database',
      error: error.message
    });
  }
});

export const driveFilesRouter = router;