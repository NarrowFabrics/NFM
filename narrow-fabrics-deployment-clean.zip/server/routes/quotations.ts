import { Router } from 'express';
import { storage } from '../storage';
import { InsertPriceQuotation, insertPriceQuotationSchema } from '@shared/schema';
import { z } from 'zod';

export const quotationsRouter = Router();

// Create a price quotation
quotationsRouter.post('/', async (req, res) => {
  try {
    const userId = req.session.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Validate the request body
    const quotationData = req.body;
    
    try {
      // Validate with Zod schema
      const validatedData = insertPriceQuotationSchema.parse({
        ...quotationData,
        created_by: userId,
        elastic_parts_data: quotationData.elasticParts || [],
      });
      
      // Create the quotation
      const newQuotation = await storage.createPriceQuotation(validatedData);
      
      // Log the activity
      await storage.createUserActivity(
        userId,
        'create_price_quotation',
        { quotationId: newQuotation.id, reference: newQuotation.reference_no }
      );
      
      return res.status(201).json(newQuotation);
    } catch (validationError) {
      if (validationError instanceof z.ZodError) {
        return res.status(400).json({ 
          error: 'Validation error', 
          details: validationError.errors 
        });
      }
      throw validationError;
    }
  } catch (error) {
    console.error('Error creating price quotation:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Get a specific price quotation
quotationsRouter.get('/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid ID' });
    }
    
    const quotation = await storage.getPriceQuotation(id);
    if (!quotation) {
      return res.status(404).json({ error: 'Price quotation not found' });
    }
    
    return res.json(quotation);
  } catch (error) {
    console.error('Error getting price quotation:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Update a price quotation
quotationsRouter.patch('/:id', async (req, res) => {
  try {
    const userId = req.session.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid ID' });
    }
    
    const quotation = await storage.getPriceQuotation(id);
    if (!quotation) {
      return res.status(404).json({ error: 'Price quotation not found' });
    }
    
    // Validate partial update data
    const updateData = req.body;
    
    try {
      // For partial updates, we use partial schema validation
      const partialSchema = insertPriceQuotationSchema.partial();
      const validatedData = partialSchema.parse(updateData);
      
      if (updateData.elasticParts) {
        validatedData.elastic_parts_data = updateData.elasticParts;
      }
      
      // Update the quotation
      const updatedQuotation = await storage.updatePriceQuotation(id, validatedData);
      
      // Log the activity
      await storage.createUserActivity(
        userId,
        'update_price_quotation',
        { quotationId: id, reference: quotation.reference_no }
      );
      
      return res.json(updatedQuotation);
    } catch (validationError) {
      if (validationError instanceof z.ZodError) {
        return res.status(400).json({ 
          error: 'Validation error', 
          details: validationError.errors 
        });
      }
      throw validationError;
    }
  } catch (error) {
    console.error('Error updating price quotation:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete a price quotation
quotationsRouter.delete('/:id', async (req, res) => {
  try {
    const userId = req.session.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid ID' });
    }
    
    const quotation = await storage.getPriceQuotation(id);
    if (!quotation) {
      return res.status(404).json({ error: 'Price quotation not found' });
    }
    
    const deleted = await storage.deletePriceQuotation(id);
    if (!deleted) {
      return res.status(500).json({ error: 'Failed to delete price quotation' });
    }
    
    // Log the activity
    await storage.createUserActivity(
      userId,
      'delete_price_quotation',
      { quotationId: id, reference: quotation.reference_no }
    );
    
    return res.status(204).end();
  } catch (error) {
    console.error('Error deleting price quotation:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// List price quotations
quotationsRouter.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page as string, 10) || 1;
    const limit = parseInt(req.query.limit as string, 10) || 10;
    const filter = req.query.filter as string;
    
    const quotations = await storage.listPriceQuotations(page, limit, filter);
    
    return res.json(quotations);
  } catch (error) {
    console.error('Error listing price quotations:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});