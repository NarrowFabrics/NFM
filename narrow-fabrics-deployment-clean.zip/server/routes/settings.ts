import { Router } from 'express';
import { storage } from '../storage';
import { type InsertFabricPart, type InsertProductionUnitSettingDb, type InsertFabricYarnType, 
  type InsertYarnCount, type InsertYarnPrice, type InsertProfitMargin, type InsertYarnCategory } from '../../shared/schema';
import { z } from 'zod';

// Create schemas for validation
const fabricPartSchema = z.object({
  name: z.string().min(1, "Name is required"),
  is_active: z.boolean().default(true)
});

const yarnCategorySchema = z.object({
  name: z.string().min(1, "Name is required"),
  code: z.string().min(1, "Code is required"),
  is_active: z.boolean().default(true)
});

const fabricYarnTypeSchema = z.object({
  name: z.string().min(1, "Name is required"),
  is_active: z.boolean().default(true)
});

const yarnCountSchema = z.object({
  count: z.string().min(1, "Count is required"),
  description: z.string().optional(),
  is_active: z.boolean().default(true)
});

const yarnPriceSchema = z.object({
  yarn_type_id: z.number().int().positive(),
  price_per_kg: z.number().nonnegative(),
  effective_date: z.string().optional(),
  is_active: z.boolean().default(true)
});

const productionUnitSettingSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  is_active: z.boolean().default(true)
});

const profitMarginSchema = z.object({
  production_unit: z.string().min(1, "Production Unit is required"),
  item_name: z.string().min(1, "Item Name is required"),
  profit_margin: z.number().nonnegative(),
  description: z.string().optional().default("No description"),
  is_active: z.boolean().default(true)
});

export const settingsRouter = Router();

// Yarn Categories
settingsRouter.get('/yarn-categories', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    const result = await storage.listYarnCategories(page, limit, activeOnly);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/yarn-categories', async (req, res, next) => {
  try {
    const validation = yarnCategorySchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const newCategory = await storage.createYarnCategory(validation.data as InsertYarnCategory);
    res.status(201).json(newCategory);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/yarn-categories/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const category = await storage.getYarnCategory(id);
    if (!category) {
      return res.status(404).json({ error: "Yarn category not found" });
    }
    
    res.json(category);
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/yarn-categories/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const partialSchema = yarnCategorySchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const updatedCategory = await storage.updateYarnCategory(id, validation.data as Partial<InsertYarnCategory>);
    if (!updatedCategory) {
      return res.status(404).json({ error: "Yarn category not found" });
    }
    
    res.json(updatedCategory);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/yarn-categories/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const success = await storage.deleteYarnCategory(id);
    if (!success) {
      return res.status(404).json({ error: "Yarn category not found" });
    }
    
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

// Fabric Parts
settingsRouter.get('/fabric-parts', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    const result = await storage.listFabricParts(page, limit, activeOnly);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/fabric-parts', async (req, res, next) => {
  try {
    const validation = fabricPartSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const newPart = await storage.createFabricPart(validation.data as InsertFabricPart);
    res.status(201).json(newPart);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/fabric-parts/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const part = await storage.getFabricPart(id);
    if (!part) {
      return res.status(404).json({ error: "Fabric part not found" });
    }
    
    res.json(part);
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/fabric-parts/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    // Allow partial updates by converting schema to partial
    const partialSchema = fabricPartSchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const updatedPart = await storage.updateFabricPart(id, validation.data as Partial<InsertFabricPart>);
    if (!updatedPart) {
      return res.status(404).json({ error: "Fabric part not found" });
    }
    
    res.json(updatedPart);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/fabric-parts/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const success = await storage.deleteFabricPart(id);
    if (!success) {
      return res.status(404).json({ error: "Fabric part not found" });
    }
    
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

// Production Unit Settings
settingsRouter.get('/production-units', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    const result = await storage.listProductionUnitSettings(page, limit, activeOnly);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/production-units', async (req, res, next) => {
  try {
    const validation = productionUnitSettingSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const newSetting = await storage.createProductionUnitSetting(validation.data as InsertProductionUnitSettingDb);
    res.status(201).json(newSetting);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/production-units/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const setting = await storage.getProductionUnitSetting(id);
    if (!setting) {
      return res.status(404).json({ error: "Production unit setting not found" });
    }
    
    res.json(setting);
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/production-units/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const partialSchema = productionUnitSettingSchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const updatedSetting = await storage.updateProductionUnitSetting(id, validation.data as Partial<InsertProductionUnitSetting>);
    if (!updatedSetting) {
      return res.status(404).json({ error: "Production unit setting not found" });
    }
    
    res.json(updatedSetting);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/production-units/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const success = await storage.deleteProductionUnitSetting(id);
    if (!success) {
      return res.status(404).json({ error: "Production unit setting not found" });
    }
    
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

// Yarn Types
settingsRouter.get('/yarn-types', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    const result = await storage.listFabricYarnTypes(page, limit, activeOnly);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/yarn-types', async (req, res, next) => {
  try {
    const validation = fabricYarnTypeSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const newType = await storage.createFabricYarnType(validation.data as InsertFabricYarnType);
    res.status(201).json(newType);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/yarn-types/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const type = await storage.getFabricYarnType(id);
    if (!type) {
      return res.status(404).json({ error: "Yarn type not found" });
    }
    
    res.json(type);
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/yarn-types/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const partialSchema = fabricYarnTypeSchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const updatedType = await storage.updateFabricYarnType(id, validation.data as Partial<InsertFabricYarnType>);
    if (!updatedType) {
      return res.status(404).json({ error: "Yarn type not found" });
    }
    
    res.json(updatedType);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/yarn-types/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const success = await storage.deleteFabricYarnType(id);
    if (!success) {
      return res.status(404).json({ error: "Yarn type not found" });
    }
    
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

// Yarn Counts
settingsRouter.get('/yarn-counts', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    const result = await storage.listYarnCounts(page, limit, activeOnly);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/yarn-counts', async (req, res, next) => {
  try {
    const validation = yarnCountSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const newCount = await storage.createYarnCount(validation.data as InsertYarnCount);
    res.status(201).json(newCount);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/yarn-counts/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const count = await storage.getYarnCount(id);
    if (!count) {
      return res.status(404).json({ error: "Yarn count not found" });
    }
    
    res.json(count);
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/yarn-counts/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const partialSchema = yarnCountSchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const updatedCount = await storage.updateYarnCount(id, validation.data as Partial<InsertYarnCount>);
    if (!updatedCount) {
      return res.status(404).json({ error: "Yarn count not found" });
    }
    
    res.json(updatedCount);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/yarn-counts/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const success = await storage.deleteYarnCount(id);
    if (!success) {
      return res.status(404).json({ error: "Yarn count not found" });
    }
    
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

// Yarn Prices
settingsRouter.get('/yarn-prices', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    const result = await storage.listYarnPrices(page, limit, activeOnly);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/yarn-prices', async (req, res, next) => {
  try {
    const validation = yarnPriceSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const newPrice = await storage.createYarnPrice(validation.data as InsertYarnPrice);
    res.status(201).json(newPrice);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/yarn-prices/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const price = await storage.getYarnPrice(id);
    if (!price) {
      return res.status(404).json({ error: "Yarn price not found" });
    }
    
    res.json(price);
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/yarn-prices/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const partialSchema = yarnPriceSchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const updatedPrice = await storage.updateYarnPrice(id, validation.data as Partial<InsertYarnPrice>);
    if (!updatedPrice) {
      return res.status(404).json({ error: "Yarn price not found" });
    }
    
    res.json(updatedPrice);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/yarn-prices/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const success = await storage.deleteYarnPrice(id);
    if (!success) {
      return res.status(404).json({ error: "Yarn price not found" });
    }
    
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

// Profit Margins
settingsRouter.get('/profit-margins', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    const result = await storage.listProfitMargins(page, limit, activeOnly);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/profit-margins', async (req, res, next) => {
  try {
    const validation = profitMarginSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const newMargin = await storage.createProfitMargin(validation.data as InsertProfitMargin);
    res.status(201).json(newMargin);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/profit-margins/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const margin = await storage.getProfitMargin(id);
    if (!margin) {
      return res.status(404).json({ error: "Profit margin not found" });
    }
    
    res.json(margin);
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/profit-margins/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const partialSchema = profitMarginSchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    const updatedMargin = await storage.updateProfitMargin(id, validation.data as Partial<InsertProfitMargin>);
    if (!updatedMargin) {
      return res.status(404).json({ error: "Profit margin not found" });
    }
    
    res.json(updatedMargin);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/profit-margins/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const success = await storage.deleteProfitMargin(id);
    if (!success) {
      return res.status(404).json({ error: "Profit margin not found" });
    }
    
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

// Overhead Percentages
// Define schema for validation
const overheadPercentSchema = z.object({
  productionUnit: z.string().min(1, "Production unit is required"),
  itemName: z.string().min(1, "Item name is required"),
  overHeadPercent: z.number().nonnegative(),
  description: z.string().optional(),
  is_active: z.boolean().default(true)
});

settingsRouter.get('/overhead-percents', async (req, res, next) => {
  try {
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const activeOnly = req.query.activeOnly === 'true';
    
    // If we had a dedicated storage method, we would use it
    // For now, returning a mock response to match client expectations
    const overheadPercents = [
      {
        id: 1,
        productionUnit: 'Jacquard Unit',
        itemName: 'Jacquard Elastic',
        overHeadPercent: 15,
        description: 'Standard overhead for jacquard production',
        is_active: true,
        created_at: new Date().toISOString()
      }
    ];
    
    res.json({ overheadPercents, total: overheadPercents.length });
  } catch (error) {
    next(error);
  }
});

settingsRouter.post('/overhead-percents', async (req, res, next) => {
  try {
    const validation = overheadPercentSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    // If we had a dedicated storage method, we would use it
    // For now, creating a mock response
    const newOverhead = {
      id: Date.now(),
      ...validation.data,
      created_at: new Date().toISOString()
    };
    
    res.status(201).json(newOverhead);
  } catch (error) {
    next(error);
  }
});

settingsRouter.get('/overhead-percents/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    // Mock response for now
    if (id === 1) {
      const overhead = {
        id: 1,
        productionUnit: 'Jacquard Unit',
        itemName: 'Jacquard Elastic',
        overHeadPercent: 15,
        description: 'Standard overhead for jacquard production',
        is_active: true,
        created_at: new Date().toISOString()
      };
      return res.json(overhead);
    }
    
    return res.status(404).json({ error: "Overhead percentage not found" });
  } catch (error) {
    next(error);
  }
});

settingsRouter.patch('/overhead-percents/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    const partialSchema = overheadPercentSchema.partial();
    const validation = partialSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: validation.error.format() });
    }
    
    // Mock response for now
    const updatedOverhead = {
      id,
      productionUnit: validation.data.productionUnit || 'Jacquard Unit',
      itemName: validation.data.itemName || 'Jacquard Elastic',
      overHeadPercent: validation.data.overHeadPercent || 15,
      description: validation.data.description || 'Standard overhead for jacquard production',
      is_active: validation.data.is_active !== undefined ? validation.data.is_active : true,
      created_at: new Date().toISOString()
    };
    
    res.json(updatedOverhead);
  } catch (error) {
    next(error);
  }
});

settingsRouter.delete('/overhead-percents/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    
    // Just return success for any ID for now
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});