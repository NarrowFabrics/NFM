import { Router } from 'express';
import { settingsRouter } from './settings';
import { backupRouter } from './backup';
import { quotationsRouter } from './quotations';
import { systemRouter } from './system';
// Removed Google Drive integrations

export const apiRouter = Router();

// Register all routes under /api
apiRouter.use('/settings', settingsRouter);
apiRouter.use('/backup', backupRouter);
apiRouter.use('/quotations', quotationsRouter);
apiRouter.use('/system', systemRouter);

// Expose items data endpoint directly at the root
apiRouter.get('/items', async (req, res, next) => {
  try {
    // Get production unit from query parameter for filtering
    const productionUnit = req.query.productionUnit as string;
    
    // Base items data structure
    const allItems = [
      {
        id: 1,
        name: 'Jacquard Elastic',
        unit: 'Yards',
        productionUnit: 'Jacquard Loom',
        description: 'Jacquard elastic with customizable patterns',
        is_active: true,
        created_at: new Date().toISOString()
      },
      {
        id: 2,
        name: 'Needle Loom Elastic',
        unit: 'Yards',
        productionUnit: 'Needle Loom',
        description: 'Needle loom elastic with high durability',
        is_active: true,
        created_at: new Date().toISOString()
      },
      {
        id: 3,
        name: 'Hook Elastic',
        unit: 'Yards',
        productionUnit: 'Crochet Machine',
        description: 'Hook elastic for specialized applications',
        is_active: true,
        created_at: new Date().toISOString()
      },
      {
        id: 4,
        name: 'Drawstring',
        unit: 'Yards',
        productionUnit: 'Drawstring Machine',
        description: 'Drawstring for apparel',
        is_active: true,
        created_at: new Date().toISOString()
      },
      {
        id: 5,
        name: 'Printed Elastic',
        unit: 'Yards',
        productionUnit: 'Screen Print',
        description: 'Screen printed elastic',
        is_active: true,
        created_at: new Date().toISOString()
      },
      {
        id: 6,
        name: 'Embossed Elastic',
        unit: 'Yards',
        productionUnit: 'Embossed/Heat Print',
        description: 'Embossed elastic with custom patterns',
        is_active: true,
        created_at: new Date().toISOString()
      }
    ];
    
    // Filter items by production unit if specified
    let items = allItems;
    if (productionUnit) {
      items = allItems.filter(item => item.productionUnit === productionUnit);
    }
    
    res.json({ items });
  } catch (error) {
    next(error);
  }
});

// Add more routes as needed
// apiRouter.use('/users', usersRouter);
// apiRouter.use('/auth', authRouter);