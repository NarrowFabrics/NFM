import { Router } from 'express';
import { 
  getAuthUrl, 
  getTokens, 
  createDriveClient,
  listFiles
} from '../lib/drive-service';

const router = Router();

// Trigger Google OAuth2 flow
router.get('/auth/google', (req, res) => {
  console.log('Starting Google auth flow...');
  const authUrl = getAuthUrl();
  console.log('Generated auth URL:', authUrl);
  res.redirect(authUrl);
});

// Handle OAuth2 callback
router.get('/auth/google/callback', async (req, res) => {
  try {
    const code = req.query.code as string;
    if (!code) {
      return res.status(400).json({ message: 'Authorization code is missing' });
    }
    
    // Exchange code for tokens
    const tokens = await getTokens(code);
    
    // Store tokens in session
    req.session.driveTokens = tokens;

    // Log successful authentication
    req.session.driveAuthenticated = true;
    console.log('User authenticated with Google Drive');
    
    // Redirect to a success page
    res.redirect('/settings/backup-restore-settings?auth=success');
  } catch (error) {
    console.error('Error in Google callback:', error);
    res.redirect('/settings/backup-restore-settings?auth=error');
  }
});

// Check if user is authenticated with Google Drive
router.get('/drive/status', (req, res) => {
  const isAuthenticated = !!req.session.driveAuthenticated;
  res.json({ authenticated: isAuthenticated });
});

// Logout from Google Drive 
router.get('/drive/logout', (req, res) => {
  delete req.session.driveTokens;
  delete req.session.driveAuthenticated;
  res.json({ message: 'Successfully logged out from Google Drive' });
});

export const driveAuthRouter = router;