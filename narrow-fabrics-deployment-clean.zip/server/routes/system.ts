import { Router } from 'express';
import { storage } from '../storage';
import { isAuthenticated } from '../middlewares/auth';

export const systemRouter = Router();

// Public health-check endpoint (no authentication required)
systemRouter.get('/health', (req, res) => {
  const startTime = process.hrtime();
  
  res.status(200).json({
    status: 'ok',
    time: new Date().toISOString(),
    uptime: process.uptime(),
    responseTime: process.hrtime(startTime)[1] / 1000000, // Convert to milliseconds
  });
});

// Get latest system metrics summary
systemRouter.get('/metrics/summary', isAuthenticated, async (req, res) => {
  try {
    const metrics = await storage.getSystemMetricsSummary();
    res.json(metrics);
  } catch (error) {
    console.error('Error fetching system metrics summary:', error);
    res.status(500).json({ error: 'Failed to fetch system metrics summary' });
  }
});

// Get system metrics with time range filter
systemRouter.get('/metrics', isAuthenticated, async (req, res) => {
  try {
    const timeRange = req.query.timeRange as 'hour' | 'day' | 'week' | 'month' || 'hour';
    const limit = parseInt(req.query.limit as string || '60', 10);
    
    const metrics = await storage.getSystemMetrics(timeRange, limit);
    
    res.json({
      timeRange,
      limit,
      count: metrics.length,
      metrics
    });
  } catch (error) {
    console.error('Error fetching system metrics:', error);
    res.status(500).json({ error: 'Failed to fetch system metrics' });
  }
});

// Trigger metrics collection (admin only)
systemRouter.post('/metrics/collect', isAuthenticated, async (req, res) => {
  try {
    // Check if user has admin privileges (user.role === 'admin')
    if (req.user?.role !== 'admin') {
      return res.status(403).json({ error: 'Only administrators can trigger metrics collection' });
    }
    
    const metrics = await storage.collectSystemMetrics();
    res.status(201).json({
      message: 'System metrics collected successfully',
      metrics
    });
  } catch (error) {
    console.error('Error collecting system metrics:', error);
    res.status(500).json({ error: 'Failed to collect system metrics' });
  }
});

// Endpoint to manually publish scheduled notices
systemRouter.post('/notices/publish-scheduled', isAuthenticated, async (req, res) => {
  try {
    // Check if user has admin privileges
    if (req.user?.role !== 'admin') {
      return res.status(403).json({ error: 'Only administrators can trigger notice publishing' });
    }
    
    const result = await storage.publishScheduledNotices();
    
    res.status(200).json({
      message: `Published ${result.published} scheduled notices`,
      publishedNotices: result.notices
    });
  } catch (error) {
    console.error('Error publishing scheduled notices:', error);
    res.status(500).json({ error: 'Failed to publish scheduled notices' });
  }
});