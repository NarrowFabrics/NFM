import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import * as backupService from '../lib/backup-service';
import { db } from '../db';
import { backups, backupSchedules, backupNotifications, backupVersions } from '../../shared/schema';
import { storage } from '../storage';
import { eq } from 'drizzle-orm';

export const backupRouter = Router();

// Create upload middleware with memory storage for processing
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB max file size
  }
});

// Ensure backup directory exists
const backupDir = path.join(process.cwd(), 'backups');
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
}

// Admin middleware
const ensureAdmin = (req: any, res: any, next: any) => {
  if (req.isAuthenticated() && req.user.is_admin) {
    return next();
  }
  res.status(403).json({ message: "Admin privileges required" });
};

// Get all backups
backupRouter.get('/', ensureAdmin, async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const offset = (page - 1) * limit;
    
    const backupList = await db.select().from(backups)
      .orderBy({ created_at: 'desc' })
      .limit(limit)
      .offset(offset);
    
    const totalCount = await db.select({ count: db.fn.count() }).from(backups);
    
    res.json({
      backups: backupList,
      total: Number(totalCount[0].count),
      page,
      pages: Math.ceil(Number(totalCount[0].count) / limit)
    });
  } catch (error) {
    res.status(500).json({ message: "Error retrieving backups", error: error.message });
  }
});

// Create a new backup
backupRouter.post('/', ensureAdmin, async (req, res) => {
  try {
    const {
      description,
      backupType = 'full',
      isEncrypted = false,
      isCompressed = true,
      encryptionKey,
      tablesToInclude,
      retentionPeriod
    } = req.body;

    // Validate backup type
    if (!['full', 'differential', 'partial'].includes(backupType)) {
      return res.status(400).json({ message: "Invalid backup type" });
    }

    // If encrypted, ensure encryption key is provided
    if (isEncrypted && !encryptionKey) {
      return res.status(400).json({ message: "Encryption key is required for encrypted backups" });
    }

    // If partial backup, ensure tables are specified
    if (backupType === 'partial' && (!tablesToInclude || !Array.isArray(tablesToInclude) || tablesToInclude.length === 0)) {
      return res.status(400).json({ message: "Tables must be specified for partial backups" });
    }

    // Create the backup
    const result = await backupService.createBackup({
      description,
      backupType: backupType as 'full' | 'differential' | 'partial',
      isEncrypted,
      isCompressed,
      encryptionKey,
      tablesToInclude,
      userId: req.user.id,
      retentionPeriod: retentionPeriod ? parseInt(retentionPeriod) : undefined,
      isAuto: false
    });

    // Return backup metadata
    res.status(201).json({
      success: true,
      message: "Backup created successfully",
      backup: {
        filename: result.filename,
        size: result.size
      }
    });
  } catch (error) {
    res.status(500).json({ message: "Error creating backup", error: error.message });
  }
});

// Download a backup file
backupRouter.get('/:id/download', ensureAdmin, async (req, res) => {
  try {
    const backupId = parseInt(req.params.id);
    const backup = await db.select().from(backups).where(eq(backups.id, backupId)).limit(1);
    
    if (backup.length === 0) {
      return res.status(404).json({ message: "Backup not found" });
    }
    
    const backupFile = backup[0];
    
    // Check if file exists
    if (!fs.existsSync(backupFile.storage_path)) {
      return res.status(404).json({ message: "Backup file not found on server" });
    }
    
    // Set appropriate headers
    res.setHeader('Content-Disposition', `attachment; filename=${backupFile.filename}`);
    res.setHeader('Content-Type', 'application/json');
    
    // Stream the file to the response
    const fileStream = fs.createReadStream(backupFile.storage_path);
    fileStream.pipe(res);
    
    // Log activity
    storage.createUserActivity(req.user.id, "Downloaded backup", { backupId, filename: backupFile.filename });
  } catch (error) {
    res.status(500).json({ message: "Error downloading backup", error: error.message });
  }
});

// Restore from a backup file
backupRouter.post('/restore', ensureAdmin, upload.single('backupFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No backup file uploaded" });
    }

    // Create a temporary file to store the uploaded backup
    const filename = `temp-restore-${Date.now()}.json`;
    const tempFilePath = path.join(backupDir, filename);
    
    try {
      // Write the uploaded file to disk
      fs.writeFileSync(tempFilePath, req.file.buffer);
      
      // Optional decryption key if provided
      const encryptionKey = req.body.encryptionKey;
      
      // Optional specific tables to restore
      const tablesToRestore = req.body.tablesToRestore 
        ? Array.isArray(req.body.tablesToRestore) 
          ? req.body.tablesToRestore 
          : JSON.parse(req.body.tablesToRestore)
        : undefined;
      
      // Restore from the backup
      await backupService.restoreFromBackup(tempFilePath, req.user.id, {
        encryptionKey,
        tablesToRestore
      });
      
      // Clean up temporary file
      fs.unlinkSync(tempFilePath);
      
      res.json({
        success: true,
        message: "Database restored successfully",
        filename: req.file.originalname
      });
    } catch (error) {
      // Clean up temporary file in case of error
      if (fs.existsSync(tempFilePath)) {
        fs.unlinkSync(tempFilePath);
      }
      throw error;
    }
  } catch (error) {
    res.status(500).json({ message: "Error restoring from backup", error: error.message });
  }
});

// Delete a backup
backupRouter.delete('/:id', ensureAdmin, async (req, res) => {
  try {
    const backupId = parseInt(req.params.id);
    const backup = await db.select().from(backups).where(eq(backups.id, backupId)).limit(1);
    
    if (backup.length === 0) {
      return res.status(404).json({ message: "Backup not found" });
    }
    
    const backupFile = backup[0];
    
    // Delete the file if it exists
    if (fs.existsSync(backupFile.storage_path)) {
      fs.unlinkSync(backupFile.storage_path);
    }
    
    // Delete the database record
    await db.delete(backups).where(eq(backups.id, backupId));
    
    // Log activity
    storage.createUserActivity(req.user.id, "Deleted backup", { backupId, filename: backupFile.filename });
    
    res.json({ success: true, message: "Backup deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting backup", error: error.message });
  }
});

/* BACKUP SCHEDULES */

// Get all backup schedules
backupRouter.get('/schedules', ensureAdmin, async (req, res) => {
  try {
    const schedules = await db.select().from(backupSchedules);
    res.json(schedules);
  } catch (error) {
    res.status(500).json({ message: "Error retrieving backup schedules", error: error.message });
  }
});

// Create a new backup schedule
backupRouter.post('/schedules', ensureAdmin, async (req, res) => {
  try {
    const {
      name,
      description,
      frequency,
      dayOfWeek,
      dayOfMonth,
      timeOfDay,
      backupType,
      tablesToInclude,
      isEncrypted,
      isCompressed,
      retentionPeriod
    } = req.body;
    
    // Validate required fields
    if (!name || !frequency || !timeOfDay || !backupType || !retentionPeriod) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    
    // Validate frequency
    if (!['daily', 'weekly', 'monthly'].includes(frequency)) {
      return res.status(400).json({ message: "Invalid frequency" });
    }
    
    // Validate backup type
    if (!['full', 'differential', 'partial'].includes(backupType)) {
      return res.status(400).json({ message: "Invalid backup type" });
    }
    
    // If weekly, ensure day of week is valid
    if (frequency === 'weekly' && (dayOfWeek === undefined || dayOfWeek < 0 || dayOfWeek > 6)) {
      return res.status(400).json({ message: "Day of week must be between 0-6 for weekly schedules" });
    }
    
    // If monthly, ensure day of month is valid
    if (frequency === 'monthly' && (dayOfMonth === undefined || dayOfMonth < 1 || dayOfMonth > 31)) {
      return res.status(400).json({ message: "Day of month must be between 1-31 for monthly schedules" });
    }
    
    // Calculate initial next run time
    const now = new Date();
    let nextRun: Date;
    
    // Parse time of day
    const [hours, minutes] = timeOfDay.split(':').map(Number);
    
    switch (frequency) {
      case 'daily':
        nextRun = new Date(now);
        nextRun.setHours(hours, minutes, 0, 0);
        if (nextRun <= now) {
          nextRun.setDate(nextRun.getDate() + 1);
        }
        break;
      case 'weekly':
        nextRun = new Date(now);
        nextRun.setHours(hours, minutes, 0, 0);
        const dayDiff = (dayOfWeek - now.getDay() + 7) % 7;
        nextRun.setDate(nextRun.getDate() + (dayDiff === 0 && nextRun <= now ? 7 : dayDiff));
        break;
      case 'monthly':
        nextRun = new Date(now);
        nextRun.setDate(dayOfMonth);
        nextRun.setHours(hours, minutes, 0, 0);
        if (nextRun <= now || nextRun.getDate() !== dayOfMonth) {
          nextRun.setMonth(nextRun.getMonth() + 1);
          nextRun.setDate(dayOfMonth);
        }
        break;
    }
    
    // Create the schedule
    const scheduleRecord = await db.insert(backupSchedules).values({
      name,
      description,
      frequency,
      day_of_week: frequency === 'weekly' ? dayOfWeek : null,
      day_of_month: frequency === 'monthly' ? dayOfMonth : null,
      time_of_day: timeOfDay,
      backup_type: backupType,
      tables_to_include: tablesToInclude,
      is_encrypted: isEncrypted || false,
      is_compressed: isCompressed || true,
      retention_period: parseInt(retentionPeriod),
      created_by: req.user.id,
      next_run: nextRun
    }).returning();
    
    // Log activity
    storage.createUserActivity(req.user.id, "Created backup schedule", { name, frequency, backupType });
    
    res.status(201).json({
      success: true,
      message: "Backup schedule created successfully",
      schedule: scheduleRecord[0]
    });
  } catch (error) {
    res.status(500).json({ message: "Error creating backup schedule", error: error.message });
  }
});

// Update a backup schedule
backupRouter.put('/schedules/:id', ensureAdmin, async (req, res) => {
  try {
    const scheduleId = parseInt(req.params.id);
    const {
      name,
      description,
      frequency,
      dayOfWeek,
      dayOfMonth,
      timeOfDay,
      backupType,
      tablesToInclude,
      isEncrypted,
      isCompressed,
      retentionPeriod,
      isActive
    } = req.body;
    
    // Validate that the schedule exists
    const existingSchedule = await db.select().from(backupSchedules).where(eq(backupSchedules.id, scheduleId));
    if (existingSchedule.length === 0) {
      return res.status(404).json({ message: "Backup schedule not found" });
    }
    
    // Prepare update data
    const updateData: any = {};
    
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (frequency !== undefined) updateData.frequency = frequency;
    if (dayOfWeek !== undefined && frequency === 'weekly') updateData.day_of_week = dayOfWeek;
    if (dayOfMonth !== undefined && frequency === 'monthly') updateData.day_of_month = dayOfMonth;
    if (timeOfDay !== undefined) updateData.time_of_day = timeOfDay;
    if (backupType !== undefined) updateData.backup_type = backupType;
    if (tablesToInclude !== undefined) updateData.tables_to_include = tablesToInclude;
    if (isEncrypted !== undefined) updateData.is_encrypted = isEncrypted;
    if (isCompressed !== undefined) updateData.is_compressed = isCompressed;
    if (retentionPeriod !== undefined) updateData.retention_period = parseInt(retentionPeriod);
    if (isActive !== undefined) updateData.is_active = isActive;
    
    // Recalculate next run if schedule parameters changed
    if (frequency !== undefined || dayOfWeek !== undefined || dayOfMonth !== undefined || timeOfDay !== undefined || isActive !== undefined) {
      // Use the updated values or fall back to existing values
      const updatedFrequency = frequency || existingSchedule[0].frequency;
      const updatedDayOfWeek = dayOfWeek !== undefined ? dayOfWeek : existingSchedule[0].day_of_week;
      const updatedDayOfMonth = dayOfMonth !== undefined ? dayOfMonth : existingSchedule[0].day_of_month;
      const updatedTimeOfDay = timeOfDay || existingSchedule[0].time_of_day;
      
      const now = new Date();
      let nextRun: Date;
      
      // Parse time of day
      const [hours, minutes] = updatedTimeOfDay.split(':').map(Number);
      
      switch (updatedFrequency) {
        case 'daily':
          nextRun = new Date(now);
          nextRun.setHours(hours, minutes, 0, 0);
          if (nextRun <= now) {
            nextRun.setDate(nextRun.getDate() + 1);
          }
          break;
        case 'weekly':
          nextRun = new Date(now);
          nextRun.setHours(hours, minutes, 0, 0);
          const dayDiff = (updatedDayOfWeek - now.getDay() + 7) % 7;
          nextRun.setDate(nextRun.getDate() + (dayDiff === 0 && nextRun <= now ? 7 : dayDiff));
          break;
        case 'monthly':
          nextRun = new Date(now);
          nextRun.setDate(updatedDayOfMonth);
          nextRun.setHours(hours, minutes, 0, 0);
          if (nextRun <= now || nextRun.getDate() !== updatedDayOfMonth) {
            nextRun.setMonth(nextRun.getMonth() + 1);
            nextRun.setDate(updatedDayOfMonth);
          }
          break;
      }
      
      updateData.next_run = nextRun;
    }
    
    // Update the schedule
    const updatedSchedule = await db.update(backupSchedules)
      .set(updateData)
      .where(eq(backupSchedules.id, scheduleId))
      .returning();
    
    // Log activity
    storage.createUserActivity(req.user.id, "Updated backup schedule", { scheduleId, name: updateData.name || existingSchedule[0].name });
    
    res.json({
      success: true,
      message: "Backup schedule updated successfully",
      schedule: updatedSchedule[0]
    });
  } catch (error) {
    res.status(500).json({ message: "Error updating backup schedule", error: error.message });
  }
});

// Delete a backup schedule
backupRouter.delete('/schedules/:id', ensureAdmin, async (req, res) => {
  try {
    const scheduleId = parseInt(req.params.id);
    
    // Check if the schedule exists
    const existingSchedule = await db.select().from(backupSchedules).where(eq(backupSchedules.id, scheduleId));
    if (existingSchedule.length === 0) {
      return res.status(404).json({ message: "Backup schedule not found" });
    }
    
    // Delete the schedule
    await db.delete(backupSchedules).where(eq(backupSchedules.id, scheduleId));
    
    // Log activity
    storage.createUserActivity(req.user.id, "Deleted backup schedule", { scheduleId, name: existingSchedule[0].name });
    
    res.json({ success: true, message: "Backup schedule deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting backup schedule", error: error.message });
  }
});

/* BACKUP NOTIFICATIONS */

// Get notification settings for user
backupRouter.get('/notifications', ensureAdmin, async (req, res) => {
  try {
    // Get or create notification settings for the user
    let notificationSettings = await db.select().from(backupNotifications).where(eq(backupNotifications.user_id, req.user.id));
    
    if (notificationSettings.length === 0) {
      // Create default notification settings for the user
      notificationSettings = await db.insert(backupNotifications).values({
        user_id: req.user.id,
        email_notification: false,
        push_notification: false,
        notify_on_success: true,
        notify_on_failure: true
      }).returning();
    }
    
    res.json(notificationSettings[0]);
  } catch (error) {
    res.status(500).json({ message: "Error retrieving notification settings", error: error.message });
  }
});

// Update notification settings
backupRouter.put('/notifications', ensureAdmin, async (req, res) => {
  try {
    const {
      emailNotification,
      pushNotification,
      notifyOnSuccess,
      notifyOnFailure
    } = req.body;
    
    // Get or create notification settings for the user
    let notificationSettings = await db.select().from(backupNotifications).where(eq(backupNotifications.user_id, req.user.id));
    
    if (notificationSettings.length === 0) {
      // Create new notification settings
      notificationSettings = await db.insert(backupNotifications).values({
        user_id: req.user.id,
        email_notification: emailNotification !== undefined ? emailNotification : false,
        push_notification: pushNotification !== undefined ? pushNotification : false,
        notify_on_success: notifyOnSuccess !== undefined ? notifyOnSuccess : true,
        notify_on_failure: notifyOnFailure !== undefined ? notifyOnFailure : true
      }).returning();
    } else {
      // Update existing notification settings
      const updateData: any = {};
      
      if (emailNotification !== undefined) updateData.email_notification = emailNotification;
      if (pushNotification !== undefined) updateData.push_notification = pushNotification;
      if (notifyOnSuccess !== undefined) updateData.notify_on_success = notifyOnSuccess;
      if (notifyOnFailure !== undefined) updateData.notify_on_failure = notifyOnFailure;
      
      notificationSettings = await db.update(backupNotifications)
        .set(updateData)
        .where(eq(backupNotifications.user_id, req.user.id))
        .returning();
    }
    
    res.json({
      success: true,
      message: "Notification settings updated successfully",
      settings: notificationSettings[0]
    });
  } catch (error) {
    res.status(500).json({ message: "Error updating notification settings", error: error.message });
  }
});

/* BACKUP VERSIONS */

// Get all versions of a backup
backupRouter.get('/:id/versions', ensureAdmin, async (req, res) => {
  try {
    const backupId = parseInt(req.params.id);
    
    // Check if the backup exists
    const backup = await db.select().from(backups).where(eq(backups.id, backupId));
    if (backup.length === 0) {
      return res.status(404).json({ message: "Backup not found" });
    }
    
    // Get all versions
    const versions = await db.select().from(backupVersions).where(eq(backupVersions.backup_id, backupId));
    
    res.json(versions);
  } catch (error) {
    res.status(500).json({ message: "Error retrieving backup versions", error: error.message });
  }
});

// Create a new version of a backup
backupRouter.post('/:id/versions', ensureAdmin, async (req, res) => {
  try {
    const backupId = parseInt(req.params.id);
    const { versionNumber, changesDescription } = req.body;
    
    // Validate required fields
    if (!versionNumber) {
      return res.status(400).json({ message: "Version number is required" });
    }
    
    // Check if the backup exists
    const backup = await db.select().from(backups).where(eq(backups.id, backupId));
    if (backup.length === 0) {
      return res.status(404).json({ message: "Backup not found" });
    }
    
    // Create a new version
    const version = await db.insert(backupVersions).values({
      backup_id: backupId,
      version_number: versionNumber,
      changes_description: changesDescription
    }).returning();
    
    res.status(201).json({
      success: true,
      message: "Backup version created successfully",
      version: version[0]
    });
  } catch (error) {
    res.status(500).json({ message: "Error creating backup version", error: error.message });
  }
});