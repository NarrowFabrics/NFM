import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import dotenv from 'dotenv';
import path from 'path';
import { Server } from 'http';

// TypeScript declaration for global server instance
declare global {
  var serverInstance: Server | undefined;
}

// Load environment variables from .env file
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

// Debug environment variables on startup
console.log("=== Environment Variables ===");
console.log("USE_NEON_DB:", process.env.USE_NEON_DB);
console.log("NEON_DATABASE_URL exists:", !!process.env.NEON_DATABASE_URL);
console.log("DATABASE_URL exists:", !!process.env.DATABASE_URL);
console.log("Working directory:", process.cwd());

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    log(`${req.method} ${req.originalUrl} ${res.statusCode} ${duration}ms`);
  });
  next();
});

(async () => {
  // Google Drive service initialization temporarily disabled
  // initDriveService();
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Get port configuration from environment variables or use defaults
  // This serves both the API and the client
  // For Render.com, we need to use the PORT environment variable
  const port = process.env.PORT || 5000;
  log(`Using port: ${port}`);
  
  // Close any previous server instances before creating a new one
  if (global.serverInstance) {
    try {
      global.serverInstance.close();
    } catch (e) {
      // Ignore errors from closing
    }
  }
  
  function tryListening() {
    const serverInstance = server.listen({
      port,
      host: "0.0.0.0",
      reusePort: false, // Changed to false to prevent port sharing
    });
    
    // Store server instance globally
    global.serverInstance = serverInstance;
    
    serverInstance.on('error', (err) => {
      // For any errors, log them
      log(`Error starting server: ${err.message}`);
      process.exit(1);
    });
    
    serverInstance.on('listening', () => {
      log(`Server running on port ${port}`);
    });
  }
  
  tryListening();
})();
